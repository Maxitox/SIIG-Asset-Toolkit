# SIIG Blender Add-on 0.3.0

This add-on imports extracted SIIG `.gmx` models through the same verified GMX → glTF exporter shipped in `siig_toolkit.py`. It also imports toolkit-generated assembled `.gltf`/`.glb` scenes, organizes logical SIIG components into hideable Blender collections, and provides an optional **SIIG Style Preview**. It does not contain game assets and does not contact the network.

## Install

1. In Blender, open **Edit → Preferences → Add-ons**.
2. Choose **Install from Disk** and select `addons/SIIG_Blender_Addon_v0.3.0.zip`.
3. Enable **SIIG Asset Toolkit**.
4. Open the add-on preferences and select the folder containing `siig_toolkit.py`.

## Import and assembly controls

- **File → Import → Space Invaders Infinity Gene (.gmx)** imports one or several raw GMX files.
- **File → Import → SIIG Assembled Model (.gltf/.glb)** imports a Boss/Entity Assembler result.
- The **SIIG** sidebar exposes **Organize SIIG Part Collections** for an assembly imported previously with Blender's normal glTF importer.
- Hide/show a generated `SIIG_PART_*` collection in the Outliner to toggle one logical game part, including its native solid/face (`_F`) and outline/edge (`_E`) objects.
- Recursive raw-GMX folder import, optional V flip, and an external texture root remain available.

## SIIG Style Preview

The preview is deliberately host-side and non-destructive. It does not rewrite GMX, textures, animations or the game renderer.

### Native white outlines

SIIG's GMX exporter preserves the native `_E` line pass, but Blender does not render bare mesh edges as ordinary final-render geometry. Add-on 0.3.0 can therefore build thin white emissive **curve copies** from those native `_E` edges. The original edge meshes remain untouched.

- Toggle **White native outlines** in the SIIG sidebar.
- **Outline thickness (%)** scales the curve radius relative to each native outline object's local bounds.
- **Apply / Refresh SIIG Style Preview** rebuilds only the generated preview curves.
- **Remove SIIG Style Preview** deletes the generated curves and leaves the imported model unchanged.

### Post-process scanlines

Scanlines are applied after the existing compositor image source rather than being inserted into every material. The add-on creates a one-pixel-wide horizontal pattern, scales it to the render dimensions with Blender's compositor Scale node, and multiplies it over the final image.

- Toggle **Post-process scanlines**.
- Adjust spacing, thickness and strength in the SIIG sidebar.
- If render resolution changes, press **Apply / Refresh SIIG Style Preview** so pixel spacing is regenerated for the new output height.
- Removing the preview restores the compositor image link that existed before the SIIG overlay was inserted.

**Auto-apply SIIG Style Preview after import** is enabled by default and can be disabled in the same panel or Add-on Preferences.

## Fidelity boundary

The outline source geometry is native SIIG `_E` data, but Blender curve radius is a host presentation choice. The scanline overlay is also a Blender post-process approximation. Neither feature is presented as an exact reconstruction of Xenos/RSX rasterization, native line width, antialiasing, scanout or final-composite behavior.

Blender 3.6 or newer remains the supported baseline. Source syntax, packaging, metadata/grouping contracts, style-preview source contracts and exporter integration are regression-tested outside Blender. Final visual appearance and UI/operator behavior still require an actual Blender runtime check.
