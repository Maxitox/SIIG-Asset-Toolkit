# Mod workspace workflow

`2.9.0-dev2` extends the mod-workspace project layer above the native asset builders. The goal is to remove manual BBX path surgery from ordinary modding experiments while keeping the original rip immutable.

## 1. Create a workspace

Start from a clean `rip-game` output:

```text
python siig_toolkit.py mod-init SIIG_Ripped -o My_SIIG_Mod --name "My SIIG Mod"
```

The workspace stores the source-rip path and a baseline SHA-256 for every top-level BBX archive. The game assets themselves remain in the user's rip; the toolkit release does not bundle them.

Use `mod-list` to discover stable archive/resource keys:

```text
python siig_toolkit.py mod-list My_SIIG_Mod
python siig_toolkit.py mod-list My_SIIG_Mod --archive <archive-key>
```

If the rip is moved later, pass `--rip <new-path>` to workspace commands.

## 2. Export an editable resource

For a supported native resource inside a BBX:

```text
python siig_toolkit.py mod-export My_SIIG_Mod <archive-key> <resource-path>
```

The command chooses the proven round-trip representation automatically:

- GMX -> fixed-layout edit JSON
- TEX -> PNG
- system-font CRP -> PNG
- DAT -> CSV
- MAP -> editable JSON plus previews
- ANM -> CSV
- COL -> PNG
- Bmap/Xmap/map4/map5 -> stage3D editable JSON
- wall/Xwall/stage_generate -> stagewall editable JSON

Edit the file under `editable/`. `mod-build` notices when the canonical editable file differs from its export baseline, compiles it back to the native format, and stages it automatically.

## 3. Edit whole localization archives

`text.bin` and `message.bin` are BBX archives whose human-editable representation describes the whole archive. Use:

```text
python siig_toolkit.py mod-export-archive My_SIIG_Mod <text-archive-key>
python siig_toolkit.py mod-export-archive My_SIIG_Mod <message-archive-key>
```

For `text.bin`, edit `text_strings.csv`. For `message.bin`, edit the six `message_<language>_readable.nut` files. The build step recompiles the complete native localization BBX when any tracked file changes.

## 4. Stage an already-native replacement

If a format is not integrated into `mod-export`, or another tool produced the native file, stage it directly:

```text
python siig_toolkit.py mod-stage My_SIIG_Mod <archive-key> <resource-path> replacement.bin
```

A complete rebuilt BBX can be staged with:

```text
python siig_toolkit.py mod-stage-archive My_SIIG_Mod <archive-key> rebuilt_archive.bin
```

## Integrated glTF model + texture import (2.9.0-dev2)

For a GMX already present in the source rip, the workspace can now compile an edited glTF and stage its linked native texture payloads in one operation:

```text
python siig_toolkit.py mod-import-gltf My_SIIG_Mod <archive-key> <model.gmx> edited.gltf
```

The command enables the GMX texture/scene/mesh synchronization stack, stages the rebuilt GMX, follows material `baseColorTexture` PNGs, and rebuilds them through the existing native TEX encoder. If the TXIF still names an existing TEX, that resource is replaced. If the edited glTF allocates a genuinely new TXIF filename, the workspace appends a new named BBX resource using a compatible donor TEX layout.

New TEX payloads still require a compatible existing native TEX template. Dimensions and encoded platform layout are therefore donor-constrained; `2.9.0-dev2` does not invent arbitrary Xenos/RSX texture headers. By default the command fails rather than leaving a new TXIF without a native payload. `--allow-reference-only` exists for research cases where a reference-only GMX is intentional.

Because BBX entry count/name tables change when a member is added, `.siigmod` packaging switches that archive to a baseline-dependent **archive-level delta**. The clean BBX is still not redistributed.

## 5. Build and verify

```text
python siig_toolkit.py mod-build My_SIIG_Mod --clean
python siig_toolkit.py mod-verify My_SIIG_Mod
```

The build writes:

- `build/decompressed_bbx/` — verified rebuilt BBX archives;
- `build/game_patch/` — files placed at the original game-relative path when the outer packaging can be reproduced safely;
- `build/MOD_BUILD_REPORT.json` — exact original/rebuilt hashes, affected resources, package status, and limitations.

For ordinary Xbox `.gz` resources the workspace emits deterministic gzip-wrapped replacements. Raw `.bin` BBX inputs are emitted directly.

## Share a workspace as a baseline-dependent package

Dev24 adds `.siigmod` distribution without bundling clean source resources:

```text
python siig_toolkit.py mod-pack My_SIIG_Mod -o My_Mod.siigmod
python siig_toolkit.py mod-package-info My_Mod.siigmod
python siig_toolkit.py mod-apply My_Mod.siigmod SIIG_Ripped Applied_Mod --build
```

See [`MOD_PACKAGES.md`](MOD_PACKAGES.md) for the delta format, baseline checks, conflict policy, and distribution boundaries.

## Safety and current limits

- The source rip is treated as immutable. A source archive whose SHA-256 changed since `mod-init` is rejected until the workspace is recreated or pointed at the correct rip.
- Every rebuilt BBX is reparsed and verified before it is reported as built.
- `mod-verify` checks source baselines, rebuilt BBX hashes, and gzip payload identity.
- PS3 NPDRM/SDAT **re-encryption is not implemented**. PS3 SDAT-backed changes therefore remain available as rebuilt/decompressed BBX files for research or deployment methods that do not require recreating the signed/encrypted SDAT wrapper.
- A successfully rebuilt native asset or BBX does not automatically prove that every possible edit is accepted by the retail game. Keep changes small and test them in an appropriate emulator/test environment.
- GMX can now synthesize mesh/scene/TXIF graph nodes and integrate texture payloads into the workspace, but arbitrary vertex declarations/material schemas, arbitrary TEX layouts, animation-graph synthesis, platform shader compilation, and fully template-free GMX creation remain open boundaries.

## Retail corpus validation through dev24

The user-supplied retail Xbox corpus was used only as external validation input and is not bundled. Dev23 reproduced all 13 GMXs in `player.bin` byte-for-byte through the GMX editable/rebuild path. Retail `text.bin` (542 strings) and `message.bin` (284 groups, 1295 strings per language) also rebuilt byte-for-byte from their readable edit representations. Dev24 expands the same external validation to 307 GMXs and large retail DAT/MAP/stage-table corpora; see `validation/REAL_CORPUS_ROUNDTRIP_DEV24.json`. No retail payload is bundled.


### 2.9.0-dev2 schema fallback

`mod-import-gltf` now enables native schema synthesis as a fallback. Compatible original MESH/ARRY and MTRL schemas are still reused when present, but a genuinely new Blender mesh/material is no longer rejected solely because no matching donor declaration exists. The remaining texture payload step is still TEX-layout donor constrained.
