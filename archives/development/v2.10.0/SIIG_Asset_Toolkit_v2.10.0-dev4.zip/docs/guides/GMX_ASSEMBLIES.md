# Multi-GMX assemblies (2.10.0-dev4)

Some SIIG runtime objects are assembled from several separate GMX resources. `gmx-assemble` combines explicit GMX instances into one glTF scene without claiming that the separate native files form one on-disc GMX.

## PROGRESSIVE UFO

The built-in catalog now contains the executable-backed first runtime formation:

| model | runtime | local translation | local rotation |
|---|---|---|---|
| `bos_009.gmx` | `0xA2` | `(0, 0, 0)` | `(0, 0, 0)` |
| `bos_009a.gmx` | `0xC2` | `(-90, 0, -10)` | `(0, 0, 0)` |
| `bos_009a.gmx` | `0xC2` | `(90, 0, -10)` | `(0, 0, 0)` |
| `bos_009b.gmx` | `0xC3` | `(-160, 0, -50)` | `(0, 0, 0)` |
| `bos_009b.gmx` | `0xC3` | `(160, 0, -50)` | `(0, 0, 0)` |

The values are cross-checked in June Xbox, retail Xbox, and retail PS3 executable evidence. They are not screenshot/symmetry estimates. See `docs/research/PROGRESSIVE_UFO_RUNTIME_ASSEMBLY_2.10.0-dev3.md`.

Export it directly:

```bat
python siig_toolkit.py gmx-assemble-catalog progressive_ufo --root extracted_gmx -o progressive_ufo.gltf
```

Or write the completed manifest first:

```bat
python siig_toolkit.py gmx-assembly-template progressive_ufo -o progressive_ufo.assembly.json
python siig_toolkit.py gmx-assemble progressive_ufo.assembly.json --root extracted_gmx -o progressive_ufo.gltf
```

Each instance uses a standard 16-value glTF column-major local-to-assembly matrix. Native GMX POSITION XYZ/units are preserved by the exporter, so the executable-derived local XYZ offsets require no axis permutation.

The exporter keeps each GMX hierarchy under a named instance node, remaps mesh/material/animation/accessor indices, combines the binary buffers, and copies resolved texture images into `_assembly_textures`. A `.assembly.json` report records source hashes and matrices.

## CRAB

CRAB uses a runtime hierarchy rather than one static set of model-space offsets. The built-in `crab` catalog represents the deterministic **first-visible** state recovered from June Xbox, retail Xbox and retail PS3. It contains `A7 + CD + CC + 2×CE + 4×CF` (nine instances).

The A7 root is baked at native animation sample `167`; the animated CD body shell is baked at sample `0`. The child matrices are then applied at the executable/model-derived `lt_000` attachment center with ±81 propodus and ±23 dactyl offsets.

```bat
python siig_toolkit.py gmx-assemble-catalog crab --root extracted_gmx -o crab.gltf
```

Or write/edit the catalog manifest first:

```bat
python siig_toolkit.py gmx-assembly-template crab -o crab.assembly.json
python siig_toolkit.py gmx-assemble crab.assembly.json --root extracted_gmx -o crab.gltf
```

### `pose_sample`

An assembly instance may include an optional non-negative `pose_sample`. The exporter bakes that native GMX logical animation sample into the instance's node hierarchy and deliberately does not merge that instance's animation channels. This is intended for evidence-backed static runtime snapshots such as CRAB, where separately instantiated child GMXs would otherwise remain fixed while an animated parent moves away from them.

`pose_sample` is validated against every native ANIM track in the source GMX; an out-of-range sample is a hard error.

## Evidence boundary

An unresolved transform remains a hard error for generic `gmx-assemble`; the toolkit never invents missing placements. The PROGRESSIVE UFO and CRAB catalogs are complete for the documented static runtime formations. CRAB specifically represents its executable-defined first-visible sample-167 state. Later dynamic phase poses remain separate research targets.
