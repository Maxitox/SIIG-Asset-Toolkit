#!/usr/bin/env python3
"""Desktop control center for the SIIG Asset Toolkit.

The GUI intentionally wraps the existing audited CLI instead of duplicating format logic.
It uses only the Python standard library (Tkinter) and launches toolkit commands in a
background thread so long extraction/build operations do not freeze the window.
"""
from __future__ import annotations

import json
import os
import queue
import shlex
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path
from typing import Callable, Optional

ROOT = Path(__file__).resolve().parent
TOOLKIT = ROOT / "siig_toolkit.py"
VERSION_FILE = ROOT / "VERSION.txt"
GUI_VERSION = "0.15.0-dev4"


def toolkit_version() -> str:
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return "unknown"


def diagnostics() -> dict:
    try:
        import tkinter as tk  # noqa: F401
        tkinter_ok = True
    except Exception:
        tkinter_ok = False
    return {
        "gui_version": GUI_VERSION,
        "toolkit_version": toolkit_version(),
        "toolkit_exists": TOOLKIT.is_file(),
        "tkinter_available": tkinter_ok,
        "python": sys.version.split()[0],
        "tabs": ["Game Rip", "Mod Workspace", "GMX Workbench", "Utilities"],
        "principle": "GUI wraps the existing CLI; format logic stays in audited toolkit code",
        "gmx_scene_graph_report": True,
        "gmx_scene_graph_sync": True,
        "gmx_texture_graph_sync": True,
        "gmx_animation_graph_sync": True,
        "mod_gltf_texture_pipeline": True,
        "native_tex_layout_synthesis": True,
        "gmx_multibone_animation_sync": True,
        "gltf_cubicspline_animation_import": True,
        "gmx_template_free_compile": True,
        "gmx_canonical_root_synthesis": True,
        "gmx_rigid_skin_import": True,
        "gmx_blended_skin_rejection": True,
        "gmx_rigid_inverse_bind_rebake": True,
        "gmx_rigid_partitioning": True,
        "gmx_multi_file_assembly": True,
        "progressive_ufo_one_click_assembly": True,
        "crab_one_click_assembly": True,
        "gui_modes": ["simple", "advanced"],
        "default_gui_mode": "simple",
        "hover_context_help": True,
    }


def _open_path(path: Path) -> None:
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception:
        if path.is_file() and path.suffix.lower() in {".html", ".htm"}:
            webbrowser.open(path.resolve().as_uri())


def main() -> int:
    if "--check" in sys.argv:
        print(json.dumps(diagnostics(), indent=2))
        return 0
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except Exception as exc:
        print(f"Tkinter is unavailable: {exc}", file=sys.stderr)
        return 2

    class App(tk.Tk):
        def __init__(self) -> None:
            super().__init__()
            self.title(f"SIIG Asset Toolkit {toolkit_version()} — Desktop")
            self.geometry("1120x780")
            self.minsize(900, 650)
            self._queue: queue.Queue = queue.Queue()
            self._busy = False
            self._buttons: list[ttk.Button] = []
            self._status = tk.StringVar(value="Ready")
            self.advanced_mode = tk.BooleanVar(value=False)
            self._mode_label = tk.StringVar(value="Mode: Simple")
            self._help_default = "Hover over a box or button to see what it does. Simple mode hides specialist controls; Advanced mode shows everything."
            self._advanced_widgets: list[object] = []
            self._simple_widgets: list[object] = []
            self._build_ui()
            self._apply_mode()
            self.after(80, self._poll_queue)

        def _build_ui(self) -> None:
            outer = ttk.Frame(self, padding=10)
            outer.pack(fill="both", expand=True)
            header = ttk.Frame(outer)
            header.pack(fill="x", pady=(0, 8))
            ttk.Label(header, text="SIIG Asset Toolkit", font=("TkDefaultFont", 16, "bold")).pack(side="left")
            ttk.Label(header, text=f"  {toolkit_version()}  •  GUI {GUI_VERSION}").pack(side="left", padx=6)
            ttk.Label(header, textvariable=self._status).pack(side="right", padx=(10, 0))
            mode_switch = ttk.Checkbutton(header, text="Advanced mode", variable=self.advanced_mode, command=self._apply_mode)
            mode_switch.pack(side="right", padx=(10, 0))
            ttk.Label(header, textvariable=self._mode_label).pack(side="right")
            self._register_help(mode_switch, "Switch between the beginner-friendly Simple interface and the full Advanced interface. Advanced mode does not unlock hidden format features; it only shows the specialist controls.")

            note = ttk.Label(
                outer,
                text="Desktop control center. Simple mode is recommended if you are new to the toolkit; native parsing/building still uses the same audited CLI code underneath.",
                foreground="#555555",
            )
            note.pack(fill="x", pady=(0, 8))

            self.tabs = ttk.Notebook(outer)
            self.tabs.pack(fill="both", expand=True)
            self._tab_game(ttk.Frame(self.tabs, padding=12))
            self._tab_mod(ttk.Frame(self.tabs, padding=12))
            self._tab_gmx(ttk.Frame(self.tabs, padding=12))
            self._tab_util(ttk.Frame(self.tabs, padding=12))
            self.tabs.bind("<<NotebookTabChanged>>", lambda _event: self._restore_help())

            help_frame = ttk.LabelFrame(outer, text="What does this do?", padding=6)
            help_frame.pack(fill="x", expand=False, pady=(10, 0))
            self.help_box = tk.Text(help_frame, height=4, wrap="word", relief="flat", padx=4, pady=4)
            self.help_box.pack(fill="x", expand=True)
            self.help_box.configure(state="disabled")
            self._set_help(self._help_default)

            log_frame = ttk.LabelFrame(outer, text="Task log / results", padding=6)
            log_frame.pack(fill="both", expand=False, pady=(8, 0))
            self.log = tk.Text(log_frame, height=9, wrap="word")
            scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
            self.log.configure(yscrollcommand=scroll.set)
            self.log.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")
            toolbar = ttk.Frame(outer)
            toolbar.pack(fill="x", pady=(5, 0))
            clear = ttk.Button(toolbar, text="Clear log", command=lambda: self.log.delete("1.0", "end"))
            clear.pack(side="left")
            copy = ttk.Button(toolbar, text="Copy log", command=self._copy_log)
            copy.pack(side="left", padx=5)
            self._register_help(clear, "Clear the task log. This does not delete or undo any files or toolkit work.")
            self._register_help(copy, "Copy the entire task log to the clipboard so you can save it or send it for troubleshooting.")

        def _register_help(self, widget, text: str) -> None:
            """Show contextual help for any interactive control without intrusive pop-ups."""
            widget.bind("<Enter>", lambda _event, message=text: self._set_help(message), add="+")
            widget.bind("<FocusIn>", lambda _event, message=text: self._set_help(message), add="+")
            widget.bind("<Leave>", lambda _event: self._restore_help(), add="+")

        def _set_help(self, text: str) -> None:
            if not hasattr(self, "help_box"):
                return
            self.help_box.configure(state="normal")
            self.help_box.delete("1.0", "end")
            self.help_box.insert("1.0", text)
            self.help_box.configure(state="disabled")

        def _restore_help(self) -> None:
            if not hasattr(self, "tabs"):
                return
            try:
                tab_name = self.tabs.tab(self.tabs.select(), "text")
            except Exception:
                tab_name = ""
            defaults = {
                "Game Rip": "Game Rip extracts the game/package into a verified working copy and builds convenient converted previews. Hover over a control for details.",
                "Mod Workspace": "Simple mode: choose a verified rip and a workspace, create the workspace, edit files, then Build → Verify → Pack. Advanced mode exposes direct GMX resource-import plumbing.",
                "GMX Workbench": "Simple mode: choose a GMX, export it for Blender, edit the glTF, then rebuild a new GMX. Advanced mode exposes low-level graph/schema/JSON controls.",
                "Utilities": "Utilities contains validation, diagnostics, self-tests and the standalone browser asset viewer. Hover over a control for details.",
            }
            self._set_help(defaults.get(tab_name, self._help_default))

        def _mode_only(self, widget, *, advanced: bool = False, simple: bool = False) -> None:
            if advanced:
                self._advanced_widgets.append(widget)
            if simple:
                self._simple_widgets.append(widget)

        def _apply_mode(self) -> None:
            advanced = bool(self.advanced_mode.get())
            self._mode_label.set("Mode: Advanced" if advanced else "Mode: Simple")
            for widget in self._advanced_widgets:
                try:
                    widget.grid() if advanced else widget.grid_remove()
                except Exception:
                    pass
            for widget in self._simple_widgets:
                try:
                    widget.grid_remove() if advanced else widget.grid()
                except Exception:
                    pass
            if hasattr(self, "mod_mode_note"):
                self.mod_mode_note.set(
                    "Advanced mode shows direct resource keys, raw glTF/TEX import and package inspection tools."
                    if advanced else
                    "Simple mode: create a workspace from a verified rip, edit its files, then Build → Verify → Pack. The specialist GMX resource fields are hidden."
                )
            if hasattr(self, "gmx_mode_note"):
                self.gmx_mode_note.set(
                    "Advanced mode shows JSON editing, graph/schema synchronization, generic assembly and template-free construction controls."
                    if advanced else
                    "Simple mode: choose a GMX, export it for Blender, edit the glTF, then rebuild a new GMX. PROGRESSIVE UFO can also be assembled in one click."
                )
            self._restore_help()

        def _entry_row(self, parent, row: int, label: str, var, kind: str = "file", save: bool = False, filetypes=None, help_text: str = "", advanced_only: bool = False) -> None:
            help_text = help_text or f"Set {label}. Use Browse if you do not want to type the path manually."
            label_widget = ttk.Label(parent, text=label)
            label_widget.grid(row=row, column=0, sticky="w", padx=(0, 8), pady=4)
            entry = ttk.Entry(parent, textvariable=var)
            entry.grid(row=row, column=1, sticky="ew", pady=4)
            def browse() -> None:
                initial = Path(var.get()).expanduser() if var.get() else Path.home()
                if kind == "dir":
                    value = filedialog.askdirectory(initialdir=str(initial if initial.is_dir() else initial.parent))
                elif save:
                    value = filedialog.asksaveasfilename(initialdir=str(initial.parent), initialfile=initial.name, filetypes=filetypes or [("All files", "*.*")])
                else:
                    value = filedialog.askopenfilename(initialdir=str(initial if initial.is_dir() else initial.parent), filetypes=filetypes or [("All files", "*.*")])
                if value:
                    var.set(value)
            browse_button = ttk.Button(parent, text="Browse…", command=browse)
            browse_button.grid(row=row, column=2, padx=(8, 0), pady=4)
            parent.columnconfigure(1, weight=1)
            for widget in (label_widget, entry, browse_button):
                self._register_help(widget, help_text)
                if advanced_only:
                    self._mode_only(widget, advanced=True)

        def _action(self, parent, text: str, command: Callable[[], None], row: int, col: int = 0, span: int = 1, help_text: str = "") -> None:
            button = ttk.Button(parent, text=text, command=command)
            button.grid(row=row, column=col, columnspan=span, sticky="ew", padx=4, pady=4)
            self._buttons.append(button)
            self._register_help(button, help_text or f"Run {text}. The command and its results will appear in the task log below.")

        def _tab_game(self, tab) -> None:
            self.tabs.add(tab, text="Game Rip")
            self.game_input = tk.StringVar()
            self.game_output = tk.StringVar(value=str(Path.cwd() / "SIIG_Ripped"))
            self.game_resume = tk.BooleanVar(value=True)
            ttk.Label(tab, text="Full-game extraction and verification", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
            self._entry_row(tab, 1, "Game/package", self.game_input, help_text="Choose the Xbox 360 STFS/game package, PS3 package/extracted game input, or another supported game source you want the toolkit to rip.")
            self._entry_row(tab, 2, "Rip output", self.game_output, kind="dir", help_text="Choose where the extracted and converted game files should be written. The toolkit creates its organized rip structure here.")
            resume = ttk.Checkbutton(tab, text="Resume/reuse unchanged work", variable=self.game_resume)
            resume.grid(row=3, column=1, sticky="w", pady=4)
            self._register_help(resume, "Recommended. Reuses already completed extraction/conversion work when the source has not changed, which makes repeated runs much faster.")
            actions = ttk.Frame(tab); actions.grid(row=4, column=0, columnspan=3, sticky="ew", pady=8)
            for c in range(4): actions.columnconfigure(c, weight=1)
            self._action(actions, "Rip game", self._rip_game, 0, 0, help_text="Start the full extraction/conversion workflow using the selected game/package and output folder.")
            self._action(actions, "Verify rip", lambda: self._run(["verify-output", self.game_output.get()]), 0, 1, help_text="Check the completed rip for missing, changed or invalid outputs. This does not modify the rip.")
            self._action(actions, "Build asset viewer", self._build_viewer, 0, 2, help_text="Create a local browser-based viewer for the ripped assets and open it when finished.")
            self._action(actions, "Open rip folder", lambda: _open_path(Path(self.game_output.get())), 0, 3, help_text="Open the selected rip-output directory in your normal file manager.")
            ttk.Label(tab, text="The full rip automatically converts supported models/textures/scripts and writes validation reports.", wraplength=850).grid(row=5, column=0, columnspan=3, sticky="w", pady=4)

        def _tab_mod(self, tab) -> None:
            self.tabs.add(tab, text="Mod Workspace")
            self.mod_rip = tk.StringVar()
            self.mod_ws = tk.StringVar(value=str(Path.cwd() / "SIIG_Mod_Workspace"))
            self.mod_archive = tk.StringVar()
            self.mod_resource = tk.StringVar()
            self.mod_gltf = tk.StringVar()
            self.mod_mode_note = tk.StringVar()
            ttk.Label(tab, text="Mod Workspace", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 4))
            ttk.Label(tab, textvariable=self.mod_mode_note, wraplength=900).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 8))
            self._entry_row(tab, 2, "Verified game rip", self.mod_rip, kind="dir", help_text="Choose the verified rip you made in Game Rip. Mod Workspace uses this as the clean source when building or applying changes.")
            self._entry_row(tab, 3, "Mod workspace folder", self.mod_ws, kind="dir", help_text="Choose the folder where your editable mod project will live. Create Workspace will prepare it for you.")

            # Direct GMX-resource plumbing is intentionally hidden from beginners.
            self._entry_row(tab, 4, "GMX archive key", self.mod_archive, help_text="Advanced: internal BBX/archive key that identifies which container owns the GMX resource you want to replace.", advanced_only=True)
            self._entry_row(tab, 5, "GMX resource", self.mod_resource, help_text="Advanced: exact GMX resource name/path inside the selected archive key.", advanced_only=True)
            self._entry_row(tab, 6, "Edited glTF", self.mod_gltf, filetypes=[("glTF 2.0", "*.gltf"), ("All files", "*.*")], help_text="Advanced: an edited glTF that should be compiled and imported directly into the selected GMX resource, including compatible texture changes.", advanced_only=True)

            simple_actions = ttk.LabelFrame(tab, text="Beginner workflow", padding=6)
            simple_actions.grid(row=7, column=0, columnspan=3, sticky="ew", pady=8)
            self._mode_only(simple_actions, simple=True)
            for c in range(4): simple_actions.columnconfigure(c, weight=1)
            self._action(simple_actions, "1. Create workspace", lambda: self._run(["mod-init", self.mod_rip.get(), "-o", self.mod_ws.get()]), 0, 0, help_text="Create a new editable mod workspace from the verified game rip. Do this once when starting a mod project.")
            self._action(simple_actions, "2. Open workspace", lambda: _open_path(Path(self.mod_ws.get())), 0, 1, help_text="Open your mod workspace in the file manager so you can replace/edit the prepared files.")
            self._action(simple_actions, "3. Build changes", lambda: self._run(["mod-build", self.mod_ws.get()]), 0, 2, help_text="Compile the files you changed in the workspace into game-ready replacement data.")
            self._action(simple_actions, "4. Verify build", lambda: self._run(["mod-verify", self.mod_ws.get()]), 0, 3, help_text="Check that the current built mod is structurally valid before packaging or applying it.")
            self._action(simple_actions, "5. Pack .siigmod…", self._pack_mod, 1, 0, 2, help_text="Package your verified workspace changes into one shareable .siigmod file.")
            self._action(simple_actions, "Apply .siigmod…", self._apply_mod, 1, 2, 2, help_text="Apply an existing .siigmod package to a clean verified rip and build the resulting mod workspace.")

            advanced_actions = ttk.LabelFrame(tab, text="Advanced workspace tools", padding=6)
            advanced_actions.grid(row=7, column=0, columnspan=3, sticky="ew", pady=8)
            self._mode_only(advanced_actions, advanced=True)
            for c in range(4): advanced_actions.columnconfigure(c, weight=1)
            self._action(advanced_actions, "Initialize", lambda: self._run(["mod-init", self.mod_rip.get(), "-o", self.mod_ws.get()]), 0, 0, help_text="Initialize a mod workspace from the selected verified rip.")
            self._action(advanced_actions, "List assets", lambda: self._run(["mod-list", self.mod_ws.get()]), 0, 1, help_text="Print the assets known to the current mod workspace and their change/build state.")
            self._action(advanced_actions, "Build changes", lambda: self._run(["mod-build", self.mod_ws.get()]), 0, 2, help_text="Build all pending workspace changes into native game resources.")
            self._action(advanced_actions, "Verify build", lambda: self._run(["mod-verify", self.mod_ws.get()]), 0, 3, help_text="Run structural verification on the built mod workspace.")
            self._action(advanced_actions, "Pack .siigmod…", self._pack_mod, 1, 0, help_text="Package the current workspace delta as a deterministic .siigmod file.")
            self._action(advanced_actions, "Inspect .siigmod…", self._inspect_mod, 1, 1, help_text="Read and validate a .siigmod package without applying it.")
            self._action(advanced_actions, "Apply .siigmod…", self._apply_mod, 1, 2, help_text="Apply a .siigmod package to the selected verified source rip and build it into this workspace.")
            self._action(advanced_actions, "Open workspace", lambda: _open_path(Path(self.mod_ws.get())), 1, 3, help_text="Open the current mod workspace folder in your file manager.")
            self._action(advanced_actions, "Import glTF + TEX", self._mod_import_gltf, 2, 0, 2, help_text="Advanced: compile the selected edited glTF into the specified GMX resource and synchronize compatible texture replacements through the workspace pipeline.")
            ttk.Label(tab, text="The safe rigid-mesh path partitions disjoint single-joint islands automatically. Cross-joint triangles and true blended skinning are still rejected because SIIG's native per-vertex weight format has not been proven.", wraplength=900).grid(row=8, column=0, columnspan=3, sticky="w", pady=4)

        def _tab_gmx(self, tab) -> None:
            self.tabs.add(tab, text="GMX Workbench")
            self.gmx_template = tk.StringVar()
            self.gmx_gltf = tk.StringVar()
            self.gmx_output = tk.StringVar()
            self.gmx_json = tk.StringVar()
            self.gmx_flip = tk.BooleanVar(value=False)
            self.gmx_sync_graph = tk.BooleanVar(value=False)
            self.gmx_sync_scene = tk.BooleanVar(value=False)
            self.gmx_sync_texture = tk.BooleanVar(value=False)
            self.gmx_synthesize_schemas = tk.BooleanVar(value=False)
            self.gmx_sync_animation = tk.BooleanVar(value=False)
            self.gmx_sync_rigid_skins = tk.BooleanVar(value=False)
            self.gmx_mode_note = tk.StringVar()
            ttk.Label(tab, text="GMX Workbench", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 4))
            ttk.Label(tab, textvariable=self.gmx_mode_note, wraplength=900).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 8))
            self._entry_row(tab, 2, "Original/native GMX", self.gmx_template, filetypes=[("SIIG GMX", "*.gmx"), ("All files", "*.*")], help_text="Choose the original GMX model. Export for Blender converts this file; Rebuild GMX uses it as the structural template unless you use the advanced template-free creator.")
            self._entry_row(tab, 3, "Edited glTF", self.gmx_gltf, filetypes=[("glTF 2.0", "*.gltf"), ("All files", "*.*")], help_text="Choose the glTF you edited in Blender or another glTF editor. Export for Blender fills this automatically with the newly exported glTF path.")
            self._entry_row(tab, 4, "Output GMX", self.gmx_output, save=True, filetypes=[("SIIG GMX", "*.gmx")], help_text="Advanced: choose the exact output filename. If left blank, Rebuild GMX automatically writes <original>.edited.gmx beside the source model.", advanced_only=True)
            self._entry_row(tab, 5, "Editable GMX JSON", self.gmx_json, save=True, filetypes=[("JSON", "*.json")], help_text="Advanced: path for the low-level editable GMX JSON representation used by Export editable JSON / Build JSON → GMX.", advanced_only=True)

            advanced_options = ttk.LabelFrame(tab, text="Advanced import options", padding=6)
            advanced_options.grid(row=6, column=0, columnspan=3, sticky="ew", pady=6)
            self._mode_only(advanced_options, advanced=True)
            options = [
                ("Flip UV V on glTF import/export", self.gmx_flip, "Flip the V texture coordinate during glTF conversion. Leave this off unless the texture orientation in your editing workflow specifically requires it."),
                ("Sync native MESH/ARRY graph", self.gmx_sync_graph, "Rebuild the native mesh/index graph from the glTF rather than preserving the donor graph. Useful for topology changes; more invasive than a basic template-preserving edit."),
                ("Sync BONE/PARE + material/shader scene graph", self.gmx_sync_scene, "Rebuild the decoded bone/parent/material/shader scene relationships from glTF. Use for scene-graph changes rather than simple geometry edits."),
                ("Sync TXIF texture bindings", self.gmx_sync_texture, "Rebuild native texture binding records from the glTF material/texture graph."),
                ("Synthesize native vertex/material schemas", self.gmx_synthesize_schemas, "Allow donor-free synthesis of the decoded standard native vertex/material schemas when the glTF needs structures not present in the template."),
                ("Sync MOTN/ANIM animation graph", self.gmx_sync_animation, "Rebuild native 30 Hz MOTN/ANIM tracks from supported glTF animation channels."),
                ("Import rigid glTF skins + inverse-bind rebake", self.gmx_sync_rigid_skins, "Import single-joint rigid glTF skinning and rebake inverse-bind transforms. True blended weights remain unsupported."),
            ]
            for row, (text, var, help_text) in enumerate(options):
                cb = ttk.Checkbutton(advanced_options, text=text, variable=var)
                cb.grid(row=row, column=0, sticky="w", pady=2)
                self._register_help(cb, help_text)

            simple_actions = ttk.LabelFrame(tab, text="Beginner workflow", padding=6)
            simple_actions.grid(row=7, column=0, columnspan=3, sticky="ew", pady=8)
            self._mode_only(simple_actions, simple=True)
            for c in range(4): simple_actions.columnconfigure(c, weight=1)
            self._action(simple_actions, "1. Export for Blender", self._export_gltf, 0, 0, 2, help_text="Convert the selected original GMX into a glTF you can open in Blender. After export, the Edited glTF box is filled automatically.")
            self._action(simple_actions, "2. Rebuild GMX", self._import_gltf, 0, 2, 2, help_text="Compile the selected edited glTF back into a new GMX using the original GMX as a conservative structural template. The original file is not overwritten by default.")
            self._action(simple_actions, "Inspect GMX", self._inspect_gmx, 1, 0, help_text="Show a structural scan of the selected GMX in the task log. This is read-only and safe.")
            self._action(simple_actions, "Open model folder", lambda: _open_path(Path(self.gmx_template.get()).parent), 1, 1, help_text="Open the folder containing the selected original GMX.")
            self._action(simple_actions, "Assemble PROGRESSIVE UFO", self._assemble_progressive_ufo, 1, 2, 2, help_text="Choose a folder containing bos_009.gmx, bos_009a.gmx and bos_009b.gmx, then export the complete five-part boss at its executable-backed in-game formation.")
            self._action(simple_actions, "Assemble CRAB", self._assemble_crab, 2, 0, 4, help_text="Choose a folder containing bos_013.gmx plus bos_013a/b/c/d.gmx, then export CRAB in the executable-backed first-visible frame-167 formation. The root and body-shell animation samples are baked automatically.")

            advanced_actions = ttk.LabelFrame(tab, text="Advanced GMX tools", padding=6)
            advanced_actions.grid(row=7, column=0, columnspan=3, sticky="ew", pady=8)
            self._mode_only(advanced_actions, advanced=True)
            for c in range(4): advanced_actions.columnconfigure(c, weight=1)
            self._action(advanced_actions, "Inspect GMX", self._inspect_gmx, 0, 0, help_text="Read-only structural scan of the selected native GMX.")
            self._action(advanced_actions, "Export glTF", self._export_gltf, 0, 1, help_text="Export the selected GMX into an editable glTF scene.")
            self._action(advanced_actions, "Import glTF → GMX", self._import_gltf, 0, 2, help_text="Template-backed glTF import using the selected advanced synchronization options.")
            self._action(advanced_actions, "Export editable JSON", self._export_gmx_json, 0, 3, help_text="Export a low-level editable JSON representation of the selected GMX for expert structural work.")
            self._action(advanced_actions, "Build JSON → GMX", self._build_gmx_json, 1, 0, help_text="Build a GMX from the editable JSON while preserving unsupported/opaque data from the selected template where required.")
            self._action(advanced_actions, "Open model folder", lambda: _open_path(Path(self.gmx_template.get()).parent), 1, 1, help_text="Open the selected GMX's containing directory.")
            self._action(advanced_actions, "Scene graph report", self._gmx_scene_report, 1, 2, help_text="Generate an HTML report of the decoded GMX scene/bone/material/animation relationships and open it.")
            self._action(advanced_actions, "Create new GMX", self._create_gmx_new, 1, 3, help_text="Compile a supported glTF into a completely new GMX without an original GMX template. Still subject to the toolkit's documented native-format boundaries.")
            self._action(advanced_actions, "PROGRESSIVE UFO manifest", self._progressive_ufo_manifest, 2, 0, help_text="Write the built-in evidence-backed PROGRESSIVE UFO assembly definition to JSON for inspection or manual editing.")
            self._action(advanced_actions, "Assemble PROGRESSIVE UFO", self._assemble_progressive_ufo, 2, 1, 2, help_text="Export the complete five-part PROGRESSIVE UFO scene using the recovered runtime formation.")
            self._action(advanced_actions, "Assemble GMXs…", self._assemble_gmx_manifest, 2, 3, help_text="Use a custom multi-GMX assembly manifest to combine several native GMX files into one editable glTF scene.")
            self._action(advanced_actions, "CRAB manifest", self._crab_manifest, 3, 0, help_text="Write the built-in evidence-backed CRAB first-visible assembly definition to JSON for inspection or manual editing, including its baked native pose samples.")
            self._action(advanced_actions, "Assemble CRAB", self._assemble_crab, 3, 1, 3, help_text="Export the nine-part CRAB first-visible formation. A7 is baked at native sample 167 and the CD shell at sample 0 before the runtime attachment transforms are applied.")
            ttk.Label(tab, text="Template-backed import remains the conservative path for editing an existing asset. Simple mode deliberately hides controls that are only needed when changing native topology, hierarchy, bindings, schemas or animations.", wraplength=900).grid(row=8, column=0, columnspan=3, sticky="w", pady=8)

        def _tab_util(self, tab) -> None:
            self.tabs.add(tab, text="Utilities")
            self.util_input = tk.StringVar()
            self.viewer_input = tk.StringVar()
            self.viewer_output = tk.StringVar(value=str(Path.cwd() / "siig_asset_viewer"))
            ttk.Label(tab, text="Validation and browser utilities", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
            self._entry_row(tab, 1, "Doctor input (optional)", self.util_input, help_text="Optional file/folder input for the Doctor diagnostic command. Leave blank for general toolkit diagnostics.")
            self._entry_row(tab, 2, "Asset directory", self.viewer_input, kind="dir", help_text="Choose a directory of extracted/converted assets you want to browse with the local web asset viewer.")
            self._entry_row(tab, 3, "Viewer output", self.viewer_output, kind="dir", help_text="Choose where the generated browser asset viewer should be written.")
            actions = ttk.Frame(tab); actions.grid(row=4, column=0, columnspan=3, sticky="ew", pady=8)
            for c in range(4): actions.columnconfigure(c, weight=1)
            self._action(actions, "Doctor", self._doctor, 0, 0, help_text="Run non-destructive toolkit/input diagnostics and print findings in the task log.")
            self._action(actions, "Run selftests", lambda: self._run(["selftest"]), 0, 1, help_text="Run the toolkit's dependency-free regression suite. This is useful after moving/updating the toolkit or before reporting a bug.")
            self._action(actions, "Asset capabilities", lambda: self._run(["asset-capabilities"]), 0, 2, help_text="Show which SIIG asset families can currently be viewed, edited, round-tripped or synthesized.")
            self._action(actions, "Build viewer", self._util_viewer, 0, 3, help_text="Generate the local browser asset viewer for the selected asset directory and open it.")
            docs = ttk.Button(tab, text="Open toolkit documentation folder", command=lambda: _open_path(ROOT / "docs"))
            docs.grid(row=5, column=0, sticky="w", padx=4, pady=4)
            self._register_help(docs, "Open the bundled documentation and research notes in your file manager.")

        def _copy_log(self) -> None:
            self.clipboard_clear(); self.clipboard_append(self.log.get("1.0", "end-1c"))

        def _append(self, text: str) -> None:
            self.log.insert("end", text)
            self.log.see("end")

        def _set_busy(self, busy: bool) -> None:
            self._busy = busy
            for button in self._buttons:
                try: button.configure(state="disabled" if busy else "normal")
                except Exception: pass
            self._status.set("Working…" if busy else "Ready")

        def _run(self, args: list[str], on_done: Optional[Callable[[int], None]] = None) -> None:
            args = [str(x) for x in args if str(x) != ""]
            if self._busy:
                messagebox.showinfo("SIIG Toolkit", "Another toolkit task is already running.")
                return
            if not TOOLKIT.is_file():
                messagebox.showerror("SIIG Toolkit", f"Missing {TOOLKIT}")
                return
            self._set_busy(True)
            cmd = [sys.executable, str(TOOLKIT), *args]
            self._append("\n$ " + " ".join(shlex.quote(x) for x in cmd) + "\n")
            def worker() -> None:
                code = 1
                try:
                    proc = subprocess.Popen(cmd, cwd=str(ROOT), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
                    assert proc.stdout is not None
                    for line in proc.stdout:
                        self._queue.put(("line", line))
                    code = proc.wait()
                except Exception as exc:
                    self._queue.put(("line", f"GUI launcher error: {exc}\n"))
                self._queue.put(("done", code, on_done))
            threading.Thread(target=worker, daemon=True).start()

        def _poll_queue(self) -> None:
            try:
                while True:
                    item = self._queue.get_nowait()
                    if item[0] == "line": self._append(item[1])
                    elif item[0] == "done":
                        code, callback = item[1], item[2]
                        self._append(f"[exit {code}]\n")
                        self._set_busy(False)
                        if callback: callback(code)
            except queue.Empty:
                pass
            self.after(80, self._poll_queue)

        def _rip_game(self) -> None:
            if not self.game_input.get(): return messagebox.showerror("Game rip", "Choose an input first.")
            args = ["rip-game", self.game_input.get(), "-o", self.game_output.get()]
            if self.game_resume.get(): args.append("--resume")
            self._run(args)

        def _build_viewer(self) -> None:
            root = Path(self.game_output.get())
            out = root / "asset_viewer"
            self._run(["asset-viewer", str(root), "-o", str(out)], lambda code: _open_path(out / "index.html") if code == 0 else None)

        def _pack_mod(self) -> None:
            out = filedialog.asksaveasfilename(defaultextension=".siigmod", filetypes=[("SIIG mod package", "*.siigmod")])
            if out: self._run(["mod-pack", self.mod_ws.get(), "-o", out])

        def _inspect_mod(self) -> None:
            path = filedialog.askopenfilename(filetypes=[("SIIG mod package", "*.siigmod"), ("All files", "*.*")])
            if path: self._run(["mod-package-info", path])

        def _apply_mod(self) -> None:
            path = filedialog.askopenfilename(filetypes=[("SIIG mod package", "*.siigmod"), ("All files", "*.*")])
            if path:
                if not self.mod_rip.get():
                    return messagebox.showerror("Apply mod", "Choose the verified source rip first.")
                self._run(["mod-apply", path, self.mod_rip.get(), self.mod_ws.get(), "--build"])

        def _mod_import_gltf(self) -> None:
            if not self.mod_archive.get() or not self.mod_resource.get() or not self.mod_gltf.get():
                return messagebox.showerror("Import glTF + TEX", "Enter the GMX archive key/resource and choose the edited glTF first.")
            args = ["mod-import-gltf", self.mod_ws.get(), self.mod_archive.get(), self.mod_resource.get(), self.mod_gltf.get()]
            self._run(args)

        def _inspect_gmx(self) -> None:
            if self.gmx_template.get(): self._run(["scan", self.gmx_template.get()])

        def _export_gltf(self) -> None:
            template = Path(self.gmx_template.get())
            if not template.is_file(): return messagebox.showerror("GMX", "Choose a native GMX first.")
            out = filedialog.askdirectory(title="Choose glTF output directory")
            if not out: return
            args = ["gmx2gltf", str(template), "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            def done(code: int) -> None:
                if code == 0:
                    gltf = Path(out) / (template.stem + ".gltf")
                    if gltf.exists(): self.gmx_gltf.set(str(gltf))
            self._run(args, done)

        def _import_gltf(self) -> None:
            template = Path(self.gmx_template.get()); gltf = Path(self.gmx_gltf.get())
            if not template.is_file() or not gltf.is_file(): return messagebox.showerror("GMX", "Choose both the native GMX template and edited glTF.")
            out = self.gmx_output.get() or str(template.with_name(template.stem + ".edited.gmx")); self.gmx_output.set(out)
            args = ["gltf2gmx-template", str(gltf), "--template", str(template), "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            if self.gmx_sync_graph.get(): args.append("--sync-mesh-graph")
            if self.gmx_sync_scene.get(): args.append("--sync-scene-graph")
            if self.gmx_sync_texture.get(): args.append("--sync-texture-graph")
            if self.gmx_synthesize_schemas.get(): args.append("--synthesize-native-schemas")
            if self.gmx_sync_animation.get(): args.append("--sync-animation-graph")
            if self.gmx_sync_rigid_skins.get(): args.append("--sync-rigid-skins")
            self._run(args)

        def _create_gmx_new(self) -> None:
            gltf = Path(self.gmx_gltf.get())
            if not gltf.is_file():
                return messagebox.showerror("GMX", "Choose an edited glTF first.")
            out = self.gmx_output.get() or str(gltf.with_suffix(".gmx"))
            self.gmx_output.set(out)
            args = ["gltf2gmx-new", str(gltf), "-o", out]
            if self.gmx_flip.get():
                args.append("--flip-v")
            self._run(args)

        def _progressive_ufo_manifest(self) -> None:
            out = filedialog.asksaveasfilename(title="Save PROGRESSIVE UFO assembly manifest", defaultextension=".json", filetypes=[("JSON", "*.json")])
            if out:
                self._run(["gmx-assembly-template", "progressive_ufo", "-o", out])

        def _assemble_progressive_ufo(self) -> None:
            root = filedialog.askdirectory(title="Choose directory containing bos_009.gmx / bos_009a.gmx / bos_009b.gmx")
            if not root: return
            out = filedialog.asksaveasfilename(title="Save assembled PROGRESSIVE UFO glTF", defaultextension=".gltf", filetypes=[("glTF 2.0", "*.gltf")])
            if not out: return
            args = ["gmx-assemble-catalog", "progressive_ufo", "--root", root, "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _crab_manifest(self) -> None:
            out = filedialog.asksaveasfilename(title="Save CRAB assembly manifest", defaultextension=".json", filetypes=[("JSON", "*.json")])
            if out:
                self._run(["gmx-assembly-template", "crab", "-o", out])

        def _assemble_crab(self) -> None:
            root = filedialog.askdirectory(title="Choose directory containing bos_013.gmx / bos_013a.gmx / bos_013b.gmx / bos_013c.gmx / bos_013d.gmx")
            if not root: return
            out = filedialog.asksaveasfilename(title="Save assembled CRAB glTF", defaultextension=".gltf", filetypes=[("glTF 2.0", "*.gltf")])
            if not out: return
            args = ["gmx-assemble-catalog", "crab", "--root", root, "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _assemble_gmx_manifest(self) -> None:
            manifest = filedialog.askopenfilename(title="Choose GMX assembly manifest", filetypes=[("JSON", "*.json"), ("All files", "*.*")])
            if not manifest: return
            root = filedialog.askdirectory(title="Choose directory containing referenced GMX files")
            if not root: return
            out = filedialog.asksaveasfilename(title="Save assembled glTF", defaultextension=".gltf", filetypes=[("glTF 2.0", "*.gltf")])
            if not out: return
            args = ["gmx-assemble", manifest, "--root", root, "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _gmx_scene_report(self) -> None:
            template = Path(self.gmx_template.get())
            if not template.is_file(): return messagebox.showerror("GMX", "Choose a native GMX first.")
            out = template.with_name(template.stem + ".scene.html")
            self._run(["gmx-scene-report", str(template), "-o", str(out)], lambda code: _open_path(out) if code == 0 else None)

        def _export_gmx_json(self) -> None:
            template = Path(self.gmx_template.get())
            if not template.is_file(): return messagebox.showerror("GMX", "Choose a native GMX first.")
            out = self.gmx_json.get() or str(template.with_suffix(".gmx.edit.json")); self.gmx_json.set(out)
            self._run(["gmx-edit-export", str(template), "-o", out])

        def _build_gmx_json(self) -> None:
            template = Path(self.gmx_template.get()); doc = Path(self.gmx_json.get())
            if not template.is_file() or not doc.is_file(): return messagebox.showerror("GMX", "Choose a GMX template and editable JSON.")
            out = self.gmx_output.get() or str(template.with_name(template.stem + ".edited.gmx")); self.gmx_output.set(out)
            self._run(["gmx-build", str(doc), "--template", str(template), "-o", out])

        def _doctor(self) -> None:
            args = ["doctor"]
            if self.util_input.get(): args.append(self.util_input.get())
            self._run(args)

        def _util_viewer(self) -> None:
            if not self.viewer_input.get(): return messagebox.showerror("Asset viewer", "Choose an asset directory first.")
            out = Path(self.viewer_output.get())
            self._run(["asset-viewer", self.viewer_input.get(), "-o", str(out)], lambda code: _open_path(out / "index.html") if code == 0 else None)

    app = App()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
