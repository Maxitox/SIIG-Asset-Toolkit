# Multi-GMX assemblies (2.10.0-dev3)

Some SIIG runtime objects are assembled from several separate GMX resources. `gmx-assemble` combines explicit GMX instances into one glTF scene without claiming that the separate native files form one on-disc GMX.

## PROGRESSIVE UFO

The built-in catalog now contains the executable-backed first runtime formation:

| model | runtime | local translation | local rotation |
|---|---|---|---|
| `bos_009.gmx` | `0xA2` | `(0, 0, 0)` | `(0, 0, 0)` |
| `bos_009a.gmx` | `0xC2` | `(-90, 0, -10)` | `(0, 0, 0)` |
| `bos_009a.gmx` | `0xC2` | `(90, 0, -10)` | `(0, 0, 0)` |
| `bos_009b.gmx` | `0xC3` | `(-160, 0, -50)` | `(0, 0, 0)` |
| `bos_009b.gmx` | `0xC3` | `(160, 0, -50)` | `(0, 0, 0)` |

The values are cross-checked in June Xbox, retail Xbox, and retail PS3 executable evidence. They are not screenshot/symmetry estimates. See `docs/research/PROGRESSIVE_UFO_RUNTIME_ASSEMBLY_2.10.0-dev3.md`.

Export it directly:

```bat
python siig_toolkit.py gmx-assemble-catalog progressive_ufo --root extracted_gmx -o progressive_ufo.gltf
```

Or write the completed manifest first:

```bat
python siig_toolkit.py gmx-assembly-template progressive_ufo -o progressive_ufo.assembly.json
python siig_toolkit.py gmx-assemble progressive_ufo.assembly.json --root extracted_gmx -o progressive_ufo.gltf
```

Each instance uses a standard 16-value glTF column-major local-to-assembly matrix. Native GMX POSITION XYZ/units are preserved by the exporter, so the executable-derived local XYZ offsets require no axis permutation.

The exporter keeps each GMX hierarchy under a named instance node, remaps mesh/material/animation/accessor indices, combines the binary buffers, and copies resolved texture images into `_assembly_textures`. A `.assembly.json` report records source hashes and matrices.

## Evidence boundary

An unresolved transform remains a hard error for generic `gmx-assemble`; the toolkit never invents missing placements. The PROGRESSIVE UFO catalog is now complete because the first formation was recovered from executable state initialization on three console builds/platforms. Later dynamic phase poses remain separate research targets.
