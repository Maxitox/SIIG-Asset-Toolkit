# Dev24 current unresolved-boundary audit

Status: **living WIP158 audit** for unsealed `2.10.0-dev24`. Historical versioned release notes and validation reports may retain period-correct unresolved statements. Sealed historical release notes and validation files remain period-correct and are **not** rewritten merely because later work resolved an item. The machine-readable companion is `validation/UNRESOLVED_BOUNDARIES_2.10.0-dev24.json`.

## Why this exists

The project has accumulated several generations of research notes. A phrase such as “unresolved” in a dev16, dev22, or earlier validation report describes the state **at that checkpoint**; it is not automatically a current limitation. This registry is the current-facing source of truth for what still lacks evidence, implementation, or external runtime validation.

The strongest rule is unchanged: an opaque field, transform, GPU state, or gameplay name stays open rather than being guessed. Conversely, once later evidence closes a boundary, it should not be repeatedly rediscovered just because historical documents retain the old wording.

## Current open boundaries

| ID | Class | Current boundary | What would close it |
|---|---|---|---|
| `VISUALIZER_RT_ALPHA_STORAGE` | External runtime semantics | Visualizer RGB recurrence is recovered; Canvas is not claimed bit-identical to Xenos render-target alpha storage/compositing. | Controlled Xenos/runtime evidence for the alpha path. |
| `VISUALIZER_BGM_PROCESSING_CADENCE` | External runtime semantics | BGM value = stereo arithmetic mean of peak amplitudes; browser analysis-window cadence is approximate. | Exact XAudio2 processing-window/cadence evidence. |
| `STAGE_PLACEMENT_EULER_ORDER` | Research semantics | Stored placement rotations are shown but not applied to Stage Explorer proxies. | Native transform consumer or controlled runtime cross-check proving multiplication/order convention. |
| `ROUTE_DAT_PAIRING_AND_ACTIVATION` | Research semantics | Route math/playback is recovered; route↔DAT pairing and object activation frame remain explicit inputs. | Scene-level ownership/activation evidence. |
| `MAP_SCROLL_LAYER_PLAYER_NAMES` | Nomenclature | SCROLL_01/02/03 behavior is known; player-facing layer names are not. | Trustworthy name-bearing source. |
| `RUNTIME_009D_EMY051_GAMEPLAY_NAME` | Nomenclature | 0x9D/`emy_051` ownership and five-field DAT schema are known; gameplay/script name is not. | Trustworthy name-bearing string/script/debug source. |
| `GMX_NATIVE_BLENDED_SKINNING` | Evidence-absent feature | True multi-joint weights remain rejected; 901 checked player/enemy MESH records use `skin_index=0xFFFF` with no JOINT/WEIGHT ARRY streams. | Genuine native weighted-skin evidence. |
| `GMX_SKIN_INDEX_NONFFFF_SEMANTICS` | Research semantics | `skin_index` is only bounded by the repeated `0xFFFF` no-vertex-skin observation. | Native sample/consumer using another value. |
| `GMX_PLATFORM_SHADER_COMPILATION` | Implementation gap | Targeted shader semantics can be researched, but new Xenos/RSX microcode is not compiled by the toolkit. | Justified compiler/assembler path plus runtime validation. |
| `GMX_OPAQUE_FIELD_SEMANTICS` | Research semantics | Remaining unnamed GMX/root fields are preserved/defaulted without invented meanings. | Field-specific executable/corpus evidence. |
| `GMX_NATIVE_NAMED_CLIP_CONTAINER` | Research semantics | Multi-bone MOTN/ANIM tracks exist; no native named animation-clip container is proven. | Name-bearing native animation container/consumer. |
| `GMX_ARBITRARY_ORIGINAL_SCENE_RUNTIME_ACCEPTANCE` | External validation | Template-free GMX construction is structural; arbitrary original scenes are not claimed retail-safe. | Representative Xenia/console/devkit execution. |
| `TEX_COMPRESSED_MIPMAPPED_AUTHORING` | Implementation gap | Canonical uncompressed donor-free TEX path is implemented; general compressed/mipmapped authoring is not. | Per-layout format evidence, encoder, and runtime tests. |
| `PS3_SYNTH_TEX_UNKNOWN_WRAPPER_RUNTIME_ACCEPTANCE` | External validation | New PS3 A8R8G8B8 wrapper synthesis is structurally valid; unknown-wrapper-field runtime acceptance remains unproven. | PS3 runtime test of genuinely new textures. |
| `PS3_NPDRM_SDAT_REENCRYPTION` | Implementation gap | SDAT decryption/authentication works; signed/encrypted replacement wrapper generation does not. | Justified re-encryption/signing implementation and verification. |
| `AUDIO_REPLACEMENT_REBUILD` | Deferred feature | Audio extraction/decoding works; replacement/rebuild remains deferred. | Dedicated native encoder/rebuild development and runtime validation. |
| `BLENDER_UI_RUNTIME_VALIDATION` | External validation | Add-on source contracts are tested; in-Blender UI/operator execution is not part of the release environment. | Run the validation in supported Blender. |
| `ANDROID_LEVEL9_PLACEHOLDER_RATIONALE` | Low-priority research | Mobile Level-9 split is mapped; Android placeholder-script rationale is not. | Additional mobile code/content rationale evidence. |
| `CONSOLE_GENERATOR_2X_CAPACITY_RATIONALE` | Low-priority research | Console generator MAP capacity is exactly 2× iOS; the reason is not known. | Exact console allocation/ownership rationale. |

## Boundaries that are no longer current

These can still appear as unresolved in older checkpoint files, but later work supersedes them:

- Survival conversion status bytes → resolved in dev17 as Evolution Tree stage-node statuses.
- Retail route Hermite/resampling algorithm → reproduced; only route pairing/activation remains open.
- Template-free GMX root/scene construction → implemented.
- Donor-free GMX vertex/material schema synthesis → implemented.
- Multi-bone animation + glTF CUBICSPLINE import → implemented.
- Donor-free canonical TEX synthesis → implemented for the proven layouts.
- Camera preset word 11 → resolved as `face_bias`.
- Visualizer recursive feedback sampler → repeat + point min/mag/mip, anisotropy disabled.
- Visualizer SHAPE sampler → same exact sampling class recovered from all ten retail SHAPE resources.
- Visualizer EffectBlur fixed-function blend → Add(SrcAlpha, One).
- Visualizer EffectBlur pixel shader → sampled feedback RGB + uniform source alpha.
- Visualizer ScreenSprite SHAPE shader → sampled RGBA × runtime float4 tint; source-over SrcAlpha/OneMinusSrcAlpha.

## Human decisions are not technical unknowns

The original-project license remains intentionally unselected at the project owner's request while meaningful development/research remains. Dev24 sealing/promotion is also owner-controlled. Neither item should be “closed” by an automated audit.

## Practical priority

The registry separates tasks that can plausibly be advanced with retained source evidence from tasks that fundamentally need new runtime/corpus evidence. In particular, **do not manufacture native blended skinning, stage rotation order, Xenos alpha behavior, emy_051 naming, or opaque GMX meanings merely to make the open list shorter**. Implementation-only items such as compressed/mipmapped TEX authoring, audio rebuild, shader compilation, and PS3 SDAT re-encryption are real future features, but they are not evidence gaps in the existing decoders.
