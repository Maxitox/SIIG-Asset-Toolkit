# Dev24 release-readiness audit

This is a **WIP readiness audit**, not a sealed release decision. Sealed v2.10.0-dev23 remains immutable.

## Current consistency gates

- Toolkit version: `2.10.0-dev24`.
- Desktop GUI: `0.42.0-dev24`.
- Boss matrix: 18 total = 14 deep runtime + 3 exact gameplay-pose + 1 native-inspection-only.
- THE MOON is the sole native-only boss and exposes the exact `the-moon-controller` sampler without fake node scaling.
- Root `RELEASE_MANIFEST.json` is regenerated from the current source tree and checked by selftest; the finalized dev24 WIP readiness tree contains **715 manifest-tracked source files** (the manifest excludes itself).
- Built-in regression gate: **159/159 passed** on the finalized working tree; the checkpoint builder must repeat this from a fresh extracted package before the WIP is accepted.
- `reference/provenance/PROVENANCE.json`, `SOURCES.csv`, Credits, third-party notices and AI disclosure are current-facing.
- TrueAncestor EDAT Rebuilder is represented explicitly as a historical external fallback; it is not bundled and no code is copied.
- Source-only packaging contains no game binaries/assets and no external executable/library payloads.
- Historical dev20–dev23 release notes/validation files retain their period-correct counts; current docs carry explicit dev24 follow-ups instead of rewriting sealed history.

## Publication gates that remain human decisions

- Original project code still has **no selected public license**. Choose one before public redistribution.
- Preserve the Xenia BSD-3-Clause notice and all provenance/AI disclosure files.
- In-Blender UI/operator validation remains a documented external-environment gap.
- Do not seal dev24 merely because readiness checks pass; sealing/version promotion remains an explicit project-owner decision.

### WIP164 route compatibility follow-up

The current route-playback regression additionally checks explicit Bmap13/Bmap15 DAT compatibility against the proven WARNING special-resource requests while preserving the separate unresolved canonical-ownership/route-initialization boundary. At the WIP164 checkpoint this added no source files and the source manifest remained 712 entries; WIP165 supersedes that package-count state with the usable-preview additions above.


### WIP165 usable-preview gate

WIP165 adds the first explicit end-to-end usability gate on the canonical retail outer packages, while remaining an unsealed dev24 checkpoint. Xbox 360 and PS3 both complete direct-package extraction/conversion, Stage Explorer, Visualizer Simulator, Asset Viewer and SHA-256 output-manifest generation. Independent later re-hash verification passes **16,567/16,567 Xbox files** and **16,422/16,422 PS3 files** with zero integrity/privacy issues. PS3 internally authenticates/decrypts all six SIIG SDAT resources / 18 blocks with no external fallback.

GUI 0.42.0-dev24 makes Rip + verify the primary first-run action, persists convenience settings outside project outputs, opens the verified Asset Viewer optionally, and forwards the completed rip to Mod Workspace. Resume adds source/plaintext SHA-bound PS3 SDAT caching and safe reuse of unchanged Stage Explorer/Visualizer/Asset Viewer output. Manifest and explicit verification hashing are deterministic in sorted output order while using a bounded standard-library thread pool for independent file reads.

These usability results do not convert the living research-boundary registry into release blockers. Evidence-absent runtime/shader/GMX semantics and external Blender UI validation remain documented limitations. Project license selection and sealing remain owner decisions.
