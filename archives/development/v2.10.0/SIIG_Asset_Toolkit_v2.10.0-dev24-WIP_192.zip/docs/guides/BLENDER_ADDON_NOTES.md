# Blender add-on

The current `addons/SIIG_Blender_Addon_v0.3.0.zip` supports Blender 3.6 or newer.

The add-on deliberately does **not** implement a second GMX parser. Raw GMX import loads the selected toolkit installation, runs the verified GMX → glTF exporter in Blender's Python process, and hands the temporary glTF to Blender's built-in importer. This keeps Blender results aligned with command-line conversion fixes.

## Installation

1. Open **Edit → Preferences → Add-ons** in Blender.
2. Choose **Install from Disk** and select `addons/SIIG_Blender_Addon_v0.3.0.zip`.
3. Enable **SIIG Asset Toolkit**.
4. In the add-on preferences, choose the folder containing `siig_toolkit.py`.

An alternative is to set the `SIIG_TOOLKIT_HOME` environment variable to the toolkit folder. Add-on 0.3.0 retains the 0.2.1 upward source-tree discovery fix, so the readable source copy inside an unpacked toolkit can find the adjacent `siig_toolkit.py` without accidentally stopping at `addons/`.

## Raw GMX features

- File → Import → **Space Invaders Infinity Gene (.gmx)**.
- Multi-file selection and recursive folder import.
- Optional V-coordinate flip and configurable texture-search root.
- Optional collection per raw GMX.
- Source filename and toolkit version stored as Blender custom properties.
- Missing textures reported without discarding geometry.

## Assembled-model visibility

Toolkit Boss/Entity assemblies intentionally preserve native face/solid (`_F`) and edge/outline (`_E`) meshes as separate Blender objects. Hiding only one mesh object therefore leaves its overlapping sibling visible.

- **Import SIIG Assembly (.gltf/.glb)** imports an assembled toolkit output and automatically builds logical part collections.
- **Organize SIIG Part Collections** can post-process an already imported toolkit assembly.

Each toolkit `siigAssemblyModel` master becomes one `SIIG_PART_*` collection containing that master and its native descendants, stopping at nested child-part masters. Use the **collection eye/monitor controls** in Blender's Outliner to hide/show a whole logical part while native transform parenting and animations stay intact.

## SIIG Style Preview (0.3.0)

The sidebar now has a **SIIG Style Preview** box. It is optional, locally generated and removable.

### White native outlines

The exporter already retains SIIG's native line/edge pass, recognized from `_E` naming, edge materials and a conservative imported-line fallback. Blender final renders do not treat bare mesh edges as visible shaded geometry, so the preview creates thin white emissive curve objects from the existing native edge segments.

The generated objects are marked `siig_style_preview_outline`, parented to the original `_E` objects so animation/transform inheritance remains intact, and use a dedicated `SIIG_Preview_Outline_White` material. Refreshing first removes only those marked preview objects. The imported GMX/assembly remains unchanged.

### Compositor scanline overlay

Scanlines are a **post-process overlay**, not a material effect. Enabling them:

1. preserves the current source connected to the active Composite node;
2. creates a generated one-pixel-wide grayscale scanline image for the current output height;
3. scales the pattern to render size using Blender's compositor Scale node;
4. multiplies the pattern over the pre-existing final image source; and
5. reconnects that result to Composite.

**Remove SIIG Style Preview** restores the previous Composite input link and, when the add-on had to enable compositor nodes itself, restores the prior `use_nodes` state. Existing unrelated compositor nodes are not deleted.

Spacing, thickness, strength and outline thickness are adjustable. The pattern is pixel-based, so refresh it after changing render resolution. Auto-apply after SIIG import is enabled by default but can be disabled.

## Validation boundary

The release regression validates Python syntax, package/source identity, expected operators, logical-master metadata handling, outline classification/generation contracts, scanline compositor-node contracts, source-tree discovery and non-destructive hierarchy/link-restoration rules.

Blender itself is not available in the release-build environment. The `_E` geometry source is native/recovered, but generated curve width and scanline appearance are host presentation controls and are **not** claimed to reproduce exact Xenos/RSX line rasterization, antialiasing or final scanout. Final visual/UI behavior remains an in-Blender runtime gate.
