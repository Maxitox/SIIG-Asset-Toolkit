# Dev24 release-readiness audit

This is a **WIP readiness audit**, not a sealed release decision. Sealed v2.10.0-dev23 remains immutable.

## Current consistency gates

- Toolkit version: `2.10.0-dev24`.
- Desktop GUI: `0.41.0-dev24`.
- Boss matrix: 18 total = 14 deep runtime + 3 exact gameplay-pose + 1 native-inspection-only.
- THE MOON is the sole native-only boss and exposes the exact `the-moon-controller` sampler without fake node scaling.
- Root `RELEASE_MANIFEST.json` is regenerated from the current source tree and checked by selftest; the finalized dev24 WIP readiness tree contains **712 manifest-tracked source files** (the manifest excludes itself).
- Built-in regression gate: **158/158 passed** on the finalized working tree; the checkpoint builder must repeat this from a fresh extracted package before the WIP is accepted.
- `reference/provenance/PROVENANCE.json`, `SOURCES.csv`, Credits, third-party notices and AI disclosure are current-facing.
- TrueAncestor EDAT Rebuilder is represented explicitly as a historical external fallback; it is not bundled and no code is copied.
- Source-only packaging contains no game binaries/assets and no external executable/library payloads.
- Historical dev20–dev23 release notes/validation files retain their period-correct counts; current docs carry explicit dev24 follow-ups instead of rewriting sealed history.

## Publication gates that remain human decisions

- Original project code still has **no selected public license**. Choose one before public redistribution.
- Preserve the Xenia BSD-3-Clause notice and all provenance/AI disclosure files.
- In-Blender UI/operator validation remains a documented external-environment gap.
- Do not seal dev24 merely because readiness checks pass; sealing/version promotion remains an explicit project-owner decision.
