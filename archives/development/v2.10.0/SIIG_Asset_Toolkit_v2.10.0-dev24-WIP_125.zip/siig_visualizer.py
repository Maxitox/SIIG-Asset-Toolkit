#!/usr/bin/env python3
"""Offline SIIG visualizer simulator.

The dev23 renderer keeps recovered data and approximated rendering separate:

* DAT timing/state is decoded from the game.
* The 29-value ParameterSet row, 57 SequenceSet slots and exact ten-SHAPE
  resource order are recovered facts.
* June 10 Visualizer Check Mode code now grounds the debug control surface:
  VolumeSet 0=from BGM / 1=from Stick, X clears the feedback surface, Y toggles
  debug text, and all numeric control ranges/defaults are recovered from the
  executable's 30-row menu table.
* Fix Rotation is a signed angle override, not a boolean.  Zero leaves the
  normal accumulated rotation path active; a non-zero value supplies the
  fixed angle used by the visualization transform.
* ParameterSet.nut and SequenceSet.nut are parsed from a supplied rip when
  available.  Their proprietary rows are never bundled into the source-only
  toolkit.

Exact SHAPE sprite pixels, the fixed-position coordinates behind Position Fix
1..9, and the final framebuffer blend/order are still unresolved.  The HTML
labels those boundaries instead of presenting approximations as recovered
runtime behavior.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import siig_toolkit as toolkit

VISUALIZER_OPCODES = set(range(0xC8, 0xCF))
MAX_SCRIPT_BYTES = 8 * 1024 * 1024
MAX_NUT_BYTES = 2 * 1024 * 1024

# Exact resource order recovered from visualizer.bin.
SHAPE_RESOURCES = (
    "WhiteCircle",
    "line",
    "3line",
    "square",
    "triangle",
    "WhiteCircle2",
    "line2",
    "3line2",
    "square2",
    "triangle2",
)

# 29 serialized ParameterSet values.  Position Free is one debug-menu row but
# serializes as two numbers, which is why the menu has 28 parameter rows while
# the NUT row width is 29.
PARAMETER_FIELDS = (
    "magnify_scale_x_min",
    "magnify_scale_x_max",
    "magnify_scale_y_min",
    "magnify_scale_y_max",
    "magnify_a_min",
    "magnify_a_max",
    "bg_r",
    "bg_g",
    "bg_b",
    "bg_a",
    "shape",
    "position_fix",
    "position_free_x",
    "position_free_y",
    "rotation_base",
    "add_rotation",
    "fix_rotation",
    "scale_x_min",
    "scale_x_max",
    "scale_y_min",
    "scale_y_max",
    "rgb_r_min",
    "rgb_r_max",
    "rgb_g_min",
    "rgb_g_max",
    "rgb_b_min",
    "rgb_b_max",
    "rgb_a_min",
    "rgb_a_max",
)

# June 10 executable VisualizerCheckMode menu table at 0x82574550.  Integer
# storage scaling is normalized here to the values printed by the game's own
# format strings.  The free-position bounds come from Function_821839B8.
VISUALIZER_CHECK_CONTROLS = {
    "volume_source": {"default": 1, "min": 0, "max": 1, "options": ["from BGM", "from Stick"]},
    "bgm_index": {"default": 0, "min": 0, "max": 50, "step": 1},
    "magnify_scale_x_min": {"default": 1.03, "min": 0.8, "max": 2.0, "step": 0.001},
    "magnify_scale_x_max": {"default": 1.03, "min": 0.8, "max": 2.0, "step": 0.001},
    "magnify_scale_y_min": {"default": 1.03, "min": 0.8, "max": 2.0, "step": 0.001},
    "magnify_scale_y_max": {"default": 1.03, "min": 0.8, "max": 2.0, "step": 0.001},
    "magnify_a_min": {"default": 1.0, "min": 0.7, "max": 1.0, "step": 0.001},
    "magnify_a_max": {"default": 1.0, "min": 0.7, "max": 1.0, "step": 0.001},
    "bg_r": {"default": 0, "min": 0, "max": 255, "step": 1},
    "bg_g": {"default": 0, "min": 0, "max": 255, "step": 1},
    "bg_b": {"default": 0, "min": 0, "max": 255, "step": 1},
    "bg_a": {"default": 0, "min": 0, "max": 255, "step": 1},
    "shape": {"default": 0, "min": 0, "max": 9, "step": 1},
    "position_fix": {"default": 0, "min": 0, "max": 9, "step": 1},
    "position_free_x": {"default": 0, "min": -560, "max": 560, "step": 1},
    "position_free_y": {"default": 0, "min": -360, "max": 360, "step": 1},
    "rotation_base": {"default": 0.1, "min": -365.0, "max": 365.0, "step": 0.1},
    "add_rotation": {"default": 0.0, "min": -730.0, "max": 730.0, "step": 0.1},
    "fix_rotation": {"default": 0.0, "min": -365.0, "max": 365.0, "step": 0.1},
    "scale_x_min": {"default": 1.0, "min": 0.01, "max": 4.0, "step": 0.001},
    "scale_x_max": {"default": 1.0, "min": 0.01, "max": 4.0, "step": 0.001},
    "scale_y_min": {"default": 1.0, "min": 0.01, "max": 4.0, "step": 0.001},
    "scale_y_max": {"default": 1.0, "min": 0.01, "max": 4.0, "step": 0.001},
    "rgb_r_min": {"default": 128, "min": 0, "max": 255, "step": 1},
    "rgb_r_max": {"default": 255, "min": 0, "max": 255, "step": 1},
    "rgb_g_min": {"default": 0, "min": 0, "max": 255, "step": 1},
    "rgb_g_max": {"default": 0, "min": 0, "max": 255, "step": 1},
    "rgb_b_min": {"default": 0, "min": 0, "max": 255, "step": 1},
    "rgb_b_max": {"default": 0, "min": 0, "max": 255, "step": 1},
    "rgb_a_min": {"default": 255, "min": 0, "max": 255, "step": 1},
    "rgb_a_max": {"default": 255, "min": 0, "max": 255, "step": 1},
}


def _find_media(input_path: Path) -> Path | None:
    candidates = (
        input_path / "assets" / "Media",
        input_path / "Media",
        input_path / "assets" / "USRDIR",
        input_path / "USRDIR",
        input_path,
    )
    for candidate in candidates:
        if (candidate / "script").is_dir():
            return candidate
    return None


def _visualizer_timelines(input_path: Path | None) -> list[dict]:
    if input_path is None:
        return []
    media = _find_media(input_path)
    if media is None:
        return []
    result: list[dict] = []
    for path in sorted((media / "script").glob("*.dat"), key=lambda p: p.name.lower()):
        try:
            if path.stat().st_size > MAX_SCRIPT_BYTES:
                continue
            parsed = toolkit.parse_dat_bytes(path.read_bytes())
        except Exception:
            continue
        events = []
        for record in parsed["records"]:
            if record["opcode"] not in VISUALIZER_OPCODES:
                continue
            events.append({
                "frame": record["absolute_frame"],
                "opcode": record["opcode_name"],
                "args": record["args_signed"],
                "fields": record["semantic"]["fields"],
            })
        if events:
            result.append({
                "script": path.name,
                "duration_frames": parsed["duration_frames"],
                "events": events,
            })
    return result


def _find_visualizer_set_file(input_path: Path | None, name: str) -> Path | None:
    if input_path is None or not input_path.exists():
        return None
    candidates = (
        input_path / name,
        input_path / "visualizerSet" / name,
        input_path / "assets" / "visualizerSet" / name,
        input_path / "assets" / "Media" / "visualizerSet" / name,
        input_path / "Media" / "visualizerSet" / name,
        input_path / "converted_assets" / "visualizerSet" / name,
    )
    for path in candidates:
        if path.is_file() and path.stat().st_size <= MAX_NUT_BYTES:
            return path
    try:
        for path in input_path.rglob(name):
            if path.is_file() and path.stat().st_size <= MAX_NUT_BYTES:
                return path
    except OSError:
        return None
    return None


def _parse_nut_number(token: str) -> int | float:
    token = token.strip()
    if not token:
        raise ValueError("empty NUT number")
    value = float(token)
    if not any(ch in token.lower() for ch in (".", "e")) and value.is_integer():
        return int(value)
    return value


def _parse_nut_rows(text: str, prefix: str) -> list[list[int | float]]:
    pattern = re.compile(rf"\b{re.escape(prefix)}_(\d+)\s*<-\s*\[([^\]]*)\]", re.MULTILINE)
    rows: dict[int, list[int | float]] = {}
    for match in pattern.finditer(text):
        index = int(match.group(1))
        values = [_parse_nut_number(token) for token in match.group(2).split(",") if token.strip()]
        rows[index] = values
    if not rows:
        return []
    maximum = max(rows)
    return [rows.get(i, []) for i in range(maximum + 1)]


def _visualizer_sets(input_path: Path | None) -> dict:
    parameter_path = _find_visualizer_set_file(input_path, "ParameterSet.nut")
    sequence_path = _find_visualizer_set_file(input_path, "SequenceSet.nut")
    parameter_rows: list[list[int | float]] = []
    sequence_rows: list[list[int | float]] = []
    try:
        if parameter_path is not None:
            parameter_rows = _parse_nut_rows(parameter_path.read_text(encoding="utf-8", errors="replace"), "PARAM")
    except (OSError, ValueError):
        parameter_rows = []
    try:
        if sequence_path is not None:
            sequence_rows = _parse_nut_rows(sequence_path.read_text(encoding="utf-8", errors="replace"), "SEQUENCE")
    except (OSError, ValueError):
        sequence_rows = []
    parameter_sets = []
    for index, values in enumerate(parameter_rows):
        if len(values) != len(PARAMETER_FIELDS):
            continue
        parameter_sets.append({"id": index, "values": values})
    sequence_sets = []
    for index, values in enumerate(sequence_rows):
        if not values:
            continue
        sequence_sets.append({"id": index, "parameter_ids": [int(value) for value in values]})
    return {
        "parameter_sets": parameter_sets,
        "sequence_sets": sequence_sets,
        "source_files": [name for name, path in (("ParameterSet.nut", parameter_path), ("SequenceSet.nut", sequence_path)) if path is not None],
    }


def _timeline_presets(timelines: list[dict], sequence_sets: list[dict]) -> list[dict]:
    sequence_map = {item["id"]: [value for value in item["parameter_ids"] if value >= 0] for item in sequence_sets}
    presets: list[dict] = []
    for timeline in timelines:
        for event in timeline.get("events", []):
            if event.get("opcode") != "VL_SEQUENCESET" or not event.get("args"):
                continue
            sequence_id = int(event["args"][0])
            presets.append({
                "script": timeline["script"],
                "frame": int(event["frame"]),
                "sequence_id": sequence_id,
                "parameter_ids": sequence_map.get(sequence_id, []),
            })
    return presets


def _html(dataset: dict) -> str:
    payload = json.dumps(dataset, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    template = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SIIG Visualizer Simulator</title>
<style>
:root{color-scheme:dark;background:#08090d;color:#eef1f7;font:14px system-ui,sans-serif}*{box-sizing:border-box}body{margin:0}header{padding:12px 16px;background:#111621;border-bottom:1px solid #293247;display:flex;gap:10px;align-items:center;flex-wrap:wrap;position:sticky;top:0;z-index:5}h1{font-size:18px;margin:0 14px 0 0}button,select,input,audio{background:#1a2130;color:#eef;border:1px solid #3a465e;border-radius:6px;padding:6px 8px}button{cursor:pointer}main{display:grid;grid-template-columns:minmax(350px,455px) 1fr;min-height:calc(100vh - 58px)}aside{padding:14px;border-right:1px solid #293247;overflow:auto}section{padding:14px;min-width:0}fieldset{border:1px solid #2e394f;border-radius:8px;margin:0 0 10px;padding:10px}legend{color:#b9c7df;padding:0 5px}.row{display:grid;grid-template-columns:1fr 138px;gap:8px;align-items:center;margin:5px 0}.pair{display:grid;grid-template-columns:1fr 1fr;gap:6px}.quad{display:grid;grid-template-columns:repeat(4,1fr);gap:5px}.muted{color:#9ba8bd}.notice{padding:9px;border:1px solid #5b4b27;background:#251f14;color:#f0d99d;border-radius:8px;margin-bottom:10px}.good{border-color:#335d41;background:#15251b;color:#bde6c6}.canvas-wrap{display:flex;justify-content:center;align-items:center;min-height:440px;background:#000;border:1px solid #263047;border-radius:9px;overflow:hidden}canvas{display:block;max-width:100%;height:auto;background:#000}.timeline{margin-top:12px;border:1px solid #293247;border-radius:8px;overflow:auto;max-height:36vh}table{width:100%;border-collapse:collapse}th,td{padding:6px 8px;border-bottom:1px solid #222a3b;text-align:left}th{position:sticky;top:0;background:#151c29}.mono{font-family:ui-monospace,monospace;font-size:12px}.status{margin-top:8px;color:#b9c7df;font-family:ui-monospace,monospace}.small{font-size:12px}.schema{max-height:180px;overflow:auto;margin-top:7px;border:1px solid #252f42;border-radius:6px;padding:6px}.schema code{display:block;color:#b8c4d8;padding:1px 0}.hidden{display:none!important}.wide{width:100%}.meter{font-family:ui-monospace,monospace;color:#bde6c6}@media(max-width:950px){main{display:block}aside{border-right:0;border-bottom:1px solid #293247}.canvas-wrap{min-height:300px}}
</style></head><body>
<header><h1>SIIG Visualizer Simulator · dev23 check-mode controls</h1><button id="play" type="button">Pause</button><button id="reset" type="button">Reset feedback (X)</button><button id="toggleDebug" type="button">Hide debug text (Y)</button><label>SHAPE <select id="shape"></select></label></header>
<main><aside>
<div class="notice good"><b>June 10 executable-backed controls.</b> X clears the feedback surface, Y toggles Visualizer info, VolumeSet 0 reads the BGM meter and 1 reads stick magnitude, and the original debug-menu ranges/defaults are reproduced below.</div>
<div class="notice small">Recovered facts are kept separate from approximation. <b>Fix Rotation is now exact as a signed angle override.</b> Position Fix 0 means free X/Y; values 1–9 enter the game's fixed-position path, but their final coordinates remain unresolved. Exact SHAPE pixels and final feedback blend/order also remain unresolved.</div>
<fieldset><legend>VolumeSet / input</legend>
<div class="row"><label>VolumeSet</label><select id="volumeSource"><option value="0">0 · from BGM</option><option value="1" selected>1 · from Stick</option></select></div>
<div class="row"><label>Left Stick magnitude</label><input id="stickVolume" type="range" min="0" max="1" step="0.001" value="0"></div>
<div class="muted small">Arrow keys or WASD temporarily drive the simulated stick to 1.0. The original code takes the absolute stick value.</div>
<div class="row"><label>Host BGM audio</label><input id="bgmFile" type="file" accept="audio/*"></div>
<audio id="bgmAudio" class="wide" controls></audio><div id="bgmMeter" class="meter small">BGM meter: −∞ dBFS · normalized 0.000</div>
<div class="muted small">The browser bridge maps −60..0 dBFS to 0..1. The game-side getter returns an already-computed float; its upstream audio-meter transfer curve is not yet recovered.</div>
</fieldset>
<fieldset><legend>Feedback / magnify</legend>
<div class="row"><label>Magnify Scale X min/max</label><div class="pair"><input id="magxmin" type="number" min="0.8" max="2" step="0.001" value="1.030"><input id="magxmax" type="number" min="0.8" max="2" step="0.001" value="1.030"></div></div>
<div class="row"><label>Magnify Scale Y min/max</label><div class="pair"><input id="magymin" type="number" min="0.8" max="2" step="0.001" value="1.030"><input id="magymax" type="number" min="0.8" max="2" step="0.001" value="1.030"></div></div>
<div class="row"><label>Magnify A min/max</label><div class="pair"><input id="magamin" type="number" min="0.7" max="1" step="0.001" value="1.000"><input id="magamax" type="number" min="0.7" max="1" step="0.001" value="1.000"></div></div>
<div class="row"><label>Rotation Base (deg/update)</label><input id="rotbase" type="number" min="-365" max="365" step="0.1" value="0.1"></div>
<div class="row"><label>Add Rotation</label><input id="rotadd" type="number" min="-730" max="730" step="0.1" value="0.0"></div>
<div class="row"><label>Fix Rotation (deg)</label><input id="rotfix" type="number" min="-365" max="365" step="0.1" value="0.0"></div>
<div class="muted small">Fix Rotation = 0 keeps accumulated rotation active. Any non-zero value overrides the visualization angle with that fixed angle.</div>
</fieldset>
<fieldset><legend>Stamp / position</legend>
<div class="row"><label>Position Fix</label><select id="positionFix"></select></div>
<div class="row"><label>Position Free X/Y</label><div class="pair"><input id="posx" type="number" min="-560" max="560" step="1" value="0"><input id="posy" type="number" min="-360" max="360" step="1" value="0"></div></div>
<div class="row"><label>Scale X min/max</label><div class="pair"><input id="sxmin" type="number" min="0.01" max="4" step="0.001" value="1"><input id="sxmax" type="number" min="0.01" max="4" step="0.001" value="1"></div></div>
<div class="row"><label>Scale Y min/max</label><div class="pair"><input id="symin" type="number" min="0.01" max="4" step="0.001" value="1"><input id="symax" type="number" min="0.01" max="4" step="0.001" value="1"></div></div>
</fieldset>
<fieldset><legend>Background RGBA</legend>
<div class="quad"><input id="bgr" aria-label="BG R" type="number" min="0" max="255" value="0"><input id="bgg" aria-label="BG G" type="number" min="0" max="255" value="0"><input id="bgb" aria-label="BG B" type="number" min="0" max="255" value="0"><input id="bga" aria-label="BG A" type="number" min="0" max="255" value="0"></div>
</fieldset>
<fieldset><legend>Stamp RGBA min/max</legend>
<div class="row"><label>R min/max</label><div class="pair"><input id="rmin" type="number" min="0" max="255" value="128"><input id="rmax" type="number" min="0" max="255" value="255"></div></div>
<div class="row"><label>G min/max</label><div class="pair"><input id="gmin" type="number" min="0" max="255" value="0"><input id="gmax" type="number" min="0" max="255" value="0"></div></div>
<div class="row"><label>B min/max</label><div class="pair"><input id="bmin" type="number" min="0" max="255" value="0"><input id="bmax" type="number" min="0" max="255" value="0"></div></div>
<div class="row"><label>A min/max</label><div class="pair"><input id="amin" type="number" min="0" max="255" value="255"><input id="amax" type="number" min="0" max="255" value="255"></div></div>
</fieldset>
<fieldset><legend>Recovered game presets</legend>
<div id="setStatus" class="muted small">No ParameterSet.nut / SequenceSet.nut loaded. Build the simulator from a full rip to enable exact game rows.</div>
<div class="row"><label>ParameterSet</label><select id="parameterPreset"></select></div><button id="applyParameter" type="button">Apply parameter row</button>
<div class="row"><label>SequenceSet</label><select id="sequencePreset"></select></div><button id="applySequence" type="button">Apply first active row</button>
<div class="row"><label>Stage / boss event</label><select id="timelinePreset"></select></div><button id="applyTimelinePreset" type="button">Jump to authored event + apply row</button>
<div class="muted small">SequenceSet preserves all 16 authored entries. “Apply first active row” is an inspection convenience, not a claim about sequence timing. Stage/boss events come directly from decoded <code>VL_SEQUENCESET</code> commands.</div>
</fieldset>
<fieldset><legend>Recovered parameter schema</legend><div class="muted small">29 values / ParameterSet row · 49 retail rows · 57 retail sequences</div><div id="schema" class="schema mono"></div></fieldset>
<fieldset><legend>Decoded stage / boss visualizer timeline</legend><div class="row"><label>Script</label><select id="script"></select></div><div class="row"><label>Authored frame</label><input id="frame" type="range" min="0" max="0" value="0"></div><div class="status" id="scriptStatus">No DAT timeline loaded.</div></fieldset>
</aside><section><div class="canvas-wrap"><canvas id="canvas" width="960" height="540"></canvas></div><div id="debugInfo"><div class="status" id="status"></div></div><div class="timeline"><table><thead><tr><th>Frame</th><th>Opcode</th><th>Arguments</th></tr></thead><tbody id="events"></tbody></table></div></section></main>
<script id="data" type="application/json">__DATA__</script><script>
const DB=JSON.parse(document.getElementById('data').textContent),$=id=>document.getElementById(id),can=$('canvas'),ctx=can.getContext('2d',{alpha:true});
const W=can.width,H=can.height,feedback=[document.createElement('canvas'),document.createElement('canvas')];for(const c of feedback){c.width=W;c.height=H}let front=0,running=true,last=performance.now(),accum=0,logicalFrames=0,rotationAccum=0,showDebugInfo=true,bgmLevel=0,bgmDb=-Infinity;const STEP=1/60;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,Number(v)||0)),num=id=>Number($(id).value)||0,mix=(a,b,t)=>a+(b-a)*t,rad=d=>d*Math.PI/180;
const stickKeys=new Set(),stickVolume=()=>clamp(Math.max(num('stickVolume'),stickKeys.size?1:0),0,1),volume=()=>$('volumeSource').value==='0'?bgmLevel:stickVolume(),mixControl=(a,b)=>mix(num(a),num(b),volume());
function colorNow(){const v=volume();return [clamp(mix(num('rmin'),num('rmax'),v),0,255),clamp(mix(num('gmin'),num('gmax'),v),0,255),clamp(mix(num('bmin'),num('bmax'),v),0,255),clamp(mix(num('amin'),num('amax'),v),0,255)]}
function resetFeedback(){for(const c of feedback)c.getContext('2d').clearRect(0,0,W,H);front=0;logicalFrames=0;rotationAccum=0;drawDisplay()}
function toggleDebug(){showDebugInfo=!showDebugInfo;$('debugInfo').classList.toggle('hidden',!showDebugInfo);$('toggleDebug').textContent=showDebugInfo?'Hide debug text (Y)':'Show debug text (Y)'}
function shapeStamp(g,name,cx,cy,sx,sy,rgba,stampAngle){g.save();g.translate(cx,cy);g.rotate(stampAngle);g.scale(sx,sy);g.strokeStyle=`rgba(${rgba[0]|0},${rgba[1]|0},${rgba[2]|0},${rgba[3]/255})`;g.fillStyle=g.strokeStyle;g.lineCap='round';g.lineJoin='round';const r=42;switch(name){case 'WhiteCircle':g.lineWidth=8;g.beginPath();g.arc(0,0,r,0,Math.PI*2);g.stroke();break;case 'line':g.lineWidth=8;g.beginPath();g.moveTo(-64,0);g.lineTo(64,0);g.stroke();break;case '3line':g.lineWidth=7;for(const y of [-17,0,17]){g.beginPath();g.moveTo(-58,y);g.lineTo(58,y);g.stroke()}break;case 'square':g.lineWidth=8;g.strokeRect(-42,-42,84,84);break;case 'triangle':g.lineWidth=8;g.beginPath();g.moveTo(0,-52);g.lineTo(48,36);g.lineTo(-48,36);g.closePath();g.stroke();break;case 'WhiteCircle2':g.beginPath();g.arc(0,0,r,0,Math.PI*2);g.fill();break;case 'line2':g.lineWidth=18;g.beginPath();g.moveTo(-64,0);g.lineTo(64,0);g.stroke();break;case '3line2':g.lineWidth=15;for(const y of [-21,0,21]){g.beginPath();g.moveTo(-58,y);g.lineTo(58,y);g.stroke()}break;case 'square2':g.fillRect(-42,-42,84,84);break;case 'triangle2':g.beginPath();g.moveTo(0,-52);g.lineTo(48,36);g.lineTo(-48,36);g.closePath();g.fill();break}g.restore()}
function logicalStep(){const src=feedback[front],dst=feedback[1-front],g=dst.getContext('2d',{alpha:true});g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='copy';g.clearRect(0,0,W,H);g.globalCompositeOperation='source-over';const ba=clamp(num('bga'),0,255)/255;if(ba>0){g.fillStyle=`rgba(${clamp(num('bgr'),0,255)|0},${clamp(num('bgg'),0,255)|0},${clamp(num('bgb'),0,255)|0},${ba})`;g.fillRect(0,0,W,H)}const mx=Math.max(0.001,mixControl('magxmin','magxmax')),my=Math.max(0.001,mixControl('magymin','magymax')),ma=clamp(mixControl('magamin','magamax'),0,2);const rotStep=num('rotbase')+num('rotadd')*volume();const fix=Math.round(num('positionFix')),freeX=num('posx'),freeY=num('posy');const cx=W/2+(fix?0:freeX),cy=H/2+(fix?0:freeY);g.save();g.globalAlpha=Math.min(1,ma);g.translate(cx,cy);g.rotate(rad(rotStep));g.scale(mx,my);g.translate(-cx,-cy);g.drawImage(src,0,0);g.restore();const fixRot=num('rotfix');if(Math.abs(fixRot)<1e-9)rotationAccum+=rotStep;const stampAngle=rad(Math.abs(fixRot)<1e-9?rotationAccum:fixRot);const rgba=colorNow(),sx=mixControl('sxmin','sxmax'),sy=mixControl('symin','symax');shapeStamp(g,$('shape').value,cx,cy,sx,sy,rgba,stampAngle);front=1-front;logicalFrames++}
function drawDisplay(){ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,W,H);ctx.fillStyle='#000';ctx.fillRect(0,0,W,H);ctx.drawImage(feedback[front],0,0);const v=volume(),name=$('shape').value;const mx=mixControl('magxmin','magxmax'),my=mixControl('magymin','magymax'),ma=mixControl('magamin','magamax'),fixRot=num('rotfix');$('status').textContent=`${name} · VolumeSet ${$('volumeSource').value==='0'?'BGM':'Stick'} ${v.toFixed(3)} · feedback scale ${mx.toFixed(3)}×${my.toFixed(3)} · A ${ma.toFixed(3)} · rotation ${Math.abs(fixRot)<1e-9?'accum '+rotationAccum.toFixed(1)+'°':'fixed '+fixRot.toFixed(1)+'°'} · ${logicalFrames} logical frames`;}
let audioCtx=null,analyser=null,audioSource=null,audioSamples=null,lastAudioUrl=null;const bgmAudio=$('bgmAudio');
function ensureAudioGraph(){if(analyser)return;const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;audioCtx=new AC();analyser=audioCtx.createAnalyser();analyser.fftSize=2048;audioSamples=new Float32Array(analyser.fftSize);audioSource=audioCtx.createMediaElementSource(bgmAudio);audioSource.connect(analyser);analyser.connect(audioCtx.destination)}
function updateBgmMeter(){if(!analyser||bgmAudio.paused){if(bgmAudio.paused){bgmLevel=0;bgmDb=-Infinity}}else{analyser.getFloatTimeDomainData(audioSamples);let sum=0;for(const x of audioSamples)sum+=x*x;const rms=Math.sqrt(sum/audioSamples.length);bgmDb=rms>1e-9?20*Math.log10(rms):-Infinity;bgmLevel=Number.isFinite(bgmDb)?clamp((bgmDb+60)/60,0,1):0}$('bgmMeter').textContent=`BGM meter: ${Number.isFinite(bgmDb)?bgmDb.toFixed(1):'−∞'} dBFS · normalized ${bgmLevel.toFixed(3)}`}
$('bgmFile').onchange=()=>{const file=$('bgmFile').files&&$('bgmFile').files[0];if(!file)return;if(lastAudioUrl)URL.revokeObjectURL(lastAudioUrl);lastAudioUrl=URL.createObjectURL(file);bgmAudio.src=lastAudioUrl;bgmAudio.load()};bgmAudio.addEventListener('play',()=>{ensureAudioGraph();if(audioCtx&&audioCtx.state==='suspended')audioCtx.resume()});
function tick(now){updateBgmMeter();let dt=Math.min(0.1,(now-last)/1000);last=now;if(running){accum+=dt;while(accum>=STEP){logicalStep();accum-=STEP}drawDisplay()}requestAnimationFrame(tick)}
for(const name of DB.evidence.shape_resources){const o=document.createElement('option');o.value=name;o.textContent=`${DB.evidence.shape_resources.indexOf(name)} · ${name}`;$('shape').appendChild(o)}$('shape').value=DB.evidence.shape_resources[DB.evidence.check_mode_controls.shape.default]||'WhiteCircle';
for(let i=0;i<=9;i++){const o=document.createElement('option');o.value=String(i);o.textContent=i===0?'0 · Free X/Y':`${i} · Fixed preset ${i} (coords unresolved)`;$('positionFix').appendChild(o)}
$('schema').innerHTML=DB.evidence.parameter_fields.map((x,i)=>`<code>${String(i).padStart(2,'0')} · ${x}</code>`).join('');
$('play').onclick=()=>{running=!running;$('play').textContent=running?'Pause':'Play';last=performance.now()};$('reset').onclick=resetFeedback;$('toggleDebug').onclick=toggleDebug;
const ignoredTypingTarget=e=>['INPUT','SELECT','TEXTAREA'].includes((e.target&&e.target.tagName)||'');document.addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(!ignoredTypingTarget(e)&&k==='x'&&!e.repeat){resetFeedback();e.preventDefault();return}if(!ignoredTypingTarget(e)&&k==='y'&&!e.repeat){toggleDebug();e.preventDefault();return}if(!ignoredTypingTarget(e)&&['arrowup','arrowdown','arrowleft','arrowright','w','a','s','d'].includes(k)){stickKeys.add(k);e.preventDefault()}});document.addEventListener('keyup',e=>stickKeys.delete(e.key.toLowerCase()));window.addEventListener('blur',()=>stickKeys.clear());
for(const el of document.querySelectorAll('input,select')){if(['script','frame','bgmFile'].includes(el.id))continue;el.addEventListener('input',()=>{if(!running)drawDisplay()})}
const paramSets=DB.parameter_sets||[],seqSets=DB.sequence_sets||[],timelinePresets=DB.timeline_presets||[],paramSel=$('parameterPreset'),seqSel=$('sequencePreset'),timelinePresetSel=$('timelinePreset');
if(paramSets.length){$('setStatus').textContent=`Loaded ${paramSets.length} ParameterSet rows and ${seqSets.length} SequenceSet rows from the supplied rip.`;for(const p of paramSets){const o=document.createElement('option');o.value=String(p.id);o.textContent=`PARAM_${p.id}`;paramSel.appendChild(o)}}else{paramSel.disabled=true;$('applyParameter').disabled=true}
if(seqSets.length){for(const s of seqSets){const active=s.parameter_ids.filter(x=>x>=0);const o=document.createElement('option');o.value=String(s.id);o.textContent=`SEQUENCE_${s.id} → ${active.length?active.map(x=>'PARAM_'+x).join(', '):'empty'}`;seqSel.appendChild(o)}}else{seqSel.disabled=true;$('applySequence').disabled=true}
if(timelinePresets.length){timelinePresets.forEach((p,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent=`${p.script} @ ${p.frame} → SEQUENCE_${p.sequence_id}${p.parameter_ids.length?' / '+p.parameter_ids.map(x=>'PARAM_'+x).join(', '):''}`;timelinePresetSel.appendChild(o)})}else{timelinePresetSel.disabled=true;$('applyTimelinePreset').disabled=true}
const fieldTargets=['magxmin','magxmax','magymin','magymax','magamin','magamax','bgr','bgg','bgb','bga',null,'positionFix','posx','posy','rotbase','rotadd','rotfix','sxmin','sxmax','symin','symax','rmin','rmax','gmin','gmax','bmin','bmax','amin','amax'];
function applyParameter(id){const p=paramSets.find(x=>x.id===Number(id));if(!p||p.values.length!==fieldTargets.length)return;for(let i=0;i<p.values.length;i++){if(i===10){const idx=Math.max(0,Math.min(DB.evidence.shape_resources.length-1,Math.round(Number(p.values[i])||0)));$('shape').value=DB.evidence.shape_resources[idx];continue}const target=fieldTargets[i];if(target)$(target).value=String(p.values[i])}rotationAccum=0;if(!running)drawDisplay()}
$('applyParameter').onclick=()=>applyParameter(paramSel.value);$('applySequence').onclick=()=>{const s=seqSets.find(x=>x.id===Number(seqSel.value));if(!s)return;const first=s.parameter_ids.find(x=>x>=0);if(first!==undefined){paramSel.value=String(first);applyParameter(first)}};
$('applyTimelinePreset').onclick=()=>{const p=timelinePresets[Number(timelinePresetSel.value)];if(!p)return;sel.value=p.script;frame.value=String(p.frame);renderTimeline();seqSel.value=String(p.sequence_id);const first=p.parameter_ids.find(x=>x>=0);if(first!==undefined){paramSel.value=String(first);applyParameter(first)}};
const sel=$('script'),frame=$('frame'),events=$('events'),scriptStatus=$('scriptStatus'),timelines=DB.timelines||[];if(timelines.length){for(const t of timelines){const o=document.createElement('option');o.value=t.script;o.textContent=t.script;sel.appendChild(o)}}else{const o=document.createElement('option');o.textContent='No decoded DAT timeline';o.value='';sel.appendChild(o);sel.disabled=true;frame.disabled=true}
function renderTimeline(){const t=timelines.find(x=>x.script===sel.value);events.innerHTML='';if(!t){scriptStatus.textContent='No DAT timeline loaded.';return}frame.max=t.duration_frames||0;const f=Number(frame.value);let active=false,display=false,seq=null,volumeScale=null,changeTime=null;for(const e of t.events){const tr=document.createElement('tr');tr.innerHTML=`<td>${e.frame}</td><td>${e.opcode}</td><td class="mono">${e.args.join(' ')||'—'}</td>`;events.appendChild(tr);if(e.frame>f)continue;if(e.opcode==='VL_START')active=true;if(e.opcode==='VL_END')active=false;if(e.opcode==='VL_DISP_ON')display=true;if(e.opcode==='VL_DISP_OFF')display=false;if(e.opcode==='VL_SEQUENCESET')seq=e.args[0];if(e.opcode==='VL_VOLUME_SCALE')volumeScale=e.args[0];if(e.opcode==='VL_CHANGETIME')changeTime=e.args[0]}if(seq!==null&&seqSets.some(x=>x.id===seq))seqSel.value=String(seq);scriptStatus.textContent=`frame ${f} · active ${active?'yes':'no'} · display ${display?'on':'off'} · sequence ${seq??'—'} · change time ${changeTime??'—'} · volume scale ${volumeScale??'—'}`}
sel.onchange=()=>{frame.value='0';renderTimeline()};frame.oninput=renderTimeline;renderTimeline();resetFeedback();requestAnimationFrame(tick);
</script></body></html>'''
    return template.replace("__DATA__", payload)


def build_visualizer_simulator(input_path: Path | None, output: Path) -> dict:
    timelines = _visualizer_timelines(input_path)
    sets = _visualizer_sets(input_path)
    dataset = {
        "format": "SIIG_VISUALIZER_SIMULATOR",
        "version": 3,
        "timelines": timelines,
        "parameter_sets": sets["parameter_sets"],
        "sequence_sets": sets["sequence_sets"],
        "timeline_presets": _timeline_presets(timelines, sets["sequence_sets"]),
        "evidence": {
            "primary_visual_reference": "June 10 Visualizer Check Mode footage",
            "runtime_assets": ["visualizerSet.bin.gz.sdat", "ParameterSet.nut", "SequenceSet.nut"],
            "parameter_preset_count": 49,
            "sequence_count": 57,
            "parameter_width": 29,
            "parameter_fields": list(PARAMETER_FIELDS),
            "shape_resources": list(SHAPE_RESOURCES),
            "check_mode_control_rows": 30,
            "check_mode_controls": VISUALIZER_CHECK_CONTROLS,
            "check_mode_input": {
                "volume_source_0": "from BGM",
                "volume_source_1": "from Stick",
                "reset_button": "X / input mask 0x40",
                "toggle_info_button": "Y / input mask 0x80",
                "position_free_bounds": {"x": [-560, 560], "y": [-360, 360]},
            },
            "loaded_set_files": sets["source_files"],
            "dat_opcodes": ["VL_START", "VL_END", "VL_DISP_ON", "VL_DISP_OFF", "VL_SEQUENCESET", "VL_CHANGETIME", "VL_VOLUME_SCALE"],
            "render_model": "ping-pong framebuffer feedback approximation plus executable-backed Visualizer Check controls",
            "unresolved": [
                "exact pixel content/filtering of the ten visualizer shape sprites",
                "fixed coordinates selected by Position Fix indices 1..9",
                "exact upstream BGM meter transfer curve before the check-mode float getter",
                "exact final framebuffer blend/order details",
            ],
        },
    }
    output.mkdir(parents=True, exist_ok=True)
    path = output / "SIIG_Visualizer_Simulator.html"
    toolkit.write_text_atomic(path, _html(dataset), encoding="utf-8")
    report = {
        "format": dataset["format"],
        "version": dataset["version"],
        "timeline_count": len(timelines),
        "event_count": sum(len(item["events"]) for item in timelines),
        "parameter_preset_count": 49,
        "sequence_count": 57,
        "loaded_parameter_preset_count": len(sets["parameter_sets"]),
        "loaded_sequence_count": len(sets["sequence_sets"]),
        "timeline_preset_count": len(dataset["timeline_presets"]),
        "check_mode_control_rows": 30,
        "shape_count": len(SHAPE_RESOURCES),
        "html": path.name,
    }
    toolkit.write_json_private(output / "VISUALIZER_SIMULATOR_MANIFEST.json", report, ensure_ascii=False)
    return report
