# Mod workspace workflow

`2.9.0-dev2` extends the mod-workspace project layer above the native asset builders. The goal is to remove manual BBX path surgery from ordinary modding experiments while keeping the original rip immutable.

## 1. Create a workspace

Start from a clean `rip-game` output:

```text
python siig_toolkit.py mod-init SIIG_Ripped -o My_SIIG_Mod --name "My SIIG Mod"
```

The workspace stores the source-rip path and a baseline SHA-256 for every top-level BBX archive. The game assets themselves remain in the user's rip; the toolkit release does not bundle them.

Use `mod-list` to discover stable archive/resource keys:

```text
python siig_toolkit.py mod-list My_SIIG_Mod
python siig_toolkit.py mod-list My_SIIG_Mod --archive <archive-key>
```

If the rip is moved later, pass `--rip <new-path>` to workspace commands.

## 2. Export an editable resource

For a supported native resource inside a BBX:

```text
python siig_toolkit.py mod-export My_SIIG_Mod <archive-key> <resource-path>
```

The command chooses the proven round-trip representation automatically:

- GMX -> fixed-layout edit JSON
- TEX -> PNG
- system-font CRP -> PNG
- DAT -> CSV
- MAP -> editable JSON plus previews
- ANM -> CSV
- COL -> PNG
- Bmap/Xmap/map4/map5 -> stage3D editable JSON
- wall/Xwall/stage_generate -> stagewall editable JSON

Edit the file under `editable/`. `mod-build` notices when the canonical editable file differs from its export baseline, compiles it back to the native format, and stages it automatically.

## 3. Edit whole localization archives

`text.bin` and `message.bin` are BBX archives whose human-editable representation describes the whole archive. Use:

```text
python siig_toolkit.py mod-export-archive My_SIIG_Mod <text-archive-key>
python siig_toolkit.py mod-export-archive My_SIIG_Mod <message-archive-key>
```

For `text.bin`, edit `text_strings.csv`. For `message.bin`, edit the six `message_<language>_readable.nut` files. The build step recompiles the complete native localization BBX when any tracked file changes.

### Audio editing in Mod Workspace (dev24 WIP186)

**Xbox 360:** selecting the `sound.bin` / `media/sound` archive in the Simple tree shows **AUDIO · EDIT**. **Open selected** runs the whole-archive export and leaves only the WAV files that actually feed `mod-build`. Edit a WAV without changing its channel count, sample rate, or sample count, then press **Refresh marks**: the archive changes from **Exported** to **Edited**. `mod-build` keeps untouched XMA2 streams unchanged and replaces only edited slots with XACT PCM16 before rebuilding the nested BBX archive. FFmpeg is required to obtain editable WAVs from XMA2 source slots. Native XMA2 encoding is not bundled or claimed.

**PS3:** supported SBlk/989SND `.bnk` resources export their fixed-slot mono PS-ADPCM entries as WAV files directly through ordinary `mod-export`. Edited WAVs must remain mono PCM16 with the exact native sample rate and sample count. `mod-build` encodes the changed slot back to Sony PS-ADPCM while preserving its stream offset/capacity and frame-control bytes.

Both paths use persistent baseline hashes, so audio status survives GUI restarts just like text/model edits. Xbox runtime acceptance of the PCM16-substituted retail bank and PS3 runtime acceptance of edited SBlk payloads remain external validation tasks.

## 4. Stage an already-native replacement

If a format is not integrated into `mod-export`, or another tool produced the native file, stage it directly:

```text
python siig_toolkit.py mod-stage My_SIIG_Mod <archive-key> <resource-path> replacement.bin
```

A complete rebuilt BBX can be staged with:

```text
python siig_toolkit.py mod-stage-archive My_SIIG_Mod <archive-key> rebuilt_archive.bin
```

## Integrated glTF model + texture + animation import (2.9.0-dev6)

For a GMX already present in the source rip, the workspace can now compile an edited glTF and stage its linked native texture payloads in one operation:

```text
python siig_toolkit.py mod-import-gltf My_SIIG_Mod <archive-key> <model.gmx> edited.gltf
```

The command enables the GMX animation/texture/scene/mesh synchronization stack, stages the rebuilt GMX, compiles glTF translation/rotation/scale channels—including multi-bone clips and CUBICSPLINE samplers—into synchronized native 30 Hz `MOTN`/`ANIM` tracks, follows material `baseColorTexture` PNGs, and builds native TEX payloads. Existing same-layout TEX resources still use the byte-preserving template encoder first. If dimensions differ, or a genuinely new TXIF has no native TEX donor at all, `2.9.0-dev3` synthesizes a canonical layout from the workspace platform and can append the result as a new named BBX member.

Xbox synthesis follows the corpus-proven tiled 8_8_8_8 layout and therefore removes the previous same-dimension donor restriction. PS3 synthesis creates the understood linear A8R8G8B8 wrapper structurally; newly synthesized PS3 wrappers still require emulator/hardware validation before runtime compatibility is claimed. `--allow-reference-only` remains available for research cases where a native payload is intentionally omitted.

Because BBX entry count/name tables change when a member is added, `.siigmod` packaging switches that archive to a baseline-dependent **archive-level delta**. The clean BBX is still not redistributed.

## 5. Build and verify

```text
python siig_toolkit.py mod-build My_SIIG_Mod --clean
python siig_toolkit.py mod-verify My_SIIG_Mod
```

The build writes:

- `build/decompressed_bbx/` — verified rebuilt BBX archives;
- `build/game_patch/` — files placed at the original game-relative path when the outer packaging can be reproduced safely;
- `build/MOD_BUILD_REPORT.json` — exact original/rebuilt hashes, affected resources, package status, and limitations.

For ordinary Xbox `.gz` resources the workspace emits deterministic gzip-wrapped replacements. Raw `.bin` BBX inputs are emitted directly.

## Share a workspace as a baseline-dependent package

Dev24 adds `.siigmod` distribution without bundling clean source resources:

```text
python siig_toolkit.py mod-pack My_SIIG_Mod -o My_Mod.siigmod
python siig_toolkit.py mod-package-info My_Mod.siigmod
python siig_toolkit.py mod-apply My_Mod.siigmod SIIG_Ripped Applied_Mod --build
```

See [`MOD_PACKAGES.md`](MOD_PACKAGES.md) for the delta format, baseline checks, conflict policy, and distribution boundaries.

## Safety and current limits

- The source rip is treated as immutable. A source archive whose SHA-256 changed since `mod-init` is rejected until the workspace is recreated or pointed at the correct rip.
- Every rebuilt BBX is reparsed and verified before it is reported as built.
- `mod-verify` checks source baselines, rebuilt BBX hashes, and gzip payload identity.
- PS3 NPDRM/SDAT **re-encryption is not implemented**. PS3 SDAT-backed changes therefore remain available as rebuilt/decompressed BBX files for research or deployment methods that do not require recreating the signed/encrypted SDAT wrapper.
- A successfully rebuilt native asset or BBX does not automatically prove that every possible edit is accepted by the retail game. Keep changes small and test them in an appropriate emulator/test environment.
- GMX can synthesize mesh/scene/TXIF/MOTN/ANIM graph nodes, vertex/material schemas, canonical TEX payloads, and—through standalone `gltf2gmx-new`—a canonical GMX root without an original GMX. Mod Workspace `mod-import-gltf` remains replacement-oriented and still begins from the selected clean GMX resource. Remaining major boundaries include glTF skin/joint-weight import, compressed or mipmapped texture variants, platform shader compilation, opaque semantics, and runtime validation of fully original scenes.

## Retail corpus validation through dev24

The user-supplied retail Xbox corpus was used only as external validation input and is not bundled. Dev23 reproduced all 13 GMXs in `player.bin` byte-for-byte through the GMX editable/rebuild path. Retail `text.bin` (542 strings) and `message.bin` (284 groups, 1295 strings per language) also rebuilt byte-for-byte from their readable edit representations. Dev24 expands the same external validation to 307 GMXs and large retail DAT/MAP/stage-table corpora; see `validation/REAL_CORPUS_ROUNDTRIP_DEV24.json`. No retail payload is bundled.


### 2.9.0-dev2 schema fallback

`mod-import-gltf` now enables native schema synthesis as a fallback. Compatible original MESH/ARRY and MTRL schemas are still reused when present, but a genuinely new Blender mesh/material is no longer rejected solely because no matching donor declaration exists. The remaining texture payload step is still TEX-layout donor constrained.


### Rigid skin compatibility (2.9.0-dev7)

`Import glTF + TEX` now enables the rigid-skin compatibility pass automatically. A Blender/glTF skinned object may be staged when every vertex is assigned to the same single joint with unit weight; the mesh/material is attached to that native BONE. True blended weights are rejected before anything is staged. This keeps mod packages inside the representation confirmed by the retail GMX corpus.
## Desktop GUI Simple-mode asset tree (dev24 WIP184)

Desktop GUI **0.47.0-dev24** makes **List Assets** part of the beginner workflow. After creating or choosing a workspace, click **List Assets** to reveal an archive/resource tree directly below the Mod Workspace buttons.

The tree is intentionally a lightweight modding browser rather than a second Asset Viewer. It shows the archive hierarchy, resource name/type/size and one persistent workspace state:

- **Untouched** — no editable export or staged replacement exists.
- **Exported** — an editable representation exists and still matches its export baseline.
- **Edited** — the editable representation differs from its baseline.
- **Staged** — a native replacement has been staged/built for the resource.
- **Added** — the workspace contains a genuinely new archive member.

Double-click a resource, or select it and press **Open selected**. For a supported untouched resource the GUI runs the normal audited `mod-export` path, refreshes the tree, and opens the resulting editable file. Supported whole localization archives (`text.bin` / `message.bin`) can likewise be opened from their archive row. After saving a file in an external editor, press **Refresh marks** to recalculate its state. Build and Verify also refresh an already-open tree automatically.

The marks are derived from `meta/edits` baseline hashes plus staged/addition files. They therefore survive closing/reopening the GUI and do not depend on in-memory click history. Selecting a GMX row also fills the Advanced-mode archive/resource fields so the same selection can be used with **Import glTF + TEX**.

