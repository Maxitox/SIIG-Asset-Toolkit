# SIIG audio notes

## Xbox 360 — XACT3/XMA2

`sound.bin` contains nested XSB/XWB banks. The retail Xbox corpus resolves 86 named streams: 83 SE cues plus `BGM007`, `BGM008_MIX_C`, and `BGM_XACT_SE33`. The toolkit writes RIFF/XMA2 wrappers and invokes FFmpeg when available for PCM WAV output; FFmpeg is not bundled.

```bat
python siig_toolkit.py xact2wav sound.bin -o audio
```

The supplied retail Xbox regression decodes 86/86 streams with zero failures when FFmpeg is available. Ready WMA media is copied unchanged.

## PlayStation 3 — Sony 989SND/SCREAM SBlk v3

The retail PS3 bank is a big-endian Sony SBlk v3/989SND bank. The current narrow parser resolves all 84 sound/grain/wave entries and names, and the full 4,200,384-byte audio region is accounted for by the 84 streams. SIIG uses mono Sony PS-ADPCM for these entries.

```bat
python siig_toolkit.py sblk2wav sound.bnk -o ps3_audio
```

The built-in decoder exports 84/84 PCM WAV files with zero failures on the supplied retail bank and retains the source `.bnk`. vgmstream remains a recommended general-purpose fallback for unrelated Sony bank variants.

## Provenance

The SIIG-specific Python parser/decoder is locally authored from the supplied retail bank and synthetic tests. Table/field behavior was cross-checked against vgmstream's public `src/meta/bnk_sony.c`, and PS-ADPCM behavior was cross-checked against `src/coding/psx_decoder.c`. No vgmstream source is vendored or copied into the package; see `docs/project/THIRD_PARTY_NOTICES.md`.
