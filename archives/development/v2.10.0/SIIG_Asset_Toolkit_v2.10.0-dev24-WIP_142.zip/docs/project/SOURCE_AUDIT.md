# Source-provenance audit report

Audit date: 2026-09-15  
Development tree reviewed: SIIG Asset Toolkit 2.10.0-dev10

## Scope

Reviewed bundled Python/Java source, launchers, add-on source, documentation, provenance tables, and release-layout files for vendored dependencies, copied/adapted logic, external-process calls, game assets, and unresolved attribution.

## Findings

- No third-party Python package, executable, shared library, emulator, decompiler, OpenSSL binary, FFmpeg binary, or vgmstream binary/source is bundled.
- One direct code adaptation remains identified: `xg_address_2d_tiled_offset`, an independent Python translation/adaptation of Xenia's Xenos tiled-texture addressing. The BSD 3-Clause notice remains bundled. The historical exact Xenia commit/file consulted was not preserved; that limitation remains explicit.
- The XMA2 RIFF wrapper is locally written against public Microsoft/DirectXTK structure documentation.
- AES-128, STFS, PS3 PKG, debug package streaming, extraction-safety policy, and NPDRM SDAT handling are locally authored clean-room code. FIPS-197 is the AES normative/known-answer reference.
- Finalized PS3 PKG extraction may invoke an installed OpenSSL executable as an optional acceleration backend. OpenSSL is external and not bundled; Python AES-CTR remains the fallback and is equivalence-tested.
- The new Sony SBlk v3/PS-ADPCM implementation is locally authored for the supplied SIIG bank. vgmstream `src/meta/bnk_sony.c` and `src/coding/psx_decoder.c` were explicitly consulted as behavioral/field-layout cross-checks. No vgmstream code was copied or vendored.
- BBX, GMX, SIIG TEX wrappers, system font, localization, COL, ANM, DAT, MAP, stage tables, atlas mapping, Bmap/Xmap, wall/generator, and shader-container work remains based on user-supplied binaries, Ghidra exports, synthetic fixtures, and corpus validation.
- Stage Explorer v5 source was reconstructed from the project's own retained validated generated explorer plus current executable-backed semantics; no third-party UI code was introduced.
- The Blender add-on, Asset Viewer, BBX repacker, localhost server, and resume-cache implementation are locally authored.
- TCRF/The Cutting Room Floor remains explicitly excluded.

## Real-package validation

The project now possesses and has directly exercised the supplied original retail Xbox 360 LIVE STFS and PS3 type-1 PKG. This supersedes older notes claiming those exact packages were unavailable. Retail regressions reach 2,593 resources with zero BBX hash mismatches/archive failures on both platforms; PS3 validates six internally decrypted SDATs / 18 authenticated blocks and 84 Sony WAV streams, while Xbox validates 86 XACT WAV streams.

## Current source-only validation

The 2.10.0-dev2 source tree passes 84/84 built-in tests. A packaging audit found zero proprietary game-asset extensions, zero external executable/container magic, zero bundled binary members inside the locally authored Blender add-on ZIP, zero private runtime paths, and zero Python bytecode. `reference/provenance/SOURCES.csv` contains 24 source/reference rows with a consistent 10-column schema.


Dev2 adds executable-derived runtime registry, route-source, GMX animation-track, route-descriptor, and raw camera-preset outputs. These additions were derived from the retained five-build Ghidra exports and supplied retail corpus; no new third-party code was copied or vendored. The changed paths were revalidated on all 47 retail Bmap/Xmap-layout files and all four route/camera GMXs.

Dev3 adds a locally authored executable-backed route resampler and runtime camera-preset tables. The route implementation is derived directly from the retained PS3 retail PPC listing/decompilation at functions `0x00158790`, `0x00158A28`, `0x00158D38`, `0x00159298`, `0x00159560`, and `0x0015A338`; no external spline library/code is used. The camera runtime table applies the 160 initializer writes traced at `0x0015C7F0` and preserves uncertain semantics structurally. No new third-party source or binary dependency was introduced.

Dev4 adds locally authored runtime route state and DAT-coupling code derived from the same retained PS3 retail executable: SCROLL_02 conversion at `0x0014E408`, route advancement at `0x00159560`, and route initialization at `0x0015A338`. No external spline, animation, or timing library is used. The new state machine was stress-stepped on all 46 resampleable retail route tables in both non-loop and loop modes, and DAT coupling was additionally exercised on explicit filename-correspondence candidates without claiming a complete global pairing map. No new third-party source or binary dependency was introduced.

Dev5 adds locally authored camera-preset semantic helpers derived directly from retained PS3 retail consumers at `0x00155300`, `0x00157540`, `0x00157A10`, `0x0015B910`, `0x0020D69C`, and `0x0020E984`, plus the renderer `fogRange`/`vFogColor` paths. The untouched raw preset table remains bundled for auditability. No third-party camera/math package or copied implementation was introduced. Word 11 remains explicitly unresolved rather than receiving a guessed material-property name.

Dev6 adds locally authored procedural route-orientation matrix/state helpers and combined procedural camera-world playback derived from the retained PS3 retail route/camera consumers. No third-party matrix, camera, scenegraph, or animation library is used. The combined command requires caller-supplied route/DAT/preset/runtime-coordinate inputs and explicitly excludes animated `cam1`/`int1` and `fld014`/`fld015` modes rather than inferring unsupported activation state.

Dev7 corrects matrix-animation timing and adds animated camera/field evaluators derived directly from the retained PS3 retail executable. Channel-type-12 matrix sampling is implemented as the executable's direct `logical_frame % frame_count` lookup; the raw float timestamp table is preserved as metadata rather than treated as runtime time. No third-party animation/interpolation library or copied code was introduced.

Dev8 adds locally authored PA-route research helpers and four machine-readable cross-build tables derived only from the retained user-supplied PS3 retail, Xbox 360 retail, June 10, May 11, and May 9 Ghidra exports plus the supplied retail DAT corpus. No new third-party source, executable, library, emulator, or online code was introduced. Prototype debug strings are used to recover names such as `Route::SetPaRoute`, while retail/PS3 correspondences are recorded by executable address and function/vtable shape. Strong correlations are explicitly labeled as such rather than promoted to direct-call proof.

Independent post-processing validation also passed on both supplied retail rips: Stage Explorer v5 generated 92 entries / 78 runtime pairings on both Xbox `Media` and PS3 `USRDIR` layouts; Asset Viewer coverage reached 3,520/3,520 Xbox and 3,991/3,991 PS3 previewable thumbnails with zero missing; full hash/privacy verification checked 9,855 Xbox files and 11,195 PS3 files with zero issues.

Dev24 adds locally authored `.siigmod` binary-delta packaging and application code using only Python's standard library. The format stores source/target hashes, copy/sparse instructions, and changed target-byte payloads; it does not bundle clean source assets. External retail corpus validation expanded to 2,197 completed byte-identical no-edit rebuild checks across GMX/TEX/DAT/MAP/ANM/stage tables/COL/systemfont/localization, while proprietary corpus files remain outside the release. No new third-party code, package, executable, or binary dependency was introduced.

Dev26 extends the locally authored GMX reverse compiler with opt-in whole `MESH`/`ARRY` graph synchronization. New native mesh/array records are synthesized only by cloning field layouts already proven from the supplied corpus; no third-party model-format or scene-graph code was introduced. Removal uses explicit cross-reference accounting and existing BONE attachment encoding already documented by this project. The default dev25-compatible path remains unchanged unless the user explicitly enables graph synchronization.

Dev27 extends that same clean-room GMX compiler with opt-in `BONE`/`PARE`/`MTRL`/`SHAD` relationship synchronization and a self-contained scene-graph report. New material parameter schemas, mesh vertex declarations, PARE prefixes, and fixed shader records are synthesized only by cloning compatible native layouts already represented by the template; no external scene-graph, material, shader, or model-format library is used. Existing bone transform bytes remain preserved unless transform import is explicitly requested. The release does not claim TXIF synthesis, arbitrary material-schema invention, shader-bytecode compilation, or template-free GMX creation.

Dev28 extends the same locally authored clean-room compiler with fixed-layout TXIF reference synthesis and glTF texture-binding resolution. The implementation uses the already decoded 0x30-byte TXIF index/flags/name layout and standard glTF image/texture metadata; no external texture/material library or copied implementation is introduced. The source-only release creates only GMX references/bindings and does not bundle proprietary TEX/DDS payloads or claim arbitrary texture payload generation.

## AI disclosure

OpenAI ChatGPT assisted with analysis, code drafting, tests, documentation, and packaging. The project can enumerate explicit sources intentionally consulted, but cannot enumerate the model's full training corpus or latent influences. See `AI_DISCLOSURE.md`.

## Remaining publication gates

- Select a license for original project code before public redistribution.
- Preserve Xenia's BSD notice and all provenance records.
- Keep proprietary game packages/assets and generated game-data viewers out of a source-only public release.
- Perform in-Blender UI/operator validation when Blender is available.
- Continue source-overlap/license review whenever future code is copied or adapted.
- Record exact upstream commit/file whenever feasible for all future external code references.

Dev9 adds only locally authored tables/helpers/documentation derived from the retained five-build Ghidra exports. No executable bytes or proprietary game assets are bundled. Retail Xbox and PS3 literal boss-route tables were byte-matched against June 10 during validation; prototype timing deltas remain documentary data only.

Dev14 adds a locally authored Ultimate UFO final-reset audit table, helper, regression test, and research note derived from retained Xbox 360 retail and PS3 executable listings plus retail DAT records. It records the exact camera-gate clear precondition and separates proven negative results at Mframes 6030/6200 from the still-unresolved ordinary higher-level reset caller. No footage or executable bytes are bundled.


Dev15 adds locally authored mobile package/format inspection and comparison code derived from the user-supplied iOS 4.1.0 IPA and Android 1.0.4 APK research copies. The packages themselves and all extracted assets/executables are excluded from the source-only release. TZIP, mobile MAP, DEX-header, binary-AXML, Mach-O metadata and package-integrity helpers use Python's standard library only.

Dev16 adds locally authored mobile-exclusive research tables, shared DAT opcode labels, and a Chimera opcode regression derived from retained iOS executable symbols/resources plus user-supplied research packages. Third-party MaxTheMurdererV2 gameplay videos are credited as observational corroboration only and are not bundled. No video, crossover music, stage data, mobile executable, IPA, or APK content is included.

Dev17 adds locally authored Survival Evolution Tree gating/substitution references, V2 enemy-shot dispatch/attack-pool mappings, conservative V2 mover-branch summaries, and Chimera A/B boss-argument documentation derived from retained iOS executable/resource analysis. No new third-party code or binary dependency was introduced; existing gameplay-video references remain observational provenance only and no footage is bundled.


Dev18 adds locally authored iOS→console MAP/DAT/timing/generator lineage metadata derived from retained user-supplied iOS ARMv7 and console Ghidra exports plus decoded resource tables. No executable bytes, decompiled proprietary code, IPA/APK content, or stage payloads are bundled.

Dev19 extends that source-only lineage into six original Stage-3 boss constructor/pool ancestry, the Xbox 0x96..0xAB enemy-handler family, World-5 integration chronology, and exact authored-DAT-loader anchors. The release explicitly preserves the continuity boundary where raw handler pointer values and exact per-boss May11→June10 similarity scores were not retained instead of reconstructing them speculatively. No new third-party source or binary dependency was introduced.
Dev20 extends the source-only lineage into the six original mobile boss gameplay movers using re-supplied project-owner Ghidra exports for May 9, May 11, June 10, retail Xbox and retail PS3 plus the retained iOS ARMv7 research copy. Only derived addresses, instruction fingerprints, constants, equations and semantic summaries are included. No XEX/EBOOT/Mach-O bytes or decompiled proprietary code are bundled. The local Mach-O metadata repair used to disassemble the modified iOS research copy is an analysis-only working file and is excluded from the package. No new third-party source or binary dependency was introduced.



Dev22 adds locally authored native rebuilders for the completely mapped stagewall/generator and `0x118` stage3D table records, a template-preserving fixed-layout GMX field editor, and dedicated `text.bin` / `message.bin` localization compilers. These builders are derived from the project's existing clean-room parsers, supplied-corpus structure research, and synthetic byte-roundtrip fixtures. The release does not bundle a GMX, localization archive, audio bank, game executable, or other proprietary validation input. GMX native rebuild and localization byte-identity regression claims in dev22 are intentionally limited to synthetic structural fixtures unless separately noted; real runtime acceptance remains outside the source-only release gate. No new third-party dependency or copied external implementation was introduced.

Dev23 adds the locally authored mod-workspace orchestration layer above the existing clean-room native builders. Its real-corpus round-trip validation used user-supplied retail `player.bin`, `text.bin`, and `message.bin` as external test inputs only: all 13 player GMXs and both localization archives passed byte-identical no-op rebuild checks. Only derived hashes/counts are retained in the source-only validation report; proprietary inputs, extracted assets, and rebuilt test payloads are excluded. The workspace project file may intentionally store the user's local source-rip path at runtime, but no such runtime workspace or private path is bundled in the release. Xbox gzip patch generation is locally authored; PS3 NPDRM/SDAT re-encryption remains unsupported. No new third-party dependency or copied external implementation was introduced.
Dev6 adds locally authored canonical GMX-root synthesis and a no-template glTF compiler entry point. The 0x30-byte root builder uses only fields already decoded by this project: tag/size, total stream size, the dev25-proven geometry AABB, and explicitly unnamed/reserved bytes that default to zero. It composes the project's existing clean-room MESH/ARRY, SHAD/MTRL, TXIF, BONE/PARE, and MOTN/ANIM builders; no external model compiler, scene graph, shader library, or copied implementation was added. The release does not claim semantics for the root +0x08/+0x28 fields, platform shader microcode compilation, glTF skinning import, or runtime acceptance of arbitrary original scenes.



Dev7 rigid-skin compatibility is locally authored from the already-decoded glTF accessor reader and native BONE/MESH graph compiler. No external skinning library or copied implementation is introduced. The feature intentionally refuses blended weights because the supplied GMX evidence contains no per-vertex joint/weight streams; the user-supplied player/enemy corpus was used only for validation statistics and is not bundled.


### 2.10.0-dev1

The inverse-bind rebake implementation is locally authored from the glTF affine skinning contract and the project's previously decoded rigid SIIG BONE→MESH representation. It uses only standard-library matrix arithmetic. No third-party skinning library, copied renderer code, proprietary model payload, or executable code is bundled. The retail player/enemy inputs used for the dev7 corpus cross-check remain external and are not included in the release tree.


### 2.10.0-dev2

Dev2 adds only clean-room Python/Tkinter logic for rigid joint-island partitioning and explicit-transform multi-GMX glTF assembly. The built-in PROGRESSIVE UFO catalog records filenames/runtime IDs/counts already established in project research but contains no proprietary model bytes and deliberately leaves four unrecovered placement matrices null.


### 2.10.0-dev3

Dev3 adds locally authored catalog/GUI/CLI/documentation logic for the PROGRESSIVE UFO five-part assembly. Runtime order and transforms were derived from user-supplied June/retail Xbox executable analysis and the project-owner PS3 Ghidra export, with the PS3 input hash matched to the previously recorded research corpus. Only derived addresses, normalized instruction fingerprints, constants and matrices are retained. No XEX/EBOOT bytes, Ghidra export, GMX payload, screenshot, or decompiled proprietary code is bundled. The glTF coordinate application reuses the toolkit's existing clean-room GMX exporter convention; no new external code dependency or copied implementation was introduced.

Dev5 adds only locally authored assembly-catalog/data-flow code, GUI wiring, tests and derived research metadata. HORNET/CRAB/PROGRESSIVE validation used user-supplied Xbox/PS3 executables, Ghidra exports, ANM and GMX files as external research inputs; no proprietary bytes or generated retail assemblies are bundled. HORNET's C1 locator lattice and pool counts, CRAB's landed sample, and PROGRESSIVE barrier bind orientation are retained only as derived constants/hashes/addresses. No new third-party code, binary dependency, or copied implementation was introduced. Native game units are preserved rather than converted through an external DCC/unit library.

### 2.10.0-dev6

Dev6 adds only locally authored assembly-catalog generation, Tkinter wiring, regression tests and derived HORNET runtime research metadata. The 45-record prism-wall grid, 13-entry A1 random-slot table, A1/C0 substitution semantics and phase-state boundaries were derived from the retained project-owner June Xbox, retail Xbox and retail PS3 Ghidra exports. The real retail A1/C0 GMXs were exercised externally only to validate one representative slot-22 assembly. No XEX/EBOOT, Ghidra export, GMX, ANM, generated retail glTF, third-party binary, or copied external implementation is bundled. HORNET state 6 remains explicitly unresolved rather than being inferred from the recovered state-4 wall.


### 2.10.0-dev9 ULTIMATE UFO assembly evidence

Dev9 adds only locally authored assembly metadata/code derived from project-owner Ghidra exports and prior model-registry research. The source-only package contains exact runtime type counts, phase/state metadata, named locator ranges and controller semantics, but no XEX/EBOOT bytes or `bos_015*.gmx` assets. The exporter resolves `lt_###` nodes from user-selected local GMXs at runtime and rejects missing or ambiguous locators rather than embedding proprietary transforms or guessed geometry. No new third-party dependency or copied external implementation was introduced.
## 2.10.0-dev10 addendum

Dev10 adds only locally authored assembly metadata/UI/test/documentation around HORNET state-3 behavior recovered from the retained user-supplied five-build Ghidra exports. The project owner re-supplied the original retail Xbox package, which was used externally to verify the historical HORNET GMX/ANM hashes and run a real `hornet_exposed_core` export. Those proprietary package/GMX/glTF bytes remain outside the source release. No new third-party source, library, executable or copied implementation was introduced. The built-in suite is 92/92 before release sealing.
### 2.10.0-dev22

Dev22 adds locally authored Tkinter/HTML/Python presentation and orchestration logic plus derived executable/footage-backed research metadata. The Visualizer feedback renderer is based on the project-owner June 10 Visualizer Check Mode footage and recovered game parameters/timelines; no footage frames are bundled. The Stage Explorer GMX-size proxies use only decoded native root AABBs/runtime placement metadata and deliberately do not invent unresolved placement rotation order. The five-boss controller audit retains only derived addresses/function identifiers/findings from the supplied Xbox/PS3 Ghidra exports.

The four GMX visual-pass modes classify native `_F` face/solid and `_E` edge/outline bones and reuse the project's existing clean-room glTF exporter; no third-party rendering/model library was added. The Asset Viewer OS-default Open-file bridge is localhost-only and implemented with the Python standard library/OS shell facilities; no protocol-handler executable or third-party server is bundled. Full retail Xbox validation inputs and the generated ~GiB rip remain external to the source release.

