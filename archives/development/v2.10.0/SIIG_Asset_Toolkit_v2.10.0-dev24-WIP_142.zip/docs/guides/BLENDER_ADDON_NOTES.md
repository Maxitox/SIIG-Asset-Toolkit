# Blender add-on

The current `addons/SIIG_Blender_Addon_v0.2.0.zip` supports Blender 3.6 or newer.

The add-on deliberately does **not** implement a second GMX parser. Raw GMX import loads the selected toolkit installation, runs the verified GMX → glTF exporter in Blender's Python process, and hands the temporary glTF to Blender's built-in importer. This keeps Blender results aligned with command-line conversion fixes.

## Installation

1. Open **Edit → Preferences → Add-ons** in Blender.
2. Choose **Install from Disk** and select `addons/SIIG_Blender_Addon_v0.2.0.zip`.
3. Enable **SIIG Asset Toolkit**.
4. In the add-on preferences, choose the folder containing `siig_toolkit.py`.

An alternative is to set the `SIIG_TOOLKIT_HOME` environment variable to the toolkit folder.

## Raw GMX features

- File → Import → **Space Invaders Infinity Gene (.gmx)**.
- Multi-file selection and recursive folder import.
- Optional V-coordinate flip and configurable texture-search root.
- Optional collection per raw GMX.
- Source filename and toolkit version stored as Blender custom properties.
- Missing textures reported without discarding geometry.

## Assembled-model visibility

Toolkit Boss/Entity assemblies intentionally preserve native face/solid (`_F`) and edge/outline (`_E`) meshes as separate Blender objects. Hiding only one mesh object therefore leaves its overlapping sibling visible. This was the reason a boss part could appear impossible to hide.

Add-on 0.2.0 adds two assembly actions:

- **Import SIIG Assembly (.gltf/.glb)** imports an assembled toolkit output and automatically builds logical part collections.
- **Organize SIIG Part Collections** can post-process an already imported toolkit assembly.

Each toolkit `siigAssemblyModel` master becomes one `SIIG_PART_*` collection containing that master and its native descendants, stopping at nested child-part masters. Use the **collection eye/monitor controls** in Blender's Outliner to hide/show a whole logical part; its solid and outline disappear together while native transform parenting and animations stay intact.

## Validation boundary

The release regression can validate Python syntax, package/source identity, expected operators, logical-master metadata handling and non-destructive hierarchy rules without importing `bpy`. Blender itself is not available in the release-build environment, so final Outliner/UI behavior still requires an actual Blender runtime test.
