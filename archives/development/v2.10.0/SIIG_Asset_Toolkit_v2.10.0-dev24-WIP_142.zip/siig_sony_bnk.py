#!/usr/bin/env python3
"""Minimal Sony 989SND/SCREAM SBlk v3 reader used by SIIG's PS3 sound bank.

This module is intentionally narrow and dependency-free.  The container/table
layout and field meanings were cross-checked against the public vgmstream Sony
BNK implementation (src/meta/bnk_sony.c) and Sony PS-ADPCM behavior.  The code
below is an independent Python implementation for the exact format subset found
in Space Invaders Infinity Gene; no vgmstream source is vendored.
"""

from __future__ import annotations

from array import array
from dataclasses import asdict, dataclass
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import sys
import wave


class SonyBnkError(ValueError):
    """Raised for unsupported, malformed, or inconsistent Sony SBlk banks."""


def _u16be(data: bytes, offset: int) -> int:
    if offset < 0 or offset + 2 > len(data):
        raise SonyBnkError(f"u16 read outside bank at 0x{offset:X}")
    return struct.unpack_from(">H", data, offset)[0]


def _u32be(data: bytes, offset: int) -> int:
    if offset < 0 or offset + 4 > len(data):
        raise SonyBnkError(f"u32 read outside bank at 0x{offset:X}")
    return struct.unpack_from(">I", data, offset)[0]


def _cstring(data: bytes, offset: int, maximum: int = 0x100) -> str:
    if offset < 0 or offset >= len(data):
        return ""
    end = min(len(data), offset + maximum)
    nul = data.find(b"\0", offset, end)
    if nul >= 0:
        end = nul
    return data[offset:end].decode("ascii", "replace")


def _safe_name(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._")
    return cleaned or "stream"


def _sample_rate_from_center(center_note: int, center_fine: int) -> int:
    """Convert SCREAM's PS2 center-note/fine encoding to its SPU sample rate.

    SIIG's bank uses the PS2/48 kHz form (high bit set).  This formulation uses
    the equivalent pitch-register relationship directly rather than copying an
    SDK lookup table.  Integer truncation matches the register/sample-rate path.
    """
    ps2_mode = bool(center_note & 0x80)
    center = (0x100 - center_note) if ps2_mode else center_note
    semitones = (60 - center) + (center_fine / 128.0)
    pitch = int(4096.0 * math.pow(2.0, semitones / 12.0))
    pitch = max(0, min(0x4000, pitch))
    if not ps2_mode:
        pitch = (pitch * 44100) // 48000
    return max(1, (48000 * pitch) // 4096)


@dataclass(frozen=True)
class SonySblkStream:
    index: int
    name: str
    name_resolved: bool
    center_note: int
    center_fine: int
    flags: int
    codec: str
    sample_rate: int
    channels: int
    stream_offset: int
    stream_size: int
    absolute_offset: int
    num_samples: int
    loop_flag: bool


@dataclass(frozen=True)
class SonySblkBank:
    outer_version: int
    sections: int
    sblk_version: int
    sblk_offset: int
    data_offset: int
    data_size: int
    sounds_entries: int
    grains_entries: int
    stream_entries: int
    streams: tuple[SonySblkStream, ...]
    covered_audio_bytes: int
    coverage_complete: bool


def _resolve_v3_name(
    data: bytes,
    table1: int,
    table4: int,
    sounds_entries: int,
    table2_entry_offset: int,
) -> tuple[str, bool]:
    section_id = None
    for i in range(sounds_entries):
        base = table1 + i * 0x0C
        if base + 0x0C > len(data):
            raise SonyBnkError("SBlk sound table exceeds bank")
        entry_count = data[base + 0x04]
        entry_offset = _u32be(data, base + 0x08)
        if entry_offset <= table2_entry_offset < entry_offset + entry_count * 0x08:
            section_id = i
            break
    if section_id is None:
        return "", False

    if table4 <= 0 or table4 + 0x58 > len(data):
        return "", False
    names_base = table4 + _u32be(data, table4 + 0x08)
    chunks = [_u16be(data, table4 + 0x18 + i * 2) for i in range(32)]
    for bucket, first_record in enumerate(chunks):
        offset = names_base + first_record * 0x14
        # Bound the walk so malformed chunk indices cannot spin into arbitrary data.
        for _ in range(sounds_entries + 1):
            if offset + 0x14 > len(data) or data[offset] == 0:
                break
            if ((data[offset] + data[offset + 4] + data[offset + 8] + data[offset + 12]) & 0x1F) != bucket:
                raise SonyBnkError("SBlk v3 name-bucket checksum mismatch")
            if _u16be(data, offset + 0x10) == section_id:
                name = _cstring(data, offset, 0x10)
                return name, bool(name)
            offset += 0x14
    return "", False


def parse_sony_sblk_v3(data: bytes) -> SonySblkBank:
    """Parse the big-endian SBlk v3 subset used by SIIG's PS3 sound bank."""
    if len(data) < 0x60:
        raise SonyBnkError("Sony bank is too small")
    outer_version = _u32be(data, 0x00)
    sections = _u32be(data, 0x04)
    if outer_version != 3:
        raise SonyBnkError(f"unsupported Sony bank outer version {outer_version}; expected 3")
    if sections not in (2, 3):
        raise SonyBnkError(f"unsupported Sony bank section count {sections}")

    sblk = _u32be(data, 0x08)
    sblk_size = _u32be(data, 0x0C)
    data_offset = _u32be(data, 0x10)
    data_size = _u32be(data, 0x14)
    if sblk > 0x20 or sblk + 0x40 > len(data):
        raise SonyBnkError("invalid SBlk offset")
    if data[sblk:sblk + 4] != b"klBS":
        raise SonyBnkError("missing big-endian SBlk marker")
    sblk_version = _u32be(data, sblk + 0x04)
    if sblk_version != 3:
        raise SonyBnkError(f"unsupported SBlk version {sblk_version}; SIIG uses v3")
    if sblk_size and sblk + sblk_size > data_offset:
        # A few banks align after SBlk; overlap is never expected.
        raise SonyBnkError("SBlk section overlaps audio data")
    if data_offset + data_size > len(data):
        raise SonyBnkError("Sony bank audio section exceeds file")

    sounds_entries = _u16be(data, sblk + 0x16)
    grains_entries = _u16be(data, sblk + 0x18)
    stream_entries = _u16be(data, sblk + 0x1A)
    if not (sounds_entries and grains_entries and stream_entries):
        raise SonyBnkError("Sony bank contains no SBlk sound entries")
    if max(sounds_entries, grains_entries, stream_entries) > 100_000:
        raise SonyBnkError("unreasonable SBlk entry count")

    table1 = sblk + _u32be(data, sblk + 0x1C)
    table2 = sblk + _u32be(data, sblk + 0x20)
    table3 = sblk + _u32be(data, sblk + 0x34)
    table4 = sblk + _u32be(data, sblk + 0x38)
    for label, offset in (("sound", table1), ("grain", table2), ("wave", table3), ("name", table4)):
        if offset < sblk or offset >= data_offset:
            raise SonyBnkError(f"SBlk {label} table offset is outside header section")

    streams: list[SonySblkStream] = []
    for grain_index in range(grains_entries):
        grain_offset = table2 + grain_index * 0x08
        if grain_offset + 0x08 > len(data):
            raise SonyBnkError("SBlk grain table exceeds bank")
        value = _u32be(data, grain_offset)
        subtype = (value >> 16) & 0xFFFF
        wave_suboffset = value & 0xFFFF
        if subtype != 0x0100:
            continue
        header = table3 + wave_suboffset
        if header < table3 or header + 0x18 > data_offset:
            raise SonyBnkError("SBlk wave header is outside header section")

        center_note = data[header + 0x02]
        center_fine = data[header + 0x03]
        flags = _u16be(data, header + 0x0E)
        stream_offset = _u32be(data, header + 0x10)
        stream_size = _u32be(data, header + 0x14)
        if stream_offset > data_size or stream_size > data_size - stream_offset:
            raise SonyBnkError("SBlk stream range exceeds audio section")

        if flags & 0x1000:
            codec = "MPEG"
        elif flags & 0x0080:
            codec = "PCM16BE"
        else:
            codec = "PSX_ADPCM"
        if codec == "PSX_ADPCM" and stream_size % 0x10:
            raise SonyBnkError("PSX ADPCM stream size is not 16-byte-frame aligned")

        resolved, name_ok = _resolve_v3_name(data, table1, table4, sounds_entries, grain_index * 0x08)
        name = resolved or f"stream_{len(streams) + 1:03d}.vag"
        channels = 1
        if codec == "PSX_ADPCM":
            num_samples = (stream_size // 0x10) * 28
        elif codec == "PCM16BE":
            num_samples = stream_size // 2
        else:
            num_samples = 0
        streams.append(SonySblkStream(
            index=len(streams),
            name=name,
            name_resolved=name_ok,
            center_note=center_note,
            center_fine=center_fine,
            flags=flags,
            codec=codec,
            sample_rate=_sample_rate_from_center(center_note, center_fine),
            channels=channels,
            stream_offset=stream_offset,
            stream_size=stream_size,
            absolute_offset=data_offset + stream_offset,
            num_samples=num_samples,
            loop_flag=bool(flags & 0x0040),
        ))

    if not streams:
        raise SonyBnkError("SBlk grain table contains no waveform entries")
    if len(streams) != stream_entries:
        raise SonyBnkError(
            f"SBlk waveform count mismatch: parsed {len(streams)}, header says {stream_entries}"
        )

    ordered = sorted((s.stream_offset, s.stream_offset + s.stream_size) for s in streams)
    covered = 0
    cursor = 0
    complete = True
    for start, end in ordered:
        if start != cursor:
            complete = False
        if start < cursor:
            raise SonyBnkError("overlapping SBlk audio stream ranges")
        covered += end - start
        cursor = end
    complete = complete and cursor == data_size

    return SonySblkBank(
        outer_version=outer_version,
        sections=sections,
        sblk_version=sblk_version,
        sblk_offset=sblk,
        data_offset=data_offset,
        data_size=data_size,
        sounds_entries=sounds_entries,
        grains_entries=grains_entries,
        stream_entries=stream_entries,
        streams=tuple(streams),
        covered_audio_bytes=covered,
        coverage_complete=complete,
    )


_PSX_COEFS = ((0, 0), (60, 0), (115, -52), (98, -55), (122, -60))


def decode_psx_adpcm_mono(raw: bytes) -> bytes:
    """Decode standard 16-byte Sony PS-ADPCM frames to little-endian PCM16."""
    if len(raw) % 0x10:
        raise SonyBnkError("PSX ADPCM data is not frame aligned")
    hist1 = 0
    hist2 = 0
    samples = array("h")
    for frame_offset in range(0, len(raw), 0x10):
        frame = raw[frame_offset:frame_offset + 0x10]
        coef_index = (frame[0] >> 4) & 0x0F
        shift_factor = frame[0] & 0x0F
        flag = frame[1]
        if coef_index > 4:
            coef_index = 0
        if shift_factor > 12:
            shift_factor = 9
        coef0, coef1 = _PSX_COEFS[coef_index]
        scale_shift = 20 - shift_factor
        for i in range(28):
            sample = 0
            # 0x07 is an explicit silent/end frame. Unknown high flag values in
            # trailing padding are likewise rendered silent, matching the normal
            # console decoder behavior instead of interpreting garbage nibbles.
            if flag < 0x07:
                packed = frame[0x02 + i // 2]
                nibble = ((packed >> 4) & 0x0F) if (i & 1) else (packed & 0x0F)
                if nibble & 0x08:
                    nibble -= 0x10
                sample = nibble << scale_shift
                # The standard filter coefficients are rational values /64;
                # multiplying by 256 here keeps the whole predictor path exact.
                sample += (coef0 * hist1 + coef1 * hist2) * 4
                sample >>= 8
            clipped = max(-32768, min(32767, sample))
            samples.append(clipped)
            hist2, hist1 = hist1, sample
    if sys.byteorder != "little":
        samples.byteswap()
    return samples.tobytes()


def decode_sblk_stream(data: bytes, stream: SonySblkStream) -> bytes:
    raw = data[stream.absolute_offset:stream.absolute_offset + stream.stream_size]
    if len(raw) != stream.stream_size:
        raise SonyBnkError("truncated SBlk stream")
    if stream.codec == "PSX_ADPCM":
        return decode_psx_adpcm_mono(raw)
    if stream.codec == "PCM16BE":
        samples = array("h")
        samples.frombytes(raw)
        # Input bytes are big-endian while WAV PCM16 is little-endian.
        # array.frombytes interprets native endian, so one byte swap is needed
        # on either host endian before serialising the WAV payload.
        samples.byteswap()
        return samples.tobytes()
    raise SonyBnkError(f"built-in Sony bank decoder does not support {stream.codec}")


def export_sony_sblk_wav_bytes(data: bytes, output_dir: Path, source_label: str = "sound.bnk") -> dict:
    """Export every supported SBlk v3 stream to PCM16 WAV plus CSV/JSON manifests."""
    bank = parse_sony_sblk_v3(data)
    output_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []
    used_names: set[str] = set()
    decode_failures = 0

    for stream in bank.streams:
        base = Path(stream.name).stem
        stem = _safe_name(base)
        key = stem.casefold()
        if key in used_names:
            stem = f"{stream.index + 1:03d}_{stem}"
            key = stem.casefold()
        used_names.add(key)
        wav_name = stem + ".wav"
        wav_path = output_dir / wav_name
        error = ""
        decoded = False
        pcm = b""
        try:
            pcm = decode_sblk_stream(data, stream)
            with wave.open(str(wav_path), "wb") as wav:
                wav.setnchannels(stream.channels)
                wav.setsampwidth(2)
                wav.setframerate(stream.sample_rate)
                wav.writeframes(pcm)
            decoded = True
        except Exception as exc:
            decode_failures += 1
            error = str(exc)
            wav_path.unlink(missing_ok=True)

        row = asdict(stream)
        row.update({
            "flags_hex": f"0x{stream.flags:04X}",
            "wav_file": wav_name if decoded else "",
            "decoded": decoded,
            "pcm_sha256": hashlib.sha256(pcm).hexdigest() if decoded else "",
            "error": error,
        })
        rows.append(row)

    manifest = {
        "source": Path(source_label).name,
        "format": "Sony 989SND/SCREAM SBlk v3",
        "outer_version": bank.outer_version,
        "sblk_version": bank.sblk_version,
        "stream_count": len(bank.streams),
        "decoded_wav": len(bank.streams) - decode_failures,
        "decode_failures": decode_failures,
        "audio_data_size": bank.data_size,
        "covered_audio_bytes": bank.covered_audio_bytes,
        "coverage_complete": bank.coverage_complete,
        "entries": rows,
    }
    (output_dir / "sblk_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    if rows:
        csv_rows = []
        for row in rows:
            flat = dict(row)
            # bools/ints are already CSV-friendly; keep stable scalar columns.
            csv_rows.append(flat)
        with (output_dir / "sblk_manifest.csv").open("w", newline="", encoding="utf-8") as fp:
            writer = csv.DictWriter(fp, fieldnames=list(csv_rows[0].keys()))
            writer.writeheader()
            writer.writerows(csv_rows)
    return manifest


def export_sony_sblk_wav_file(input_path: Path, output_dir: Path) -> dict:
    return export_sony_sblk_wav_bytes(input_path.read_bytes(), output_dir, input_path.name)
