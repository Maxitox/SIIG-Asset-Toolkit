# Optional add-ons

- `SIIG_Blender_Addon_v0.2.0.zip` — current installable Blender add-on with logical assembly-part collections
- `SIIG_Blender_Addon_v0.1.0.zip` — retained legacy importer package
- `blender_addon_source/` — readable source copy of the current add-on

See `docs/guides/BLENDER_ADDON_NOTES.md`.
