# Reference data

Machine-readable supporting material is grouped by purpose:

- [`tables/`](tables/) — DAT, MAP, stage-pairing, and tile-set CSV tables
- [`provenance/`](provenance/) — source and implementation provenance records
- [`systemfont/`](systemfont/) — BMFont descriptor, glyph table, and metadata
- [`samples/`](samples/) — small source-only format examples

Dev14 adds `tables/ULTIMATE_UFO_FINAL_RESET_AUDIT.csv`, which keeps the proven gate-clear mechanism separate from destructor-only removal, plus `tables/ULTIMATE_UFO_VISIBLE_REMOVAL_DEV14.csv` for the strictly observational June 10 frame boundary.
