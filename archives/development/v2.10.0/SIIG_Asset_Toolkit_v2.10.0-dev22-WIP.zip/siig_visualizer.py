#!/usr/bin/env python3
"""Offline SIIG visualizer simulator.

The simulator separates executable-backed DAT timing/state from footage-backed
shape presentation.  SequenceSet.nut/ParameterSet.nut geometry is not decoded
here, so observed shapes without a proven numeric SHAPE id remain explicitly
marked as approximations.
"""
from __future__ import annotations

import json
from pathlib import Path

import siig_toolkit as toolkit

VISUALIZER_OPCODES = set(range(0xC8, 0xCF))
MAX_SCRIPT_BYTES = 8 * 1024 * 1024


def _find_media(input_path: Path) -> Path | None:
    candidates = (
        input_path / "assets" / "Media",
        input_path / "Media",
        input_path / "assets" / "USRDIR",
        input_path / "USRDIR",
        input_path,
    )
    for candidate in candidates:
        if (candidate / "script").is_dir():
            return candidate
    return None


def _visualizer_timelines(input_path: Path | None) -> list[dict]:
    if input_path is None:
        return []
    media = _find_media(input_path)
    if media is None:
        return []
    result: list[dict] = []
    for path in sorted((media / "script").glob("*.dat"), key=lambda p: p.name.lower()):
        try:
            if path.stat().st_size > MAX_SCRIPT_BYTES:
                continue
            parsed = toolkit.parse_dat_bytes(path.read_bytes())
        except Exception:
            continue
        events = []
        for record in parsed["records"]:
            if record["opcode"] not in VISUALIZER_OPCODES:
                continue
            events.append({
                "frame": record["absolute_frame"],
                "opcode": record["opcode_name"],
                "args": record["args_signed"],
                "fields": record["semantic"]["fields"],
            })
        if events:
            result.append({
                "script": path.name,
                "duration_frames": parsed["duration_frames"],
                "events": events,
            })
    return result


def _html(dataset: dict) -> str:
    payload = json.dumps(dataset, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SIIG Visualizer Simulator</title>
<style>
:root{{color-scheme:dark;background:#08090d;color:#eef1f7;font:14px system-ui,sans-serif}}*{{box-sizing:border-box}}body{{margin:0}}header{{padding:12px 16px;background:#111621;border-bottom:1px solid #293247;display:flex;gap:12px;align-items:center;flex-wrap:wrap;position:sticky;top:0;z-index:5}}h1{{font-size:18px;margin:0 18px 0 0}}button,select,input{{background:#1a2130;color:#eef;border:1px solid #3a465e;border-radius:6px;padding:6px 8px}}button{{cursor:pointer}}main{{display:grid;grid-template-columns:minmax(300px,390px) 1fr;min-height:calc(100vh - 58px)}}aside{{padding:14px;border-right:1px solid #293247;overflow:auto}}section{{padding:14px;min-width:0}}fieldset{{border:1px solid #2e394f;border-radius:8px;margin:0 0 10px;padding:10px}}legend{{color:#b9c7df;padding:0 5px}}.row{{display:grid;grid-template-columns:1fr 92px;gap:8px;align-items:center;margin:5px 0}}.pair{{display:grid;grid-template-columns:1fr 1fr;gap:6px}}.muted{{color:#9ba8bd}}.notice{{padding:9px;border:1px solid #5b4b27;background:#251f14;color:#f0d99d;border-radius:8px;margin-bottom:10px}}.good{{border-color:#335d41;background:#15251b;color:#bde6c6}}.canvas-wrap{{display:flex;justify-content:center;align-items:center;min-height:440px;background:#000;border:1px solid #263047;border-radius:9px;overflow:hidden}}canvas{{display:block;max-width:100%;height:auto}}.timeline{{margin-top:12px;border:1px solid #293247;border-radius:8px;overflow:auto;max-height:36vh}}table{{width:100%;border-collapse:collapse}}th,td{{padding:6px 8px;border-bottom:1px solid #222a3b;text-align:left}}th{{position:sticky;top:0;background:#151c29}}.mono{{font-family:ui-monospace,monospace;font-size:12px}}.status{{margin-top:8px;color:#b9c7df;font-family:ui-monospace,monospace}}@media(max-width:900px){{main{{display:block}}aside{{border-right:0;border-bottom:1px solid #293247}}.canvas-wrap{{min-height:300px}}}}
</style></head><body>
<header><h1>SIIG Visualizer Simulator</h1><button id="play" type="button">Pause</button><button id="reset" type="button">Reset</button><label>Observed shape <select id="shape"><option value="ring">SHAPE 0 · radial ring</option><option value="square">SHAPE 3 · square/frame</option><option value="triangle">Observed triangle/frame · ID unresolved</option><option value="rays">Observed ray fan · ID unresolved</option><option value="dots">Observed dot/tunnel · ID unresolved</option><option value="solid">Observed solid field · ID unresolved</option></select></label></header>
<main><aside>
<div class="notice">This is an evidence-bounded simulator, not a pixel-identical reimplementation. DAT visualizer timing/opcodes below are decoded from the game. SHAPE 0/ring and SHAPE 3/square are footage-backed; other observed pattern IDs and the internal SequenceSet/ParameterSet geometry remain unresolved.</div>
<fieldset><legend>Visualizer Check parameters</legend>
<div class="row"><label>Volume</label><input id="volume" type="range" min="0" max="255" value="180"></div>
<div class="row"><label>Magnify X min/max</label><div class="pair"><input id="magxmin" type="number" step="0.05" value="1"><input id="magxmax" type="number" step="0.05" value="1"></div></div>
<div class="row"><label>Magnify Y min/max</label><div class="pair"><input id="magymin" type="number" step="0.05" value="1"><input id="magymax" type="number" step="0.05" value="1"></div></div>
<div class="row"><label>Magnify A min/max</label><div class="pair"><input id="magamin" type="number" step="1" value="255"><input id="magamax" type="number" step="1" value="255"></div></div>
<div class="row"><label>Position Fix</label><input id="positionFix" type="checkbox"></div>
<div class="row"><label>Position Free X/Y</label><div class="pair"><input id="posx" type="number" step="0.05" value="0"><input id="posy" type="number" step="0.05" value="0"></div></div>
<div class="row"><label>Rotation Base</label><input id="rotbase" type="number" step="0.01" value="0.10"></div>
<div class="row"><label>Add Rotation</label><input id="rotadd" type="number" step="0.01" value="0.18"></div>
<div class="row"><label>Fix Rotation</label><input id="rotfix" type="checkbox"></div>
<div class="row"><label>Scale X min/max</label><div class="pair"><input id="sxmin" type="number" step="0.05" value="1"><input id="sxmax" type="number" step="0.05" value="1"></div></div>
<div class="row"><label>Scale Y min/max</label><div class="pair"><input id="symin" type="number" step="0.05" value="1"><input id="symax" type="number" step="0.05" value="1"></div></div>
</fieldset>
<fieldset><legend>RGBA ranges</legend>
<div class="row"><label>R min/max</label><div class="pair"><input id="rmin" type="number" min="0" max="255" value="128"><input id="rmax" type="number" min="0" max="255" value="255"></div></div>
<div class="row"><label>G min/max</label><div class="pair"><input id="gmin" type="number" min="0" max="255" value="0"><input id="gmax" type="number" min="0" max="255" value="0"></div></div>
<div class="row"><label>B min/max</label><div class="pair"><input id="bmin" type="number" min="0" max="255" value="0"><input id="bmax" type="number" min="0" max="255" value="0"></div></div>
<div class="row"><label>A min/max</label><div class="pair"><input id="amin" type="number" min="0" max="255" value="255"><input id="amax" type="number" min="0" max="255" value="255"></div></div>
<div class="row"><label>Background RGBA</label><input id="bg" type="color" value="#000000"></div>
</fieldset>
<fieldset><legend>Decoded stage visualizer timeline</legend><div class="row"><label>Script</label><select id="script"></select></div><div class="row"><label>Authored frame</label><input id="frame" type="range" min="0" max="0" value="0"></div><div class="status" id="scriptStatus">No DAT timeline loaded.</div></fieldset>
</aside><section><div class="canvas-wrap"><canvas id="canvas" width="960" height="540"></canvas></div><div class="status" id="status"></div><div class="timeline"><table><thead><tr><th>Frame</th><th>Opcode</th><th>Arguments</th></tr></thead><tbody id="events"></tbody></table></div></section></main>
<script id="data" type="application/json">{payload}</script><script>
const DB=JSON.parse(document.getElementById('data').textContent),$=id=>document.getElementById(id),can=$('canvas'),ctx=can.getContext('2d');let running=true,t0=performance.now(),phase=0;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,Number(v)||0)),num=id=>Number($(id).value)||0,lerp=(a,b,t)=>a+(b-a)*t;
function rgba(t){{const r=clamp(lerp(num('rmin'),num('rmax'),t),0,255),g=clamp(lerp(num('gmin'),num('gmax'),1-t),0,255),b=clamp(lerp(num('bmin'),num('bmax'),0.5+0.5*Math.sin(t*6.28)),0,255),a=clamp(lerp(num('amin'),num('amax'),t),0,255)/255;return `rgba(${{r|0}},${{g|0}},${{b|0}},${{a}})`}}
function shapeScale(t){{const pulse=(num('volume')/255)*(0.5+0.5*Math.sin(t*3.1));return [lerp(num('sxmin'),num('sxmax'),pulse)*lerp(num('magxmin'),num('magxmax'),pulse),lerp(num('symin'),num('symax'),pulse)*lerp(num('magymin'),num('magymax'),pulse)]}}
function transform(t){{const [sx,sy]=shapeScale(t),rot=$('rotfix').checked?num('rotbase'):num('rotbase')+num('rotadd')*t;const px=$('positionFix').checked?0:num('posx')*can.width,py=$('positionFix').checked?0:num('posy')*can.height;ctx.translate(can.width/2+px,can.height/2+py);ctx.rotate(rot);ctx.scale(sx,sy)}}
function poly(n,r,filled=false){{ctx.beginPath();for(let i=0;i<n;i++){{const a=-Math.PI/2+i*Math.PI*2/n,x=Math.cos(a)*r,y=Math.sin(a)*r;i?ctx.lineTo(x,y):ctx.moveTo(x,y)}}ctx.closePath();filled?ctx.fill():ctx.stroke()}}
function draw(t){{ctx.fillStyle=$('bg').value;ctx.fillRect(0,0,can.width,can.height);ctx.save();transform(t);const mode=$('shape').value,base=Math.min(can.width,can.height)*0.26;ctx.lineWidth=3;ctx.strokeStyle=rgba((Math.sin(t*1.7)+1)/2);ctx.fillStyle=rgba((Math.sin(t*1.3)+1)/2);if(mode==='ring'){{for(let i=0;i<9;i++){{ctx.globalAlpha=0.14+0.08*i;ctx.beginPath();ctx.arc(0,0,base*(0.25+i*0.1)*(0.9+0.1*Math.sin(t*2+i)),0,Math.PI*2);ctx.stroke()}}ctx.globalAlpha=1}}else if(mode==='square'){{for(let i=0;i<6;i++){{const q=base*(0.65+i*0.14);ctx.globalAlpha=0.2+0.11*i;ctx.strokeRect(-q,-q,q*2,q*2)}}ctx.globalAlpha=1}}else if(mode==='triangle'){{for(let i=0;i<7;i++){{ctx.globalAlpha=0.18+0.1*i;poly(3,base*(0.55+i*0.11));}}ctx.globalAlpha=1}}else if(mode==='solid'){{ctx.globalAlpha=0.85;ctx.fillRect(-can.width,-can.height,can.width*2,can.height*2);ctx.globalAlpha=1}}else if(mode==='rays'){{for(let i=0;i<28;i++){{const a=i*Math.PI*2/28+t*0.15,r=base*(1.3+0.25*Math.sin(t+i));ctx.globalAlpha=0.25+0.5*(i%3===0);ctx.beginPath();ctx.moveTo(Math.cos(a)*20,Math.sin(a)*20);ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r);ctx.stroke()}}ctx.globalAlpha=1}}else{{for(let i=0;i<70;i++){{const a=i*2.399963+t*0.1,r=15+(i/70)*base*1.8*(0.85+0.15*Math.sin(t+i));ctx.globalAlpha=0.25+0.7*i/70;ctx.beginPath();ctx.arc(Math.cos(a)*r,Math.sin(a)*r,1.5+3*i/70,0,Math.PI*2);ctx.fill()}}ctx.globalAlpha=1}}ctx.restore();$('status').textContent=`observed preset: ${{$('shape').selectedOptions[0].textContent}} · simulator phase ${{t.toFixed(2)}} · render is approximate until visualizerSet SequenceSet/ParameterSet geometry is decoded`;}}
function tick(now){{if(running){{phase+=(now-t0)/1000;t0=now;draw(phase)}}else t0=now;requestAnimationFrame(tick)}}
$('play').onclick=()=>{{running=!running;$('play').textContent=running?'Pause':'Play'}};$('reset').onclick=()=>{{phase=0;draw(0)}};
for(const el of document.querySelectorAll('input,select'))el.addEventListener('input',()=>draw(phase));
const sel=$('script'),frame=$('frame'),events=$('events'),scriptStatus=$('scriptStatus');const timelines=DB.timelines||[];if(timelines.length){{for(const t of timelines){{const o=document.createElement('option');o.value=t.script;o.textContent=t.script;sel.appendChild(o)}}}}else{{const o=document.createElement('option');o.textContent='No decoded DAT timeline';o.value='';sel.appendChild(o);sel.disabled=true;frame.disabled=true}}
function renderTimeline(){{const t=timelines.find(x=>x.script===sel.value);events.innerHTML='';if(!t){{scriptStatus.textContent='No DAT timeline loaded.';return}}frame.max=t.duration_frames||0;const f=Number(frame.value);let active=false,display=false,seq=null,volume=null;for(const e of t.events){{const tr=document.createElement('tr');tr.innerHTML=`<td>${{e.frame}}</td><td>${{e.opcode}}</td><td class="mono">${{e.args.join(' ')||'—'}}</td>`;events.appendChild(tr);if(e.frame>f)continue;if(e.opcode==='VL_START')active=true;if(e.opcode==='VL_END')active=false;if(e.opcode==='VL_DISP_ON')display=true;if(e.opcode==='VL_DISP_OFF')display=false;if(e.opcode==='VL_SEQUENCESET')seq=e.args[0];if(e.opcode==='VL_VOLUME_SCALE')volume=e.args[0]}}scriptStatus.textContent=`frame ${{f}} · active ${{active?'yes':'no'}} · display ${{display?'on':'off'}} · sequence ${{seq??'—'}} · volume scale ${{volume??'—'}}`;}}
sel.onchange=()=>{{frame.value='0';renderTimeline()}};frame.oninput=renderTimeline;renderTimeline();requestAnimationFrame(tick);
</script></body></html>'''


def build_visualizer_simulator(input_path: Path | None, output: Path) -> dict:
    timelines = _visualizer_timelines(input_path)
    dataset = {
        "format": "SIIG_VISUALIZER_SIMULATOR",
        "version": 1,
        "timelines": timelines,
        "evidence": {
            "runtime_assets": ["visualizerSet.bin.gz.sdat", "ParameterSet.nut", "SequenceSet.nut"],
            "dat_opcodes": ["VL_START", "VL_END", "VL_DISP_ON", "VL_DISP_OFF", "VL_SEQUENCESET", "VL_CHANGETIME", "VL_VOLUME_SCALE"],
            "footage_backed_shape_ids": {"0": "radial ring", "3": "square/frame"},
            "unresolved": "visualizerSet SequenceSet/ParameterSet shape geometry and numeric IDs for other observed patterns",
        },
    }
    output.mkdir(parents=True, exist_ok=True)
    path = output / "SIIG_Visualizer_Simulator.html"
    toolkit.write_text_atomic(path, _html(dataset), encoding="utf-8")
    report = {
        "format": dataset["format"],
        "version": dataset["version"],
        "timeline_count": len(timelines),
        "event_count": sum(len(item["events"]) for item in timelines),
        "html": path.name,
    }
    toolkit.write_json_private(output / "VISUALIZER_SIMULATOR_MANIFEST.json", report, ensure_ascii=False)
    return report
