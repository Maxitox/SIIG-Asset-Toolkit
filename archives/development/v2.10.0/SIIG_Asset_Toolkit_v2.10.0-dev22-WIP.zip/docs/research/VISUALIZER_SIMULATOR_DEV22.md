# Visualizer simulator — dev22 evidence boundary

## Sources used

- Project-owner prototype footage, May 9 part 2 Visualizer Check Mode (`00:37:08.233–00:39:04.400`).
- Project-owner prototype footage, May 11 part 2 Visualizer Check Mode (`00:48:12.483–00:54:58.317`).
- Retail Xbox executable: `Function_82157958` loads `visualizerSet.bin.gz.sdat`, then creates runtime objects from `ParameterSet.nut` and `SequenceSet.nut`.
- Retail DAT semantic schema: `VL_START`, `VL_END`, `VL_DISP_ON`, `VL_DISP_OFF`, `VL_SEQUENCESET`, `VL_CHANGETIME`, `VL_VOLUME_SCALE`.

## Footage-backed controls and shapes

The May 11 debug UI visibly exposes volume/magnification, background RGBA, position, rotation, X/Y scale ranges and RGBA ranges.  The footage also directly associates:

- `SHAPE:0` with the red radial/ring presentation.
- `SHAPE:3` with the red square/frame presentation.

Additional triangle/frame, ray/fan, dot/tunnel and solid-field presentations are visibly present in the footage, but their numeric SHAPE IDs are not assigned in dev22.

## Simulator policy

`siig_visualizer.py` is intentionally split into two evidence layers:

1. **Exact decoded stage timeline** when a full rip is supplied.  The simulator lists and evaluates the game's authored `VL_*` DAT commands, including `VL_SEQUENCESET` IDs and volume-scale changes.
2. **Footage-backed visual approximation.**  The canvas reproduces the observed families of shapes and the debug-mode parameter surface, but does not claim pixel-identical SequenceSet/ParameterSet geometry.

Until `visualizerSet.bin.gz.sdat` / `SequenceSet.nut` / `ParameterSet.nut` are directly decoded, sequence ID → exact shape-program mapping stays unresolved.  The UI says this explicitly instead of inventing a mapping.
