#!/usr/bin/env python3
"""Offline SIIG visualizer simulator.

The dev24 renderer keeps recovered data and approximated rendering separate:

* DAT timing/state is decoded from the game.
* The 29-value ParameterSet row, 57 SequenceSet slots and exact ten-SHAPE
  resource order are recovered facts.
* June 10 Visualizer Check Mode code now grounds the debug control surface:
  VolumeSet 0=from BGM / 1=from Stick, X clears the feedback surface, Y toggles
  debug text, and all numeric control ranges/defaults are recovered from the
  executable's 30-row menu table.
* Fix Rotation is a signed angle override, not a boolean.  Zero leaves the
  normal accumulated SHAPE rotation path active; a non-zero value supplies the
  fixed angle used by the source-image transform.
* May 11/June-era executable tracing recovers the 1280x720 feedback target,
  128x128 source-image footprint, SHAPE-first draw order, feedback-only
  magnification, and exact Position Fix table.  WIP170 corrects the browser
  bridge to the game's center-origin, +Y-up position convention and collapses
  the executable's runtime-patched 3x3 fixed-position grid in the UI.
* June 10 audio tracing recovers VolumeSet/BGM as the arithmetic mean of the
  two XAudio2 volume-meter peak levels.  Dedicated Visualizer Check Mode feeds
  that raw linear float directly into the parameter interpolator.  Normal stage
  playback instead applies the recovered VisualizerScript adaptive normalizer:
  a 300-sample min/max window produces VOL SCALE, while 180-sample RAW/SCALE
  histories feed the on-hardware diagnostic averages.
* ParameterSet.nut and SequenceSet.nut are parsed from a supplied rip when
  available.  Their proprietary rows are never bundled into the source-only
  toolkit.

Proprietary SHAPE pixels can now be consumed from a user-supplied full rip but
are never bundled.  Their serialized Xbox TEX headers also prove point-filtered
sampling with repeat addressing, matching the generic SIIG TEX fetch-constant
decoder.  The ordinary ScreenSprite source shader is also recovered as sampled
SHAPE RGBA multiplied by runtime float4 tint RGBA with SrcAlpha/OneMinusSrcAlpha
source-over blending, while EffectBlur RGB sample/blend math is independently
closed.  Remaining browser boundaries are the exact XAudio2 processing-pass
sampling window and bit-exact Xenos render-target alpha storage/compositing.
"""
from __future__ import annotations

import base64
import concurrent.futures
import json
import re
import shutil
import subprocess
from pathlib import Path

import siig_toolkit as toolkit

VISUALIZER_OPCODES = set(range(0xC8, 0xCF))
MAX_SCRIPT_BYTES = 8 * 1024 * 1024
MAX_NUT_BYTES = 2 * 1024 * 1024

# Exact resource order recovered from visualizer.bin.
SHAPE_RESOURCES = (
    "WhiteCircle",
    "line",
    "3line",
    "square",
    "triangle",
    "WhiteCircle2",
    "line2",
    "3line2",
    "square2",
    "triangle2",
)

# VisualizerMain constructs a 1280x720 render target; each of the ten source
# images is instantiated as 128x128.  The fixed-position table is read by the
# feedback/source renderer when Position Fix is non-zero.
RENDER_TARGET_SIZE = (1280, 720)
SHAPE_TEXTURE_SIZE = (128, 128)
# The executable image contains the horizontal columns immediately, while a
# startup initializer patches the upper/lower Y rows into the writable table.
# C39A0000 is -308.0: the initializer writes +308 to raw 1..3 and -308 to
# raw 7..9.  Raw 4..6 remain Y=0.  Raw 0 is special in VisualizerMain: it
# selects Position Free X/Y instead of the fixed table, although the table's
# default entry itself is (0,0).
POSITION_FIX_COORDS = (
    (0.0, 0.0),
    (-448.0, 308.0),
    (0.0, 308.0),
    (448.0, 308.0),
    (-448.0, 0.0),
    (0.0, 0.0),
    (448.0, 0.0),
    (-448.0, -308.0),
    (0.0, -308.0),
    (448.0, -308.0),
)

# WIP170 incorrectly treated the zero-filled pre-constructor Y words as final
# data and collapsed rows into aliases.  Preserve this compatibility symbol as
# an identity map so existing callers keep working, but never collapse raw
# Position Fix values: all 1..9 are distinct runtime presets.
POSITION_FIX_CANONICAL_INDICES = tuple(range(10))
POSITION_FIX_CHOICES = (
    {"canonical_index": 0, "raw_indices": (0,), "label": "Free X/Y", "coord": (0.0, 0.0)},
    {"canonical_index": 1, "raw_indices": (1,), "label": "Upper left", "coord": (-448.0, 308.0)},
    {"canonical_index": 2, "raw_indices": (2,), "label": "Upper center", "coord": (0.0, 308.0)},
    {"canonical_index": 3, "raw_indices": (3,), "label": "Upper right", "coord": (448.0, 308.0)},
    {"canonical_index": 4, "raw_indices": (4,), "label": "Middle left", "coord": (-448.0, 0.0)},
    {"canonical_index": 5, "raw_indices": (5,), "label": "Fixed center", "coord": (0.0, 0.0)},
    {"canonical_index": 6, "raw_indices": (6,), "label": "Middle right", "coord": (448.0, 0.0)},
    {"canonical_index": 7, "raw_indices": (7,), "label": "Lower left", "coord": (-448.0, -308.0)},
    {"canonical_index": 8, "raw_indices": (8,), "label": "Lower center", "coord": (0.0, -308.0)},
    {"canonical_index": 9, "raw_indices": (9,), "label": "Lower right", "coord": (448.0, -308.0)},
)


def canonical_position_fix_index(raw_index: int | float) -> int:
    """Clamp Position Fix to the native raw 0..9 range without aliasing."""
    return max(0, min(9, int(round(float(raw_index)))))


def visualizer_canvas_position(
    x: float,
    y: float,
    *,
    width: int = RENDER_TARGET_SIZE[0],
    height: int = RENDER_TARGET_SIZE[1],
) -> tuple[float, float]:
    """Map SIIG's center-origin, +Y-up Visualizer coordinates to Canvas.

    The game-space Position Free values are centered on the 1280x720 target.
    Browser Canvas uses +Y downward, so only Y changes sign.  The project-owner
    same-stage project-owner hardware capture validates the important edge case: PARAM_3's
    authored (10, +360) spawn belongs at the *top* edge, not the bottom edge.
    """
    return (float(width) * 0.5 + float(x), float(height) * 0.5 - float(y))

# June 10 VisualizerScript constructor/update path:
# Function_82177510 creates a 300-float adaptive range window and 180-float
# diagnostic RAW/SCALE histories. Function_821773F0 refreshes extrema only
# when the 300-sample write index wraps, guards a sub-0.001 span, and maps the
# current raw stereo-peak mean to VOL SCALE. Function_82175FA8 refreshes the
# diagnostic 180-sample averages when their ring wraps.
GAMEPLAY_VOLUME_WINDOW = 300
GAMEPLAY_DIAGNOSTIC_HISTORY = 180
GAMEPLAY_VOLUME_MIN_SPAN = 0.001


def gameplay_volume_normalizer_trace(
    samples: list[float] | tuple[float, ...],
    *,
    window_samples: int = GAMEPLAY_VOLUME_WINDOW,
) -> list[dict]:
    """Reference the recovered June-10 normal-stage BGM normalizer.

    This intentionally models the game-side post-meter logic only.  ``samples``
    are the already-recovered linear stereo peak averages returned by the XAudio2
    meter bridge.  Exact upstream XAudio2 meter window/cadence remains external.
    """
    window_samples = max(5, int(window_samples))
    window = [0.0] * window_samples
    raw_hist = [0.0] * GAMEPLAY_DIAGNOSTIC_HISTORY
    scale_hist = [0.0] * GAMEPLAY_DIAGNOSTIC_HISTORY
    wi = 0
    hi = 0
    minimum = 0.0
    maximum = 1.0
    scale = 1.0
    ave_raw = 0.0
    ave_scale = 0.0
    out: list[dict] = []
    for value in samples:
        raw = float(value)
        raw_hist[hi] = raw
        clamped = min(1.0, max(0.0, raw))
        window[wi] = clamped
        wi += 1
        if wi >= window_samples:
            wi = 0
        if wi == 0:
            ordered = sorted(window)
            minimum = ordered[0]
            maximum = ordered[-1]
            if abs(maximum - minimum) < GAMEPLAY_VOLUME_MIN_SPAN:
                if maximum < GAMEPLAY_VOLUME_MIN_SPAN or minimum <= 0.999:
                    maximum = minimum + GAMEPLAY_VOLUME_MIN_SPAN
                else:
                    minimum = maximum - GAMEPLAY_VOLUME_MIN_SPAN
        if raw < minimum:
            scale = 0.0
        elif raw > maximum:
            scale = 1.0
        else:
            span = max(abs(maximum - minimum), GAMEPLAY_VOLUME_MIN_SPAN)
            scale = (raw - minimum) / span
        scale_hist[hi] = scale
        hi += 1
        if hi >= GAMEPLAY_DIAGNOSTIC_HISTORY:
            hi = 0
            # Function_82175FA8 does not clear the prior display average before
            # accumulating, so preserve its tiny 1/180 carry exactly.
            ave_raw = (ave_raw + sum(raw_hist)) / GAMEPLAY_DIAGNOSTIC_HISTORY
            ave_scale = (ave_scale + sum(scale_hist)) / GAMEPLAY_DIAGNOSTIC_HISTORY
        out.append({
            "raw": raw,
            "minimum": minimum,
            "maximum": maximum,
            "scale": scale,
            "average_raw": ave_raw,
            "average_scale": ave_scale,
            "window_index": wi,
            "history_index": hi,
        })
    return out

# 29 serialized ParameterSet values.  Position Free is one debug-menu row but
# serializes as two numbers, which is why the menu has 28 parameter rows while
# the NUT row width is 29.
PARAMETER_FIELDS = (
    "magnify_scale_x_min",
    "magnify_scale_x_max",
    "magnify_scale_y_min",
    "magnify_scale_y_max",
    "magnify_a_min",
    "magnify_a_max",
    "bg_r",
    "bg_g",
    "bg_b",
    "bg_a",
    "shape",
    "position_fix",
    "position_free_x",
    "position_free_y",
    "rotation_base",
    "add_rotation",
    "fix_rotation",
    "scale_x_min",
    "scale_x_max",
    "scale_y_min",
    "scale_y_max",
    "rgb_r_min",
    "rgb_r_max",
    "rgb_g_min",
    "rgb_g_max",
    "rgb_b_min",
    "rgb_b_max",
    "rgb_a_min",
    "rgb_a_max",
)

# June 10 executable VisualizerCheckMode menu table at 0x82574550.  Integer
# storage scaling is normalized here to the values printed by the game's own
# format strings.  The free-position bounds come from Function_821839B8.
VISUALIZER_CHECK_CONTROLS = {
    "volume_source": {"default": 1, "min": 0, "max": 1, "options": ["from BGM", "from Stick"]},
    "bgm_index": {"default": 0, "min": 0, "max": 50, "step": 1},
    "magnify_scale_x_min": {"default": 1.03, "min": 0.8, "max": 2.0, "step": 0.001},
    "magnify_scale_x_max": {"default": 1.03, "min": 0.8, "max": 2.0, "step": 0.001},
    "magnify_scale_y_min": {"default": 1.03, "min": 0.8, "max": 2.0, "step": 0.001},
    "magnify_scale_y_max": {"default": 1.03, "min": 0.8, "max": 2.0, "step": 0.001},
    "magnify_a_min": {"default": 1.0, "min": 0.7, "max": 1.0, "step": 0.001},
    "magnify_a_max": {"default": 1.0, "min": 0.7, "max": 1.0, "step": 0.001},
    "bg_r": {"default": 0, "min": 0, "max": 255, "step": 1},
    "bg_g": {"default": 0, "min": 0, "max": 255, "step": 1},
    "bg_b": {"default": 0, "min": 0, "max": 255, "step": 1},
    "bg_a": {"default": 0, "min": 0, "max": 255, "step": 1},
    "shape": {"default": 0, "min": 0, "max": 9, "step": 1},
    "position_fix": {"default": 0, "min": 0, "max": 9, "step": 1},
    "position_free_x": {"default": 0, "min": -560, "max": 560, "step": 1},
    "position_free_y": {"default": 0, "min": -360, "max": 360, "step": 1},
    "rotation_base": {"default": 0.1, "min": -365.0, "max": 365.0, "step": 0.1},
    "add_rotation": {"default": 0.0, "min": -730.0, "max": 730.0, "step": 0.1},
    "fix_rotation": {"default": 0.0, "min": -365.0, "max": 365.0, "step": 0.1},
    "scale_x_min": {"default": 1.0, "min": 0.01, "max": 4.0, "step": 0.001},
    "scale_x_max": {"default": 1.0, "min": 0.01, "max": 4.0, "step": 0.001},
    "scale_y_min": {"default": 1.0, "min": 0.01, "max": 4.0, "step": 0.001},
    "scale_y_max": {"default": 1.0, "min": 0.01, "max": 4.0, "step": 0.001},
    "rgb_r_min": {"default": 128, "min": 0, "max": 255, "step": 1},
    "rgb_r_max": {"default": 255, "min": 0, "max": 255, "step": 1},
    "rgb_g_min": {"default": 0, "min": 0, "max": 255, "step": 1},
    "rgb_g_max": {"default": 0, "min": 0, "max": 255, "step": 1},
    "rgb_b_min": {"default": 0, "min": 0, "max": 255, "step": 1},
    "rgb_b_max": {"default": 0, "min": 0, "max": 255, "step": 1},
    "rgb_a_min": {"default": 255, "min": 0, "max": 255, "step": 1},
    "rgb_a_max": {"default": 255, "min": 0, "max": 255, "step": 1},
}


def _find_media(input_path: Path) -> Path | None:
    candidates = (
        input_path / "assets" / "Media",
        input_path / "Media",
        input_path / "assets" / "USRDIR",
        input_path / "USRDIR",
        input_path,
    )
    for candidate in candidates:
        if (candidate / "script").is_dir():
            return candidate
    return None


def _visualizer_timelines(input_path: Path | None) -> list[dict]:
    if input_path is None:
        return []
    media = _find_media(input_path)
    if media is None:
        return []
    result: list[dict] = []
    for path in sorted((media / "script").glob("*.dat"), key=lambda p: p.name.lower()):
        try:
            if path.stat().st_size > MAX_SCRIPT_BYTES:
                continue
            parsed = toolkit.parse_dat_bytes(path.read_bytes())
        except Exception:
            continue
        events = []
        for record in parsed["records"]:
            if record["opcode"] not in VISUALIZER_OPCODES:
                continue
            events.append({
                "frame": record["absolute_frame"],
                "opcode": record["opcode_name"],
                "args": record["args_signed"],
                "fields": record["semantic"]["fields"],
            })
        if events:
            result.append({
                "script": path.name,
                "duration_frames": parsed["duration_frames"],
                "events": events,
            })
    return result


def _find_visualizer_set_file(input_path: Path | None, name: str) -> Path | None:
    if input_path is None or not input_path.exists():
        return None
    candidates = (
        input_path / name,
        input_path / "visualizerSet" / name,
        input_path / "assets" / "visualizerSet" / name,
        input_path / "assets" / "Media" / "visualizerSet" / name,
        input_path / "Media" / "visualizerSet" / name,
        input_path / "converted_assets" / "visualizerSet" / name,
    )
    for path in candidates:
        if path.is_file() and path.stat().st_size <= MAX_NUT_BYTES:
            return path
    try:
        for path in input_path.rglob(name):
            if path.is_file() and path.stat().st_size <= MAX_NUT_BYTES:
                return path
    except OSError:
        return None
    return None


def _parse_nut_number(token: str) -> int | float:
    token = token.strip()
    if not token:
        raise ValueError("empty NUT number")
    value = float(token)
    if not any(ch in token.lower() for ch in (".", "e")) and value.is_integer():
        return int(value)
    return value


def _parse_nut_rows(text: str, prefix: str) -> list[list[int | float]]:
    pattern = re.compile(rf"\b{re.escape(prefix)}_(\d+)\s*<-\s*\[([^\]]*)\]", re.MULTILINE)
    rows: dict[int, list[int | float]] = {}
    for match in pattern.finditer(text):
        index = int(match.group(1))
        values = [_parse_nut_number(token) for token in match.group(2).split(",") if token.strip()]
        rows[index] = values
    if not rows:
        return []
    maximum = max(rows)
    return [rows.get(i, []) for i in range(maximum + 1)]


def _visualizer_sets(input_path: Path | None) -> dict:
    parameter_path = _find_visualizer_set_file(input_path, "ParameterSet.nut")
    sequence_path = _find_visualizer_set_file(input_path, "SequenceSet.nut")
    parameter_rows: list[list[int | float]] = []
    sequence_rows: list[list[int | float]] = []
    try:
        if parameter_path is not None:
            parameter_rows = _parse_nut_rows(parameter_path.read_text(encoding="utf-8", errors="replace"), "PARAM")
    except (OSError, ValueError):
        parameter_rows = []
    try:
        if sequence_path is not None:
            sequence_rows = _parse_nut_rows(sequence_path.read_text(encoding="utf-8", errors="replace"), "SEQUENCE")
    except (OSError, ValueError):
        sequence_rows = []
    parameter_sets = []
    for index, values in enumerate(parameter_rows):
        if len(values) != len(PARAMETER_FIELDS):
            continue
        parameter_sets.append({"id": index, "values": values})
    sequence_sets = []
    for index, values in enumerate(sequence_rows):
        if not values:
            continue
        sequence_sets.append({"id": index, "parameter_ids": [int(value) for value in values]})
    return {
        "parameter_sets": parameter_sets,
        "sequence_sets": sequence_sets,
        "source_files": [name for name, path in (("ParameterSet.nut", parameter_path), ("SequenceSet.nut", sequence_path)) if path is not None],
    }


def _timeline_presets(timelines: list[dict], sequence_sets: list[dict]) -> list[dict]:
    sequence_map = {item["id"]: [value for value in item["parameter_ids"] if value >= 0] for item in sequence_sets}
    presets: list[dict] = []
    for timeline in timelines:
        for event in timeline.get("events", []):
            if event.get("opcode") != "VL_SEQUENCESET" or not event.get("args"):
                continue
            sequence_id = int(event["args"][0])
            presets.append({
                "script": timeline["script"],
                "frame": int(event["frame"]),
                "sequence_id": sequence_id,
                "parameter_ids": sequence_map.get(sequence_id, []),
            })
    return presets


def _shape_image_payloads(input_path: Path | None) -> dict[str, str]:
    """Find converted retail Visualizer SHAPE PNGs in a user-supplied rip.

    Proprietary pixels are never part of the source package.  When the user
    builds the simulator from a full rip, the already-converted PNGs can be
    embedded into that *local generated HTML* so the source-image morphology
    is exact.
    """
    if input_path is None or not input_path.exists():
        return {}
    roots = [input_path] if input_path.is_dir() else [input_path.parent]
    candidates: dict[str, Path] = {}
    for scan_root in roots:
        for path in scan_root.rglob("*.png"):
            if path.stem not in SHAPE_RESOURCES:
                continue
            # Avoid same-named unrelated resources outside the Visualizer
            # extraction tree.
            if "visualizer" not in {part.lower() for part in path.parts}:
                continue
            candidates.setdefault(path.stem, path)
    payloads: dict[str, str] = {}
    for name in SHAPE_RESOURCES:
        path = candidates.get(name)
        if path is None:
            continue
        data = path.read_bytes()
        # Minimal PNG identity + recovered 128x128 source contract.
        if len(data) < 24 or data[:8] != b"\x89PNG\r\n\x1a\n":
            continue
        width = int.from_bytes(data[16:20], "big")
        height = int.from_bytes(data[20:24], "big")
        if (width, height) != SHAPE_TEXTURE_SIZE:
            continue
        payloads[name] = "data:image/png;base64," + base64.b64encode(data).decode("ascii")
    return payloads



NATIVE_BGM_EXTENSIONS = {
    ".wma": "Xbox 360 WMA",
    ".at3": "PS3 AT3/ATRAC3+",
}


def _bgm_roots(input_path: Path | None) -> list[Path]:
    if input_path is None or not input_path.exists():
        return []
    candidates = (
        input_path / "ready_files" / "Media" / "BGM",
        input_path / "ready_files" / "USRDIR" / "BGM",
        input_path / "assets" / "Media" / "BGM",
        input_path / "assets" / "USRDIR" / "BGM",
        input_path / "Media" / "BGM",
        input_path / "USRDIR" / "BGM",
        input_path / "BGM",
    )
    result: list[Path] = []
    seen: set[str] = set()
    for root in candidates:
        try:
            if not root.is_dir():
                continue
            key = str(root.resolve())
        except OSError:
            continue
        if key in seen:
            continue
        seen.add(key)
        result.append(root)
    return result


def _ffmpeg_preview_codec(ffmpeg: str) -> tuple[str, str, list[str]]:
    """Return (extension, label, encoder args) for a browser-safe preview."""
    try:
        proc = subprocess.run(
            [ffmpeg, "-nostdin", "-hide_banner", "-encoders"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=15,
            check=False,
        )
        if "libmp3lame" in (proc.stdout or ""):
            return ".mp3", "MP3", ["-c:a", "libmp3lame", "-q:a", "5"]
    except (OSError, subprocess.SubprocessError):
        pass
    # FFmpeg's native AAC encoder is present in normal builds and gives us a
    # dependency-light fallback when libmp3lame is unavailable.
    return ".m4a", "AAC/M4A", ["-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart"]


def _prepare_bgm_previews(input_path: Path | None, output: Path, ffmpeg_path: str | None = None) -> dict:
    """Discover console-native BGM and make browser-safe local previews.

    Original WMA/AT3 bytes are never modified or bundled into the source-only
    toolkit.  Preview files are generated only beside a locally generated
    simulator from the user's own rip.  The source SHA-256 is part of the
    preview filename, so unchanged tracks are naturally cacheable across
    simulator rebuilds.
    """
    sources: list[Path] = []
    seen: set[str] = set()
    for root in _bgm_roots(input_path):
        try:
            children = sorted(root.iterdir(), key=lambda p: p.name.lower())
        except OSError:
            continue
        for path in children:
            if not path.is_file() or path.suffix.lower() not in NATIVE_BGM_EXTENSIONS:
                continue
            try:
                key = str(path.resolve())
            except OSError:
                key = str(path)
            if key in seen:
                continue
            seen.add(key)
            sources.append(path)

    ffmpeg = ffmpeg_path or shutil.which("ffmpeg")
    if ffmpeg_path and not Path(ffmpeg_path).exists():
        ffmpeg = shutil.which(ffmpeg_path)
    preview_root = output / "bgm_preview"
    if sources:
        preview_root.mkdir(parents=True, exist_ok=True)

    codec_ext, codec_label, codec_args = ("", "", [])
    if ffmpeg:
        codec_ext, codec_label, codec_args = _ffmpeg_preview_codec(ffmpeg)

    entries: list[dict] = []
    jobs: list[tuple[int, Path, Path]] = []
    for path in sources:
        try:
            digest = toolkit.sha256_file(path)
        except OSError:
            digest = "unreadable"
        safe_stem = re.sub(r"[^A-Za-z0-9._-]+", "_", path.stem).strip("._") or "bgm"
        preview_name = f"{safe_stem}-{digest[:12]}{codec_ext}" if ffmpeg and digest != "unreadable" else None
        entry = {
            "name": path.name,
            "native_format": NATIVE_BGM_EXTENSIONS[path.suffix.lower()],
            "source_sha256": digest if digest != "unreadable" else None,
            "preview": f"bgm_preview/{preview_name}" if preview_name else None,
            "preview_codec": codec_label if preview_name else None,
            "status": "ready" if preview_name and (preview_root / preview_name).is_file() else ("pending" if preview_name else "ffmpeg_unavailable"),
        }
        entries.append(entry)
        if preview_name and not (preview_root / preview_name).is_file():
            jobs.append((len(entries) - 1, path, preview_root / preview_name))

    def transcode(job: tuple[int, Path, Path]) -> tuple[int, bool]:
        index, source, destination = job
        temp = destination.with_suffix(destination.suffix + ".partial")
        try:
            temp.unlink(missing_ok=True)
            command = [
                ffmpeg,
                "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
                "-i", str(source), "-map", "0:a:0", "-vn",
                "-ac", "2", "-ar", "48000",
                *codec_args,
                str(temp),
            ]
            # Because .partial is the final suffix here, explicitly name the
            # muxer for deterministic temporary output.
            if destination.suffix.lower() == ".mp3":
                command[-1:-1] = ["-f", "mp3"]
            else:
                command[-1:-1] = ["-f", "mp4"]
            proc = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=300, check=False)
            if proc.returncode != 0 or not temp.is_file() or temp.stat().st_size <= 0:
                temp.unlink(missing_ok=True)
                return index, False
            temp.replace(destination)
            return index, True
        except (OSError, subprocess.SubprocessError):
            temp.unlink(missing_ok=True)
            return index, False

    if ffmpeg and jobs:
        workers = min(4, len(jobs))
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
            for index, ok in pool.map(transcode, jobs):
                entries[index]["status"] = "ready" if ok else "transcode_failed"
                if not ok:
                    entries[index]["preview"] = None
                    entries[index]["preview_codec"] = None

    ready = sum(1 for item in entries if item["status"] == "ready")
    return {
        "tracks": entries,
        "native_track_count": len(entries),
        "preview_count": ready,
        "ffmpeg_available": bool(ffmpeg),
        "preview_codec": codec_label or None,
    }


def _html(dataset: dict) -> str:
    payload = json.dumps(dataset, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    template = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SIIG Visualizer Simulator</title>
<style>
:root{color-scheme:dark;background:#08090d;color:#eef1f7;font:14px system-ui,sans-serif}*{box-sizing:border-box}body{margin:0}header{padding:12px 16px;background:#111621;border-bottom:1px solid #293247;display:flex;gap:10px;align-items:center;flex-wrap:wrap;position:sticky;top:0;z-index:5}h1{font-size:18px;margin:0 14px 0 0}button,select,input,audio{background:#1a2130;color:#eef;border:1px solid #3a465e;border-radius:6px;padding:6px 8px}button{cursor:pointer}main{display:grid;grid-template-columns:minmax(350px,455px) 1fr;min-height:calc(100vh - 58px)}aside{padding:14px;border-right:1px solid #293247;overflow:auto}section{padding:14px;min-width:0}fieldset{border:1px solid #2e394f;border-radius:8px;margin:0 0 10px;padding:10px}legend{color:#b9c7df;padding:0 5px}.row{display:grid;grid-template-columns:1fr 138px;gap:8px;align-items:center;margin:5px 0}.pair{display:grid;grid-template-columns:1fr 1fr;gap:6px}.quad{display:grid;grid-template-columns:repeat(4,1fr);gap:5px}.muted{color:#9ba8bd}.notice{padding:9px;border:1px solid #5b4b27;background:#251f14;color:#f0d99d;border-radius:8px;margin-bottom:10px}.good{border-color:#335d41;background:#15251b;color:#bde6c6}.canvas-wrap{display:flex;justify-content:center;align-items:center;min-height:440px;background:#000;border:1px solid #263047;border-radius:9px;overflow:hidden}canvas{display:block;max-width:100%;height:auto;background:#000}.timeline{margin-top:12px;border:1px solid #293247;border-radius:8px;overflow:auto;max-height:36vh}table{width:100%;border-collapse:collapse}th,td{padding:6px 8px;border-bottom:1px solid #222a3b;text-align:left}th{position:sticky;top:0;background:#151c29}.mono{font-family:ui-monospace,monospace;font-size:12px}.status{margin-top:8px;color:#b9c7df;font-family:ui-monospace,monospace}.small{font-size:12px}.schema{max-height:180px;overflow:auto;margin-top:7px;border:1px solid #252f42;border-radius:6px;padding:6px}.schema code{display:block;color:#b8c4d8;padding:1px 0}.hidden{display:none!important}.wide{width:100%}.meter{font-family:ui-monospace,monospace;color:#bde6c6}@media(max-width:950px){main{display:block}aside{border-right:0;border-bottom:1px solid #293247}.canvas-wrap{min-height:300px}}
</style></head><body>
<header><h1>SIIG Visualizer Simulator · dev24 runtime pipeline</h1><button id="play" type="button">Pause</button><button id="reset" type="button">Reset feedback (X)</button><button id="toggleDebug" type="button">Hide debug text (Y)</button><label>SHAPE <select id="shape"></select></label></header>
<main><aside>
<div class="notice good"><b>June 10 executable-backed controls.</b> X clears the feedback surface, Y toggles Visualizer info, VolumeSet 0 reads the BGM meter and 1 reads stick magnitude, and the original debug-menu ranges/defaults are reproduced below. Real-hardware stage 4-2/4-4/4-5 footage now also anchors the normal gameplay VOL/MIN/MAX/VOL SCALE diagnostics.</div>
<div class="notice small">Recovered facts are kept separate from approximation. <b>The runtime pipeline is executable-backed:</b> 1280×720 feedback target, 128×128 SHAPE source, SHAPE-first draw order, feedback magnification without framebuffer rotation, signed Fix Rotation, and the exact Position Fix coordinate table. Position coordinates use the game's centered convention: <b>+X right, +Y up</b>; Canvas therefore flips only Y. Startup code patches the writable fixed-position table into a full 3×3 grid: raw 1..3 upper, 4..6 middle, and 7..9 lower; raw 0 remains the Free X/Y path. When built from a full rip, the simulator embeds the user's real ten Visualizer SHAPE PNGs; otherwise it falls back to procedural stand-ins. Recursive GPU sampler/blend/shader semantics are executable-backed; only final host presentation and exact render-target alpha storage remain browser-side approximations.</div>
<fieldset><legend>VolumeSet / input</legend>
<div class="row"><label>VolumeSet</label><select id="volumeSource"><option value="0">0 · from BGM</option><option value="1" selected>1 · from Stick</option></select></div>
<div class="row"><label>BGM response model</label><select id="bgmResponseModel"><option value="check" selected>Check Mode · raw peak mean</option><option value="gameplay">Stage playback · adaptive VOL SCALE</option></select></div>
<div class="row"><label>Left Stick magnitude</label><input id="stickVolume" type="range" min="0" max="1" step="0.001" value="0"></div>
<div class="muted small">Arrow keys or WASD temporarily drive the simulated stick to 1.0. The original code takes the absolute stick value.</div>
<div class="row"><label>Extracted game BGM</label><select id="bgmPreset"><option value="">— choose generated preview —</option></select></div>
<div id="bgmPreviewStatus" class="muted small">No console-native BGM previews were generated.</div>
<div class="row"><label>Host BGM audio</label><input id="bgmFile" type="file" accept=".wma,.at3,.wav,.mp3,.m4a,.aac,.ogg,.flac,audio/*"></div>
<audio id="bgmAudio" class="wide" controls></audio><div id="bgmMeter" class="meter small">BGM meter: peak L 0.000 · peak R 0.000 · raw mean 0.000</div>
<div id="bgmGameplayMeter" class="meter small">Stage meter: VOL 0.0000 · MIN 0.0000 · MAX 1.0000 · VOL SCALE 1.0000 · AVE RAW 0.0000 · AVE SCALE 0.0000</div>
<div class="muted small">Executable-backed semantics: the game averages the left/right XAudio2 volume-meter <b>peak</b> levels. Check Mode consumes that raw linear 0..1 mean directly. Normal stage playback writes it through a 300-sample adaptive min/max window and drives parameter interpolation with normalized <b>VOL SCALE</b>; the hardware AVE RAW/SCALE diagnostics use 180-sample histories. The simulator executes that recovered post-meter state once per logical 60 Hz simulation step; the upstream XAudio2 analysis-window cadence itself remains an approximation in the browser. Xbox WMA and PS3 AT3/ATRAC3+ are converted by the toolkit to browser-safe local previews when FFmpeg is available; originals remain untouched.</div>
<button id="resetBgmNormalizer" type="button">Reset stage BGM normalizer</button>
</fieldset>
<fieldset><legend>Feedback / magnify</legend>
<div class="row"><label>Magnify Scale X min/max</label><div class="pair"><input id="magxmin" type="number" min="0.8" max="2" step="0.001" value="1.030"><input id="magxmax" type="number" min="0.8" max="2" step="0.001" value="1.030"></div></div>
<div class="row"><label>Magnify Scale Y min/max</label><div class="pair"><input id="magymin" type="number" min="0.8" max="2" step="0.001" value="1.030"><input id="magymax" type="number" min="0.8" max="2" step="0.001" value="1.030"></div></div>
<div class="row"><label>Magnify A min/max</label><div class="pair"><input id="magamin" type="number" min="0.7" max="1" step="0.001" value="1.000"><input id="magamax" type="number" min="0.7" max="1" step="0.001" value="1.000"></div></div>
<div class="row"><label>Display softness (host-only px)</label><input id="displaySoftness" type="range" min="0" max="12" step="0.1" value="5.5"></div>
<div class="row"><label>Display intensity (host-only)</label><input id="displayIntensity" type="range" min="0.1" max="1" step="0.01" value="0.32"></div>
<div class="muted small">Presentation-only softening/intensity after the recovered feedback pass. The 5.5 px / 0.32 defaults are calibrated to the project-owner's June-10 real-hardware capture and do <b>not</b> feed back into the executable-backed point-filtered SHAPE/feedback surfaces. Set softness 0 and intensity 1 for the raw recovered RGB recurrence.</div>
<div class="row"><label>Rotation Base (deg/update)</label><input id="rotbase" type="number" min="-365" max="365" step="0.1" value="0.1"></div>
<div class="row"><label>Add Rotation (deg/update × volume)</label><input id="rotadd" type="number" min="-730" max="730" step="0.1" value="0.0"></div>
<div class="row"><label>Fix Rotation (deg)</label><input id="rotfix" type="number" min="-365" max="365" step="0.1" value="0.0"></div>
<div class="muted small">Fix Rotation = 0 keeps accumulated rotation active. Any non-zero value overrides the visualization angle with that fixed angle.</div>
</fieldset>
<fieldset><legend>Stamp / position</legend>
<div class="row"><label>Position Fix</label><select id="positionFix"></select></div>
<div class="row"><label>Position Free X/Y</label><div class="pair"><input id="posx" type="number" min="-560" max="560" step="1" value="0"><input id="posy" type="number" min="-360" max="360" step="1" value="0"></div></div><div class="muted small">Centered game coordinates: +X moves right and +Y moves up. Example: Y +360 anchors the SHAPE at the top edge; Y -360 anchors it at the bottom edge.</div>
<div class="row"><label>Scale X min/max</label><div class="pair"><input id="sxmin" type="number" min="0.01" max="4" step="0.001" value="1"><input id="sxmax" type="number" min="0.01" max="4" step="0.001" value="1"></div></div>
<div class="row"><label>Scale Y min/max</label><div class="pair"><input id="symin" type="number" min="0.01" max="4" step="0.001" value="1"><input id="symax" type="number" min="0.01" max="4" step="0.001" value="1"></div></div>
</fieldset>
<fieldset><legend>Background RGBA</legend>
<div class="quad"><input id="bgr" aria-label="BG R" type="number" min="0" max="255" value="0"><input id="bgg" aria-label="BG G" type="number" min="0" max="255" value="0"><input id="bgb" aria-label="BG B" type="number" min="0" max="255" value="0"><input id="bga" aria-label="BG A" type="number" min="0" max="255" value="0"></div>
</fieldset>
<fieldset><legend>Stamp RGBA min/max</legend>
<div class="row"><label>R min/max</label><div class="pair"><input id="rmin" type="number" min="0" max="255" value="128"><input id="rmax" type="number" min="0" max="255" value="255"></div></div>
<div class="row"><label>G min/max</label><div class="pair"><input id="gmin" type="number" min="0" max="255" value="0"><input id="gmax" type="number" min="0" max="255" value="0"></div></div>
<div class="row"><label>B min/max</label><div class="pair"><input id="bmin" type="number" min="0" max="255" value="0"><input id="bmax" type="number" min="0" max="255" value="0"></div></div>
<div class="row"><label>A min/max</label><div class="pair"><input id="amin" type="number" min="0" max="255" value="255"><input id="amax" type="number" min="0" max="255" value="255"></div></div>
</fieldset>
<fieldset><legend>Recovered game presets</legend>
<div id="setStatus" class="muted small">No ParameterSet.nut / SequenceSet.nut loaded. Build the simulator from a full rip to enable exact game rows.</div>
<div class="row"><label>ParameterSet</label><select id="parameterPreset"></select></div><button id="applyParameter" type="button">Apply parameter row</button>
<div class="row"><label>SequenceSet</label><select id="sequencePreset"></select></div><button id="applySequence" type="button">Apply active parameter row</button>
<div class="row"><label>Stage / boss event</label><select id="timelinePreset"></select></div><button id="applyTimelinePreset" type="button">Jump to authored event + apply row</button>
<div class="muted small">SequenceSet preserves all 16 authored entries. Retail rows currently contain one active parameter id each. Stage/boss events come directly from decoded <code>VL_SEQUENCESET</code> commands, and the timeline now synchronizes the active parameter automatically.</div>
</fieldset>
<fieldset><legend>Recovered parameter schema</legend><div class="muted small">29 values / ParameterSet row · 49 retail rows · 57 retail sequences</div><div id="schema" class="schema mono"></div></fieldset>
<fieldset><legend>Decoded stage / boss visualizer timeline</legend><div class="row"><label>Script</label><select id="script"></select></div><div class="row"><label>Authored frame</label><input id="frame" type="range" min="0" max="0" value="0"></div><label class="small"><input id="timelineFollow" type="checkbox" checked> Advance authored stage frame with the 60 Hz simulator</label><div class="status" id="scriptStatus">No DAT timeline loaded.</div></fieldset>
</aside><section><div class="canvas-wrap"><canvas id="canvas" width="1280" height="720"></canvas></div><div id="debugInfo"><div class="status" id="status"></div></div><div class="timeline"><table><thead><tr><th>Frame</th><th>Opcode</th><th>Arguments</th></tr></thead><tbody id="events"></tbody></table></div></section></main>
<script id="data" type="application/json">__DATA__</script><script>
const DB=JSON.parse(document.getElementById('data').textContent),$=id=>document.getElementById(id),can=$('canvas'),ctx=can.getContext('2d',{alpha:true});
const W=can.width,H=can.height,feedback=[document.createElement('canvas'),document.createElement('canvas')],feedbackCtx=[];for(const c of feedback){c.width=W;c.height=H;feedbackCtx.push(c.getContext('2d',{alpha:false}))}let front=0,running=true,last=performance.now(),accum=0,logicalFrames=0,rotationAccum=0,showDebugInfo=true,bgmLevel=0,bgmPeakL=0,bgmPeakR=0,bgmChannels=2;const STEP=1/60,FIXED_POS=DB.evidence.position_fix_coords,FIXED_CHOICES=DB.evidence.position_fix_choices,FIXED_CANON=DB.evidence.position_fix_canonical_indices,GAME_VOL_WINDOW=300,GAME_AVG_HISTORY=180,GAME_MIN_SPAN=0.001;
const stageBgm={windowLength:GAME_VOL_WINDOW,window:new Float32Array(GAME_VOL_WINDOW),rawHistory:new Float32Array(GAME_AVG_HISTORY),scaleHistory:new Float32Array(GAME_AVG_HISTORY),windowIndex:0,historyIndex:0,min:0,max:1,scale:1,averageRaw:0,averageScale:0};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,Number(v)||0)),num=id=>Number($(id).value)||0,mix=(a,b,t)=>a+(b-a)*t,rad=d=>d*Math.PI/180;
const shapeImages={},shapePixels={},shapeTint=document.createElement('canvas');shapeTint.width=128;shapeTint.height=128;for(const [name,src] of Object.entries(DB.shape_images||{})){const img=new Image();img.src=src;shapeImages[name]=img}
function exactShapePixels(name){if(shapePixels[name])return shapePixels[name];const img=shapeImages[name];if(!img||!img.complete||!img.naturalWidth)return null;const c=document.createElement('canvas');c.width=128;c.height=128;const cg=c.getContext('2d',{willReadFrequently:true});cg.imageSmoothingEnabled=false;cg.clearRect(0,0,128,128);cg.drawImage(img,0,0,128,128);const pixels=new Uint8ClampedArray(cg.getImageData(0,0,128,128).data);shapePixels[name]=pixels;return pixels}
const stickKeys=new Set(),stickVolume=()=>clamp(Math.max(num('stickVolume'),stickKeys.size?1:0),0,1);
function resetGameplayBgmNormalizer(){stageBgm.window.fill(0);stageBgm.rawHistory.fill(0);stageBgm.scaleHistory.fill(0);stageBgm.windowIndex=0;stageBgm.historyIndex=0;stageBgm.min=0;stageBgm.max=1;stageBgm.scale=1;stageBgm.averageRaw=0;stageBgm.averageScale=0;updateGameplayMeter()}
function configureGameplayBgmWindow(samples){const n=Math.max(5,Math.round(Number(samples)||GAME_VOL_WINDOW));if(n===stageBgm.windowLength)return;stageBgm.windowLength=n;stageBgm.window=new Float32Array(n);resetGameplayBgmNormalizer()}
function updateGameplayBgmNormalizer(raw){stageBgm.rawHistory[stageBgm.historyIndex]=raw;stageBgm.window[stageBgm.windowIndex]=clamp(raw,0,1);stageBgm.windowIndex++;if(stageBgm.windowIndex>=stageBgm.windowLength)stageBgm.windowIndex=0;if(stageBgm.windowIndex===0){let lo=1,hi=0;for(const v of stageBgm.window){if(v<lo)lo=v;if(v>hi)hi=v}stageBgm.min=lo;stageBgm.max=hi;if(Math.abs(stageBgm.max-stageBgm.min)<GAME_MIN_SPAN){if(stageBgm.max<GAME_MIN_SPAN||stageBgm.min<=0.999)stageBgm.max=stageBgm.min+GAME_MIN_SPAN;else stageBgm.min=stageBgm.max-GAME_MIN_SPAN}}if(raw<stageBgm.min)stageBgm.scale=0;else if(raw>stageBgm.max)stageBgm.scale=1;else stageBgm.scale=(raw-stageBgm.min)/Math.max(Math.abs(stageBgm.max-stageBgm.min),GAME_MIN_SPAN);stageBgm.scaleHistory[stageBgm.historyIndex]=stageBgm.scale;stageBgm.historyIndex++;if(stageBgm.historyIndex>=GAME_AVG_HISTORY){stageBgm.historyIndex=0;let rawSum=stageBgm.averageRaw,scaleSum=stageBgm.averageScale;for(let i=0;i<GAME_AVG_HISTORY;i++){rawSum+=stageBgm.rawHistory[i];scaleSum+=stageBgm.scaleHistory[i]}stageBgm.averageRaw=rawSum/GAME_AVG_HISTORY;stageBgm.averageScale=scaleSum/GAME_AVG_HISTORY}updateGameplayMeter()}
const bgmDrive=()=>$('bgmResponseModel').value==='gameplay'?stageBgm.scale:bgmLevel,volume=()=>$('volumeSource').value==='0'?bgmDrive():stickVolume(),mixControl=(a,b)=>mix(num(a),num(b),volume());
function updateGameplayMeter(){$('bgmGameplayMeter').textContent=`Stage meter: VOL ${bgmLevel.toFixed(4)} · MIN ${stageBgm.min.toFixed(4)} · MAX ${stageBgm.max.toFixed(4)} · VOL SCALE ${stageBgm.scale.toFixed(4)} · AVE RAW ${stageBgm.averageRaw.toFixed(4)} · AVE SCALE ${stageBgm.averageScale.toFixed(4)} · window ${stageBgm.windowLength}f`}
function colorNow(){const v=volume();return [clamp(mix(num('rmin'),num('rmax'),v),0,255),clamp(mix(num('gmin'),num('gmax'),v),0,255),clamp(mix(num('bmin'),num('bmax'),v),0,255),clamp(mix(num('amin'),num('amax'),v),0,255)]}
function resetFeedback(){for(const c of feedback)c.getContext('2d').clearRect(0,0,W,H);front=0;logicalFrames=0;rotationAccum=0;drawDisplay()}
function toggleDebug(){showDebugInfo=!showDebugInfo;$('debugInfo').classList.toggle('hidden',!showDebugInfo);$('toggleDebug').textContent=showDebugInfo?'Hide debug text (Y)':'Show debug text (Y)'}
function shapeStamp(g,name,cx,cy,sx,sy,rgba,stampAngle){const pixels=exactShapePixels(name);if(pixels){const tg=shapeTint.getContext('2d',{willReadFrequently:true}),out=tg.createImageData(128,128),tr=clamp(rgba[0],0,255)/255,tgMul=clamp(rgba[1],0,255)/255,tb=clamp(rgba[2],0,255)/255,ta=clamp(rgba[3],0,255)/255;for(let i=0;i<pixels.length;i+=4){out.data[i]=Math.round(pixels[i]*tr);out.data[i+1]=Math.round(pixels[i+1]*tgMul);out.data[i+2]=Math.round(pixels[i+2]*tb);out.data[i+3]=Math.round(pixels[i+3]*ta)}tg.putImageData(out,0,0);g.save();g.translate(cx,cy);g.rotate(stampAngle);g.scale(sx,sy);g.globalCompositeOperation='source-over';const shapeSmooth=g.imageSmoothingEnabled;g.imageSmoothingEnabled=false;g.drawImage(shapeTint,-64,-64,128,128);g.imageSmoothingEnabled=shapeSmooth;g.restore();return}g.save();g.translate(cx,cy);g.rotate(stampAngle);g.scale(sx,sy);g.globalCompositeOperation='source-over';g.strokeStyle=`rgba(${rgba[0]|0},${rgba[1]|0},${rgba[2]|0},${rgba[3]/255})`;g.fillStyle=g.strokeStyle;g.lineCap='round';g.lineJoin='round';const r=42;switch(name){case 'WhiteCircle':g.lineWidth=8;g.beginPath();g.arc(0,0,r,0,Math.PI*2);g.stroke();break;case 'line':g.lineWidth=8;g.beginPath();g.moveTo(-64,0);g.lineTo(64,0);g.stroke();break;case '3line':g.lineWidth=7;for(const y of [-17,0,17]){g.beginPath();g.moveTo(-58,y);g.lineTo(58,y);g.stroke()}break;case 'square':g.lineWidth=8;g.strokeRect(-42,-42,84,84);break;case 'triangle':g.lineWidth=8;g.beginPath();g.moveTo(0,-52);g.lineTo(48,36);g.lineTo(-48,36);g.closePath();g.stroke();break;case 'WhiteCircle2':g.beginPath();g.arc(0,0,r,0,Math.PI*2);g.fill();break;case 'line2':g.lineWidth=18;g.beginPath();g.moveTo(-64,0);g.lineTo(64,0);g.stroke();break;case '3line2':g.lineWidth=15;for(const y of [-21,0,21]){g.beginPath();g.moveTo(-58,y);g.lineTo(58,y);g.stroke()}break;case 'square2':g.fillRect(-42,-42,84,84);break;case 'triangle2':g.beginPath();g.moveTo(0,-52);g.lineTo(48,36);g.lineTo(-48,36);g.closePath();g.fill();break}g.restore()}
function logicalStep(){updateGameplayBgmNormalizer(bgmLevel);const src=feedback[front],dst=feedback[1-front],g=feedbackCtx[1-front];g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='copy';const br=clamp(num('bgr'),0,255)|0,bg=clamp(num('bgg'),0,255)|0,bb=clamp(num('bgb'),0,255)|0,ba=clamp(num('bga'),0,255)/255;/* EffectBlurPS samples previous RGB but discards sampled alpha, replacing W with the uniform Alpha parameter. Keep feedback working canvases opaque and always preserve clear RGB so Canvas source alpha cannot attenuate the recovered RGB recurrence. */g.fillStyle=`rgb(${br},${bg},${bb})`;g.fillRect(0,0,W,H);g.globalCompositeOperation='source-over';const v=volume(),mx=Math.max(0.001,mixControl('magxmin','magxmax')),my=Math.max(0.001,mixControl('magymin','magymax')),ma=clamp(mixControl('magamin','magamax'),0,1);const rotStep=num('rotbase')+num('rotadd')*v,fix=Math.max(0,Math.min(9,Math.round(num('positionFix')))),freeX=num('posx'),freeY=num('posy'),fixed=(FIXED_CHOICES.find(x=>x.canonical_index===fix)||{coord:[0,0]}).coord,px=fix?fixed[0]:freeX,py=fix?fixed[1]:freeY,cx=W/2+px,cy=H/2-py;const fixRot=num('rotfix');if(Math.abs(fixRot)<1e-9)rotationAccum+=rotStep;const stampAngle=rad(Math.abs(fixRot)<1e-9?rotationAccum:fixRot),rgba=colorNow(),sx=mixControl('sxmin','sxmax'),sy=mixControl('symin','symax');/* Runtime order: clear target -> draw current SHAPE -> draw magnified previous feedback -> swap. Rotation is source-image only. */shapeStamp(g,$('shape').value,cx,cy,sx,sy,rgba,stampAngle);g.save();g.globalAlpha=ma;g.globalCompositeOperation='lighter';const prevSmooth=g.imageSmoothingEnabled;g.imageSmoothingEnabled=false;g.translate(cx,cy);g.scale(mx,my);g.translate(-cx,-cy);g.drawImage(src,0,0);g.imageSmoothingEnabled=prevSmooth;g.globalCompositeOperation='source-over';g.restore();front=1-front;logicalFrames++;advanceTimelineFrame()}
function drawDisplay(){ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,W,H);ctx.fillStyle='#000';ctx.fillRect(0,0,W,H);const softness=clamp(num('displaySoftness'),0,12),intensity=clamp(num('displayIntensity'),0.1,1);ctx.filter=softness>0?`blur(${softness.toFixed(2)}px)`:'none';ctx.globalAlpha=intensity;ctx.drawImage(feedback[front],0,0);ctx.globalAlpha=1;ctx.filter='none';const v=volume(),name=$('shape').value;const mx=mixControl('magxmin','magxmax'),my=mixControl('magymin','magymax'),ma=mixControl('magamin','magamax'),fixRot=num('rotfix');const seqText=activeTimelineSequence===null?'—':activeTimelineSequence,paramText=activeTimelineParameter===null?'—':activeTimelineParameter;$('status').textContent=`SEQ ${seqText} · PARAM ${paramText} · ${name} · VolumeSet ${$('volumeSource').value==='0'?'BGM '+($('bgmResponseModel').value==='gameplay'?'VOL SCALE':'raw'):'Stick'} ${v.toFixed(3)} · feedback scale ${mx.toFixed(3)}×${my.toFixed(3)} · A ${ma.toFixed(3)} · presentation ${softness.toFixed(1)} px × ${intensity.toFixed(2)} · rotation ${Math.abs(fixRot)<1e-9?'accum '+rotationAccum.toFixed(1)+'°':'fixed '+fixRot.toFixed(1)+'°'} · ${logicalFrames} logical frames`; }
let audioCtx=null,audioSource=null,audioSplitter=null,leftAnalyser=null,rightAnalyser=null,leftSamples=null,rightSamples=null,lastAudioUrl=null;const bgmAudio=$('bgmAudio'),bgmTracks=DB.bgm_tracks||[],bgmPreset=$('bgmPreset'),bgmPreviewStatus=$('bgmPreviewStatus');
function ensureAudioContext(){if(audioCtx)return audioCtx;const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return null;audioCtx=new AC();return audioCtx}
function connectAudioGraph(){if(leftAnalyser)return true;if(!audioCtx||audioCtx.state!=='running')return false;try{audioSource=audioCtx.createMediaElementSource(bgmAudio);audioSplitter=audioCtx.createChannelSplitter(2);leftAnalyser=audioCtx.createAnalyser();rightAnalyser=audioCtx.createAnalyser();leftAnalyser.fftSize=2048;rightAnalyser.fftSize=2048;leftSamples=new Float32Array(leftAnalyser.fftSize);rightSamples=new Float32Array(rightAnalyser.fftSize);audioSource.connect(audioSplitter);audioSplitter.connect(leftAnalyser,0);audioSplitter.connect(rightAnalyser,1);audioSource.connect(audioCtx.destination);return true}catch(_){return false}}
async function unlockAudioGraph(){const ac=ensureAudioContext();if(!ac)return false;try{if(ac.state==='suspended')await ac.resume()}catch(_){}if(ac.state!=='running')return false;return connectAudioGraph()}
function peakAbs(analyser,samples){analyser.getFloatTimeDomainData(samples);let peak=0;for(const x of samples)peak=Math.max(peak,Math.abs(x));return clamp(peak,0,1)}
function updateBgmMeter(){if(!leftAnalyser||bgmAudio.paused){bgmLevel=0;bgmPeakL=0;bgmPeakR=0}else{bgmPeakL=peakAbs(leftAnalyser,leftSamples);bgmPeakR=bgmChannels===1?bgmPeakL:peakAbs(rightAnalyser,rightSamples);bgmLevel=bgmChannels===1?bgmPeakL:(bgmPeakL+bgmPeakR)*0.5}const detail=bgmChannels===1?`peak ${bgmPeakL.toFixed(3)} · game avg ${bgmLevel.toFixed(3)}`:`peak L ${bgmPeakL.toFixed(3)} · peak R ${bgmPeakR.toFixed(3)} · game avg ${bgmLevel.toFixed(3)}`;$('bgmMeter').textContent=`BGM meter: ${detail.replace('game avg','raw mean')}`}
function setBgmStatus(text,bad=false){bgmPreviewStatus.textContent=text;bgmPreviewStatus.style.color=bad?'#f0b7b7':''}
function loadPreviewTrack(track){if(!track||!track.preview){setBgmStatus(track?`${track.name}: native ${track.native_format} found, but no browser preview is available. Install FFmpeg and rebuild the simulator.`:'No BGM selected.',true);return false}if(lastAudioUrl){URL.revokeObjectURL(lastAudioUrl);lastAudioUrl=null}bgmChannels=2;resetGameplayBgmNormalizer();bgmAudio.src=track.preview;bgmAudio.load();setBgmStatus(`${track.name} · ${track.native_format} → ${track.preview_codec} browser preview · press Play to unlock the live BGM meter`);return true}
for(const [i,track] of bgmTracks.entries()){const o=document.createElement('option');o.value=String(i);o.textContent=`${track.name} · ${track.native_format}${track.preview?'':' · preview unavailable'}`;bgmPreset.appendChild(o)}if(bgmTracks.length){const ready=bgmTracks.filter(x=>x.preview).length;setBgmStatus(`${bgmTracks.length} console-native BGM track(s) found · ${ready} browser preview(s) ready.`)}else{bgmPreset.disabled=true}
bgmPreset.onchange=()=>{if(bgmPreset.value==='')return;loadPreviewTrack(bgmTracks[Number(bgmPreset.value)])};
$('bgmFile').onchange=async()=>{const file=$('bgmFile').files&&$('bgmFile').files[0];if(!file)return;const ext=(file.name.split('.').pop()||'').toLowerCase();if(ext==='wma'||ext==='at3'){const matchIndex=bgmTracks.findIndex(t=>t.name.toLowerCase()===file.name.toLowerCase()&&t.preview);if(matchIndex>=0){bgmPreset.value=String(matchIndex);loadPreviewTrack(bgmTracks[matchIndex]);return}setBgmStatus(`${file.name}: browsers do not natively decode ${ext.toUpperCase()}. Rebuild this simulator from the rip with FFmpeg so the toolkit can create a local browser-safe preview.`,true);return}const ac=ensureAudioContext();if(ac){try{const decoded=await ac.decodeAudioData(await file.arrayBuffer());bgmChannels=Math.max(1,decoded.numberOfChannels||2)}catch(_){bgmChannels=2}}if(lastAudioUrl)URL.revokeObjectURL(lastAudioUrl);lastAudioUrl=URL.createObjectURL(file);resetGameplayBgmNormalizer();bgmAudio.src=lastAudioUrl;bgmAudio.load();setBgmStatus(`${file.name} · browser-loaded host audio · press Play to unlock the live BGM meter`)};bgmAudio.addEventListener('pointerdown',()=>{void unlockAudioGraph()});bgmAudio.addEventListener('keydown',()=>{void unlockAudioGraph()});bgmAudio.addEventListener('play',async()=>{const ok=await unlockAudioGraph();if(!ok)setBgmStatus('Audio is playing through the native media element, but the browser has not unlocked Web Audio analysis yet. Click/tap the audio controls once to enable the BGM meter.',true)});bgmAudio.addEventListener('error',()=>setBgmStatus('The browser could not decode this audio source. For WMA/AT3 use a toolkit-generated preview.',true));
function tick(now){updateBgmMeter();let dt=Math.min(0.1,(now-last)/1000);last=now;if(running){accum+=dt;while(accum>=STEP){logicalStep();accum-=STEP}drawDisplay()}requestAnimationFrame(tick)}
for(const name of DB.evidence.shape_resources){const o=document.createElement('option');o.value=name;o.textContent=`${DB.evidence.shape_resources.indexOf(name)} · ${name}`;$('shape').appendChild(o)}$('shape').value=DB.evidence.shape_resources[DB.evidence.check_mode_controls.shape.default]||'WhiteCircle';
for(const choice of FIXED_CHOICES){const o=document.createElement('option');o.value=String(choice.canonical_index);o.textContent=choice.canonical_index===0?'0 · Free X/Y (default 0,0 = center)':`${choice.canonical_index} · ${choice.label} · X ${choice.coord[0]} / Y ${choice.coord[1]}`;$('positionFix').appendChild(o)}
$('schema').innerHTML=DB.evidence.parameter_fields.map((x,i)=>`<code>${String(i).padStart(2,'0')} · ${x}</code>`).join('');
$('play').onclick=()=>{running=!running;$('play').textContent=running?'Pause':'Play';last=performance.now()};$('reset').onclick=resetFeedback;$('toggleDebug').onclick=toggleDebug;$('resetBgmNormalizer').onclick=resetGameplayBgmNormalizer;$('bgmResponseModel').onchange=()=>{resetGameplayBgmNormalizer();if(!running)drawDisplay()};
const ignoredTypingTarget=e=>['INPUT','SELECT','TEXTAREA'].includes((e.target&&e.target.tagName)||'');document.addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(!ignoredTypingTarget(e)&&k==='x'&&!e.repeat){resetFeedback();e.preventDefault();return}if(!ignoredTypingTarget(e)&&k==='y'&&!e.repeat){toggleDebug();e.preventDefault();return}if(!ignoredTypingTarget(e)&&['arrowup','arrowdown','arrowleft','arrowright','w','a','s','d'].includes(k)){stickKeys.add(k);e.preventDefault()}});document.addEventListener('keyup',e=>stickKeys.delete(e.key.toLowerCase()));window.addEventListener('blur',()=>stickKeys.clear());
for(const el of document.querySelectorAll('input,select')){if(['script','frame','bgmFile'].includes(el.id))continue;el.addEventListener('input',()=>{if(!running)drawDisplay()})}
const paramSets=DB.parameter_sets||[],seqSets=DB.sequence_sets||[],timelinePresets=DB.timeline_presets||[],paramSel=$('parameterPreset'),seqSel=$('sequencePreset'),timelinePresetSel=$('timelinePreset');let activeTimelineSequence=null,activeTimelineParameter=null;
if(paramSets.length){$('setStatus').textContent=`Loaded ${paramSets.length} ParameterSet rows and ${seqSets.length} SequenceSet rows from the supplied rip.`;for(const p of paramSets){const o=document.createElement('option');o.value=String(p.id);o.textContent=`PARAM_${p.id}`;paramSel.appendChild(o)}}else{paramSel.disabled=true;$('applyParameter').disabled=true}
if(seqSets.length){for(const s of seqSets){const active=s.parameter_ids.filter(x=>x>=0);const o=document.createElement('option');o.value=String(s.id);o.textContent=`SEQUENCE_${s.id} → ${active.length?active.map(x=>'PARAM_'+x).join(', '):'empty'}`;seqSel.appendChild(o)}}else{seqSel.disabled=true;$('applySequence').disabled=true}
if(timelinePresets.length){timelinePresets.forEach((p,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent=`${p.script} @ ${p.frame} → SEQUENCE_${p.sequence_id}${p.parameter_ids.length?' / '+p.parameter_ids.map(x=>'PARAM_'+x).join(', '):''}`;timelinePresetSel.appendChild(o)})}else{timelinePresetSel.disabled=true;$('applyTimelinePreset').disabled=true}
const fieldTargets=['magxmin','magxmax','magymin','magymax','magamin','magamax','bgr','bgg','bgb','bga',null,'positionFix','posx','posy','rotbase','rotadd','rotfix','sxmin','sxmax','symin','symax','rmin','rmax','gmin','gmax','bmin','bmax','amin','amax'];
function applyParameter(id,resetRotation=true){const p=paramSets.find(x=>x.id===Number(id));if(!p||p.values.length!==fieldTargets.length)return false;for(let i=0;i<p.values.length;i++){if(i===10){const idx=Math.max(0,Math.min(DB.evidence.shape_resources.length-1,Math.round(Number(p.values[i])||0)));$('shape').value=DB.evidence.shape_resources[idx];continue}const target=fieldTargets[i];if(target){if(i===11){const rawFix=Math.max(0,Math.min(9,Math.round(Number(p.values[i])||0)));$(target).value=String(FIXED_CANON[rawFix]??0)}else $(target).value=String(p.values[i])}}activeTimelineParameter=Number(id);if(resetRotation)rotationAccum=0;if(!running)drawDisplay();return true}
$('applyParameter').onclick=()=>applyParameter(paramSel.value);$('applySequence').onclick=()=>{const s=seqSets.find(x=>x.id===Number(seqSel.value));if(!s)return;activeTimelineSequence=s.id;const first=s.parameter_ids.find(x=>x>=0);if(first!==undefined){paramSel.value=String(first);applyParameter(first)}};
$('applyTimelinePreset').onclick=()=>{const p=timelinePresets[Number(timelinePresetSel.value)];if(!p)return;$('volumeSource').value='0';$('bgmResponseModel').value='gameplay';resetGameplayBgmNormalizer();sel.value=p.script;frame.value=String(p.frame);activeTimelineSequence=null;activeTimelineParameter=null;renderTimeline();};
const sel=$('script'),frame=$('frame'),events=$('events'),scriptStatus=$('scriptStatus'),timelines=DB.timelines||[];if(timelines.length){for(const t of timelines){const o=document.createElement('option');o.value=t.script;o.textContent=t.script;sel.appendChild(o)}}else{const o=document.createElement('option');o.textContent='No decoded DAT timeline';o.value='';sel.appendChild(o);sel.disabled=true;frame.disabled=true}
function renderTimeline(rebuildRows=true){const t=timelines.find(x=>x.script===sel.value);if(rebuildRows)events.innerHTML='';if(!t){scriptStatus.textContent='No DAT timeline loaded.';configureGameplayBgmWindow(GAME_VOL_WINDOW);activeTimelineSequence=null;activeTimelineParameter=null;return}frame.max=t.duration_frames||0;const f=Number(frame.value);let active=false,display=false,seq=null,volumeWindow=null,changeTime=null;for(const e of t.events){if(rebuildRows){const tr=document.createElement('tr');tr.innerHTML=`<td>${e.frame}</td><td>${e.opcode}</td><td class="mono">${e.args.join(' ')||'—'}</td>`;events.appendChild(tr)}if(e.frame>f)continue;if(e.opcode==='VL_START')active=true;if(e.opcode==='VL_END')active=false;if(e.opcode==='VL_DISP_ON')display=true;if(e.opcode==='VL_DISP_OFF')display=false;if(e.opcode==='VL_SEQUENCESET')seq=e.args[0];if(e.opcode==='VL_VOLUME_SCALE')volumeWindow=e.args[0];if(e.opcode==='VL_CHANGETIME')changeTime=e.args[0]}if(seq!==null&&seqSets.some(x=>x.id===seq)){seqSel.value=String(seq);if(activeTimelineSequence!==seq){const seqRow=seqSets.find(x=>x.id===seq),paramId=seqRow&&seqRow.parameter_ids.find(x=>x>=0);activeTimelineSequence=seq;if(paramId!==undefined){paramSel.value=String(paramId);applyParameter(paramId,false)}}}else{activeTimelineSequence=null;activeTimelineParameter=null}configureGameplayBgmWindow(volumeWindow??GAME_VOL_WINDOW);scriptStatus.textContent=`frame ${f} · active ${active?'yes':'no'} · display ${display?'on':'off'} · sequence ${seq??'—'} · parameter ${activeTimelineParameter??'—'} · change time ${changeTime??'—'} · adaptive volume window ${volumeWindow??GAME_VOL_WINDOW} frames`}
function advanceTimelineFrame(){if(!$('timelineFollow').checked||!timelines.length||!sel.value)return;const t=timelines.find(x=>x.script===sel.value);if(!t)return;const end=Number(t.duration_frames)||0,current=Number(frame.value)||0;if(current<end){frame.value=String(current+1);renderTimeline(false)}}
sel.onchange=()=>{$('volumeSource').value='0';$('bgmResponseModel').value='gameplay';frame.value='0';activeTimelineSequence=null;activeTimelineParameter=null;renderTimeline();resetGameplayBgmNormalizer();resetFeedback()};frame.oninput=()=>{activeTimelineSequence=null;activeTimelineParameter=null;renderTimeline()};$('timelineFollow').onchange=()=>{if($('timelineFollow').checked){$('volumeSource').value='0';$('bgmResponseModel').value='gameplay'}};renderTimeline();resetGameplayBgmNormalizer();resetFeedback();requestAnimationFrame(tick);
</script></body></html>'''
    return template.replace("__DATA__", payload)


def build_visualizer_simulator(input_path: Path | None, output: Path, ffmpeg_path: str | None = None) -> dict:
    timelines = _visualizer_timelines(input_path)
    sets = _visualizer_sets(input_path)
    bgm = _prepare_bgm_previews(input_path, output, ffmpeg_path=ffmpeg_path)
    dataset = {
        "format": "SIIG_VISUALIZER_SIMULATOR",
        "version": 16,
        "timelines": timelines,
        "bgm_tracks": bgm["tracks"],
        "parameter_sets": sets["parameter_sets"],
        "sequence_sets": sets["sequence_sets"],
        "timeline_presets": _timeline_presets(timelines, sets["sequence_sets"]),
        "shape_images": _shape_image_payloads(input_path),
        "evidence": {
            "primary_visual_reference": "June 10 Visualizer Check Mode footage",
            "runtime_assets": ["visualizerSet.bin.gz.sdat", "ParameterSet.nut", "SequenceSet.nut"],
            "parameter_preset_count": 49,
            "sequence_count": 57,
            "parameter_width": 29,
            "parameter_fields": list(PARAMETER_FIELDS),
            "shape_resources": list(SHAPE_RESOURCES),
            "check_mode_control_rows": 30,
            "check_mode_controls": VISUALIZER_CHECK_CONTROLS,
            "check_mode_input": {
                "volume_source_0": "from BGM",
                "volume_source_1": "from Stick",
                "reset_button": "X / input mask 0x40",
                "toggle_info_button": "Y / input mask 0x80",
                "position_free_bounds": {"x": [-560, 560], "y": [-360, 360]},
            },
            "loaded_set_files": sets["source_files"],
            "bgm_meter": {
                "value_semantics": "arithmetic mean of the two XAudio2 per-channel peak levels",
                "range": [0.0, 1.0],
                "game_channels": 2,
                "check_mode_transfer_after_meter": "none; Visualizer Check Mode consumes the returned linear float directly",
                "normal_stage_transfer_after_meter": "300-sample adaptive min/max normalizer -> VOL SCALE; parameter interpolation consumes VOL SCALE",
                "browser_bridge": "channel-separated time-domain peak sampling; browser analysis-window timing approximates the upstream XAudio2 processing-pass cadence",
            },
            "gameplay_volume_normalizer": {
                "constructor": "June10 Function_82177510",
                "configure": "June10 Function_82177300",
                "normalize": "June10 Function_821773F0",
                "update": "June10 Function_82177648",
                "debug_average": "June10 Function_82175FA8",
                "constructor_default_window_samples": GAMEPLAY_VOLUME_WINDOW,
                "dat_override": "VL_VOLUME_SCALE / opcode 0xCE calls Function_82177300 and replaces the adaptive window length in Visualizer update frames (minimum 5)",
                "reference_stage_window_frames": {"level4_stage2.dat": 180, "level4_stage4.dat": 180, "level4_stage5.dat": 180},
                "diagnostic_history_samples": GAMEPLAY_DIAGNOSTIC_HISTORY,
                "minimum_span": GAMEPLAY_VOLUME_MIN_SPAN,
                "initial_min": 0.0,
                "initial_max": 1.0,
                "initial_scale": 1.0,
                "formula": "clamp by MIN/MAX; otherwise (VOL-MIN)/max(abs(MAX-MIN),0.001)",
                "real_hardware_reference": "project-owner June 10 build recordings of stages 4-2, 4-4 and 4-5 on Xbox 360 hardware (2026-09-19)",
                "simulator_update": "once per logical 60 Hz simulator step; exact upstream XAudio2 meter window remains unresolved",
            },
            "presentation_softness": {
                "default_px": 5.5,
                "range_px": [0.0, 12.0],
                "default_intensity": 0.32,
                "intensity_range": [0.1, 1.0],
                "scope": "display-only post-filter after the recovered feedback recurrence",
                "runtime_sampler_unchanged": True,
                "calibration": "project-owner June-10 real-hardware stage comparison supplied 2026-09-19",
                "reason": "host-side bridge for the softer/dimmer final in-game presentation; raw recovered RGB remains available at softness 0 / intensity 1",
            },
            "native_bgm_preview": {
                "native_extensions": [".wma", ".at3"],
                "xbox360": "WMA",
                "ps3": "AT3/ATRAC3+",
                "ffmpeg_available": bgm["ffmpeg_available"],
                "preview_codec": bgm["preview_codec"],
                "native_track_count": bgm["native_track_count"],
                "preview_count": bgm["preview_count"],
                "policy": "original native BGM is untouched; browser-safe previews are generated only beside the user's local simulator",
                "preview_pcm_layout": "FFmpeg output normalized to stereo 48 kHz before browser-safe encoding",
                "browser_audio_policy": "native HTML audio remains directly audible until a running user-unlocked AudioContext is available; analyser routing never occurs while the context is suspended",
            },
            "dat_opcodes": ["VL_START", "VL_END", "VL_DISP_ON", "VL_DISP_OFF", "VL_SEQUENCESET", "VL_CHANGETIME", "VL_VOLUME_SCALE"],
            "render_target_size": list(RENDER_TARGET_SIZE),
            "shape_texture_size": list(SHAPE_TEXTURE_SIZE),
            "position_fix_coords": [list(item) for item in POSITION_FIX_COORDS],
            "position_fix_canonical_indices": list(POSITION_FIX_CANONICAL_INDICES),
            "position_fix_choices": [
                {
                    "canonical_index": item["canonical_index"],
                    "raw_indices": list(item["raw_indices"]),
                    "label": item["label"],
                    "coord": list(item["coord"]),
                }
                for item in POSITION_FIX_CHOICES
            ],
            "position_coordinate_system": {
                "origin": "center of 1280x720 feedback target",
                "x_axis": "+X right",
                "y_axis": "+Y up",
                "canvas_bridge": "canvas_x = 640 + game_x; canvas_y = 360 - game_y",
                "owner_capture_crosscheck": "project-owner hardware comparison with SEQUENCE_4 / PARAM_3 uses free (10,+360), placing the source anchor at canvas (650,0), not the bottom edge",
            },
            "render_pipeline": [
                "clear destination feedback target with SHAPE clear color",
                "draw current 128x128 SHAPE source at free/fixed position with source scale/color/rotation",
                "draw previous feedback target through magnify scale/alpha around the same position without framebuffer rotation",
                "swap ping-pong feedback targets",
            ],
            "runtime_functions": {
                "visualizer_main_ctor": "May11 Function_8216B168",
                "parameter_apply": "May11 Function_8216B4F8 / Function_8216B660",
                "feedback_render": "May11 Function_8216D830 / Function_8216DC18",
                "source_transform": "May11 Function_8216E380",
                "fixed_position": "May11 LAB_8216D8F8 + DAT_825624C8",
                "bgm_meter_capture": "June10 Function_82495500 + FUN_82496828(+0x400)",
                "bgm_meter_latch": "June10 FUN_824956C0 / FUN_82495360",
                "check_mode_volume_select": "June10 Function_82183B20",
            },
            "render_model": "executable-backed ping-pong feedback pipeline; uses real user-rip SHAPE PNG morphology when available, otherwise procedural stand-ins",
            "shape_image_policy": "proprietary PNGs are embedded only into locally generated simulator HTML from a user-supplied rip; never bundled in source",
            "feedback_sampler": {
                "fetch_constant_dword3": "0x00001414",
                "addressing": "repeat on X/Y/Z",
                "mag_filter": "point",
                "min_filter": "point",
                "mip_filter": "point (no mip chain used by the feedback target)",
                "anisotropy": "disabled",
                "browser_bridge": "imageSmoothingEnabled=false for the recursive previous-feedback draw",
                "evidence": "May11 Function_821AA630 -> Function_8226F240 -> Function_8226EA98 -> Function_8226F5C0; xe_gpu_texture_fetch_t field layout cross-checked against Xenia xenos.h",
            },
            "effectblur_shader": {
                "retail_microcode_sha256": "550328d21de6af38fde4a0814bd71aa68352667c826b0d7b1f172796c3db8116",
                "microcode_size_bytes": 72,
                "control_flow": "one 2D texture fetch, then two ALU instructions, then end",
                "texture_fetch": "sample TextureSampler into r0.xyz while keeping r0.w",
                "alpha_write": "r0.w = Alpha.w",
                "export": "color0 = r0",
                "rgb_equation": "shader source RGB = sampled previous-feedback RGB; sampled texture alpha is ignored",
                "alpha_equation": "shader source alpha = uniform feedback Alpha.w",
                "ps3_cross_check": "retail PS3 EffectBlurPS exposes only TextureSampler and Alpha; draw uploads (0,0,0,alpha)",
                "browser_bridge": "feedback working canvases are opaque RGB surfaces so Canvas lighter does not re-multiply sampled feedback RGB by browser source alpha",
                "evidence": "private retail EffectBlurPS microcode decoded against public Xenia ucode.h instruction layouts; proprietary shader bytes are not bundled",
            },
            "effectblur_blend": {
                "setup": "retail Function_821595F0 immediately before Function_82159CB8",
                "blend_enable": True,
                "packed_rb_blendcontrol": "0x01060106",
                "rgb_src_factor": "SrcAlpha (6)",
                "rgb_dst_factor": "One (1)",
                "rgb_operation": "Add",
                "alpha_src_factor": "SrcAlpha (6)",
                "alpha_dst_factor": "One (1)",
                "alpha_operation": "Add",
                "browser_bridge": "Canvas lighter on opaque feedback working canvases; globalAlpha carries recovered magnify alpha",
                "evidence": "Function_821595F0 -> FUN_8224B188(enable) + FUN_8224B2A8(6) + FUN_8224B338(1); packed state expands to 0x01060106; Xenos BlendFactor values cross-checked against Xenia xenos.h",
            },
            "shape_shader": {
                "shader": "ScreenSpritePS variant 0",
                "microcode_size_bytes": 60,
                "control_flow": "one 2D texture fetch followed by one vector multiply and color export",
                "pixel_equation": "output.rgba = sampled_shape.rgba * runtime_tint.rgba",
                "runtime_tint": "four-component float RGBA propagated by the ScreenSprite vertex path",
                "blend": "Add(SrcAlpha, OneMinusSrcAlpha) for the source SHAPE pass",
                "browser_bridge": "CPU-multiply user-rip PNG RGBA by runtime tint RGBA, then point-sampled Canvas source-over draw",
                "source_only": "shader bytes and proprietary texture pixels are not bundled",
            },
            "shape_sampler": {
                "serialized_tex_fetch_dword3": "0x00000C14",
                "addressing": "repeat on X/Y/Z",
                "mag_filter": "point",
                "min_filter": "point",
                "mip_filter": "point",
                "anisotropy": "disabled",
                "browser_bridge": "when real user-rip SHAPE PNGs are present, imageSmoothingEnabled=false only for their transformed draw",
                "evidence": "retail visualizer TEX 0x34-byte resource header copied by Function_8248BEB0; all ten headers are byte-identical and bind through Function_821AB320 -> Function_821AB6D8 -> Function_8226F5C0; fetch layout cross-checked against Xenia xenos.h",
            },
            "unresolved": [
                "exact browser analysis-window timing versus the XAudio2 processing-pass cadence",
                "exact Canvas alpha-channel equivalence to Xenos is not claimed; recovered Visualizer feedback RGB recurrence is modeled independently of sampled texture alpha",
            ],
        },
    }
    output.mkdir(parents=True, exist_ok=True)
    path = output / "SIIG_Visualizer_Simulator.html"
    toolkit.write_text_atomic(path, _html(dataset), encoding="utf-8")
    report = {
        "format": dataset["format"],
        "version": dataset["version"],
        "timeline_count": len(timelines),
        "event_count": sum(len(item["events"]) for item in timelines),
        "parameter_preset_count": 49,
        "sequence_count": 57,
        "loaded_parameter_preset_count": len(sets["parameter_sets"]),
        "loaded_sequence_count": len(sets["sequence_sets"]),
        "timeline_preset_count": len(dataset["timeline_presets"]),
        "check_mode_control_rows": 30,
        "shape_count": len(SHAPE_RESOURCES),
        "embedded_shape_image_count": len(dataset["shape_images"]),
        "native_bgm_track_count": bgm["native_track_count"],
        "bgm_preview_count": bgm["preview_count"],
        "bgm_preview_codec": bgm["preview_codec"],
        "ffmpeg_available": bgm["ffmpeg_available"],
        "html": path.name,
    }
    toolkit.write_json_private(output / "VISUALIZER_SIMULATOR_MANIFEST.json", report, ensure_ascii=False)
    return report
