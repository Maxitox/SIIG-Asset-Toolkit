## 2.10.0-dev9

- Reconstructed ULTIMATE UFO's complete retail allocated GMX pool as A8 + D0–D9 families: **126 allocated model instances**, while keeping simultaneous phase visibility distinct from allocation.
- Recovered exact named-locator attachment hierarchy: D5→A8 `lt_002..003`, D4→A8 `lt_004..024`, D6→D0/D1 `lt_226..257`, and D7→D2/D3 `lt_258..321`.
- Recovered opposite runtime Y-rotation metadata for the D0/D1 FAN and D2/D3 RING parent GMXs and preserved those parents/children as a true glTF hierarchy instead of baking guessed XYZ offsets.
- Added eight retail phase catalogs: states 2/3/6/7/8/9/11/12, with exact Mframe metadata and D8 airlock / D9 core identities.
- Added ULTIMATE UFO state selector, manifest export and one-click assembly to Simple/Advanced GUI 0.20.0-dev9.
- Added attachment/phase tables, research/validation provenance, and ULTIMATE UFO regression coverage; suite is **91/91** through development gating.
- No fresh real-retail `bos_015*.gmx` export is claimed in dev9 because those proprietary GMXs were not present in the persistent research Library; runtime attachment resolution is performed against the user's own extracted GMXs and rejects missing/ambiguous locators.

## 2.10.0-dev8

- Added `mandala_initial_combat`: exact state-7 activation snapshot with 40 visible instances (20×B7, 2×B8/B9/BA/BB, 12×4A); later 32×BC intentionally excluded.
- Recovered five-build MANDALA formation evidence, native signed 8.8 trig convention, exact slot-to-model dispatch, and structural scales 40/56/82/109/4×29/4×20.
- Added Simple/Advanced MANDALA GUI assembly actions in GUI 0.19.0-dev8.
- Added 40-row transform table, research/validation provenance, and MANDALA regression; suite is now 90/90 through development gating.

## 2.10.0-dev7

- Recovered HORNET state 6 as a deterministic 13-seed propagation family inherited from the dev6 prism-wall A1 slot; no second random seed is chosen.
- Proved state 5 clears all 45 record flags and hides A1 before propagation, so each inherited seed has a deterministic wave sequence.
- Reconstructed seed-only activation followed by alternating orthogonal/diagonal 9×5 expansion to full 45-cell coverage, cross-checked in June Xbox, retail Xbox and retail PS3.
- Added procedural `hornet_propagation_SS_wave_WW` assembly catalogs using reached C0 prisms only at the wave activation instant; invalid seeds/waves and an unqualified default are rejected.
- Added Advanced GUI propagation seed/wave controls and assembly/manifest actions in GUI 0.18.0-dev7.
- Added cross-platform research/table/validation provenance plus a representative real-retail 29-prism export validation.
- Added the HORNET propagation regression; suite is now 89/89 through development gating.

## 2.10.0-dev6

- Resolved HORNET's state-4 C0 prism wall as exactly 13 runtime-valid variants: one animated A1 root occupying the selected 5×9 grid slot plus 44 C0 prisms.
- Added the 13 `hornet_prism_wall_XX` catalogs and Advanced GUI selector while deliberately rejecting an unqualified random default.
- Cross-checked the exact root-slot table and wall geometry in June Xbox, retail Xbox and retail PS3.
- Added representative real-retail wall export validation and raised the suite to 88/88.

## 2.10.0-dev5

- Changed the beginner/default CRAB catalog from the dev4 airborne first-visible root sample 167 to the executable/ANM-backed first landed combat-loop sample 1; preserved the old formation as `crab_first_visible`.
- Confirmed project-owner Blender validation of CRAB and PROGRESSIVE UFO; documented that PROGRESSIVE UFO's slight barrier tilt is authored inside `bos_009b.gmx` rather than an outer C3 transform error.
- Resolved HORNET C1 / `bos_008c.gmx` as a genuine meshless 126-track formation rig rather than a questionable/corrupt model.
- Recovered HORNET runtime construction as A1 + 125×BF armor + 125×C0 prism pool + 1×C1 controller across June Xbox, retail Xbox and retail PS3.
- Added `hornet_full_armor`: A1 sample 0 plus 125 BF cubes on the exact C1 sample-0 5×5×5 lattice, with real-retail external export validation.
- Added one-click **Assemble HORNET** and advanced HORNET manifest actions to GUI 0.16.0-dev5.
- Kept native SIIG assembly scale/units unchanged and documented Blender Frame All/Selected navigation rather than introducing an unproven unit conversion.
- Added the HORNET assembly regression; suite is now 87/87 through final release gating.

## 2.10.0-dev4

- Reworked the desktop GUI for beginners without removing expert functionality. Simple mode is now the default; Advanced mode restores the full Mod Workspace and GMX Workbench controls.
- Added a persistent **What does this do?** help box. Hovering or focusing fields, Browse buttons, action buttons and advanced checkboxes explains the control in plain language.
- Simplified Mod Workspace into a numbered Create → Open/Edit → Build → Verify → Pack workflow in Simple mode.
- Simplified GMX Workbench into the common Original GMX → Export for Blender → Edit glTF → Rebuild GMX workflow, while keeping one-click PROGRESSIVE UFO and CRAB assembly visible.
- Advanced GMX graph/schema/JSON/skin/animation controls remain available unchanged behind the mode switch; Simple mode does not silently enable aggressive synchronization options.
- Resolved console opcode `0xA7` as CRAB through the explicit `bos_013.gmx` registry + `Crab.cpp` construction/update linkage; historical dev19 unresolved records remain unchanged as historical artifacts.
- Recovered CRAB's deterministic first-visible nine-part formation across June Xbox, retail Xbox and retail PS3: A7 root animation segment 3, native sample 167, runtime 180° Y root rotation, `CD/CC + 2×CE + 4×CF` locator-driven children, ±81 propodus and ±23 dactyl offsets.
- Added per-instance `pose_sample` to multi-GMX assembly export. Posed GMXs bake one native animation sample into static node transforms and suppress that instance's animation channels so separately instantiated children cannot drift out of sync.
- Added the built-in `crab` assembly catalog, `gmx-assemble-catalog crab`, GUI one-click **Assemble CRAB**, and a synthetic nine-instance pose/export regression. Suite: 86/86.

## 2.10.0-dev3

- Recovered PROGRESSIVE UFO runtime part order `A2,C2,C2,C3,C3` and the first five-part formation directly from executable initialization/state code.
- Filled the assembly catalog with exact local translations: body `(0,0,0)`, lasers `(-90,0,-10)` / `(90,0,-10)`, barriers `(-160,0,-50)` / `(160,0,-50)`; rotations are zero and scale is identity.
- Cross-checked the same constants/formation in June Xbox, retail Xbox, and retail PS3.
- Added `gmx-assemble-catalog progressive_ufo` and GUI 0.14.0-dev3 **Assemble PROGRESSIVE UFO**.
- Added source-only research/table/validation provenance and a five-instance matrix/export regression. Regression suite: 85/85.

## 2.10.0-dev2

- Added rigid mesh partitioning by joint: one glTF mesh may contain several disjoint unit-weight rigid islands. Triangle groups are compacted into separate native MESH/ARRY graphs and attached to their corresponding BONEs after per-joint inverse-bind rebaking. Triangles spanning more than one joint are rejected.
- Added manifest-driven multi-GMX glTF assembly export (`gmx-assemble`) with explicit per-instance transforms, hierarchy/material/animation remapping, combined buffers, texture copying, source hashes, and an assembly report.
- Added `gmx-assembly-template progressive_ufo`: evidence proves one bos_009.gmx body, two bos_009a.gmx laser machines, and two bos_009b.gmx barrier machines. Exact side-component runtime matrices remain unresolved and are deliberately not guessed.
- Desktop GUI 0.13.0-dev2 exposes the PROGRESSIVE UFO manifest and generic assembly exporter.
- Regression suite: 84/84.

# Changelog

## 2.10.0-dev1

- Opened the 2.10 feature line with **rigid inverse-bind geometry rebaking** for standard glTF skins. Single-joint `JOINTS_0`/`WEIGHTS_0` bindings may now carry a non-identity affine selected `inverseBindMatrices` transform.
- Rebaked `POSITION` values use the selected inverse-bind affine transform; `NORMAL` values use the inverse-transpose of its linear 3x3 and are renormalized. Translation is excluded from normals as required.
- Singular linear transforms are rejected when normals are present instead of emitting invalid geometry.
- Rigid skin validation now happens before MESH/ARRY compilation so both donor-layout and fully synthesized-schema paths receive the same bind-space correction. The later BONE/PARE pass reuses the exact same binding record.
- True blended/multi-joint skinning remains intentionally unsupported: no retail per-vertex weight representation has been confirmed, and `MESH.skin_index` remains evidence-bounded to the observed `0xFFFF` no-vertex-skin value.
- Added an independent non-identity-bind regression with translated/non-uniformly-scaled geometry, inverse-transpose normal verification, repaired root AABB, report provenance, rigid export, and singular-matrix rejection. Suite is now **82/82**.
- GUI advanced rigid-skin control now advertises inverse-bind rebaking. GUI version is **0.12.0-dev1**.

## 2.9.0-dev7

- Added an evidence-bounded **rigid glTF skin compatibility importer**. `--sync-rigid-skins` accepts `JOINTS_0`/`WEIGHTS_0` only when every vertex has the same single unit-weight joint and collapses that binding to SIIG's proven `BONE -> MESH` attachment model.
- True blended/multi-joint weights are rejected explicitly instead of inventing unsupported native weight streams. Secondary JOINTS/WEIGHTS sets and non-identity selected inverse-bind matrices are also rejected in this checkpoint.
- New synthesized MESH records now default `skin_index` to the corpus-observed `0xFFFF` unless a donor or explicit override says otherwise.
- Skin joint nodes are synthesized as native BONEs, hierarchy lookup crosses non-bone armature/container nodes, and the skinned mesh/material attachment is transferred to the selected joint BONE rather than creating a fake BONE for the glTF mesh-object node.
- `gltf2gmx-new` and Mod Workspace enable rigid-skin compatibility automatically; template-backed import exposes it through `--sync-rigid-skins` and a GMX Workbench checkbox.
- Added a positive/negative regression: a two-joint glTF skin with all vertices rigidly weighted to the child becomes two native BONEs plus one attached MESH, while a 50/50 blended vertex is rejected. Suite is now **81/81**.
- External corpus cross-check: 150 supplied retail player/enemy GMXs containing 901 MESH records all use `skin_index = 0xFFFF` and only POSITION/NORMAL/UV/COLOR + index ARRY semantics; this agrees with the earlier 486-GMX finding that SIIG geometry is rigidly attached to scene nodes rather than carrying per-vertex skin weights. Proprietary inputs are not bundled.
- Under the project's versioning policy, dev7 is the last planned feature checkpoint before the mandatory minor-version review; the next substantial feature line should move to 2.10.0 rather than accumulating another long 2.9 dev suffix.

## 2.9.0-dev6

- Added **fully template-free GMX root/scene compilation** through `gltf2gmx-new`; the command does not read or require an original `.gmx` file.
- Formalized the canonical decoded GMX root as a locally synthesized 0x30-byte record: `GMX\0`, root size, total stream size, proven minXYZ/maxXYZ geometry AABB, plus explicitly unnamed `+0x08` and `+0x28..+0x2F` fields. Unknown root bytes default to zero and can be carried through advanced glTF extras without assigning speculative semantics.
- `gltf2gmx-new` enables the previously proven decoded builders together: MESH/ARRY declaration synthesis, SHAD/MTRL construction, TXIF binding, BONE/PARE scene graph creation, and MOTN/ANIM import.
- glTF export now records `gmxRootUnknown08` and `gmxRootReserved28Hex` provenance so research-derived root bytes can survive a no-template recompile.
- Added a GUI **Create new GMX** action that compiles the selected glTF without requiring the Native GMX template field.
- Added a dependency-free regression that starts from a plain glTF with no SIIG-native IDs and verifies synthesized GMX root, TXIF/SHAD/MTRL/BONE/MOTN/ANIM/MESH/ARRY graph, repaired AABB/size, texture/material/mesh/bone links, 30 Hz animation, exporter root provenance, and explicit root-byte overrides.
- Dependency-free regression suite is now **80 tests**.
- Remaining high-value GMX work is glTF skin/joint-weight import, runtime validation of fully original scenes, platform shader microcode compilation, and semantics for still-opaque/unnamed fields.

## 2.9.0-dev5

- Expanded `--sync-animation-graph` so one glTF animation can target multiple BONE nodes. The compiler now expands a multi-bone clip into synchronized per-BONE native `MOTN`/`ANIM` pairs on one shared 30 Hz timeline.
- Added glTF `CUBICSPLINE` import for translation, rotation and scale. Cubic sampling follows the glTF Hermite definition with interval-scaled tangents; quaternion results are normalized after component-wise Hermite evaluation.
- Retained byte-identical preservation for exporter-generated native tracks via `extras.gmxMotionIndex`; explicit native replacement remains single-track to avoid ambiguous identity mapping.
- Animation import reports now preserve clip provenance (`clip_name`, track index/count, interpolation set) even though no native SIIG named-clip container has been proven.
- Added a root-only two-bone regression: one CUBICSPLINE+LINEAR glTF clip becomes two 31-frame native tracks, verifies Hermite midpoint/quaternion normalization, exports to glTF, and reimports byte-identically.
- Dependency-free regression suite is now **79 tests**.
- Remaining GMX animation work is clip metadata beyond per-bone native tracks plus broader template/root independence; shader compilation and opaque chunk semantics remain unresolved.

## 2.9.0-dev4

- Added opt-in `gltf2gmx-template --sync-animation-graph`; it implies scene synchronization and can create native `MOTN`/`ANIM` matrix tracks from ordinary glTF translation/rotation/scale channels.
- New tracks are sampled at SIIG's proven 30 Hz logical-frame cadence, with LINEAR/STEP interpolation and shortest-path quaternion interpolation for rotation.
- Existing exporter-produced animations remain byte-preserved by default through `extras.gmxMotionIndex`; `extras.gmxReplaceNativeAnimation=true` explicitly opts into resampling/replacement.
- Added donor-free MOTN and ANIM builders plus structural verification of motion identities, BONE targets, key payloads and fresh glTF re-export.
- `mod-import-gltf` enables animation synthesis automatically alongside the existing schema/TXIF/TEX/BBX pipeline.
- `gmx-scene-report` now includes native motion targets, frame counts, runtime duration and raw MOTN duration.
- Added a root-only regression that synthesizes BONE + MOTN + 31-frame ANIM from glTF and proves animation-aware no-op byte identity; suite is now **78 tests**.
- Remaining animation gaps are multi-bone clips and CUBICSPLINE import; broader GMX gaps remain shader compilation, opaque chunk semantics and fully template-free root construction.

## 2.9.0-dev3

- Added donor-free native TEX layout synthesis. `png2tex` now accepts `--platform xbox360|ps3` without `--template`, while retaining the existing template-preserving path for exact no-op/edit round trips.
- Xbox synthesis uses the layout confirmed across all 54 supplied textures: tiled Xenos 8_8_8_8, endian 8-in-32, Z/Y/X/W swizzle, 32-pixel-aligned pitch, and 32-row-aligned tiled allocation. New dimensions therefore no longer require a same-size donor.
- Added structural PS3 0x80-byte linear A8R8G8B8 wrapper synthesis from the understood data-offset/payload-size/dimension fields. Runtime acceptance of newly synthesized PS3 wrapper unknown fields remains a separate validation boundary.
- `mod-import-gltf` now falls back to native TEX synthesis when a new TXIF has no texture donor, or when an existing donor is the correct platform but has incompatible dimensions.
- Upgraded the integrated regression to remove the TEX donor entirely: a 37x19 PNG becomes a new tiled Xbox TEX, is appended to BBX, and round-trips exactly through `.siigmod`.
- Added standalone 37x19 Xbox and 5x3 PS3 donor-free TEX synthesis regressions; dependency-free suite is now **77 tests**.
- Remaining high-value texture work is compressed/mipmapped native variants plus runtime validation of newly synthesized wrappers; the next GMX structural frontier is MOTN/ANIM creation/import and further root/template independence.

## 2.9.0-dev2

- Added opt-in `gltf2gmx-template --synthesize-native-schemas`; it implies texture/scene/mesh sync and removes two major donor requirements when no compatible native schema exists.
- GMX can now build decoded `MESH` and `ARRY` declarations directly from glTF `POSITION`, `NORMAL`, `TEXCOORD_0`, `COLOR_0`, and uint16 indices instead of requiring a cloned native vertex declaration.
- Added native `MTRL` parameter-stream construction. `extras.gmxParameterSchema` can describe arbitrary decoded type-0 float, type-1 matrix, and type-2 TXIF parameters; when omitted, the compiler synthesizes the standard SIIG `mWVP`/Diffuse PBR schema.
- A donor-free structural regression starts from a root-only GMX with no MESH/ARRY/MTRL/SHAD records and creates a complete SHAD→MTRL→BONE→MESH/ARRY scene from glTF, including an arbitrary `CustomScalar` material parameter and repaired root bounds.
- Mod Workspace `Import glTF + TEX` enables schema synthesis automatically as a fallback, while retaining proven native donors whenever compatible ones exist.
- GMX Workbench adds an explicit **Synthesize native vertex/material schemas** advanced checkbox.
- Dependency-free regression suite is now **76 tests**.
- Remaining major donor constraints are native TEX header/layout synthesis, MOTN/ANIM graph synthesis/import, opaque/unknown vertex semantics, platform shader compilation, and fully from-scratch GMX root/animation construction.

## 2.8.0-dev28

- Added opt-in `gltf2gmx-template --sync-texture-graph`; it implies dev27 scene synchronization and extends import into native `TXIF` texture-reference creation/binding.
- glTF export now preserves complete native TXIF index/flags/name metadata independently of whether the referenced TEX/DDS image can be located, and also annotates converted glTF images/textures when available.
- Blender-style `baseColorTexture` edits can now reuse an existing TXIF by native metadata/name or allocate a fresh native TXIF identity, then wire compatible `DiffuseSampler` type-2 MTRL parameters to it.
- Added fixed-layout TXIF synthesis/update plus post-build verification rejecting duplicate TXIF identities and dangling MTRL sampler references.
- Expanded `gmx-scene-report` to show TXIF records and MTRL→TXIF bindings.
- Added a structural regression proving byte-identical texture-sync no-op plus a new Blender-style baseColorTexture→TXIF→DiffuseSampler chain; suite is now 74 tests.
- Texture *reference* synthesis is now supported; native TEX/DDS payload creation/replacement remains a separate asset workflow. Remaining GMX boundaries include arbitrary vertex declarations, arbitrary MTRL parameter schemas, animation-graph synthesis/import, platform shader compilation, and fully template-free GMX creation.

## 2.8.0-dev27

- Added opt-in `gltf2gmx-template --sync-scene-graph`, which implies dev26 mesh synchronization and extends import into native SHAD/MTRL/BONE/PARE relationships.
- glTF material export now retains native material/shader indices and flags; bone nodes also retain native parent provenance.
- Added fixed-layout SHAD synthesis, cloned-schema MTRL synthesis/editing, fixed-layout BONE synthesis, BONE material/mesh rewiring, and PARE parent/child group extension.
- Existing BONE transforms stay byte-preserved by default; `extras.gmxImportTransform` explicitly imports glTF node transforms when desired.
- Added cross-reference verification for duplicate BONE/MTRL/SHAD identities, dangling material→shader and bone→material/mesh links, and invalid/duplicate PARE children.
- Added `gmx-scene-report`, a self-contained HTML + JSON relationship view for bone hierarchy, meshes, materials, and shaders; exposed it in the GMX Workbench.
- Added a structural regression proving byte-identical scene-sync no-op plus synthesized SHAD→MTRL→BONE→MESH/ARRY wiring, edited material color, and new PARE hierarchy linkage; suite is now 73 tests.
- Remaining GMX boundaries include TXIF creation, arbitrary vertex declarations, arbitrary MTRL parameter schemas, animation-graph synthesis/import, platform shader compilation, and fully template-free GMX creation.

## 2.8.0-dev26

- Added opt-in whole GMX mesh-graph synchronization to `gltf2gmx-template` with `--sync-mesh-graph`.
- New glTF meshes can synthesize fresh native `MESH` plus owned `ARRY` nodes by cloning a compatible proven native layout; omitted native meshes are removed only in sync mode.
- Added ARRY ownership/reference accounting so deletion removes only arrays no longer referenced by retained meshes.
- Added BONE mesh-attachment repair for deleted/replacement meshes and optional `extras.gmxAttachBoneIndex` attachment of one synthesized mesh to an existing bone.
- Added post-build graph validation for duplicate identities, dangling MESH->ARRY links, index-count mismatch, and dangling BONE->MESH links.
- Exposed graph synchronization in the GMX Workbench as an explicit advanced checkbox while keeping normal dev25 template-preserving behavior as the default.
- Added a dependency-free regression proving byte-identical graph-sync no-op, complete MESH/ARRY creation, complete deletion, fresh native identities, and BONE attachment repair; suite is now 72 tests.
- New BONE/MTRL/SHAD/PARE creation, arbitrary vertex-declaration synthesis, and from-scratch GMX construction remain future work.

## 2.8.0-dev25

- Added `gltf2gmx-template`, allowing edited glTF vertex/index counts to resize existing native GMX geometry arrays while preserving the template graph.
- Added GMX ARRY 0x10-alignment preservation/synthesis, MESH index-count repair, total-size repair, and root geometry AABB recomputation.
- Proved root +0x10..+0x27 as exact minXYZ/maxXYZ geometry bounds across all 13 retail player GMXs.
- Validated byte-identical GMX->glTF->GMX no-op import on 306/306 mesh-bearing retail GMXs; one additional corpus GMX is meshless/not applicable.
- Added a topology-changing retail `plr_001.gmx` smoke edit (328->329 vertices, 656->658 indices, 49,600->49,680 bytes).
- Added the first unified standard-library Tkinter desktop GUI with Game Rip, Mod Workspace, GMX Workbench, Utilities, asynchronous command execution, and shared logging.
- Expanded the dependency-free regression suite to 71 tests.
- Deferred audio replacement/rebuilding by project priority; GMX and GUI are the active focus.

## 2.8.0-dev24

- Added deterministic baseline-dependent `.siigmod` distribution with `mod-pack`, `mod-package-info`, and `mod-apply`.
- Added `SIIG_BINARY_PATCH_V1`: sparse equal-size byte deltas and bounded copy/data deltas for length-changing resources.
- Package application verifies archive/resource baselines, patch payload hashes, reconstructed target hashes, platform compatibility, and write conflicts without modifying the clean rip.
- Added package security limits for path traversal, duplicate/colliding ZIP members, member size, total uncompressed size, and baseline mismatch rejection.
- Added a real retail localization package validation: one `text.bin` character change produced a 1,184-byte `.siigmod` with a one-byte delta payload, reapplied exactly in a fresh workspace.
- Optimized the common opaque black/white `png2col` path to pack eight mask pixels at a time while retaining the exact threshold fallback for arbitrary grayscale/alpha edits.
- Expanded external retail no-edit native round-trip validation to 2,197 completed byte-identical checks, including 307 GMXs, 1,258 DAT scripts, 394 MAPs, all 47 stage3D tables, all 30 stagewall tables, TEX/ANM/systemfont/localization, and all 153 COL PNG/native round-trips across 78,643,200 collision pixels.
- Expanded the dependency-free regression suite to 69 tests.

## 2.8.0-dev23

- Added a project-level mod workspace: `mod-init`, `mod-list`, `mod-export`, `mod-export-archive`, `mod-stage`, `mod-stage-archive`, `mod-build`, and `mod-verify`.
- Workspaces fingerprint the original rip, track editable/native replacements separately, rebuild only affected BBX archives, and emit exact change/hash reports without modifying the source rip.
- Added deterministic Xbox `.gz` patch output at original game-relative paths; PS3 NPDRM/SDAT re-encryption remains explicitly unsupported and produces verified decompressed BBX output instead.
- Added integrated editable-resource orchestration for GMX, TEX, system font, DAT, MAP, ANM, COL, stage3D, stagewall, plus whole-archive text/message localization edits.
- Upgraded native round-trip evidence using user-supplied retail Xbox inputs: 13/13 `player.bin` GMXs, 542-string `text.bin`, and 284-group / 1295-string-per-language `message.bin` rebuild byte-identically. Proprietary inputs are not bundled.
- Expanded the dependency-free regression suite to 68 tests with a full editable-DAT -> BBX -> gzip patch workspace gate.

## 2.8.0-dev22

- Promoted stagewall/Xwall/stage-generator tables to native round-trip resources with `stagewall-build`; unchanged canonical records rebuild byte-identically and edited values survive reparsing.
- Promoted Bmap/Xmap/map4/map5 route/placement tables with `stage3d-build`; fully described `0x118` records can be synthesized deterministically, while an optional native template preserves inactive/tail bytes.
- Added `gmx-edit-export` and template-preserving `gmx-build` for fixed-count GMX arrays/indices, texture references, material parameters, bone transforms, motion durations, and matrix-animation samples without rewriting the proprietary chunk graph.
- Added dedicated localization compilers: `text-build` for the seven-payload UTF-8 `text.bin` BBX and `message-build` for six Shift-JIS Squirrel payloads, including reverse mapping from readable Unicode accents to SIIG glyph bytes.
- Expanded `asset-capabilities` from 7 to 11 native-round-trip families out of 14 known families; Xbox XACT/XMA2, PS3 SBlk/VAG, and Xenos compiled shaders remain one-way.
- Added five new native-builder regression gates; the dependency-free self-test suite now contains 67 tests.
- Kept full topology-changing/new-chunk-graph glTF/Blender→GMX synthesis explicitly outside the claimed GMX support boundary.

## 2.8.0-dev21

- Started the native asset-functionalization phase so extracted resources are classified by viewing, editing, native rebuild, replay, or archival capability.
- Added `png2tex` and `png2font` template-preserving rebuilders for Xbox 360 / PS3 TEX and the XOR-obfuscated system font.
- Added `dat-build`, `map-build`, `anm-build`, and `png2col` native compilers; `map2png` now emits lossless editable JSON.
- Added `asset-capabilities` plus automatic `validation/ASSET_CAPABILITIES.json` output in full-game rips.
- Added byte-identical native round-trip regression gates for TEX, DAT, MAP, ANM and COL, plus a capability-matrix gate (62 tests total).
- Added `docs/guides/NATIVE_ASSET_ROUNDTRIP.md` documenting the package -> BBX -> editable asset -> native rebuild -> BBX repack modding loop.

## 2.8.0-dev20

- Traced the six original iOS `moveTheMoon` / `moveTheSun` / `moveGiganticUfo` / `moveLadybug` / `moveMandala` / `moveUnknown` routines into dedicated console movers across May 9, May 11, June 10, retail Xbox, and retail PS3.
- Proved exact dispatcher-ID continuity: mobile boss types 70..75 are console cases `0x46..0x4B`.
- Added direct per-boss gameplay anchors and original-vs-V2 lineage tests; GIGANTIC UFO and UNKNOWN specifically retain the original mobile branches.
- Recovered exact six-boss constructor fingerprint percentages and addresses from the re-supplied raw Ghidra exports.
- Identified LADYBUG's substantive May9→May11 state-`0x14` global-state guard and separated it from compiler/relocation noise.
- Added two source-only dev20 tables, a research report, machine-readable validation, and a new regression check (56 total).

## 2.8.0-dev19

- Extended iOS→console lineage into direct Stage-3 boss constructor/pool ancestry and console World-4/5 enemy-handler evolution.
- Established 29/30 subordinate pool type/capacity slots unchanged across the six original bosses; THE SUN type 38 grows 36→60.
- Fingerprinted all six constructors across May 9, May 11, June 10 and retail, locating the structural refactor between May 11 and June 10.
- Added the complete `0x96..0xAB` slot lineage, deliberate `0x9F` null, and concrete GLUTTONY / ULTIMATE UFO / VERTEBRATE retunes.
- Added World-5 normal-stage integration chronology and exact cross-build `Invinf_LoadScript` addresses.
- Added four dev19 tables, the enemy-handler lineage report/validation, and expanded selftests to 55 checks.
- Kept sealed dev18 and earlier checkpoints unchanged.

## 2.8.0-dev18

- Added executable-backed iOS→console code-lineage mappings and `ios-console-lineage-info`.
- Matched mobile MAP loading, runtime scrolling/visibility, cell decoding, and 24-block generator assembly to their recovered console counterparts.
- Proved the shared 30 Hz authored-time equations on iOS and related them to the console frame-multiplier architecture.
- Corrected the effective mobile script-dispatch frontier to 0x8D and documented the console expansion through 0xCE.
- Added 18-stage opcode-structure comparison showing strong skeleton continuity with extensive parameter/content retuning.
- Added dev18 lineage tables/report/validation and expanded the selftest suite to 54 tests.
- Kept sealed dev17 and earlier checkpoints unchanged.

## 2.8.0-dev17

- Resolved `survivalStageConvertTable` gating as Evolution Tree stage-node status checks rather than a Survival-private status array.
- Proved the six Chimera Survival substitutions and their exact fallback stages, plus the purchase/clear unlock chain for Extra 31..36.
- Added `mobile-exclusives-info` with source-only Survival ending/substitution and V2 behavior/attack-pool reference data.
- Traced `dischargeEnemyShot_FPS60` and mapped original/V2 constructor pool type IDs to named retained projectile handlers, establishing concrete attack-repertoire swaps for all six V2 bosses.
- Documented explicit main-type behavior branches in THE SUN, GIGANTIC UFO, and UNKNOWN, including UNKNOWN_V2 helper doubling sites and `setVer2Destroy`.
- Proved King Fossil C-1A/C-1B boss-argument differences and the 48→96 executable-backed reload/countdown source.
- Added dev17 research tables/report/validation and expanded the dependency-free selftest suite to 53 tests.
- Kept dev16 sealed/frozen; dev17 is branched from the validated dev16 release.

## 2.8.0-dev16 — 2026-09-10

- Corrected the six iOS Level-9 resources as Chimera crossover stages and documented Android's V2-based replacement stubs separately from DELETION.
- Proved script opcodes 0x52/0x53/0x54 as KING_FOSSIL / TWILIGHT_MIRAGE / APARTHEAD from iOS ARMv7 executable dispatch.
- Added executable-backed DELETION V2 mappings, original/V2 entity-pool diffs, and the all-six-V2 `level8_stage9EX` observation.
- Reconstructed the 36-node Survival selection graph, terminal-node ending mapping, achievement indices, and six conditional stage substitutions.
- Added Chimera resource/title/boss mappings and retained crossover constructor/attack-symbol anchors.
- Credited MaxTheMurdererV2 gameplay videos as third-party observational evidence; no footage is bundled.
- Expanded the synthetic regression suite from 51 to 52 tests.

## 2.8.0-dev15 — 2026-09-10

- Added iOS/Android mobile lineage research and four mobile commands: `mobile-inventory`, `mobile-compare`, `tzip-extract`, and `mobile-map-info`.
- Added a dependency-free TZIP parser for SIIG's zlib + Apple binary-plist resource dictionaries.
- Added little-endian mobile MAP parsing while keeping console MAP parsing separate and big-endian.
- Validated 737 mobile DAT and 493 mobile MAP files with zero parse failures.
- Documented iOS/Android package provenance boundaries, 330/645 generator continuity, Level-9 replacement opcodes 0x4C..0x51, and iOS executable symbol anchors.
- Expanded the synthetic regression suite from 46 to 51 tests.

## 2.8.0-dev14 — 2026-09-10

- Audited the June/retail Ultimate UFO ending after Mframe 6200 and separated destruction, owned-object shutdown, entity removal, and part-0/state-0 reset.
- Proved that retail camera gate `+0x11C` is not cleared by the 6030 or 6200 phase actions; the clear remains conditional on a later part-0 `+0x48` reset through `0x8212DCB0` (`0x8212DD20` store).
- Excluded Normal 5-3 DAT cleanup, `DEL_ZAKO`, destructor-only manager removal, and the 25,200-unit lifetime watchdog as established ordinary route-end callers.
- Added the machine-readable final-reset audit and one regression check.
- Finalized the static-analysis boundary: no ordinary Normal 5-3 post-6200 `+0x48` caller is proven, so part-0/state-0 is documented as a conditional clear mechanism rather than an assumed ordinary-ending event.
- Added the June 10 project-owner footage boundary (~427.367–427.400 s in Normal seg6) showing the Ultimate UFO debug registration disappearing with the stage-completion white-out; retained it strictly as observational evidence.

## 2.8.0-dev13 — 2026-09-07

- Added `field-camera` for frame-by-frame procedural camera reconstruction from fld014/fld015 GMX matrices and an explicit camera preset.
- Added the executable/asset-backed GMX serialized-affine to runtime row-vector matrix conversion.
- Validated all 404 normal-5-3 late fld015 frames 5897..6300 as rear-follow for preset 4; measured 59.859..72.111 units behind the route tangent.
- Confirmed extreme dynamic horizontal-response values change lateral framing without breaking rear-follow classification in the late route.
- Decoded retail camera controller +0x11C as a timed-preset-transition acceptance gate and proved Ultimate UFO normal part-0/state-0 reset clears it on Xbox and PS3.
- Recovered May 9/May 11 phase-12 Mframe-6200 direct UltimateUfo::Vanish(part 0) behavior and documented the later 6030/6200 ending split.
- Added three machine-readable dev13 research tables and expanded self-tests to 45 checks.

## 2.8.0-dev12 — 2026-09-07

- Corrected dev11's prototype runtime-registry interpretation: May 9/May 11 ID `0xD9` is `bos_015k.gmx`; later builds use ID `0xD8` for the same model.
- Decoded the May 9 Ultimate UFO debug HUD (`Mframe`, `Sframe`, `state`, `L2:SKIP`) and named the eight phase bytes as Umb/Tow/Fan/Ring `col`/`dis` pairs.
- Proved `L2:SKIP` clears Sframe and recovered the Mframe/Sframe advance relationship.
- Added distinct normal 5-3 and DLC Bonus 5-6 Ultimate UFO profiles; proved the Bonus 5-6 immediate main-body destruction shortcut on retail Xbox and PS3.
- Closed direct Mframe -> `fld015.gmx` frame synchronization across all five executable builds.
- Reconstructed the PA animated-camera -> procedural-camera fallback and rejected preset 4 as an HP-zero-triggered switch.
- Evaluated real late `fld015` matrices with preset 4 and classified the normal late route as rear-follow geometry, with explicit remaining caveats.
- Audited all five direct PS3 camera-preset setter callers; none is Ultimate UFO, tightening preset-4 persistence while retaining an indirect-call caveat.
- Expanded the dependency-free regression suite to 43 tests.

## 2.8.0-dev11 — 2026-09-06

- Closed the special-stage reload parameter chain: retail DAT opcode `0x78` (`WARNING`) writes its first argument into transition state; values 12 and 14 select Bmap13/fld014 and Bmap15/fld015 respectively.
- Verified real retail scripts place `WARNING [12]` before Water Strider and `WARNING [14]` before Ultimate UFO, upgrading the former boss/field correlations to direct script→executable→reload evidence.
- Traced common HP-zero dispatch into Ultimate UFO's part-state/destruction lifecycle and recovered the May-prototype debug symbol `UltimateUfo::Vanish`.
- Documented executable-backed Ultimate UFO late-phase destruction actions at frames 6030 and 6200 while retaining airlock/rear-camera gameplay labels as unresolved.
- Added machine-readable special-stage reload and Ultimate UFO death-chain tables plus regression coverage.

## 2.8.0-dev9 — 2026-09-06

- Recovered executable-backed Water Strider 0..1440 looping route table and Ultimate UFO finite retail/prototype phase tables.
- Added cross-build boss function mapping, hold/resume documentation, helpers, CSV tables, and regression coverage.
- Preserved unresolved camera-angle semantics and cam02 activation as explicit limits.


## 2.8.0-dev8

- Added `pa-route-info` for executable-backed PA-route gate, camera-selection, and DAT boss-correlation inspection.
- Cross-mapped `Route::SetPaRoute` across PS3 retail, Xbox retail, June 10, May 11, and May 9 using prototype debug strings plus function/vtable shape.
- Proved retail Xbox/PS3 and June 10 require category 0 plus runtime state `+0x218 == 4` / `+0x21C == 1`; May 11 uses the state-only gate; the corresponding May 9 setup does not activate the branch.
- Added `PA_ROUTE_BUILD_GATES.csv`, `PA_ROUTE_FUNCTIONS.csv`, `PA_ROUTE_CAMERA_SELECTIONS.csv`, and `PA_ROUTE_BOSS_MAPPING.csv`.
- Proved known retail stage setup selects PA-route camera index 0 (`cam01_op1.gmx`); index 1/cam02 remains unproven as a retail activation callsite.
- Added conservative Water Strider -> fld014/Bmap13 and Ultimate UFO -> fld015/Bmap15 boss-field correlations, explicitly labeled strong correlation rather than direct callsite proof.
- Real retail PS3 validation scans all 76 DAT files and identifies six Water Strider/Ultimate UFO occurrences with zero parse failures.
- Expanded the dependency-free regression suite to 35 tests.

## 2.8.0-dev7

- Corrected channel-type-12 GMX matrix-animation timing from raw authoring timestamps to the retail logical-frame sampler: `matrices[logical_frame % frame_count]` at the engine's 30 Hz logical clock.
- `gmxtrack` now separates `runtime_seconds_30hz` from `raw_authoring_time`; glTF animation keys use sample-index/30 while preserving the raw float table in metadata.
- Decoded the 0x1C route/field animation descriptor as `{name[16], start_frame, end_frame, loop_flag}`.
- Added `camera-animation` for the explicit retail `cam1`/`int1` 0..199 non-loop camera controller, including `FieldPos` translation and frame-multiplier update cadence.
- Added `field-animation` for explicit `fld014`/`fld015` descriptor-frame matrix evaluation without inferring stage activation.
- Proved `fld015` is 0..6300 non-loop (6,301 samples) and `fld014` is 0..1440 loop with frame 1440 wrapping to sample 0 (1,440 samples).
- Proved both `cam01_op1` and `cam02_op1` use the same camera descriptor end 200; this path never reaches cam02 samples 200..299.
- Expanded the dependency-free regression suite to 34 tests.
- Real retail validation covers all four camera/field GMXs and corrected glTF runtime spans.

## 2.8.0-dev6

- Added executable-backed procedural route orientation state to `RouteRuntimeState`, preserving Hermite-sample update ordering before same-update next-segment preparation.
- Reconstructed row-vector route orientation as `Rz(roll+offsetZ) × Rx(pitch+offsetX) × Ry(yaw+offsetY)` with retail pitch/yaw updates from moving Hermite samples.
- Added `camera_world_state()` for the proven procedural camera path: route/stage-frame eye-offset transform, FieldPos target, and transformed word-8/9/10 dynamic local-X response.
- Added `route-camera-playback`, explicitly combining caller-supplied route/DAT/preset/runtime-coordinate inputs without inferring activation timelines.
- Added `--emit-every` output decimation to combined playback; every runtime update is still simulated.
- Expanded route-playback CSV state with procedural pitch/yaw/roll and row-vector orientation matrix columns.
- Expanded the dependency-free regression suite to 31 tests.
- Real-corpus orientation stress at 100-unit analysis spacing: six route files exercise Hermite orientation for 356 total orientation updates.
- Explicit `Xmap3_1.bin + level3_stage1.dat` combined-camera validation simulates 265,020 runtime updates, applies seven SCROLL_02 events, and terminates normally; preset 0 / runtime (213,233) are validation inputs, not inferred gameplay activation.

## 2.8.0-dev5

- Added `camera-preset` for semantic inspection of retail camera presets and optional runtime-coordinate response evaluation.
- Proved preset word 0 is perspective FOV in degrees and word 1 is uniform scene/view scale.
- Proved words 2–4 form the camera-eye offset transformed by the active route/stage orientation and added to `FieldPos`; words 5–7 are scene/view translation.
- Resolved words 8–10 as dynamic horizontal-response gain, target local-X scale, and eye local-X scale in retail PS3 `0x00157540`.
- Proved words 12–29 are three fog profiles `{start, end, RGBA}` through renderer `fogRange` and `vFogColor` consumers.
- Traced word 11 as a shared scalar forwarded unchanged to `collada_edge1`, `collada_face1`, and `collada_face2`; its exact virtual-setter semantic remains unresolved.
- Added `CAMERA_PRESETS_RUNTIME_SEMANTIC.csv` and upgraded `CAMERA_PRESET_SCHEMA.csv` with evidence-backed names while preserving the untouched raw table.
- Expanded the dependency-free regression suite to 29 tests.

## 2.8.0-dev4

- Added executable-backed dynamic route runtime state (`RouteRuntimeState`) with non-loop termination, modulo loop wrapping, and per-update source/sample progression.
- Added exact signed SCROLL_02 Y-to-spacing conversion from PS3 retail `0x0014E408`, including PPC truncation-toward-zero behavior.
- Reproduced the retail linear mid-segment spacing-change path: remaining linear samples are discarded and rebuilt from current `FieldPos`; active Hermite segments intentionally do not rebuild on spacing changes.
- Added `route-playback`, explicitly coupling one caller-supplied stage3d route and DAT script through authored-frame → runtime-update SCROLL_02 timing.
- Added explicit `--start-frame`, `--end-frame`, `--frame-multiplier`, `--loop`, and `--max-updates` controls rather than guessing route-object activation or filename pairing.
- Expanded the dependency-free regression suite to 28 tests.
- Real-corpus runtime stress gate: all 46 resampleable retail route tables survive non-loop spacing-change and loop-wrap smoke stepping; the one route-empty file remains skipped.
- Explicit filename-correspondence examples `Xmap2_1 + level2_stage1.dat` and `Xmap3_1 + level3_stage1.dat` validate DAT-coupled playback, including seven live spacing rebuilds in the latter. These examples are validation candidates, not a claim that every route↔DAT pairing is solved.

## 2.8.0-dev3

- Added executable-backed fixed-spacing non-loop route resampling (`route-resample`).
- Reproduced linear write-after-step sampling, straight/curve classification, six-state tangent-axis transitions, cubic Hermite sampling, and the final look-ahead source-point rule.
- Added runtime-initialized camera presets reconstructed from all 160 initializer writes, while retaining the untouched raw 32 × 30 table.
- Added a 30-word structural camera-preset schema documenting vec3/group layouts, interpolation behavior, consumer addresses, confidence, and unresolved semantics.
- Real-corpus route validation at a deterministic 100-unit analysis spacing: 46 resampleable files, one route-empty file skipped, 19,471 segments, 155,690 samples, 62 Hermite segments, zero conversion failures.
- Expanded the built-in regression suite to 26 tests.
- Dynamic SCROLL_02 spacing changes and looping-route wrap behavior remain explicitly outside the fixed-spacing exporter.

## 2.8.0-dev2

- Added five-build executable-derived runtime entity/primitive registry tables and decoded 0x2C record fields.
- Resolved render-group selectors to Offset Opacity / Offset Translucent / Offset Terminate / Non Opacity.
- `stage3dmap` now exports executable-ordered runtime route-source control points plus record-0 origin fallback.
- Added `gmxtrack` for decomposed GMX matrix-animation CSV and translation trajectory OBJ export.
- Added raw 32 × 30 camera-preset table and two route-animation descriptors from PS3 retail.
- Expanded the dependency-free self-test suite to 24 checks.


## 2.8.0-dev1

- Validated the supplied original retail Xbox 360 LIVE STFS and PS3 type-1 PKG directly.
- Added optional OpenSSL AES-CTR acceleration for finalized PKG extraction with Python fallback/equivalence testing.
- Added internal authenticated decryption of SIIG's six NPDRM SDATs and standalone `sdat-decrypt`.
- Added built-in Sony 989SND/SCREAM SBlk v3 parsing plus PS-ADPCM WAV export and standalone `sblk2wav`; 84/84 retail PS3 streams decode.
- Restored Stage Explorer v5 runtime SCROLL_01/02/03 playback with 30 Hz controls and source-level regeneration.
- Added content-addressed outer-container staging for `--resume` and `--no-outer-cache` override.
- Fixed the STFS `CON` first-hash-table initialization path.
- Integrated PS3 EBOOT-backed Bmap/Xmap placement, route-point, scroll, and timing corrections.
- Expanded `selftest` to 23 dependency-free cases, including cross-platform Stage Explorer root detection.
- Added explicit retained-native placeholders for WMA/XMA/AT3 and XACT data so Asset Viewer coverage reports do not mislabel intentionally non-browser-native files as missing previews.
- Fixed Stage Explorer discovery for the PS3 `USRDIR/script` and `USRDIR/map` layout.
- Updated credits/provenance for OpenSSL acceleration and vgmstream Sony bank/PS-ADPCM cross-checks.

## 2.5.1

- Reorganized the release root into `docs/`, `reference/`, `validation/`, `tools/`, and `addons/`.
- Added a central documentation index and folder-level README files.
- Updated runtime resource lookups and all documentation references to the new paths.
- Retained fallbacks for legacy root-level data-table locations.
- Reduced root-level files from 75 to 18 with no content removed.

## 2.5.0

- Replaced the monolithic Asset Viewer with a linked-data layout: compact HTML, external inventory, thumbnails, and deferred preview shards.
- Removed base64 media embedding and added pagination plus intersection-based lazy loading.
- Added direct GMX/OBJ wireframes, TEX previews, MAP/DAT/ANM thumbnails, WAV waveforms, and explicit empty/animation-only placeholders.
- Added matching converted-asset previews for source TEX, GMX, OBJ, and audio files.
- Fixed related glTF payload keys and excluded viewer output during in-tree rebuilds.
- Added detailed viewer size/coverage reporting and validation of all generated relative references.
- Validated 1,016/1,016 previewable thumbnails and reduced the tested HTML document by 99.934%.

## 2.4.0

- Corrected standalone ANM parsing to 16-byte names, start/end frames, and loop flags; added group/clip indexes.
- Added `stage3dmap` for Bmap/Xmap/map4/map5 0x118-byte 3D path and placement records.
- Added `stagewall` for wall/Xwall repeat strips and `stage_generate.bin` enabled candidates.
- Added `shader-info` for Xenos shader stages, bounded microcode, metadata strings, and hashes.
- Added automatic full-rip structured exports and `scan` recognition for these formats.
- Corrected SCROLL_01/02 to 8.8 fixed-point values and documented SCROLL_03 as a June 10 no-op.
- Expanded the built-in regression suite from 11 to 15 tests.
- Added Ghidra-backed stage/ANM/shader notes and a real-corpus validation report.

## 2.3.0

- Added `repack-bbx` with canonical archive layout, named/unnamed resources, seeded hashes, sorted indexes, preserved reserved bytes, deterministic gzip, atomic output, and mandatory post-build verification.
- Extended extraction manifests with payload SHA-256, original archive SHA-256/size, reserved header bytes, alignment, and sorted-index metadata.
- Verified the unchanged supplied retail `map.bin` as a byte-for-byte extract/repack round trip.
- Added the SIIG Blender Add-on 0.1.0 for single, multi-file, and recursive-folder GMX import through the toolkit's existing glTF exporter.
- Added `asset-viewer`, a searchable offline HTML inventory with bounded media previews, text inspection, glTF summaries, and interactive wireframe views.
- Added `serve`, bound to localhost, for viewing generated HTML without `file://` restrictions.
- `rip-game` now generates an asset viewer automatically unless disabled.
- Added drag-and-drop launchers for BBX extraction/repacking, viewer generation, and local serving.
- Expanded `selftest` from 9 to 11 checks with BBX repacker and HTML viewer tests.
- Added dedicated repacker, asset viewer, Blender add-on, and excluded-source documentation.

## 2.2.0

- Integrated the verified MAP atlas renderer into the main toolkit. Resource IDs 6, 7, 8, and 9 resolve to `fence1_512`, `fence2_512`, `fence6_512a`, and `fence3_512`; tile IDs 1–49 use the confirmed 7×7 atlas layout and X/Y reflections.
- Upgraded `stageviz` to explorer format v4 with embedded game atlases, zero-scroll layer composites, cell inspection, safe HTML escaping, and categorical fallback when an atlas is absent.
- Added optional atlas-backed output to `map2png` through `--atlas`, `--atlas-step`, and `--no-atlas-composite`.
- `rip-game` now generates the offline stage explorer automatically unless `--no-stageviz` is used.
- Added deterministic `OUTPUT_MANIFEST.json` and `.sha256` files plus `verify-output` for privacy, size, hash, partial-file, and report validation.
- Added `doctor`, global `--version`, and a built-in `selftest` covering AES, BBX, DAT, MAP, bounded gzip, PNG/atlas rendering, ZIP safety, privacy redaction, and output tamper detection.
- Hardened ZIP, STFS, and PKG extraction with configurable file-count/size limits, duplicate-path checks, traversal and symlink rejection, and atomic `.siig-part` writes.
- Added bounded gzip expansion, nested-BBX depth/resource budgets, Windows-reserved-name handling, case-insensitive output collision avoidance, and stricter platform ambiguity detection.
- Resume profiles now include the toolkit version so changed converter behavior cannot silently reuse stale output.
- Restored and updated the credits, AI disclosure, provenance, source audit, third-party notices, project-license status, and attribution policy in the package.
- Added security and testing documentation and expanded full-rip reports with elapsed time, explorer status, extraction limits, and manifest status.

## 2.1

- Added direct Xbox 360 STFS input to `rip-game` for `CON `, `LIVE`, and `PIRS` packages.
- Added direct PlayStation 3 PKG input for finalized and non-finalized/debug type-1 packages.
- Added dependency-free STFS block-chain/hash-table extraction and PS3 PKG AES/debug-stream decryption.
- Added `unpack-container` for outer-package-only extraction and `container-selftest` for the AES known-answer test.
- Added magic-based input detection; package filenames no longer need a particular extension.
- Added outer-container totals and input type to full-game validation reports.
- Preserved the separate PS3 NPDRM SDAT step: TrueAncestor `.bin.gz.dat` files are still discovered beside the PKG or through `--ps3-sdat-dir`.
- Validated synthetic STFS level-0/1/2 boundaries, chained files, finalized/debug PKGs, and both supplied extracted retail releases.
- Added `docs/guides/CONTAINER_INPUT_NOTES.md` and updated the drag-and-drop launcher.


## 2.0

- Corrected the MAP interpretation using the June 10 XEX renderer path.
- Confirmed `0` as empty, tile IDs `1..49`, `0x40` as X flip, and `0x80` as Y flip.
- Confirmed a 30-unit tile grid and three independently scrolling layers.
- Added runtime tile-set resource IDs for all 75 stage-table entries.
- Updated the offline explorer with verified tile and flip views.
- Documented generator MAPs as reusable 2D tile-pattern blocks.
- Removed the unsupported assumption that these MAP cells place 3D wall models.
- Kept exact tile-set filenames and layer gameplay roles explicitly unresolved.

## 1.9

- Added conservative XEX-backed DAT semantic decoding with categories, summaries, confidence levels and proven field names.
- Added `stageviz`, a self-contained offline MAP/DAT explorer with searchable frame timelines and three MAP bit views.
- Reconstructed the 75 stage/script pairings, two MAP-only slots and trial variant from the June 10 executable tables.
- Added explicit reporting for 12 expected-but-absent level-4/5 MAP names and 14 package MAPs unreferenced by the runtime table.
- Added `reference/tables/STAGE_PAIRING.csv`, `reference/tables/DAT_SEMANTIC_SCHEMAS.csv` and `docs/guides/STAGE_EXPLORER_NOTES.md`.
- Validated semantic export on all 1,334 June 10 DAT files with zero failures; the explorer contains 17,335 commands from all 76 stage scripts and no absolute source paths.


## 1.8

- Confirmed the shared DAT format from the June 10 DebugOpt `stageScriptBlockLoad` routine.
- Added `dat2csv`, delta-to-absolute frame conversion, full signed/hex argument preservation, and the executable-derived 207-slot opcode-name table.
- Confirmed the MAP layer format from `stageGenerate2DMap`.
- Added `map2png` with categorical/grayscale palettes, optional nearest-neighbor scaling, numeric CSV grids, and JSON metadata.
- Added DAT/MAP recognition to `scan`.
- `rip-game` now converts all extracted DAT and MAP resources automatically.
- Validated 5,244 DAT files containing 96,750 commands and 1,576 MAP files containing 4,728 layers across May 9, May 11, June 10 and retail Xbox 360 builds with zero parse failures.

## 1.7

- Added `.col` collision-mask decoding to PNG.
- Added standalone `.anm` table decoding to CSV and JSON.
- `rip-game` now converts COL and ANM resources automatically.
- Added prototype-analysis notes based on the May 9, May 11 and June 10 Xbox 360 builds.

## 1.6.0

- Added `rip-game` for original Xbox 360/PS3 directories and ZIP archives.
- Added automatic platform detection from `default.xex` and `EBOOT.BIN`.
- Added PS3 RSX TEX to PNG support and PS3 system-font atlas decoding.
- Added TrueAncestor `.bin.gz.dat` discovery for NPDRM/SDAT payloads.
- Added deterministic archive ancestry, decompressed BBX preservation, resume-state hashes, ready-file copying, and privacy-safe validation reports.
- Added drag-and-drop `SIIG_Rip_Game.bat`.
- Xbox 360 WMA files are preserved unchanged; PS3 Sony SBlk audio banks are extracted losslessly as `.bnk` for vgmstream.

## 1.5.1

- Removed absolute input, output, FFmpeg, and glTF filesystem routes from generated JSON metadata.
- JSON manifests now retain only privacy-safe filenames and archive-relative paths.
- Added `sanitize-json` to clean metadata generated by v1.5 or earlier in place.
- Sanitized the bundled glTF samples.

## 1.5

- Added `gmx2gltf` and `extract --convert-gltf`.
- Decoded GMX `TXIF`, `SHAD`, `MTRL`, `PARE`, `BONE`, `MOTN`, and `ANIM` chunk relationships.
- Added glTF 2.0 hierarchy, rigid mesh attachment, materials, vertex colors, texture assignment, and transform-animation export.
- Added automatic conversion of the shared uncompressed `ptn_001.dds` texture to PNG.
- Added `docs/formats/GMX_GLTF_NOTES.md` and detailed GMX output in `scan`.
- Validated 486 GMX files, 1,938 meshes, 3,298 nodes, 776 materials, and 913 animation tracks with zero conversion failures.

## 1.4

- Added `text2csv` for direct decoding of `text.bin`, `message.bin`, or a directory containing both.
- Recovered the 542-row `text.bin` key/translation table across Japanese, English, French, Italian, German and Spanish.
- Parsed all 284 Squirrel-style `message.bin` arrays and 1,295 strings per language.
- Added Unicode correction for the legacy language-specific accented-glyph codes while retaining untouched raw scripts.
- Added combined CSV/JSON, per-language text files, metadata, and `docs/formats/LOCALIZATION_NOTES.md`.

## 1.3

- Added `xact2wav` for direct conversion from `sound.bin`, extracted XWB files, or XWB/XSB directories.
- Added standard big-endian XACT3 wave-bank parsing and XSB cue-name recovery.
- Added RIFF XMA2 wrapper generation and optional FFmpeg PCM WAV decoding.
- Validated all 86 SIIG streams: 83 SE cues plus BGM007, BGM008_MIX_C and BGM_XACT_SE33.
- Added per-bank CSV/JSON manifests with channels, sample rates, sample counts and loop metadata.

## 1.2

- Added `font2png` for `systemfont.bin`, `.gz`, or extracted `systemfont.crp`.
- Confirmed from `default.xex` that `systemfont.crp` is XOR-obfuscated bytewise with key `0xF1`.
- Added automatic CRP conversion when `extract --convert-tex` is used.
- Added `reference/systemfont/systemfont_glyphs.csv` with all 6,732 executable-resident glyph records, atlas coordinates, widths, left insets and known aliases.
- Added `reference/systemfont/systemfont.fnt` AngelCode BMFont descriptor for the 6,730 native Unicode mappings.
- Added CRP detection to `scan`.

## 1.1

- Fixed TEX untile addressing.
- Added the missing Y[3] XOR in the Xenos pipe selector.
- Eliminated repeating 8-row jitter/scrambling in converted PNG files.
- Revalidated all 54 supplied TEX files with zero conversion failures.

## 1.0

- Initial BBX extraction, GMX-to-OBJ and TEX-to-PNG release.
