# Visualizer position coordinates and Position Fix aliases — dev24 WIP170

## Why this correction exists

A project-owner comparison of the same stage in the dev24 browser simulator and
on Xbox 360 hardware exposed a deterministic vertical mirror. In the hardware
frame the active SHAPE source is above/outside the **top** edge; the simulator
placed that source at the **bottom** edge. This was a host-coordinate conversion
error, not a ParameterSet error.

The retained original Visualizer scripts provide a direct cross-check.
`SEQUENCE_4` selects `PARAM_3`, and `PARAM_3` has Position Fix `0` (free) with
free coordinates **X=10, Y=360**. On the 1280×720 Visualizer target, the native
coordinate system is centered with +X to the right and +Y upward. Therefore:

- `canvas_x = 640 + game_x`
- `canvas_y = 360 - game_y`
- `(10, +360) -> (650, 0)` (top edge)
- `(10, -360) -> (650, 720)` (bottom edge)

The pre-WIP170 Canvas bridge used `360 + game_y`, vertically mirroring every
free/fixed anchor. WIP170 applies the corrected bridge to the SHAPE stamp and
the recursive feedback transform because the executable drives both from the
same Visualizer anchor.

## Position Fix is an alias table, not a 3×3 grid

The fixed-position setter at May-11 `0x8216D8F8` stores the requested raw index
and reads a float2 at `DAT_825624C8 + index*8`. The executable bytes genuinely
decode to the following 10 raw entries:

| Raw index | X | Y | Distinct behavior |
|---:|---:|---:|---|
| 0 | 0 | 0 | Free X/Y path |
| 1 | -448 | 0 | Fixed left |
| 2 | 0 | 0 | Fixed center |
| 3 | 448 | 0 | Fixed right |
| 4 | -448 | 0 | Alias of 1 |
| 5 | 0 | 0 | Alias of 2 |
| 6 | 448 | 0 | Alias of 3 |
| 7 | -448 | 0 | Alias of 1 |
| 8 | 0 | 0 | Alias of 2 |
| 9 | 448 | 0 | Alias of 3 |

Earlier simulator versions faithfully displayed all ten raw indices, which made
Position Fix look broken because seven choices duplicated another coordinate.
Inventing additional locations would be less faithful. WIP170 instead preserves
all ten raw values in the dataset while canonicalizing the user-facing control:

- 0 — Free X/Y (raw 0)
- 1 — Fixed left (raw aliases 1/4/7)
- 2 — Fixed center (raw aliases 2/5/8)
- 3 — Fixed right (raw aliases 3/6/9)

When a raw preset index is imported, aliases map to the matching canonical UI
choice without changing the recovered executable evidence.

## Boundaries

This correction does not alter the recovered point-filtered SHAPE/feedback
samplers, EffectBlur blend/shader equation, adaptive BGM normalizer, or the
host-only final softness/intensity calibration. Exact upstream XAudio2 meter
cadence and exact Xenos render-target alpha storage remain separate documented
boundaries. Proprietary screenshots, game scripts and executable bytes are
validation inputs only and are not bundled in the source package.
