# `est_*` effect-model audit — dev24 WIP180

This audit narrows the remaining `est_011` through `est_021` model-ownership problem without promoting visual guesses to executable facts. It combines the project-owner identity notes already retained by dev24, the five-build derived runtime registry, and geometry/hash metadata from an external project-owner retail rip. No GMX/glTF/game payload is bundled.

## Strong results

- The audited range contains **11 models** (`est_011` ... `est_021`).
- `est_012.gmx` is the **only** one with a top-level runtime-registry slot in any retained build. It is present in all five retained registries: runtime `0xE6` in Xbox retail, June 10 and PS3 retail; runtime `0xE7` in the May 9/May 11 prototypes. This proves that the `est_` prefix does not itself mean “unregistered child projectile.”
- `est_011` and `est_014` have **byte-identical converted geometry payloads** while their native GMX containers are different. This independently corroborates the project owner's visual note that both use the same hexagon silhouette, while showing that their native resources are not byte-identical files.
- No other pair in `est_011` ... `est_021` shares the same converted geometry payload hash.
- Project-owner-confirmed usage remains limited to `est_013` = PROGRESSIVE UFO missiles and `est_015` = WATER STRIDER trail spikes. Their precise executable owner/controller call paths are still not isolated.
- `est_016` remains only a project-owner hypothesis for the ULTIMATE UFO / possibly WRATH giant beam. WIP180 does **not** promote that hypothesis.

## Architectural boundary

The executable has a distinct `EShotSg` / 3D enemy-shot subsystem, but that subsystem name alone does not establish a one-to-one filename mapping for these GMXs. Likewise, a runtime resource slot does not prove which gameplay controller owns or instantiates it. Exact controller ownership therefore remains unresolved for `est_011`, `est_012`, `est_014`, and `est_016` through `est_021`; WIP180 records topology and registry facts instead of inventing owners.

## Reproducible table

See `reference/tables/EST_EFFECT_MODEL_AUDIT_DEV24.csv`. Geometry fingerprints are derived from the toolkit-generated `*.gltf.bin` payloads in the external retail rip; native GMX hashes/sizes are retained only as derived validation metadata.
