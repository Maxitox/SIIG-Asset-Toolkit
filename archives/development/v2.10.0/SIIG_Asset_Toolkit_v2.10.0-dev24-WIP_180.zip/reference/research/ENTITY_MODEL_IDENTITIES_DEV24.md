# Player / enemy / sub-boss / boss model identities — dev24 WIP178

## Scope and provenance

This reference promotes the project owner's complete model-identification pass into a machine-readable toolkit table without pretending those friendly names were recovered from executable strings. The source table is `reference/tables/ENTITY_MODEL_IDENTITIES_DEV24.csv`.

The table contains **82 identity patterns**:

- 10 player patterns;
- 36 enemy patterns;
- 7 sub-boss patterns;
- 18 boss patterns;
- 11 `est_*` effect/projectile patterns.

Of those, **71** are project-owner-confirmed player/entity identities, **2** are project-owner-confirmed effect usages (`est_013`, `est_015`), and **9** remain explicitly speculative `est_*` effect hypotheses. Wildcards are used only where the project owner explicitly said a model has related variants (for example `emy_032*` for KEEPER or `bos_003*` for GIGANTIC UFO).

The friendly-name catalog is now consumed by Asset Viewer 2.2.0. Native `.gmx` files and same-stem converted model files can be found by either filename or friendly identity (for example `emy_044` or `CELL`). The viewer displays the source/evidence status, and speculative effect rows are visibly marked **speculative** instead of being silently promoted to resolved identities.

## CELL / LUST / SHUTTER reconciliation

Three previously unnamed late enemy resources are now reconciled cleanly while keeping the distinction between *resource/runtime identity* and *friendly project-owner name*:

| Friendly identity | GMX | Runtime evidence | Result |
| --- | --- | --- | --- |
| CELL | `emy_044.gmx` | runtime type `0x97` in Xbox retail, June 10, May 11, May 9, and PS3 retail | model/runtime pairing is executable-backed across all five retained builds; `CELL` is the project-owner friendly identification |
| LUST | `emy_051.gmx` | runtime type `0x9D` in all five retained builds | model/runtime pairing is executable-backed across all five retained builds; `LUST` is the project-owner friendly identification |
| SHUTTER | `emy_052.gmx` | runtime types/opcodes `0x5A` and `0x5B` point to the same model in all five retained builds; DAT tables independently label these paths `SHUTTER1` / `SHUTTER2` | strongest name reconciliation of the three: project-owner identification agrees with the already recovered DAT/runtime family |

This closes the *catalog identity* gap for CELL/LUST/SHUTTER. It does **not** claim that `CELL` or `LUST` are internal executable strings where no such retained string evidence has been recovered.

## `est_*` effect/projectile boundary

The project owner identified:

- `est_013` as PROGRESSIVE UFO missiles;
- `est_015` as WATER STRIDER trail spikes.

Those usages are retained as confirmed project-owner observations but not upgraded to executable ownership claims. The remaining `est_*` descriptions are preserved verbatim in meaning as shape/usage hypotheses and are marked `project_owner_speculative`.

The existing five-build runtime registry also exposes an important caution: `est_012.gmx` is itself registered as a top-level model slot (`0xE6` in Xbox retail / June 10 / PS3 retail and `0xE7` in May 9 / May 11). Therefore the `est_` prefix should be treated as an observed effect/projectile-oriented resource family, **not** as proof that every `est_*` file is merely an unregistered child or bullet mesh. Exact owner/controller paths for `est_011` through `est_021` remain a separate reverse-engineering task.

## Asset Viewer integration

Asset Viewer 2.2.0 loads the CSV at generation time and adds the following derived metadata to matching model entries:

- friendly identity;
- entity kind;
- 2D/3D versus 3D-only scope where supplied;
- console-exclusive player note for FIELD / OPTION / VARIABLE;
- evidence status and notes.

Search includes all of these fields. This keeps the filename-centric reverse-engineering identity intact while making the recovered model corpus substantially easier to browse by in-game names.
