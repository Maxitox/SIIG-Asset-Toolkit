#!/usr/bin/env python3
"""Desktop control center for the SIIG Asset Toolkit.

The GUI intentionally wraps the existing audited CLI instead of duplicating format logic.
It uses only the Python standard library (Tkinter) and launches toolkit commands in a
background thread so long extraction/build operations do not freeze the window.
"""
from __future__ import annotations

import json
import os
import queue
import shlex
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path
from typing import Callable, Optional

ROOT = Path(__file__).resolve().parent
TOOLKIT = ROOT / "siig_toolkit.py"
VERSION_FILE = ROOT / "VERSION.txt"
GUI_VERSION = "0.32.0-dev21"


def toolkit_version() -> str:
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return "unknown"


def diagnostics() -> dict:
    try:
        import tkinter as tk  # noqa: F401
        tkinter_ok = True
    except Exception:
        tkinter_ok = False
    return {
        "gui_version": GUI_VERSION,
        "toolkit_version": toolkit_version(),
        "toolkit_exists": TOOLKIT.is_file(),
        "tkinter_available": tkinter_ok,
        "python": sys.version.split()[0],
        "tabs": ["Game Rip", "Mod Workspace", "GMX Workbench", "Utilities"],
        "principle": "GUI wraps the existing CLI; format logic stays in audited toolkit code",
        "gmx_scene_graph_report": True,
        "gmx_scene_graph_sync": True,
        "gmx_texture_graph_sync": True,
        "gmx_animation_graph_sync": True,
        "mod_gltf_texture_pipeline": True,
        "native_tex_layout_synthesis": True,
        "gmx_multibone_animation_sync": True,
        "gltf_cubicspline_animation_import": True,
        "gmx_template_free_compile": True,
        "gmx_canonical_root_synthesis": True,
        "gmx_rigid_skin_import": True,
        "gmx_blended_skin_rejection": True,
        "gmx_rigid_inverse_bind_rebake": True,
        "gmx_rigid_partitioning": True,
        "gmx_multi_file_assembly": True,
        "all_boss_matrix": True,
        "boss_families": 18,
        "boss_canonical_catalogs": 18,
        "boss_deep_runtime_reconstruction_families": 13,
        "boss_native_inspection_only_families": 5,
        "progressive_ufo_one_click_assembly": True,
        "progressive_ufo_formation_assemblies": 2,
        "progressive_ufo_classic_assembly": True,
        "crab_one_click_assembly": True,
        "hornet_one_click_assembly": True,
        "hornet_exposed_core_assembly": True,
        "mandala_one_click_assembly": True,
        "butterfly_one_click_assembly": True,
        "butterfly_phase_assemblies": 4,
        "unknown_internal_form_export": True,
        "unknown_internal_forms": 14,
        "unknown_unique_visual_forms": 13,
        "unknown_visual_duplicate": "uk08=uk01",
        "unknown_runtime_cycle_reference": True,
        "vertebrate_one_click_assembly": True,
        "vertebrate_phase_assemblies": 2,
        "centipede_one_click_assembly": True,
        "centipede_initial_ring_assembly": True,
        "gigantic_ufo_one_click_assembly": True,
        "gigantic_ufo_complete_assembly": True,
        "squid_one_click_assembly": True,
        "squid_phase_assemblies": 2,
        "squid_locator_leg_assembly": True,
        "axon_one_click_assembly": True,
        "axon_form_assemblies": 3,
        "axon_exact_two_ring_assembly": True,
        "the_sun_one_click_assembly": True,
        "the_sun_form_assemblies": 3,
        "the_sun_long_wave_segments": 48,
        "ultimate_ufo_one_click_assembly": True,
        "ultimate_ufo_complete_assembly": True,
        "ultimate_ufo_phase_assemblies": 8,
        "hornet_prism_wall_variants": 13,
        "hornet_propagation_seed_wave_family": True,
        "hornet_propagation_seeds": 13,
        "gui_modes": ["simple", "advanced"],
        "default_gui_mode": "simple",
        "hover_context_help": True,
        "game_rip_drag_drop": True,
        "game_rip_drag_drop_backend": "stdlib Windows WM_DROPFILES",
        "game_rip_drag_drop_accepts_files_and_folders": True,
        "game_rip_drop_starts_automatically": False,
        "game_rip_browse_fallback": True,
    }



def _select_single_drop_path(paths) -> tuple[Optional[str], Optional[str]]:
    """Normalize a shell drop and require exactly one source path."""
    unique: list[str] = []
    for raw in paths:
        value = os.path.normpath(str(raw).strip())
        if value and value not in unique:
            unique.append(value)
    if not unique:
        return None, "The drop did not contain a file or folder."
    if len(unique) != 1:
        return None, "Drop one game/package or extracted game folder at a time."
    return unique[0], None


class _WindowsFileDropTarget:
    """Small stdlib-only WM_DROPFILES bridge for Tk on Windows.

    Explorer sends WM_DROPFILES to the Tk toplevel.  Keeping this bridge here avoids
    adding tkinterdnd2/tkdnd binaries to the source-only toolkit release.
    """

    WM_DROPFILES = 0x0233
    GWL_WNDPROC = -4

    def __init__(self, root, callback: Callable[[tuple[str, ...], int, int], None]) -> None:
        if not sys.platform.startswith("win"):
            raise RuntimeError("Windows shell drag-and-drop is only available on Windows")
        import ctypes
        from ctypes import wintypes

        self._ctypes = ctypes
        self._wintypes = wintypes
        self.root = root
        self.callback = callback
        self.hwnd = int(root.winfo_id())
        self._active = False

        user32 = ctypes.windll.user32
        shell32 = ctypes.windll.shell32
        self.user32 = user32
        self.shell32 = shell32

        LRESULT = ctypes.c_ssize_t
        WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
        self._WNDPROC = WNDPROC
        self._proc = WNDPROC(self._wndproc)

        if ctypes.sizeof(ctypes.c_void_p) == 8:
            self._get_wndproc = user32.GetWindowLongPtrW
            self._set_wndproc = user32.SetWindowLongPtrW
        else:
            self._get_wndproc = user32.GetWindowLongW
            self._set_wndproc = user32.SetWindowLongW
        self._get_wndproc.argtypes = [wintypes.HWND, ctypes.c_int]
        self._get_wndproc.restype = ctypes.c_void_p
        self._set_wndproc.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_void_p]
        self._set_wndproc.restype = ctypes.c_void_p
        user32.CallWindowProcW.argtypes = [ctypes.c_void_p, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        user32.CallWindowProcW.restype = LRESULT
        shell32.DragAcceptFiles.argtypes = [wintypes.HWND, wintypes.BOOL]
        shell32.DragQueryFileW.argtypes = [wintypes.HANDLE, wintypes.UINT, wintypes.LPWSTR, wintypes.UINT]
        shell32.DragQueryFileW.restype = wintypes.UINT
        shell32.DragQueryPoint.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.POINT)]
        shell32.DragQueryPoint.restype = wintypes.BOOL
        shell32.DragFinish.argtypes = [wintypes.HANDLE]

        old = self._get_wndproc(self.hwnd, self.GWL_WNDPROC)
        if not old:
            raise OSError("Could not read the Tk window procedure")
        self._old_proc = ctypes.c_void_p(old)
        ctypes.set_last_error(0)
        result = self._set_wndproc(
            self.hwnd, self.GWL_WNDPROC, ctypes.cast(self._proc, ctypes.c_void_p)
        )
        if not result and ctypes.get_last_error():
            raise ctypes.WinError(ctypes.get_last_error())
        shell32.DragAcceptFiles(self.hwnd, True)
        self._active = True

    def _wndproc(self, hwnd, msg, wparam, lparam):
        if msg == self.WM_DROPFILES:
            try:
                count = int(self.shell32.DragQueryFileW(wparam, 0xFFFFFFFF, None, 0))
                paths: list[str] = []
                for index in range(count):
                    length = int(self.shell32.DragQueryFileW(wparam, index, None, 0))
                    buf = self._ctypes.create_unicode_buffer(length + 1)
                    self.shell32.DragQueryFileW(wparam, index, buf, length + 1)
                    paths.append(buf.value)
                point = self._wintypes.POINT()
                self.shell32.DragQueryPoint(wparam, self._ctypes.byref(point))
                payload = tuple(paths)
                x, y = int(point.x), int(point.y)
            except Exception:
                # A native window procedure must never let a Python exception escape.
                return 0
            finally:
                # The shell owns the HDROP handle until DragFinish.  Always release it,
                # even if querying one of the dropped paths fails unexpectedly.
                try:
                    self.shell32.DragFinish(wparam)
                except Exception:
                    pass
            try:
                self.root.after_idle(lambda: self.callback(payload, x, y))
            except Exception:
                pass
            return 0
        try:
            return self.user32.CallWindowProcW(self._old_proc, hwnd, msg, wparam, lparam)
        except Exception:
            # Defensive fallback: ctypes callbacks must not leak Python exceptions.
            return 0

    def close(self) -> None:
        if not self._active:
            return
        try:
            self.shell32.DragAcceptFiles(self.hwnd, False)
            self._set_wndproc(self.hwnd, self.GWL_WNDPROC, self._old_proc)
        except Exception:
            pass
        self._active = False

def _open_path(path: Path) -> None:
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception:
        if path.is_file() and path.suffix.lower() in {".html", ".htm"}:
            webbrowser.open(path.resolve().as_uri())


def main() -> int:
    if "--check" in sys.argv:
        print(json.dumps(diagnostics(), indent=2))
        return 0
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except Exception as exc:
        print(f"Tkinter is unavailable: {exc}", file=sys.stderr)
        return 2

    class App(tk.Tk):
        def __init__(self) -> None:
            super().__init__()
            self.title(f"SIIG Asset Toolkit {toolkit_version()} — Desktop")
            self.geometry("1120x780")
            self.minsize(900, 650)
            self._queue: queue.Queue = queue.Queue()
            self._busy = False
            self._buttons: list[ttk.Button] = []
            self._status = tk.StringVar(value="Ready")
            self.advanced_mode = tk.BooleanVar(value=False)
            self._mode_label = tk.StringVar(value="Mode: Simple")
            self._help_default = "Hover over a box or button to see what it does. Simple mode hides specialist controls; Advanced mode shows everything."
            self._advanced_widgets: list[object] = []
            self._simple_widgets: list[object] = []
            self._drop_target = None
            self._build_ui()
            self._apply_mode()
            self._install_game_drop()
            self.protocol("WM_DELETE_WINDOW", self._on_close)
            self.after(80, self._poll_queue)

        def _on_close(self) -> None:
            target = self._drop_target
            self._drop_target = None
            if target is not None:
                target.close()
            self.destroy()

        def _build_ui(self) -> None:
            outer = ttk.Frame(self, padding=10)
            outer.pack(fill="both", expand=True)
            header = ttk.Frame(outer)
            header.pack(fill="x", pady=(0, 8))
            ttk.Label(header, text="SIIG Asset Toolkit", font=("TkDefaultFont", 16, "bold")).pack(side="left")
            ttk.Label(header, text=f"  {toolkit_version()}  •  GUI {GUI_VERSION}").pack(side="left", padx=6)
            ttk.Label(header, textvariable=self._status).pack(side="right", padx=(10, 0))
            mode_switch = ttk.Checkbutton(header, text="Advanced mode", variable=self.advanced_mode, command=self._apply_mode)
            mode_switch.pack(side="right", padx=(10, 0))
            ttk.Label(header, textvariable=self._mode_label).pack(side="right")
            self._register_help(mode_switch, "Switch between the beginner-friendly Simple interface and the full Advanced interface. Advanced mode does not unlock hidden format features; it only shows the specialist controls.")

            note = ttk.Label(
                outer,
                text="Desktop control center. Simple mode is recommended if you are new to the toolkit; native parsing/building still uses the same audited CLI code underneath.",
                foreground="#555555",
            )
            note.pack(fill="x", pady=(0, 8))

            self.tabs = ttk.Notebook(outer)
            self.tabs.pack(fill="both", expand=True)
            self._tab_game(ttk.Frame(self.tabs, padding=12))
            self._tab_mod(ttk.Frame(self.tabs, padding=12))
            self._tab_gmx(ttk.Frame(self.tabs, padding=12))
            self._tab_util(ttk.Frame(self.tabs, padding=12))
            self.tabs.bind("<<NotebookTabChanged>>", lambda _event: self._restore_help())

            help_frame = ttk.LabelFrame(outer, text="What does this do?", padding=6)
            help_frame.pack(fill="x", expand=False, pady=(10, 0))
            self.help_box = tk.Text(help_frame, height=4, wrap="word", relief="flat", padx=4, pady=4)
            self.help_box.pack(fill="x", expand=True)
            self.help_box.configure(state="disabled")
            self._set_help(self._help_default)

            log_frame = ttk.LabelFrame(outer, text="Task log / results", padding=6)
            log_frame.pack(fill="both", expand=False, pady=(8, 0))
            self.log = tk.Text(log_frame, height=9, wrap="word")
            scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
            self.log.configure(yscrollcommand=scroll.set)
            self.log.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")
            toolbar = ttk.Frame(outer)
            toolbar.pack(fill="x", pady=(5, 0))
            clear = ttk.Button(toolbar, text="Clear log", command=lambda: self.log.delete("1.0", "end"))
            clear.pack(side="left")
            copy = ttk.Button(toolbar, text="Copy log", command=self._copy_log)
            copy.pack(side="left", padx=5)
            self._register_help(clear, "Clear the task log. This does not delete or undo any files or toolkit work.")
            self._register_help(copy, "Copy the entire task log to the clipboard so you can save it or send it for troubleshooting.")

        def _register_help(self, widget, text: str) -> None:
            """Show contextual help for any interactive control without intrusive pop-ups."""
            widget.bind("<Enter>", lambda _event, message=text: self._set_help(message), add="+")
            widget.bind("<FocusIn>", lambda _event, message=text: self._set_help(message), add="+")
            widget.bind("<Leave>", lambda _event: self._restore_help(), add="+")

        def _set_help(self, text: str) -> None:
            if not hasattr(self, "help_box"):
                return
            self.help_box.configure(state="normal")
            self.help_box.delete("1.0", "end")
            self.help_box.insert("1.0", text)
            self.help_box.configure(state="disabled")

        def _restore_help(self) -> None:
            if not hasattr(self, "tabs"):
                return
            try:
                tab_name = self.tabs.tab(self.tabs.select(), "text")
            except Exception:
                tab_name = ""
            defaults = {
                "Game Rip": "Game Rip extracts the game/package into a verified working copy and builds convenient converted previews. Hover over a control for details.",
                "Mod Workspace": "Simple mode: choose a verified rip and a workspace, create the workspace, edit files, then Build → Verify → Pack. Advanced mode exposes direct GMX resource-import plumbing.",
                "GMX Workbench": "Simple mode: choose a GMX, export it for Blender, edit the glTF, then rebuild a new GMX. Advanced mode exposes low-level graph/schema/JSON controls.",
                "Utilities": "Utilities contains validation, diagnostics, self-tests and the standalone browser asset viewer. Hover over a control for details.",
            }
            self._set_help(defaults.get(tab_name, self._help_default))

        def _mode_only(self, widget, *, advanced: bool = False, simple: bool = False) -> None:
            if advanced:
                self._advanced_widgets.append(widget)
            if simple:
                self._simple_widgets.append(widget)

        def _apply_mode(self) -> None:
            advanced = bool(self.advanced_mode.get())
            self._mode_label.set("Mode: Advanced" if advanced else "Mode: Simple")
            for widget in self._advanced_widgets:
                try:
                    widget.grid() if advanced else widget.grid_remove()
                except Exception:
                    pass
            for widget in self._simple_widgets:
                try:
                    widget.grid_remove() if advanced else widget.grid()
                except Exception:
                    pass
            if hasattr(self, "mod_mode_note"):
                self.mod_mode_note.set(
                    "Advanced mode shows direct resource keys, raw glTF/TEX import and package inspection tools."
                    if advanced else
                    "Simple mode: create a workspace from a verified rip, edit its files, then Build → Verify → Pack. The specialist GMX resource fields are hidden."
                )
            if hasattr(self, "gmx_mode_note"):
                self.gmx_mode_note.set(
                    "Advanced mode shows JSON editing, graph/schema synchronization, generic assembly and template-free construction controls."
                    if advanced else
                    "Simple mode: choose a GMX, export it for Blender, edit the glTF, then rebuild a new GMX. PROGRESSIVE UFO can also be assembled in one click."
                )
            self._restore_help()

        def _entry_row(self, parent, row: int, label: str, var, kind: str = "file", save: bool = False, filetypes=None, help_text: str = "", advanced_only: bool = False) -> None:
            help_text = help_text or f"Set {label}. Use Browse if you do not want to type the path manually."
            label_widget = ttk.Label(parent, text=label)
            label_widget.grid(row=row, column=0, sticky="w", padx=(0, 8), pady=4)
            entry = ttk.Entry(parent, textvariable=var)
            entry.grid(row=row, column=1, sticky="ew", pady=4)
            def browse() -> None:
                initial = Path(var.get()).expanduser() if var.get() else Path.home()
                if kind == "dir":
                    value = filedialog.askdirectory(initialdir=str(initial if initial.is_dir() else initial.parent))
                elif save:
                    value = filedialog.asksaveasfilename(initialdir=str(initial.parent), initialfile=initial.name, filetypes=filetypes or [("All files", "*.*")])
                else:
                    value = filedialog.askopenfilename(initialdir=str(initial if initial.is_dir() else initial.parent), filetypes=filetypes or [("All files", "*.*")])
                if value:
                    var.set(value)
            browse_button = ttk.Button(parent, text="Browse…", command=browse)
            browse_button.grid(row=row, column=2, padx=(8, 0), pady=4)
            parent.columnconfigure(1, weight=1)
            for widget in (label_widget, entry, browse_button):
                self._register_help(widget, help_text)
                if advanced_only:
                    self._mode_only(widget, advanced=True)

        def _action(self, parent, text: str, command: Callable[[], None], row: int, col: int = 0, span: int = 1, help_text: str = "") -> None:
            button = ttk.Button(parent, text=text, command=command)
            button.grid(row=row, column=col, columnspan=span, sticky="ew", padx=4, pady=4)
            self._buttons.append(button)
            self._register_help(button, help_text or f"Run {text}. The command and its results will appear in the task log below.")

        def _tab_game(self, tab) -> None:
            self.tabs.add(tab, text="Game Rip")
            self.game_tab = tab
            self.game_input = tk.StringVar()
            self.game_output = tk.StringVar(value=str(Path.cwd() / "SIIG_Ripped"))
            self.game_resume = tk.BooleanVar(value=True)
            self.game_drop_note = tk.StringVar(value="Drop one game/package or extracted game folder here, or use Browse… below.")
            ttk.Label(tab, text="Full-game extraction and verification", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))

            self.game_drop_zone = ttk.LabelFrame(tab, text="Drag and drop game input", padding=12)
            self.game_drop_zone.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(0, 8))
            drop_label = ttk.Label(self.game_drop_zone, textvariable=self.game_drop_note, anchor="center", justify="center", wraplength=820)
            drop_label.pack(fill="x", expand=True, ipady=8)
            drop_help = "Windows: drag one Xbox 360 STFS/XBLA package, PS3 package, supported archive, or extracted game folder from Explorer onto this box. Dropping only selects the source; Rip game still starts the extraction."
            self._register_help(self.game_drop_zone, drop_help)
            self._register_help(drop_label, drop_help)

            self._entry_row(tab, 2, "Game/package", self.game_input, help_text="Choose the Xbox 360 STFS/game package, PS3 package/extracted game input, or another supported game source you want the toolkit to rip. On Windows you can also drag it into the box above.")
            self._entry_row(tab, 3, "Rip output", self.game_output, kind="dir", help_text="Choose where the extracted and converted game files should be written. The toolkit creates its organized rip structure here.")
            resume = ttk.Checkbutton(tab, text="Resume/reuse unchanged work", variable=self.game_resume)
            resume.grid(row=4, column=1, sticky="w", pady=4)
            self._register_help(resume, "Recommended. Reuses already completed extraction/conversion work when the source has not changed, which makes repeated runs much faster.")
            actions = ttk.Frame(tab); actions.grid(row=5, column=0, columnspan=3, sticky="ew", pady=8)
            for c in range(4): actions.columnconfigure(c, weight=1)
            self._action(actions, "Rip game", self._rip_game, 0, 0, help_text="Start the full extraction/conversion workflow using the selected game/package and output folder.")
            self._action(actions, "Verify rip", lambda: self._run(["verify-output", self.game_output.get()]), 0, 1, help_text="Check the completed rip for missing, changed or invalid outputs. This does not modify the rip.")
            self._action(actions, "Build asset viewer", self._build_viewer, 0, 2, help_text="Create a local browser-based viewer for the ripped assets and open it when finished.")
            self._action(actions, "Open rip folder", lambda: _open_path(Path(self.game_output.get())), 0, 3, help_text="Open the selected rip-output directory in your normal file manager.")
            ttk.Label(tab, text="The full rip automatically converts supported models/textures/scripts and writes validation reports.", wraplength=850).grid(row=6, column=0, columnspan=3, sticky="w", pady=4)

        def _install_game_drop(self) -> None:
            if not hasattr(self, "game_drop_note"):
                return
            if not sys.platform.startswith("win"):
                self.game_drop_note.set("Drag-and-drop game selection is available on Windows. On this platform, use Browse… below.")
                return
            try:
                self.update_idletasks()
                self._drop_target = _WindowsFileDropTarget(self, self._on_windows_file_drop)
                self.game_drop_note.set("Drop one game/package or extracted game folder here. Then click Rip game.")
            except Exception as exc:
                self.game_drop_note.set(f"Drag-and-drop could not be enabled ({exc}). Use Browse… below.")

        def _drop_hits_game_zone(self, x: int, y: int) -> bool:
            try:
                zone = self.game_drop_zone
                left = zone.winfo_rootx() - self.winfo_rootx()
                top = zone.winfo_rooty() - self.winfo_rooty()
                return left <= x < left + zone.winfo_width() and top <= y < top + zone.winfo_height()
            except Exception:
                return False

        def _on_windows_file_drop(self, paths: tuple[str, ...], x: int, y: int) -> None:
            if not self._drop_hits_game_zone(x, y):
                self._status.set("Drop ignored — use the Game Rip drop box")
                return
            selected, error = _select_single_drop_path(paths)
            if error:
                messagebox.showinfo("Game input drop", error)
                return
            assert selected is not None
            self.game_input.set(selected)
            name = Path(selected).name or selected
            self.game_drop_note.set(f"Selected: {name}\nClick Rip game to start, or drop another source to replace it.")
            self._status.set("Game input selected")
            self.tabs.select(self.game_tab)
            self._append(f"\n[drag/drop] Selected game input: {selected}\n")

        def _tab_mod(self, tab) -> None:
            self.tabs.add(tab, text="Mod Workspace")
            self.mod_rip = tk.StringVar()
            self.mod_ws = tk.StringVar(value=str(Path.cwd() / "SIIG_Mod_Workspace"))
            self.mod_archive = tk.StringVar()
            self.mod_resource = tk.StringVar()
            self.mod_gltf = tk.StringVar()
            self.mod_mode_note = tk.StringVar()
            ttk.Label(tab, text="Mod Workspace", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 4))
            ttk.Label(tab, textvariable=self.mod_mode_note, wraplength=900).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 8))
            self._entry_row(tab, 2, "Verified game rip", self.mod_rip, kind="dir", help_text="Choose the verified rip you made in Game Rip. Mod Workspace uses this as the clean source when building or applying changes.")
            self._entry_row(tab, 3, "Mod workspace folder", self.mod_ws, kind="dir", help_text="Choose the folder where your editable mod project will live. Create Workspace will prepare it for you.")

            # Direct GMX-resource plumbing is intentionally hidden from beginners.
            self._entry_row(tab, 4, "GMX archive key", self.mod_archive, help_text="Advanced: internal BBX/archive key that identifies which container owns the GMX resource you want to replace.", advanced_only=True)
            self._entry_row(tab, 5, "GMX resource", self.mod_resource, help_text="Advanced: exact GMX resource name/path inside the selected archive key.", advanced_only=True)
            self._entry_row(tab, 6, "Edited glTF", self.mod_gltf, filetypes=[("glTF 2.0", "*.gltf"), ("All files", "*.*")], help_text="Advanced: an edited glTF that should be compiled and imported directly into the selected GMX resource, including compatible texture changes.", advanced_only=True)

            simple_actions = ttk.LabelFrame(tab, text="Beginner workflow", padding=6)
            simple_actions.grid(row=7, column=0, columnspan=3, sticky="ew", pady=8)
            self._mode_only(simple_actions, simple=True)
            for c in range(4): simple_actions.columnconfigure(c, weight=1)
            self._action(simple_actions, "1. Create workspace", lambda: self._run(["mod-init", self.mod_rip.get(), "-o", self.mod_ws.get()]), 0, 0, help_text="Create a new editable mod workspace from the verified game rip. Do this once when starting a mod project.")
            self._action(simple_actions, "2. Open workspace", lambda: _open_path(Path(self.mod_ws.get())), 0, 1, help_text="Open your mod workspace in the file manager so you can replace/edit the prepared files.")
            self._action(simple_actions, "3. Build changes", lambda: self._run(["mod-build", self.mod_ws.get()]), 0, 2, help_text="Compile the files you changed in the workspace into game-ready replacement data.")
            self._action(simple_actions, "4. Verify build", lambda: self._run(["mod-verify", self.mod_ws.get()]), 0, 3, help_text="Check that the current built mod is structurally valid before packaging or applying it.")
            self._action(simple_actions, "5. Pack .siigmod…", self._pack_mod, 1, 0, 2, help_text="Package your verified workspace changes into one shareable .siigmod file.")
            self._action(simple_actions, "Apply .siigmod…", self._apply_mod, 1, 2, 2, help_text="Apply an existing .siigmod package to a clean verified rip and build the resulting mod workspace.")

            advanced_actions = ttk.LabelFrame(tab, text="Advanced workspace tools", padding=6)
            advanced_actions.grid(row=7, column=0, columnspan=3, sticky="ew", pady=8)
            self._mode_only(advanced_actions, advanced=True)
            for c in range(4): advanced_actions.columnconfigure(c, weight=1)
            self._action(advanced_actions, "Initialize", lambda: self._run(["mod-init", self.mod_rip.get(), "-o", self.mod_ws.get()]), 0, 0, help_text="Initialize a mod workspace from the selected verified rip.")
            self._action(advanced_actions, "List assets", lambda: self._run(["mod-list", self.mod_ws.get()]), 0, 1, help_text="Print the assets known to the current mod workspace and their change/build state.")
            self._action(advanced_actions, "Build changes", lambda: self._run(["mod-build", self.mod_ws.get()]), 0, 2, help_text="Build all pending workspace changes into native game resources.")
            self._action(advanced_actions, "Verify build", lambda: self._run(["mod-verify", self.mod_ws.get()]), 0, 3, help_text="Run structural verification on the built mod workspace.")
            self._action(advanced_actions, "Pack .siigmod…", self._pack_mod, 1, 0, help_text="Package the current workspace delta as a deterministic .siigmod file.")
            self._action(advanced_actions, "Inspect .siigmod…", self._inspect_mod, 1, 1, help_text="Read and validate a .siigmod package without applying it.")
            self._action(advanced_actions, "Apply .siigmod…", self._apply_mod, 1, 2, help_text="Apply a .siigmod package to the selected verified source rip and build it into this workspace.")
            self._action(advanced_actions, "Open workspace", lambda: _open_path(Path(self.mod_ws.get())), 1, 3, help_text="Open the current mod workspace folder in your file manager.")
            self._action(advanced_actions, "Import glTF + TEX", self._mod_import_gltf, 2, 0, 2, help_text="Advanced: compile the selected edited glTF into the specified GMX resource and synchronize compatible texture replacements through the workspace pipeline.")
            ttk.Label(tab, text="The safe rigid-mesh path partitions disjoint single-joint islands automatically. Cross-joint triangles and true blended skinning are still rejected because SIIG's native per-vertex weight format has not been proven.", wraplength=900).grid(row=8, column=0, columnspan=3, sticky="w", pady=4)

        def _tab_gmx(self, tab) -> None:
            self.tabs.add(tab, text="GMX Workbench")
            self.gmx_template = tk.StringVar()
            self.gmx_gltf = tk.StringVar()
            self.gmx_output = tk.StringVar()
            self.gmx_json = tk.StringVar()
            self.gmx_flip = tk.BooleanVar(value=False)
            self.gmx_sync_graph = tk.BooleanVar(value=False)
            self.gmx_sync_scene = tk.BooleanVar(value=False)
            self.gmx_sync_texture = tk.BooleanVar(value=False)
            self.gmx_synthesize_schemas = tk.BooleanVar(value=False)
            self.gmx_sync_animation = tk.BooleanVar(value=False)
            self.gmx_sync_rigid_skins = tk.BooleanVar(value=False)
            self.gmx_mode_note = tk.StringVar()
            self.progressive_ufo_formation = tk.StringVar(value="Original — first runtime formation")
            self.ultimate_ufo_state = tk.StringVar(value="COMPLETE — 126 allocated hierarchy")
            self.butterfly_phase = tk.StringVar(value="1 — phase 1 / body only")
            self.unknown_form = tk.StringVar(value="01 — uk01")
            self.vertebrate_phase = tk.StringVar(value="1 — phase 1 / immense tower")
            self.squid_phase = tk.StringVar(value="1 — phase 1 / eight legs")
            self.axon_form = tk.StringVar(value="Expanded — core + 16 petals")
            self.the_sun_form = tk.StringVar(value="Extended arms — native sample 40")
            self.hornet_prism_slot = tk.StringVar(value="22")
            self.hornet_propagation_seed = tk.StringVar(value="22")
            self.hornet_propagation_wave = tk.StringVar(value="3")
            ttk.Label(tab, text="GMX Workbench", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 4))
            ttk.Label(tab, textvariable=self.gmx_mode_note, wraplength=900).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 8))
            self._entry_row(tab, 2, "Original/native GMX", self.gmx_template, filetypes=[("SIIG GMX", "*.gmx"), ("All files", "*.*")], help_text="Choose the original GMX model. Export for Blender converts this file; Rebuild GMX uses it as the structural template unless you use the advanced template-free creator.")
            self._entry_row(tab, 3, "Edited glTF", self.gmx_gltf, filetypes=[("glTF 2.0", "*.gltf"), ("All files", "*.*")], help_text="Choose the glTF you edited in Blender or another glTF editor. Export for Blender fills this automatically with the newly exported glTF path.")
            self._entry_row(tab, 4, "Output GMX", self.gmx_output, save=True, filetypes=[("SIIG GMX", "*.gmx")], help_text="Advanced: choose the exact output filename. If left blank, Rebuild GMX automatically writes <original>.edited.gmx beside the source model.", advanced_only=True)
            self._entry_row(tab, 5, "Editable GMX JSON", self.gmx_json, save=True, filetypes=[("JSON", "*.json")], help_text="Advanced: path for the low-level editable GMX JSON representation used by Export editable JSON / Build JSON → GMX.", advanced_only=True)

            advanced_options = ttk.LabelFrame(tab, text="Advanced import options", padding=6)
            advanced_options.grid(row=6, column=0, columnspan=3, sticky="ew", pady=6)
            self._mode_only(advanced_options, advanced=True)
            options = [
                ("Flip UV V on glTF import/export", self.gmx_flip, "Flip the V texture coordinate during glTF conversion. Leave this off unless the texture orientation in your editing workflow specifically requires it."),
                ("Sync native MESH/ARRY graph", self.gmx_sync_graph, "Rebuild the native mesh/index graph from the glTF rather than preserving the donor graph. Useful for topology changes; more invasive than a basic template-preserving edit."),
                ("Sync BONE/PARE + material/shader scene graph", self.gmx_sync_scene, "Rebuild the decoded bone/parent/material/shader scene relationships from glTF. Use for scene-graph changes rather than simple geometry edits."),
                ("Sync TXIF texture bindings", self.gmx_sync_texture, "Rebuild native texture binding records from the glTF material/texture graph."),
                ("Synthesize native vertex/material schemas", self.gmx_synthesize_schemas, "Allow donor-free synthesis of the decoded standard native vertex/material schemas when the glTF needs structures not present in the template."),
                ("Sync MOTN/ANIM animation graph", self.gmx_sync_animation, "Rebuild native 30 Hz MOTN/ANIM tracks from supported glTF animation channels."),
                ("Import rigid glTF skins + inverse-bind rebake", self.gmx_sync_rigid_skins, "Import single-joint rigid glTF skinning and rebake inverse-bind transforms. True blended weights remain unsupported."),
            ]
            for row, (text, var, help_text) in enumerate(options):
                cb = ttk.Checkbutton(advanced_options, text=text, variable=var)
                cb.grid(row=row, column=0, sticky="w", pady=2)
                self._register_help(cb, help_text)

            simple_actions = ttk.LabelFrame(tab, text="Beginner workflow", padding=6)
            simple_actions.grid(row=7, column=0, columnspan=3, sticky="ew", pady=8)
            self._mode_only(simple_actions, simple=True)
            for c in range(4): simple_actions.columnconfigure(c, weight=1)
            self._action(simple_actions, "1. Export for Blender", self._export_gltf, 0, 0, 2, help_text="Convert the selected original GMX into a glTF you can open in Blender. After export, the Edited glTF box is filled automatically.")
            self._action(simple_actions, "2. Rebuild GMX", self._import_gltf, 0, 2, 2, help_text="Compile the selected edited glTF back into a new GMX using the original GMX as a conservative structural template. The original file is not overwritten by default.")
            self._action(simple_actions, "Inspect GMX", self._inspect_gmx, 1, 0, help_text="Show a structural scan of the selected GMX in the task log. This is read-only and safe.")
            self._action(simple_actions, "Open model folder", lambda: _open_path(Path(self.gmx_template.get()).parent), 1, 1, help_text="Open the folder containing the selected original GMX.")
            ttk.Label(simple_actions, text="PROGRESSIVE UFO formation").grid(row=1, column=2, sticky="w", padx=4, pady=4)
            progressive_simple = ttk.Combobox(simple_actions, textvariable=self.progressive_ufo_formation, state="readonly", width=28, values=self._progressive_ufo_formation_values())
            progressive_simple.grid(row=1, column=3, sticky="ew", padx=4, pady=4)
            self._register_help(progressive_simple, "Choose the original executable-backed first formation or the recurring state-5/state-8 classic-UFO formation. The original progressive_ufo catalog remains unchanged for compatibility.")
            self._action(simple_actions, "Assemble PROGRESSIVE UFO", self._assemble_progressive_ufo, 2, 0, 4, help_text="Choose a folder containing bos_009.gmx, bos_009a.gmx and bos_009b.gmx, then export the selected evidence-backed five-part formation.")
            self._action(simple_actions, "Assemble CRAB", self._assemble_crab, 3, 0, 4, help_text="Choose a folder containing bos_013.gmx plus bos_013a/b/c/d.gmx, then export CRAB in its executable-backed landed/combat-ready pose. The root uses native sample 1, where the feet sit on the ground plane; the older airborne first-visible sample remains available as the crab_first_visible catalog.")
            self._action(simple_actions, "Assemble HORNET armor", self._assemble_hornet, 4, 0, 2, help_text="Choose a folder containing bos_008.gmx and bos_008a.gmx, then export HORNET's fully revealed 125-cube armor lattice. The invisible bos_008c formation rig and dormant bos_008b prism pool are runtime controllers/phase assets and are not cluttered into this viewing preset.")
            self._action(simple_actions, "Assemble HORNET exposed", self._assemble_hornet_exposed, 4, 2, 2, help_text="Export HORNET's executable-backed high-level state-3 entry: the A1 core alone at native motion-0 sample 0 after the common reset has cleared BF/C0 runtime records.")
            self._action(simple_actions, "Assemble MANDALA", self._assemble_mandala, 5, 0, 4, help_text="Choose a folder containing bos_005.gmx and bos_005a/b/c/d/e.gmx, then export MANDALA at the executable-backed initial-combat state-7 activation instant. The later BC inner phase is intentionally excluded.")
            ttk.Label(simple_actions, text="ULTIMATE UFO state").grid(row=6, column=0, sticky="w", padx=4, pady=4)
            ultimate_simple = ttk.Combobox(simple_actions, textvariable=self.ultimate_ufo_state, state="readonly", width=28, values=self._ultimate_ufo_state_values())
            ultimate_simple.grid(row=6, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(ultimate_simple, "Choose an executable-backed visible ULTIMATE UFO state. COMPLETE exports all 126 model instances allocated by the retail hierarchy without claiming simultaneous phase visibility. The numbered choices are activity-focused subsets derived from col/dis state flags.")
            self._action(simple_actions, "Assemble ULTIMATE UFO", self._assemble_ultimate_ufo, 6, 2, 2, help_text="Choose a folder containing your extracted bos_015*.gmx files, then export the selected runtime state. Locator-driven pieces are attached to exact lt_### nodes so the native parent animation hierarchy is preserved.")
            ttk.Label(simple_actions, text="BUTTERFLY phase").grid(row=7, column=0, sticky="w", padx=4, pady=4)
            butterfly_simple = ttk.Combobox(simple_actions, textvariable=self.butterfly_phase, state="readonly", width=28, values=self._butterfly_phase_values())
            butterfly_simple.grid(row=7, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(butterfly_simple, "Choose one of BUTTERFLY's four executable-backed body/module configurations. Phase 1 is body-only; phases 2–4 attach the exact C7/C8/C9 wing modules to their native lt_### locators.")
            self._action(simple_actions, "Assemble BUTTERFLY", self._assemble_butterfly, 7, 2, 2, help_text="Export the selected BUTTERFLY phase from bos_011*.gmx. Wing modules remain attached to exact native locators and follow the body GMX's preserved animation.")
            ttk.Label(simple_actions, text="UNKNOWN form").grid(row=8, column=0, sticky="w", padx=4, pady=4)
            unknown_simple = ttk.Combobox(simple_actions, textvariable=self.unknown_form, state="readonly", width=28, values=self._unknown_form_values())
            unknown_simple.grid(row=8, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(unknown_simple, "Choose one of UNKNOWN's 14 native uk01..uk14 form groups. This filters the single bos_006.gmx scene graph; it does not create duplicate GMX instances.")
            self._action(simple_actions, "Export UNKNOWN form", self._assemble_unknown, 8, 2, 2, help_text="Export the selected native UNKNOWN form from bos_006.gmx. The executable toggles these named branches at runtime; the GMX itself has no native animation clips.")
            ttk.Label(simple_actions, text="VERTEBRATE phase").grid(row=9, column=0, sticky="w", padx=4, pady=4)
            vertebrate_simple = ttk.Combobox(simple_actions, textvariable=self.vertebrate_phase, state="readonly", width=28, values=self._vertebrate_phase_values())
            vertebrate_simple.grid(row=9, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(vertebrate_simple, "Choose VERTEBRATE's executable-backed structural body: the phase-1 32-part immense tower, or the post-collapse phase-2 pair of co-located endcaps. Attack-pattern GMXs are kept separate.")
            self._action(simple_actions, "Assemble VERTEBRATE", self._assemble_vertebrate, 9, 2, 2, help_text="Export the selected VERTEBRATE structural phase from bos_017.gmx/bos_017a.gmx using exact runtime transforms. Phase 1 is 2 endcaps + 30 pillars; phase 2 is the two rebased endcaps only.")
            self._action(simple_actions, "Assemble CENTIPEDE", self._assemble_centipede, 10, 0, 4, help_text="Export CENTIPEDE's exact post-entrance 32-piece combat ring: bos_007 endpoints at head/tail and 30 bos_007a body pieces at radius 80 with 11.25-degree spacing. Split/reform positions are runtime-dependent and are not guessed.")
            self._action(simple_actions, "Assemble GIGANTIC UFO", self._assemble_gigantic_ufo, 11, 0, 4, help_text="Export GIGANTIC UFO's executable-backed 37-model hierarchy: one bos_003.gmx root plus 36 bos_003a.gmx weapon modules attached to exact native lt_001..lt_036 locators.")
            ttk.Label(simple_actions, text="SQUID phase").grid(row=12, column=0, sticky="w", padx=4, pady=4)
            squid_simple = ttk.Combobox(simple_actions, textvariable=self.squid_phase, state="readonly", width=28, values=self._squid_phase_values())
            squid_simple.grid(row=12, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(squid_simple, "Choose SQUID's executable-backed modeled form: phase 1 attaches eight bos_016a.gmx legs to native lt_000..lt_007 locators; phase 2 is the state-8-and-later body-only form after those eight runtime records are disabled.")
            self._action(simple_actions, "Assemble SQUID", self._assemble_squid, 12, 2, 2, help_text="Export the selected SQUID phase from bos_016.gmx/bos_016a.gmx. Phase 1 keeps all eight legs parented to native locator nodes so they follow the body's preserved animation.")
            ttk.Label(simple_actions, text="AXON form").grid(row=13, column=0, sticky="w", padx=4, pady=4)
            axon_simple = ttk.Combobox(simple_actions, textvariable=self.axon_form, state="readonly", width=28, values=self._axon_form_values())
            axon_simple.grid(row=13, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(axon_simple, "Choose AXON's standalone native A5 body, the exact CA + sixteen-CB stable expanded two-ring form, or the CA exposed/core form. A5 and CA/CB are kept separate because the runtime treats them as mutually exclusive representations.")
            self._action(simple_actions, "Assemble AXON", self._assemble_axon, 13, 2, 2, help_text="Export the selected AXON form from bos_012.gmx/bos_012a.gmx/bos_012b.gmx. The expanded form uses the exact retail two-ring transforms at phase angle 0.")
            ttk.Label(simple_actions, text="THE SUN form").grid(row=14, column=0, sticky="w", padx=4, pady=4)
            the_sun_simple = ttk.Combobox(simple_actions, textvariable=self.the_sun_form, state="readonly", width=28, values=self._the_sun_form_values())
            the_sun_simple.grid(row=14, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(the_sun_simple, "Choose THE SUN's native animated body, exact native sample-40 extended-arm pose, or exact maximum 48-tile B3 long-wave field. Extended body and full wave remain separate because their synchronization is not proven.")
            self._action(simple_actions, "Assemble THE SUN", self._assemble_the_sun, 14, 2, 2, help_text="Export the selected evidence-bounded THE SUN form from bos_002.gmx or bos_002b.gmx. The long-wave preset is four groups of twelve tiles at the exact retail full-ramp centers.")

            advanced_actions = ttk.LabelFrame(tab, text="Advanced GMX tools", padding=6)
            advanced_actions.grid(row=7, column=0, columnspan=3, sticky="ew", pady=8)
            self._mode_only(advanced_actions, advanced=True)
            for c in range(4): advanced_actions.columnconfigure(c, weight=1)
            self._action(advanced_actions, "Inspect GMX", self._inspect_gmx, 0, 0, help_text="Read-only structural scan of the selected native GMX.")
            self._action(advanced_actions, "Export glTF", self._export_gltf, 0, 1, help_text="Export the selected GMX into an editable glTF scene.")
            self._action(advanced_actions, "Import glTF → GMX", self._import_gltf, 0, 2, help_text="Template-backed glTF import using the selected advanced synchronization options.")
            self._action(advanced_actions, "Export editable JSON", self._export_gmx_json, 0, 3, help_text="Export a low-level editable JSON representation of the selected GMX for expert structural work.")
            self._action(advanced_actions, "Build JSON → GMX", self._build_gmx_json, 1, 0, help_text="Build a GMX from the editable JSON while preserving unsupported/opaque data from the selected template where required.")
            self._action(advanced_actions, "Open model folder", lambda: _open_path(Path(self.gmx_template.get()).parent), 1, 1, help_text="Open the selected GMX's containing directory.")
            self._action(advanced_actions, "Scene graph report", self._gmx_scene_report, 1, 2, help_text="Generate an HTML report of the decoded GMX scene/bone/material/animation relationships and open it.")
            self._action(advanced_actions, "Create new GMX", self._create_gmx_new, 1, 3, help_text="Compile a supported glTF into a completely new GMX without an original GMX template. Still subject to the toolkit's documented native-format boundaries.")
            ttk.Label(advanced_actions, text="PROGRESSIVE UFO formation").grid(row=2, column=0, sticky="w", padx=4, pady=4)
            progressive_advanced = ttk.Combobox(advanced_actions, textvariable=self.progressive_ufo_formation, state="readonly", width=28, values=self._progressive_ufo_formation_values())
            progressive_advanced.grid(row=2, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(progressive_advanced, "Select the original first runtime formation or the exact recurring state-5/state-8 classic-UFO pose table.")
            self._action(advanced_actions, "PROGRESSIVE UFO manifest", self._progressive_ufo_manifest, 2, 2, help_text="Write the selected evidence-backed PROGRESSIVE UFO assembly definition to JSON for inspection or manual editing.")
            self._action(advanced_actions, "Assemble PROGRESSIVE UFO", self._assemble_progressive_ufo, 2, 3, help_text="Export the selected executable-backed five-part PROGRESSIVE UFO formation.")
            self._action(advanced_actions, "CRAB manifest", self._crab_manifest, 3, 0, help_text="Write the built-in evidence-backed CRAB landed/combat-ready assembly definition to JSON for inspection or manual editing, including its baked native pose samples.")
            self._action(advanced_actions, "Assemble CRAB", self._assemble_crab, 3, 1, 3, help_text="Export the nine-part CRAB landed/combat-ready formation. A7 is baked at native sample 1 (grounded) and the CD shell at sample 0 before the runtime attachment transforms are applied.")
            self._action(advanced_actions, "MANDALA manifest", self._mandala_manifest, 4, 0, help_text="Write the five-build executable-backed MANDALA initial-combat assembly definition: 40 visible instances at the state-7 activation boundary.")
            self._action(advanced_actions, "Assemble MANDALA", self._assemble_mandala, 4, 1, 3, help_text="Export MANDALA's state-7 activation snapshot. Native GMX animations are preserved; no arbitrary internal sample or radial-facing rotation is baked.")
            self._action(advanced_actions, "Armor manifest", self._hornet_manifest, 5, 0, help_text="Write the executable/model-backed full-armor HORNET assembly definition: A1 plus exactly 125 BF armor cubes at the sample-0 C1 formation-rig locator positions.")
            self._action(advanced_actions, "Assemble armor", self._assemble_hornet, 5, 1, help_text="Export HORNET's fully revealed 5×5×5 BF armor formation. C1 is meshless and C0 is a separate attack pool.")
            self._action(advanced_actions, "Exposed manifest", self._hornet_exposed_manifest, 5, 2, help_text="Write the state-3 entry snapshot: one visible A1 core at native sample 0 after the common reset clears all BF/C0 runtime records.")
            self._action(advanced_actions, "Assemble exposed", self._assemble_hornet_exposed, 5, 3, help_text="Export the real executable-backed exposed HORNET state-3 entry instead of inventing an A1-only presentation.")
            ttk.Label(advanced_actions, text="ULTIMATE UFO state").grid(row=6, column=0, sticky="w", padx=4, pady=4)
            ultimate_advanced = ttk.Combobox(advanced_actions, textvariable=self.ultimate_ufo_state, state="readonly", width=28, values=self._ultimate_ufo_state_values())
            ultimate_advanced.grid(row=6, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(ultimate_advanced, "Choose one of the eight executable-backed ULTIMATE UFO state snapshots. COMPLETE is the allocation/hierarchy view; numbered entries are explicit controller-activity subsets. Phase-table collision/destructibility flags are not treated as render-visibility proof.")
            self._action(advanced_actions, "ULTIMATE UFO manifest", self._ultimate_ufo_manifest, 6, 2, help_text="Write the selected ULTIMATE UFO manifest: either the complete 126-instance allocated hierarchy or one of the eight controller-activity subsets.")
            self._action(advanced_actions, "Assemble ULTIMATE UFO", self._assemble_ultimate_ufo, 6, 3, help_text="Export the selected ULTIMATE UFO state using the exact named lt_### attachment hierarchy from the retail executable.")
            ttk.Label(advanced_actions, text="HORNET prism root slot").grid(row=7, column=0, sticky="w", padx=4, pady=4)
            prism_combo = ttk.Combobox(advanced_actions, textvariable=self.hornet_prism_slot, state="readonly", width=18, values=("0", "2", "6", "8", "18", "20", "22", "24", "26", "36", "38", "42", "44"))
            prism_combo.grid(row=7, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(prism_combo, "Advanced: choose one of the 13 exact runtime cells HORNET may randomly assign to its A1 core during the prism-wall attack. There is intentionally no single canonical random outcome.")
            self._action(advanced_actions, "Prism-wall manifest", self._hornet_prism_manifest, 7, 2, help_text="Write the selected evidence-backed HORNET prism-wall variant: one A1 core in the chosen runtime cell plus 44 C0 prisms in every other 5×9 grid cell.")
            self._action(advanced_actions, "Assemble prism wall", self._assemble_hornet_prism, 7, 3, help_text="Export the selected HORNET prism-wall runtime variant. BF armor and the invisible C1 rig are omitted because they are not visible in this settled attack formation.")
            ttk.Label(advanced_actions, text="HORNET propagation seed").grid(row=8, column=0, sticky="w", padx=4, pady=4)
            propagation_seed_combo = ttk.Combobox(advanced_actions, textvariable=self.hornet_propagation_seed, state="readonly", width=18, values=("0", "2", "6", "8", "18", "20", "22", "24", "26", "36", "38", "42", "44"))
            propagation_seed_combo.grid(row=8, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(propagation_seed_combo, "Advanced: choose the inherited prism-wall A1 slot that seeds HORNET's later state-6 C0 propagation. Only the 13 executable-backed runtime seeds are available.")
            ttk.Label(advanced_actions, text="Propagation wave").grid(row=8, column=2, sticky="w", padx=4, pady=4)
            propagation_wave_combo = ttk.Combobox(advanced_actions, textvariable=self.hornet_propagation_wave, state="readonly", width=12, values=tuple(str(i) for i in range(10)))
            propagation_wave_combo.grid(row=8, column=3, sticky="ew", padx=4, pady=4)
            self._register_help(propagation_wave_combo, "Advanced: choose the activation wave. Wave 0 is the seed cell only; later waves alternate orthogonal and diagonal expansion. Some seeds finish before wave 9; invalid combinations are rejected rather than guessed.")
            self._action(advanced_actions, "Propagation manifest", self._hornet_propagation_manifest, 9, 0, 2, help_text="Write the selected HORNET state-6 propagation activation snapshot. A1 is hidden in this state; only C0 prisms reached by the selected seed/wave are included.")
            self._action(advanced_actions, "Assemble propagation", self._assemble_hornet_propagation, 9, 2, 2, help_text="Export the selected HORNET state-6 propagation activation snapshot using the exact 5×9 runtime grid. Beam/effect objects are intentionally omitted because they are not GMX assembly members.")
            ttk.Label(advanced_actions, text="BUTTERFLY phase").grid(row=10, column=0, sticky="w", padx=4, pady=4)
            butterfly_advanced = ttk.Combobox(advanced_actions, textvariable=self.butterfly_phase, state="readonly", width=28, values=self._butterfly_phase_values())
            butterfly_advanced.grid(row=10, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(butterfly_advanced, "Select an exact BUTTERFLY phase. Retail loader records prove the body type, C7/C8/C9 module counts, and locator ranges for all four forms.")
            self._action(advanced_actions, "BUTTERFLY manifest", self._butterfly_manifest, 10, 2, help_text="Write the selected phase manifest with exact C7/C8/C9 module membership and lt_### attachment names.")
            self._action(advanced_actions, "Assemble BUTTERFLY", self._assemble_butterfly, 10, 3, help_text="Export the selected BUTTERFLY phase with native body animation and locator-attached wing modules.")
            ttk.Label(advanced_actions, text="UNKNOWN form").grid(row=11, column=0, sticky="w", padx=4, pady=4)
            unknown_advanced = ttk.Combobox(advanced_actions, textvariable=self.unknown_form, state="readonly", width=28, values=self._unknown_form_values())
            unknown_advanced.grid(row=11, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(unknown_advanced, "Select one of the exact uk01..uk14 BONE branches in retail bos_006.gmx. Retail Xbox, June 10 and retail PS3 all retain a 14-name modulo selector.")
            self._action(advanced_actions, "UNKNOWN manifest", self._unknown_manifest, 11, 2, help_text="Write the selected single-form manifest. Use unknown_all_forms from the CLI if you want all 14 named branches in one scene for manual Outliner inspection.")
            self._action(advanced_actions, "Export UNKNOWN form", self._assemble_unknown, 11, 3, help_text="Export only the selected native ukXX subtree. No fake multipart assembly or guessed transform is introduced.")
            ttk.Label(advanced_actions, text="VERTEBRATE phase").grid(row=12, column=0, sticky="w", padx=4, pady=4)
            vertebrate_advanced = ttk.Combobox(advanced_actions, textvariable=self.vertebrate_phase, state="readonly", width=28, values=self._vertebrate_phase_values())
            vertebrate_advanced.grid(row=12, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(vertebrate_advanced, "Select the exact VERTEBRATE body phase. The structural presets intentionally exclude bos_017b..j because runtime code treats those as separate attack auxiliaries rather than persistent tower pieces.")
            self._action(advanced_actions, "VERTEBRATE manifest", self._vertebrate_manifest, 12, 2, help_text="Write the selected two-phase VERTEBRATE structural assembly manifest for inspection or manual editing.")
            self._action(advanced_actions, "Assemble VERTEBRATE", self._assemble_vertebrate, 12, 3, help_text="Export the exact phase-1 tower or phase-2 endcap pair using the built-in executable-backed transforms.")
            self._action(advanced_actions, "CENTIPEDE manifest", self._centipede_manifest, 13, 0, 2, help_text="Write the exact initial 32-link ring manifest, including runtime head/body/tail roles and the evidence-backed split/reformation metadata.")
            self._action(advanced_actions, "Assemble CENTIPEDE", self._assemble_centipede, 13, 2, 2, help_text="Export the executable-backed initial CENTIPEDE ring. Dynamic split/reform/final-phase positions are intentionally not frozen into a fake canonical layout.")
            self._action(advanced_actions, "GIGANTIC UFO manifest", self._gigantic_ufo_manifest, 14, 0, 2, help_text="Write the executable-backed GIGANTIC UFO manifest: one 0x9E root and 36 0xB5 weapon modules attached to lt_001..lt_036; non-model B4 helper slots are excluded.")
            self._action(advanced_actions, "Assemble GIGANTIC UFO", self._assemble_gigantic_ufo, 14, 2, 2, help_text="Export the complete GIGANTIC UFO visual hierarchy using the native root locator transforms.")
            ttk.Label(advanced_actions, text="SQUID phase").grid(row=15, column=0, sticky="w", padx=4, pady=4)
            squid_advanced = ttk.Combobox(advanced_actions, textvariable=self.squid_phase, state="readonly", width=28, values=self._squid_phase_values())
            squid_advanced.grid(row=15, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(squid_advanced, "Select SQUID phase 1 (animated body + eight native-locator legs) or phase 2 (state-8-and-later animated body only).")
            self._action(advanced_actions, "SQUID manifest", self._squid_manifest, 15, 2, help_text="Write the selected SQUID runtime assembly manifest, including exact record membership, native locator names, and state-8 transition metadata.")
            self._action(advanced_actions, "Assemble SQUID", self._assemble_squid, 15, 3, help_text="Export the selected SQUID modeled phase while retaining the body's native animation clips and exact leg locator parenting.")
            ttk.Label(advanced_actions, text="AXON form").grid(row=16, column=0, sticky="w", padx=4, pady=4)
            axon_advanced = ttk.Combobox(advanced_actions, textvariable=self.axon_form, state="readonly", width=28, values=self._axon_form_values())
            axon_advanced.grid(row=16, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(axon_advanced, "Select AXON's native A5 body, stable expanded CA+16×CB two-ring snapshot, or CA exposed core. Runtime A5 and CA/CB representations are intentionally not stacked together.")
            self._action(advanced_actions, "AXON manifest", self._axon_manifest, 16, 2, help_text="Write the selected AXON runtime assembly manifest, including exact subordinate record membership, ring angles, radii, Y offsets and phase-0 transform provenance.")
            self._action(advanced_actions, "Assemble AXON", self._assemble_axon, 16, 3, help_text="Export the selected executable-backed AXON form. Expanded petals use the exact per-frame retail placement/orientation equations at the deterministic phase-angle-0 snapshot.")
            ttk.Label(advanced_actions, text="THE SUN form").grid(row=17, column=0, sticky="w", padx=4, pady=4)
            the_sun_advanced = ttk.Combobox(advanced_actions, textvariable=self.the_sun_form, state="readonly", width=28, values=self._the_sun_form_values())
            the_sun_advanced.grid(row=17, column=1, sticky="ew", padx=4, pady=4)
            self._register_help(the_sun_advanced, "Native 0x47 body, sample-40 extended arms, or exact 48-instance B3 maximum long-wave field. No unsupported body/wave synchronization is baked.")
            self._action(advanced_actions, "THE SUN manifest", self._the_sun_manifest, 17, 2, help_text="Write the selected THE SUN evidence-backed assembly manifest with exact pose or B3 group/segment metadata.")
            self._action(advanced_actions, "Assemble THE SUN", self._assemble_the_sun, 17, 3, help_text="Export the selected THE SUN inspection form. The long-wave form uses exact retail fixed-point-derived positions, not screenshot measurements.")
            self._action(advanced_actions, "Assemble GMXs…", self._assemble_gmx_manifest, 18, 0, 4, help_text="Use a custom multi-GMX assembly manifest to combine several native GMX files into one editable glTF scene.")
            ttk.Label(tab, text="Template-backed import remains the conservative path for editing an existing asset. Simple mode deliberately hides controls that are only needed when changing native topology, hierarchy, bindings, schemas or animations. Assembly exports preserve SIIG native scale/units; in Blender use Frame All (Home) or Frame Selected (Numpad .) if a boss is outside the current view.", wraplength=900).grid(row=9, column=0, columnspan=3, sticky="w", pady=8)

        def _tab_util(self, tab) -> None:
            self.tabs.add(tab, text="Utilities")
            self.util_input = tk.StringVar()
            self.viewer_input = tk.StringVar()
            self.viewer_output = tk.StringVar(value=str(Path.cwd() / "siig_asset_viewer"))
            ttk.Label(tab, text="Validation and browser utilities", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
            self._entry_row(tab, 1, "Doctor input (optional)", self.util_input, help_text="Optional file/folder input for the Doctor diagnostic command. Leave blank for general toolkit diagnostics.")
            self._entry_row(tab, 2, "Asset directory", self.viewer_input, kind="dir", help_text="Choose a directory of extracted/converted assets you want to browse with the local web asset viewer.")
            self._entry_row(tab, 3, "Viewer output", self.viewer_output, kind="dir", help_text="Choose where the generated browser asset viewer should be written.")
            actions = ttk.Frame(tab); actions.grid(row=4, column=0, columnspan=3, sticky="ew", pady=8)
            for c in range(4): actions.columnconfigure(c, weight=1)
            self._action(actions, "Doctor", self._doctor, 0, 0, help_text="Run non-destructive toolkit/input diagnostics and print findings in the task log.")
            self._action(actions, "Run selftests", lambda: self._run(["selftest"]), 0, 1, help_text="Run the toolkit's dependency-free regression suite. This is useful after moving/updating the toolkit or before reporting a bug.")
            self._action(actions, "Asset capabilities", lambda: self._run(["asset-capabilities"]), 0, 2, help_text="Show which SIIG asset families can currently be viewed, edited, round-tripped or synthesized.")
            self._action(actions, "Build viewer", self._util_viewer, 0, 3, help_text="Generate the local browser asset viewer for the selected asset directory and open it.")
            self._action(actions, "Boss matrix", lambda: self._run(["boss-matrix"]), 1, 0, 2, help_text="Show all 18 console boss families, their canonical catalog, and whether each has a deep runtime reconstruction or a native-model-only inspection preset.")
            docs = ttk.Button(tab, text="Open toolkit documentation folder", command=lambda: _open_path(ROOT / "docs"))
            docs.grid(row=5, column=0, sticky="w", padx=4, pady=4)
            self._register_help(docs, "Open the bundled documentation and research notes in your file manager.")

        def _copy_log(self) -> None:
            self.clipboard_clear(); self.clipboard_append(self.log.get("1.0", "end-1c"))

        def _append(self, text: str) -> None:
            self.log.insert("end", text)
            self.log.see("end")

        def _set_busy(self, busy: bool) -> None:
            self._busy = busy
            for button in self._buttons:
                try: button.configure(state="disabled" if busy else "normal")
                except Exception: pass
            self._status.set("Working…" if busy else "Ready")

        def _run(self, args: list[str], on_done: Optional[Callable[[int], None]] = None) -> None:
            args = [str(x) for x in args if str(x) != ""]
            if self._busy:
                messagebox.showinfo("SIIG Toolkit", "Another toolkit task is already running.")
                return
            if not TOOLKIT.is_file():
                messagebox.showerror("SIIG Toolkit", f"Missing {TOOLKIT}")
                return
            self._set_busy(True)
            cmd = [sys.executable, str(TOOLKIT), *args]
            self._append("\n$ " + " ".join(shlex.quote(x) for x in cmd) + "\n")
            def worker() -> None:
                code = 1
                try:
                    proc = subprocess.Popen(cmd, cwd=str(ROOT), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
                    assert proc.stdout is not None
                    for line in proc.stdout:
                        self._queue.put(("line", line))
                    code = proc.wait()
                except Exception as exc:
                    self._queue.put(("line", f"GUI launcher error: {exc}\n"))
                self._queue.put(("done", code, on_done))
            threading.Thread(target=worker, daemon=True).start()

        def _poll_queue(self) -> None:
            try:
                while True:
                    item = self._queue.get_nowait()
                    if item[0] == "line": self._append(item[1])
                    elif item[0] == "done":
                        code, callback = item[1], item[2]
                        self._append(f"[exit {code}]\n")
                        self._set_busy(False)
                        if callback: callback(code)
            except queue.Empty:
                pass
            self.after(80, self._poll_queue)

        def _rip_game(self) -> None:
            if not self.game_input.get(): return messagebox.showerror("Game rip", "Choose an input first.")
            args = ["rip-game", self.game_input.get(), "-o", self.game_output.get()]
            if self.game_resume.get(): args.append("--resume")
            self._run(args)

        def _build_viewer(self) -> None:
            root = Path(self.game_output.get())
            out = root / "asset_viewer"
            self._run(["asset-viewer", str(root), "-o", str(out)], lambda code: _open_path(out / "index.html") if code == 0 else None)

        def _pack_mod(self) -> None:
            out = filedialog.asksaveasfilename(defaultextension=".siigmod", filetypes=[("SIIG mod package", "*.siigmod")])
            if out: self._run(["mod-pack", self.mod_ws.get(), "-o", out])

        def _inspect_mod(self) -> None:
            path = filedialog.askopenfilename(filetypes=[("SIIG mod package", "*.siigmod"), ("All files", "*.*")])
            if path: self._run(["mod-package-info", path])

        def _apply_mod(self) -> None:
            path = filedialog.askopenfilename(filetypes=[("SIIG mod package", "*.siigmod"), ("All files", "*.*")])
            if path:
                if not self.mod_rip.get():
                    return messagebox.showerror("Apply mod", "Choose the verified source rip first.")
                self._run(["mod-apply", path, self.mod_rip.get(), self.mod_ws.get(), "--build"])

        def _mod_import_gltf(self) -> None:
            if not self.mod_archive.get() or not self.mod_resource.get() or not self.mod_gltf.get():
                return messagebox.showerror("Import glTF + TEX", "Enter the GMX archive key/resource and choose the edited glTF first.")
            args = ["mod-import-gltf", self.mod_ws.get(), self.mod_archive.get(), self.mod_resource.get(), self.mod_gltf.get()]
            self._run(args)

        def _inspect_gmx(self) -> None:
            if self.gmx_template.get(): self._run(["scan", self.gmx_template.get()])

        def _export_gltf(self) -> None:
            template = Path(self.gmx_template.get())
            if not template.is_file(): return messagebox.showerror("GMX", "Choose a native GMX first.")
            out = filedialog.askdirectory(title="Choose glTF output directory")
            if not out: return
            args = ["gmx2gltf", str(template), "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            def done(code: int) -> None:
                if code == 0:
                    gltf = Path(out) / (template.stem + ".gltf")
                    if gltf.exists(): self.gmx_gltf.set(str(gltf))
            self._run(args, done)

        def _import_gltf(self) -> None:
            template = Path(self.gmx_template.get()); gltf = Path(self.gmx_gltf.get())
            if not template.is_file() or not gltf.is_file(): return messagebox.showerror("GMX", "Choose both the native GMX template and edited glTF.")
            out = self.gmx_output.get() or str(template.with_name(template.stem + ".edited.gmx")); self.gmx_output.set(out)
            args = ["gltf2gmx-template", str(gltf), "--template", str(template), "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            if self.gmx_sync_graph.get(): args.append("--sync-mesh-graph")
            if self.gmx_sync_scene.get(): args.append("--sync-scene-graph")
            if self.gmx_sync_texture.get(): args.append("--sync-texture-graph")
            if self.gmx_synthesize_schemas.get(): args.append("--synthesize-native-schemas")
            if self.gmx_sync_animation.get(): args.append("--sync-animation-graph")
            if self.gmx_sync_rigid_skins.get(): args.append("--sync-rigid-skins")
            self._run(args)

        def _create_gmx_new(self) -> None:
            gltf = Path(self.gmx_gltf.get())
            if not gltf.is_file():
                return messagebox.showerror("GMX", "Choose an edited glTF first.")
            out = self.gmx_output.get() or str(gltf.with_suffix(".gmx"))
            self.gmx_output.set(out)
            args = ["gltf2gmx-new", str(gltf), "-o", out]
            if self.gmx_flip.get():
                args.append("--flip-v")
            self._run(args)

        @staticmethod
        def _ultimate_ufo_state_values() -> tuple[str, ...]:
            return (
                "COMPLETE — 126 allocated hierarchy",
                "2 — UMB activity", "3 — TOW activity", "6 — FAN + RING activity",
                "7 — FAN + RING activity (second fan)", "8 — RING activity",
                "9 — CORE HOLD activity", "11 — AIRLOCK activity", "12 — AIRLOCK LATE activity",
            )

        @staticmethod
        def _progressive_ufo_formation_values() -> tuple[str, ...]:
            return (
                "Original — first runtime formation",
                "Classic — recurring states 5/8",
            )

        def _progressive_ufo_catalog_key(self) -> str:
            value = self.progressive_ufo_formation.get().strip().lower()
            if value.startswith("original"):
                return "progressive_ufo"
            if value.startswith("classic"):
                return "progressive_ufo_classic"
            raise ValueError(f"Unknown PROGRESSIVE UFO formation selection: {self.progressive_ufo_formation.get()!r}")

        def _ultimate_ufo_catalog_key(self) -> str:
            raw = self.ultimate_ufo_state.get().strip()
            if raw.upper().startswith("COMPLETE"):
                return "ultimate_ufo_complete"
            try:
                state = int(raw.split()[0])
            except (ValueError, IndexError):
                raise ValueError("Choose one of the listed ULTIMATE UFO states.")
            if state not in (2, 3, 6, 7, 8, 9, 11, 12):
                raise ValueError("Choose one of the listed ULTIMATE UFO states.")
            return f"ultimate_ufo_state_{state:02d}"

        def _ultimate_ufo_manifest(self) -> None:
            try:
                key = self._ultimate_ufo_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("ULTIMATE UFO", str(exc))
            out = filedialog.asksaveasfilename(title="Save ULTIMATE UFO state assembly manifest", defaultextension=".json", filetypes=[("JSON", "*.json")])
            if out:
                self._run(["gmx-assembly-template", key, "-o", out])

        def _assemble_ultimate_ufo(self) -> None:
            try:
                key = self._ultimate_ufo_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("ULTIMATE UFO", str(exc))
            root = filedialog.askdirectory(title="Choose directory containing extracted bos_015*.gmx files")
            if not root: return
            out = filedialog.asksaveasfilename(title="Save assembled ULTIMATE UFO glTF", defaultextension=".gltf", filetypes=[("glTF 2.0", "*.gltf")])
            if not out: return
            args = ["gmx-assemble-catalog", key, "--root", root, "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        @staticmethod
        def _butterfly_phase_values() -> tuple[str, ...]:
            return (
                "1 — phase 1 / body only",
                "2 — phase 2 / first wings",
                "3 — phase 3 / extended wings",
                "4 — phase 4 / final wings",
            )

        def _butterfly_catalog_key(self) -> str:
            raw = self.butterfly_phase.get().strip()
            try:
                phase = int(raw.split()[0])
            except (ValueError, IndexError):
                raise ValueError("Choose one of the four BUTTERFLY phases.")
            if phase not in (1, 2, 3, 4):
                raise ValueError("Choose one of the four BUTTERFLY phases.")
            return f"butterfly_phase_{phase}"

        def _butterfly_manifest(self) -> None:
            try:
                key = self._butterfly_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("BUTTERFLY", str(exc))
            out = filedialog.asksaveasfilename(
                title="Save BUTTERFLY phase assembly manifest",
                defaultextension=".json",
                filetypes=[("JSON", "*.json")],
            )
            if out:
                self._run(["gmx-assembly-template", key, "-o", out])

        def _assemble_butterfly(self) -> None:
            try:
                key = self._butterfly_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("BUTTERFLY", str(exc))
            root = filedialog.askdirectory(title="Choose directory containing retail bos_011*.gmx files")
            if not root:
                return
            out = filedialog.asksaveasfilename(
                title="Save assembled BUTTERFLY phase glTF",
                defaultextension=".gltf",
                filetypes=[("glTF 2.0", "*.gltf")],
            )
            if not out:
                return
            args = ["gmx-assemble-catalog", key, "--root", root, "-o", out]
            if self.gmx_flip.get():
                args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        @staticmethod
        def _unknown_form_values() -> tuple[str, ...]:
            return tuple(
                f"{i:02d} — uk{i:02d}" + (" (same visual as uk01)" if i == 8 else "")
                for i in range(1, 15)
            )

        def _unknown_catalog_key(self) -> str:
            raw = self.unknown_form.get().strip()
            try:
                form = int(raw.split()[0])
            except (ValueError, IndexError):
                raise ValueError("Choose one of UNKNOWN's 14 named native forms (13 unique visuals; uk08 duplicates uk01).")
            if form not in range(1, 15):
                raise ValueError("Choose one of UNKNOWN's 14 named native forms (13 unique visuals; uk08 duplicates uk01).")
            return f"unknown_form_{form:02d}"

        def _unknown_manifest(self) -> None:
            try:
                key = self._unknown_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("UNKNOWN", str(exc))
            out = filedialog.asksaveasfilename(
                title="Save UNKNOWN form manifest",
                defaultextension=".json",
                filetypes=[("JSON", "*.json")],
            )
            if out:
                self._run(["gmx-assembly-template", key, "-o", out])

        def _assemble_unknown(self) -> None:
            try:
                key = self._unknown_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("UNKNOWN", str(exc))
            source = filedialog.askopenfilename(
                title="Choose retail bos_006.gmx",
                filetypes=[("SIIG GMX", "*.gmx"), ("All files", "*.*")],
            )
            if not source:
                return
            source_path = Path(source)
            if source_path.name.lower() != "bos_006.gmx":
                if not messagebox.askyesno("UNKNOWN", "The selected file is not named bos_006.gmx. Continue anyway?"):
                    return
            out = filedialog.asksaveasfilename(
                title="Save UNKNOWN form glTF",
                defaultextension=".gltf",
                filetypes=[("glTF 2.0", "*.gltf")],
            )
            if not out:
                return
            args = ["gmx-assemble-catalog", key, "--root", str(source_path.parent), "-o", out]
            if self.gmx_flip.get():
                args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        @staticmethod
        def _vertebrate_phase_values() -> tuple[str, ...]:
            return (
                "1 — phase 1 / immense tower",
                "2 — phase 2 / endcaps only",
            )

        def _vertebrate_catalog_key(self) -> str:
            raw = self.vertebrate_phase.get().strip()
            try:
                phase = int(raw.split()[0])
            except (ValueError, IndexError):
                raise ValueError("Choose one of the two VERTEBRATE structural phases.")
            if phase == 1:
                return "vertebrate_phase1_tower"
            if phase == 2:
                return "vertebrate_phase2_endcaps"
            raise ValueError("Choose one of the two VERTEBRATE structural phases.")

        def _vertebrate_manifest(self) -> None:
            try:
                key = self._vertebrate_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("VERTEBRATE", str(exc))
            out = filedialog.asksaveasfilename(
                title="Save VERTEBRATE phase assembly manifest",
                defaultextension=".json",
                filetypes=[("JSON", "*.json")],
            )
            if out:
                self._run(["gmx-assembly-template", key, "-o", out])

        def _assemble_vertebrate(self) -> None:
            try:
                key = self._vertebrate_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("VERTEBRATE", str(exc))
            root = filedialog.askdirectory(title="Choose directory containing retail bos_017.gmx / bos_017a.gmx")
            if not root:
                return
            out = filedialog.asksaveasfilename(
                title="Save assembled VERTEBRATE phase glTF",
                defaultextension=".gltf",
                filetypes=[("glTF 2.0", "*.gltf")],
            )
            if not out:
                return
            args = ["gmx-assemble-catalog", key, "--root", root, "-o", out]
            if self.gmx_flip.get():
                args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _centipede_manifest(self) -> None:
            out = filedialog.asksaveasfilename(
                title="Save CENTIPEDE initial-ring assembly manifest",
                defaultextension=".json",
                filetypes=[("JSON", "*.json")],
            )
            if out:
                self._run(["gmx-assembly-template", "centipede_initial_combat_ring", "-o", out])

        def _assemble_centipede(self) -> None:
            root = filedialog.askdirectory(title="Choose directory containing retail bos_007.gmx / bos_007a.gmx")
            if not root:
                return
            out = filedialog.asksaveasfilename(
                title="Save assembled CENTIPEDE initial ring glTF",
                defaultextension=".gltf",
                filetypes=[("glTF 2.0", "*.gltf")],
            )
            if not out:
                return
            args = ["gmx-assemble-catalog", "centipede_initial_combat_ring", "--root", root, "-o", out]
            if self.gmx_flip.get():
                args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        @staticmethod
        def _squid_phase_values() -> tuple[str, ...]:
            return (
                "1 — phase 1 / eight legs",
                "2 — phase 2 / body only",
            )

        def _squid_catalog_key(self) -> str:
            raw = self.squid_phase.get().strip()
            try:
                phase = int(raw.split()[0])
            except (ValueError, IndexError):
                raise ValueError("Choose one of the two SQUID modeled phases.")
            if phase == 1:
                return "squid_phase1_legs"
            if phase == 2:
                return "squid_phase2_body"
            raise ValueError("Choose one of the two SQUID modeled phases.")

        def _squid_manifest(self) -> None:
            try:
                key = self._squid_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("SQUID", str(exc))
            out = filedialog.asksaveasfilename(
                title="Save SQUID phase assembly manifest",
                defaultextension=".json",
                filetypes=[("JSON", "*.json")],
            )
            if out:
                self._run(["gmx-assembly-template", key, "-o", out])

        def _assemble_squid(self) -> None:
            try:
                key = self._squid_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("SQUID", str(exc))
            root = filedialog.askdirectory(title="Choose directory containing retail bos_016.gmx / bos_016a.gmx")
            if not root:
                return
            out = filedialog.asksaveasfilename(
                title="Save assembled SQUID phase glTF",
                defaultextension=".gltf",
                filetypes=[("glTF 2.0", "*.gltf")],
            )
            if not out:
                return
            args = ["gmx-assemble-catalog", key, "--root", root, "-o", out]
            if self.gmx_flip.get():
                args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        @staticmethod
        def _the_sun_form_values() -> tuple[str, ...]:
            return (
                "Native — animated body",
                "Extended arms — native sample 40",
                "Long wave — 48 B3 segments",
            )

        def _the_sun_catalog_key(self) -> str:
            value = self.the_sun_form.get().strip().lower()
            if value.startswith("native"):
                return "the_sun_native_body"
            if value.startswith("extended"):
                return "the_sun_extended_arms"
            if value.startswith("long"):
                return "the_sun_long_wave"
            raise ValueError("Choose one of the three THE SUN inspection forms.")

        def _the_sun_manifest(self) -> None:
            try:
                key = self._the_sun_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("THE SUN", str(exc))
            out = filedialog.asksaveasfilename(
                title="Save THE SUN assembly manifest",
                defaultextension=".json",
                filetypes=[("JSON", "*.json")],
            )
            if out:
                self._run(["gmx-assembly-template", key, "-o", out])

        def _assemble_the_sun(self) -> None:
            try:
                key = self._the_sun_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("THE SUN", str(exc))
            root = filedialog.askdirectory(title="Choose directory containing retail bos_002.gmx / bos_002b.gmx")
            if not root:
                return
            out = filedialog.asksaveasfilename(
                title="Save assembled THE SUN form glTF",
                defaultextension=".gltf",
                filetypes=[("glTF 2.0", "*.gltf")],
            )
            if not out:
                return
            args = ["gmx-assemble-catalog", key, "--root", root, "-o", out]
            if self.gmx_flip.get():
                args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        @staticmethod
        def _axon_form_values() -> tuple[str, ...]:
            return (
                "Native — animated whole body",
                "Expanded — core + 16 petals",
                "Exposed — core only",
            )

        def _axon_catalog_key(self) -> str:
            value = self.axon_form.get().strip().lower()
            if value.startswith("native"):
                return "axon_native_body"
            if value.startswith("expanded"):
                return "axon_expanded_petals"
            if value.startswith("exposed"):
                return "axon_exposed_core"
            raise ValueError("Choose one of the three AXON runtime forms.")

        def _axon_manifest(self) -> None:
            try:
                key = self._axon_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("AXON", str(exc))
            out = filedialog.asksaveasfilename(
                title="Save AXON form assembly manifest",
                defaultextension=".json",
                filetypes=[("JSON", "*.json")],
            )
            if out:
                self._run(["gmx-assembly-template", key, "-o", out])

        def _assemble_axon(self) -> None:
            try:
                key = self._axon_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("AXON", str(exc))
            root = filedialog.askdirectory(title="Choose directory containing retail bos_012.gmx / bos_012a.gmx / bos_012b.gmx")
            if not root:
                return
            out = filedialog.asksaveasfilename(
                title="Save assembled AXON form glTF",
                defaultextension=".gltf",
                filetypes=[("glTF 2.0", "*.gltf")],
            )
            if not out:
                return
            args = ["gmx-assemble-catalog", key, "--root", root, "-o", out]
            if self.gmx_flip.get():
                args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _gigantic_ufo_manifest(self) -> None:
            out = filedialog.asksaveasfilename(
                title="Save GIGANTIC UFO assembly manifest",
                defaultextension=".json",
                filetypes=[("JSON", "*.json")],
            )
            if out:
                self._run(["gmx-assembly-template", "gigantic_ufo_complete", "-o", out])

        def _assemble_gigantic_ufo(self) -> None:
            root = filedialog.askdirectory(title="Choose directory containing retail bos_003.gmx / bos_003a.gmx")
            if not root:
                return
            out = filedialog.asksaveasfilename(
                title="Save assembled GIGANTIC UFO glTF",
                defaultextension=".gltf",
                filetypes=[("glTF 2.0", "*.gltf")],
            )
            if not out:
                return
            args = ["gmx-assemble-catalog", "gigantic_ufo_complete", "--root", root, "-o", out]
            if self.gmx_flip.get():
                args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _mandala_manifest(self) -> None:
            out = filedialog.asksaveasfilename(title="Save MANDALA initial-combat assembly manifest", defaultextension=".json", filetypes=[("JSON", "*.json")])
            if out:
                self._run(["gmx-assembly-template", "mandala_initial_combat", "-o", out])

        def _assemble_mandala(self) -> None:
            root = filedialog.askdirectory(title="Choose directory containing bos_005.gmx / bos_005a.gmx / bos_005b.gmx / bos_005c.gmx / bos_005d.gmx / bos_005e.gmx")
            if not root: return
            out = filedialog.asksaveasfilename(title="Save assembled MANDALA glTF", defaultextension=".gltf", filetypes=[("glTF 2.0", "*.gltf")])
            if not out: return
            args = ["gmx-assemble-catalog", "mandala_initial_combat", "--root", root, "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _progressive_ufo_manifest(self) -> None:
            try:
                key = self._progressive_ufo_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("PROGRESSIVE UFO", str(exc))
            out = filedialog.asksaveasfilename(title="Save PROGRESSIVE UFO assembly manifest", defaultextension=".json", filetypes=[("JSON", "*.json")])
            if out:
                self._run(["gmx-assembly-template", key, "-o", out])

        def _assemble_progressive_ufo(self) -> None:
            try:
                key = self._progressive_ufo_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("PROGRESSIVE UFO", str(exc))
            root = filedialog.askdirectory(title="Choose directory containing bos_009.gmx / bos_009a.gmx / bos_009b.gmx")
            if not root: return
            out = filedialog.asksaveasfilename(title="Save assembled PROGRESSIVE UFO glTF", defaultextension=".gltf", filetypes=[("glTF 2.0", "*.gltf")])
            if not out: return
            args = ["gmx-assemble-catalog", key, "--root", root, "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _crab_manifest(self) -> None:
            out = filedialog.asksaveasfilename(title="Save CRAB assembly manifest", defaultextension=".json", filetypes=[("JSON", "*.json")])
            if out:
                self._run(["gmx-assembly-template", "crab", "-o", out])

        def _assemble_crab(self) -> None:
            root = filedialog.askdirectory(title="Choose directory containing bos_013.gmx / bos_013a.gmx / bos_013b.gmx / bos_013c.gmx / bos_013d.gmx")
            if not root: return
            out = filedialog.asksaveasfilename(title="Save assembled CRAB glTF", defaultextension=".gltf", filetypes=[("glTF 2.0", "*.gltf")])
            if not out: return
            args = ["gmx-assemble-catalog", "crab", "--root", root, "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _hornet_manifest(self) -> None:
            out = filedialog.asksaveasfilename(title="Save HORNET full-armor assembly manifest", defaultextension=".json", filetypes=[("JSON", "*.json")])
            if out:
                self._run(["gmx-assembly-template", "hornet_full_armor", "-o", out])

        def _assemble_hornet(self) -> None:
            root = filedialog.askdirectory(title="Choose directory containing bos_008.gmx / bos_008a.gmx")
            if not root: return
            out = filedialog.asksaveasfilename(title="Save assembled HORNET full-armor glTF", defaultextension=".gltf", filetypes=[("glTF 2.0", "*.gltf")])
            if not out: return
            args = ["gmx-assemble-catalog", "hornet_full_armor", "--root", root, "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _hornet_exposed_manifest(self) -> None:
            out = filedialog.asksaveasfilename(title="Save HORNET exposed-core assembly manifest", defaultextension=".json", filetypes=[("JSON", "*.json")])
            if out:
                self._run(["gmx-assembly-template", "hornet_exposed_core", "-o", out])

        def _assemble_hornet_exposed(self) -> None:
            root = filedialog.askdirectory(title="Choose directory containing bos_008.gmx")
            if not root: return
            out = filedialog.asksaveasfilename(title="Save assembled HORNET exposed-core glTF", defaultextension=".gltf", filetypes=[("glTF 2.0", "*.gltf")])
            if not out: return
            args = ["gmx-assemble-catalog", "hornet_exposed_core", "--root", root, "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _hornet_prism_catalog_key(self) -> str:
            try:
                slot = int(self.hornet_prism_slot.get())
            except ValueError:
                raise ValueError("Choose one of the listed HORNET prism-wall root slots.")
            allowed = (0, 2, 6, 8, 18, 20, 22, 24, 26, 36, 38, 42, 44)
            if slot not in allowed:
                raise ValueError("Choose one of the listed HORNET prism-wall root slots.")
            return f"hornet_prism_wall_{slot:02d}"

        def _hornet_prism_manifest(self) -> None:
            try:
                key = self._hornet_prism_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("HORNET prism wall", str(exc))
            out = filedialog.asksaveasfilename(title="Save HORNET prism-wall assembly manifest", defaultextension=".json", filetypes=[("JSON", "*.json")])
            if out:
                self._run(["gmx-assembly-template", key, "-o", out])

        def _assemble_hornet_prism(self) -> None:
            try:
                key = self._hornet_prism_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("HORNET prism wall", str(exc))
            root = filedialog.askdirectory(title="Choose directory containing bos_008.gmx / bos_008b.gmx")
            if not root: return
            out = filedialog.asksaveasfilename(title="Save assembled HORNET prism-wall glTF", defaultextension=".gltf", filetypes=[("glTF 2.0", "*.gltf")])
            if not out: return
            args = ["gmx-assemble-catalog", key, "--root", root, "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _hornet_propagation_catalog_key(self) -> str:
            try:
                seed = int(self.hornet_propagation_seed.get())
                wave = int(self.hornet_propagation_wave.get())
            except ValueError:
                raise ValueError("Choose a listed HORNET propagation seed and wave.")
            allowed = (0, 2, 6, 8, 18, 20, 22, 24, 26, 36, 38, 42, 44)
            if seed not in allowed or not 0 <= wave <= 9:
                raise ValueError("Choose a listed HORNET propagation seed and wave.")
            return f"hornet_propagation_{seed:02d}_wave_{wave:02d}"

        def _hornet_propagation_manifest(self) -> None:
            try:
                key = self._hornet_propagation_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("HORNET propagation", str(exc))
            out = filedialog.asksaveasfilename(title="Save HORNET propagation snapshot manifest", defaultextension=".json", filetypes=[("JSON", "*.json")])
            if out:
                self._run(["gmx-assembly-template", key, "-o", out])

        def _assemble_hornet_propagation(self) -> None:
            try:
                key = self._hornet_propagation_catalog_key()
            except ValueError as exc:
                return messagebox.showerror("HORNET propagation", str(exc))
            root = filedialog.askdirectory(title="Choose directory containing bos_008b.gmx")
            if not root: return
            out = filedialog.asksaveasfilename(title="Save assembled HORNET propagation glTF", defaultextension=".gltf", filetypes=[("glTF 2.0", "*.gltf")])
            if not out: return
            args = ["gmx-assemble-catalog", key, "--root", root, "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _assemble_gmx_manifest(self) -> None:
            manifest = filedialog.askopenfilename(title="Choose GMX assembly manifest", filetypes=[("JSON", "*.json"), ("All files", "*.*")])
            if not manifest: return
            root = filedialog.askdirectory(title="Choose directory containing referenced GMX files")
            if not root: return
            out = filedialog.asksaveasfilename(title="Save assembled glTF", defaultextension=".gltf", filetypes=[("glTF 2.0", "*.gltf")])
            if not out: return
            args = ["gmx-assemble", manifest, "--root", root, "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args, lambda code: _open_path(Path(out).parent) if code == 0 else None)

        def _gmx_scene_report(self) -> None:
            template = Path(self.gmx_template.get())
            if not template.is_file(): return messagebox.showerror("GMX", "Choose a native GMX first.")
            out = template.with_name(template.stem + ".scene.html")
            self._run(["gmx-scene-report", str(template), "-o", str(out)], lambda code: _open_path(out) if code == 0 else None)

        def _export_gmx_json(self) -> None:
            template = Path(self.gmx_template.get())
            if not template.is_file(): return messagebox.showerror("GMX", "Choose a native GMX first.")
            out = self.gmx_json.get() or str(template.with_suffix(".gmx.edit.json")); self.gmx_json.set(out)
            self._run(["gmx-edit-export", str(template), "-o", out])

        def _build_gmx_json(self) -> None:
            template = Path(self.gmx_template.get()); doc = Path(self.gmx_json.get())
            if not template.is_file() or not doc.is_file(): return messagebox.showerror("GMX", "Choose a GMX template and editable JSON.")
            out = self.gmx_output.get() or str(template.with_name(template.stem + ".edited.gmx")); self.gmx_output.set(out)
            self._run(["gmx-build", str(doc), "--template", str(template), "-o", out])

        def _doctor(self) -> None:
            args = ["doctor"]
            if self.util_input.get(): args.append(self.util_input.get())
            self._run(args)

        def _util_viewer(self) -> None:
            if not self.viewer_input.get(): return messagebox.showerror("Asset viewer", "Choose an asset directory first.")
            out = Path(self.viewer_output.get())
            self._run(["asset-viewer", self.viewer_input.get(), "-o", str(out)], lambda code: _open_path(out / "index.html") if code == 0 else None)

    app = App()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
