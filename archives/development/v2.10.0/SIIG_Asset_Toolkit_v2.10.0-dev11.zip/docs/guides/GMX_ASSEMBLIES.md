# Multi-GMX assemblies (2.10.0-dev10)

Some SIIG runtime objects are assembled from several separate GMX resources. `gmx-assemble` combines explicit GMX instances into one glTF scene without claiming that the game stores those instances as one native GMX.

## Built-in evidence-backed catalogs

### MANDALA initial combat — `mandala_initial_combat`

Dev8 reconstructs MANDALA at the exact state-7 activation instant before the first rotational update. The visible composition is **20×B7 + 2×B8 + 2×B9 + 2×BA + 2×BB + 12×4A = 40 instances**. The later 32×BC inner phase is intentionally excluded.

The transform math is cross-checked across May 9 Xbox, May 11 Xbox, June 10 Xbox, retail Xbox and retail PS3. Native GMX animations are preserved and no speculative radial-facing rotation is added. See `docs/research/MANDALA_RUNTIME_ASSEMBLY_2.10.0-dev8.md`.

### PROGRESSIVE UFO — `progressive_ufo`

The executable-backed five-object formation remains:

| model | runtime | local translation | outer local rotation |
|---|---|---|---|
| `bos_009.gmx` | `0xA2` | `(0,0,0)` | `(0,0,0)` |
| `bos_009a.gmx` | `0xC2` | `(-90,0,-10)` | `(0,0,0)` |
| `bos_009a.gmx` | `0xC2` | `(90,0,-10)` | `(0,0,0)` |
| `bos_009b.gmx` | `0xC3` | `(-160,0,-50)` | `(0,0,0)` |
| `bos_009b.gmx` | `0xC3` | `(160,0,-50)` | `(0,0,0)` |

The slight visible tilt of both barrier machines is authored **inside `bos_009b.gmx`** (about 190.794° Z on both barrier mesh bones), not an assembly-matrix error. See `docs/research/PROGRESSIVE_UFO_BARRIER_ORIENTATION_2.10.0-dev5.md`.

```bat
python siig_toolkit.py gmx-assemble-catalog progressive_ufo --root extracted_gmx -o progressive_ufo.gltf
```

### CRAB — `crab`

The default CRAB catalog now represents the deterministic **landed/combat-ready** state. It contains `A7 + CD + CC + 2×CE + 4×CF`.

A7 is baked at native sample **1**, the first sample of its looping landed combat segment. CD is baked at sample 0. Child placement comes from the runtime named-locator path. This avoids the hundreds-of-units-high first-visible intro snapshot while preserving native coordinates; nothing is manually recentered.

The old dev4 state remains available as `crab_first_visible`: A7 sample 167 while the boss is still airborne during its entrance.

```bat
python siig_toolkit.py gmx-assemble-catalog crab --root extracted_gmx -o crab.gltf
python siig_toolkit.py gmx-assemble-catalog crab_first_visible --root extracted_gmx -o crab_first_visible.gltf
```

See `docs/research/CRAB_RUNTIME_ASSEMBLY_2.10.0-dev5.md` and the preserved dev4 report.

### HORNET full armor — `hornet_full_armor`

HORNET uses one A1 core plus a runtime pool of **125 BF armor cubes**, **125 C0 prism objects**, and one meshless **C1 formation rig**. C1 sample 0 provides an exact 5×5×5 locator lattice at axis levels ±31.68, ±15.84 and 0.

The beginner preset exports the deterministic fully revealed armor state as **126 visible instances: A1 + 125 BF**. C1 has no mesh and therefore is not added as a useless visible root. The C0 pool is real but dormant in this state. Dev6 separately reconstructs its 45-cell prism-wall attack as a 13-variant runtime family.

```bat
python siig_toolkit.py gmx-assemble-catalog hornet_full_armor --root extracted_gmx -o hornet_full_armor.gltf
```

See `docs/research/HORNET_RUNTIME_ASSEMBLY_2.10.0-dev5.md`.

### HORNET exposed core — `hornet_exposed_core`

Dev10 proves a real A1-only **high-level state-3 entry**. On transition, the common reset restores `bos_008.gmx` at native motion 0/sample 0 and writes all 125 subordinate placement records to state `-1`; the normal selection logic therefore chooses neither BF armor nor C0 prisms at this exact boundary. C1 is a meshless control rig and is not emitted as visible geometry.

```bat
python siig_toolkit.py gmx-assemble-catalog hornet_exposed_core --root extracted_gmx -o hornet_exposed_core.gltf
```

The state/reset structure is independently present in retail Xbox, June 10 Xbox and retail PS3. Fresh real-retail validation from the re-uploaded Xbox package produced 1 instance, 2 meshes, 4 glTF nodes and native bounds about ±13.8054. The preset is intentionally the deterministic state-entry snapshot; it does not claim A1 remains frozen at sample 0 during the whole attack. See `docs/research/HORNET_EXPOSED_CORE_2.10.0-dev10.md`.

### HORNET prism wall — `hornet_prism_wall_XX`

The C0 prism-wall state uses an exact 5×9 grid with 46-unit spacing. The game randomly places A1 into one of exactly 13 valid cells and suppresses that cell's C0 child. Therefore each settled visible variant is **A1 + 44×C0**, not A1 + 45×C0.

Valid suffixes are: `00`, `02`, `06`, `08`, `18`, `20`, `22`, `24`, `26`, `36`, `38`, `42`, `44`. There is deliberately no unqualified `hornet_prism_wall` preset because choosing one random retail result as canonical would be arbitrary.

```bat
python siig_toolkit.py gmx-assemble-catalog hornet_prism_wall_22 --root extracted_gmx -o hornet_prism_wall_22.gltf
```

A1's native animation remains live in this assembly because the runtime still loops its own `0→20` clip while occupying the wall cell. The 44 C0 outer transforms are static identity-rotation/unit-scale grid placements. Advanced GUI exposes the same 13-slot selector; Simple mode intentionally keeps the deterministic full-armor preset instead.

See `docs/research/HORNET_PRISM_WALL_2.10.0-dev6.md`. Dev7 resolves the following state-6 propagation separately; it is not folded into the settled wall.

### HORNET propagation — `hornet_propagation_SS_wave_WW`

State 6 inherits one of the same 13 prism-wall seeds, hides A1, and reveals C0 prisms in deterministic waves over the 5×9 grid. Wave 0 is the inherited seed only; wave 1 expands orthogonally; wave 2 diagonally; later waves alternate until all 45 cells are visible.

```bat
python siig_toolkit.py gmx-assemble-catalog hornet_propagation_22_wave_03 --root extracted_gmx -o hornet_propagation_22_wave_03.gltf
```

The snapshot is the wave activation instant: reached C0s only, zero extra Y rotation, no A1 and no laser/effect geometry. Valid wave ranges depend on the seed. There is deliberately no unqualified default. Advanced GUI exposes explicit seed/wave controls. See `docs/research/HORNET_PROPAGATION_2.10.0-dev7.md`.

## ULTIMATE UFO complete hierarchy + activity subsets

ULTIMATE UFO is a locator-driven hierarchy rather than a flat set of hard-coded XYZ offsets. `ultimate_ufo_complete` exports all **126 model instances allocated by the retail constructor** at the constructor baseline. That catalog is deliberately an allocation/hierarchy view, not a claim that every phase-gated member is simultaneously rendered. Eight `ultimate_ufo_state_XX` catalogs (`02`, `03`, `06`, `07`, `08`, `09`, `11`, `12`) are controller-activity subsets derived from the retail col/dis phase table.

The runtime hierarchy is resolved from exact named GMX nodes: D5 under A8 `lt_002..003`, D4 under A8 `lt_004..024`, D6 under the D0/D1 FAN parents at `lt_226..257`, and D7 under the D2/D3 RING parents at `lt_258..321`. The assembly exporter reparents child containers to those source-GMX locator nodes so parent animation remains live. Missing or ambiguous locators are errors.

```bat
python siig_toolkit.py gmx-assemble-catalog ultimate_ufo_complete --root extracted_gmx -o ultimate_ufo_complete.gltf
python siig_toolkit.py gmx-assemble-catalog ultimate_ufo_state_06 --root extracted_gmx -o ultimate_ufo_state_06.gltf
```

State 9 uses D9 / `bos_015l.gmx` for the core/weak-spot assembly. States 11 and 12 use D8 / `bos_015k.gmx` for the late airlock object. The retail/June ID mapping must not be confused with older May prototype IDs. See `docs/research/ULTIMATE_UFO_RUNTIME_ASSEMBLY_2.10.0-dev9.md`.

## Writing or editing manifests

Every catalog can be written as editable JSON first:

```bat
python siig_toolkit.py gmx-assembly-template progressive_ufo -o progressive_ufo.assembly.json
python siig_toolkit.py gmx-assembly-template crab -o crab.assembly.json
python siig_toolkit.py gmx-assembly-template hornet_full_armor -o hornet.assembly.json
python siig_toolkit.py gmx-assembly-template hornet_exposed_core -o hornet_exposed.assembly.json
python siig_toolkit.py gmx-assembly-template hornet_prism_wall_22 -o hornet_prism_wall_22.assembly.json
python siig_toolkit.py gmx-assembly-template ultimate_ufo_state_06 -o ultimate_ufo_state_06.assembly.json
python siig_toolkit.py gmx-assemble hornet.assembly.json --root extracted_gmx -o hornet.gltf
```

Each instance uses a standard 16-value glTF column-major local-to-assembly matrix. Native GMX POSITION XYZ values and units are preserved; the exporter does not silently rescale bosses or reinterpret SIIG units as meters.

### Blender viewing note

SIIG boss models can be very large in their **native game units**. That is intentional. If a model is outside the current Blender view, use **Home / Frame All**, or select the boss root and use **Numpad `.` / Frame Selected**. Do not scale the authoritative assembly just to make navigation convenient unless you intentionally want a display-only copy.

## `pose_sample`

An assembly instance may include optional non-negative `pose_sample`. The exporter bakes that native GMX logical animation sample into the instance node hierarchy and deliberately omits that instance's animation channels from the combined static snapshot. An out-of-range sample is a hard error.

This is used when a multipart state depends on animated attachment nodes, such as CRAB and HORNET's A1 core sample.

## Evidence boundary

Unknown transforms remain hard errors. Built-in catalogs represent specific documented runtime states only; they do not claim that SIIG stores merged boss GMXs, nor that dynamic later phases are equivalent to those snapshots. Native scale is preserved by default. No proprietary validation GMX, executable, Ghidra export, ANM or footage is bundled.
