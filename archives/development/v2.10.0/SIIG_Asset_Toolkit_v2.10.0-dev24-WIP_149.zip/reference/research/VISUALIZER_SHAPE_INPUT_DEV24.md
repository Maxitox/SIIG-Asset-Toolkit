# Visualizer SHAPE input fidelity — dev24

## Result

Retail `visualizer.bin` contains the exact ten resources already recovered by name/order: `WhiteCircle`, `line`, `3line`, `square`, `triangle` and their five `*2` variants. A private retail Xbox full-rip probe converted all ten through the toolkit's existing TEX→PNG path; every result is exactly **128×128**, matching the executable source-image footprint.

The Visualizer Simulator dataset v6 now searches a user-supplied full rip for those exact converted PNG names under the Visualizer extraction tree. If all or some are present, their PNG bytes are embedded only in the **locally generated HTML** as data URIs. No proprietary pixels are added to the source-only toolkit.

Because the exact GPU texture/blend path is still not fully identified, browser rendering converts each supplied sprite to a luminance×alpha mask before applying the recovered runtime color/alpha controls. This preserves the real sprite morphology/intensity while keeping final shader/blend behavior explicitly approximate. If no real PNG is available, the old procedural stand-in remains as a source-only fallback.

## Private validation

`validation/VISUALIZER_SHAPE_INPUT_2.10.0-dev24.json` records dimensions and SHA-256 values only; it contains no sprite bytes. The retail pixels themselves remain outside the source package.
