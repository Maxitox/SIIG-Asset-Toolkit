# Multi-GMX assemblies (2.10.0-dev2)

Some SIIG runtime objects are assembled from several separate GMX resources. `gmx-assemble` combines explicit GMX instances into one glTF scene without claiming that the separate native files form one on-disc GMX.

## Manifest format

Create the built-in PROGRESSIVE UFO research template:

```bat
python siig_toolkit.py gmx-assembly-template progressive_ufo -o progressive_ufo.assembly.json
```

The evidence-backed membership is one `bos_009.gmx`, two `bos_009a.gmx` laser-machine instances, and two `bos_009b.gmx` barrier-machine instances. The main body uses identity as the assembly origin. The four side-component matrices are deliberately `null`: their exact in-game placements have not yet been recovered from an authored/runtime source, so the toolkit does not guess them from screenshots or symmetry.

Each instance uses a standard 16-value glTF column-major local-to-assembly matrix. Once every matrix is known:

```bat
python siig_toolkit.py gmx-assemble progressive_ufo.assembly.json --root extracted_gmx -o progressive_ufo.gltf
```

The exporter keeps each GMX hierarchy under a named instance node, remaps mesh/material/animation/accessor indices, combines the binary buffers, and copies resolved texture images into `_assembly_textures`. A `.assembly.json` report records source hashes and matrices.

## Evidence boundary

The assembly catalog may record membership/count separately from placement. An unresolved transform is a hard error for `gmx-assemble`. This is intentional: component identity and quantity can be proven before exact runtime transforms are known.
