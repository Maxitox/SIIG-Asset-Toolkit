# Multi-GMX assemblies (2.10.0-dev5)

Some SIIG runtime objects are assembled from several separate GMX resources. `gmx-assemble` combines explicit GMX instances into one glTF scene without claiming that the game stores those instances as one native GMX.

## Built-in evidence-backed catalogs

### PROGRESSIVE UFO — `progressive_ufo`

The executable-backed five-object formation remains:

| model | runtime | local translation | outer local rotation |
|---|---|---|---|
| `bos_009.gmx` | `0xA2` | `(0,0,0)` | `(0,0,0)` |
| `bos_009a.gmx` | `0xC2` | `(-90,0,-10)` | `(0,0,0)` |
| `bos_009a.gmx` | `0xC2` | `(90,0,-10)` | `(0,0,0)` |
| `bos_009b.gmx` | `0xC3` | `(-160,0,-50)` | `(0,0,0)` |
| `bos_009b.gmx` | `0xC3` | `(160,0,-50)` | `(0,0,0)` |

The slight visible tilt of both barrier machines is authored **inside `bos_009b.gmx`** (about 190.794° Z on both barrier mesh bones), not an assembly-matrix error. See `docs/research/PROGRESSIVE_UFO_BARRIER_ORIENTATION_2.10.0-dev5.md`.

```bat
python siig_toolkit.py gmx-assemble-catalog progressive_ufo --root extracted_gmx -o progressive_ufo.gltf
```

### CRAB — `crab`

The default CRAB catalog now represents the deterministic **landed/combat-ready** state. It contains `A7 + CD + CC + 2×CE + 4×CF`.

A7 is baked at native sample **1**, the first sample of its looping landed combat segment. CD is baked at sample 0. Child placement comes from the runtime named-locator path. This avoids the hundreds-of-units-high first-visible intro snapshot while preserving native coordinates; nothing is manually recentered.

The old dev4 state remains available as `crab_first_visible`: A7 sample 167 while the boss is still airborne during its entrance.

```bat
python siig_toolkit.py gmx-assemble-catalog crab --root extracted_gmx -o crab.gltf
python siig_toolkit.py gmx-assemble-catalog crab_first_visible --root extracted_gmx -o crab_first_visible.gltf
```

See `docs/research/CRAB_RUNTIME_ASSEMBLY_2.10.0-dev5.md` and the preserved dev4 report.

### HORNET full armor — `hornet_full_armor`

HORNET uses one A1 core plus a runtime pool of **125 BF armor cubes**, **125 C0 prism objects**, and one meshless **C1 formation rig**. C1 sample 0 provides an exact 5×5×5 locator lattice at axis levels ±31.68, ±15.84 and 0.

The beginner preset exports the deterministic fully revealed armor state as **126 visible instances: A1 + 125 BF**. C1 has no mesh and therefore is not added as a useless visible root. The C0 pool is real but dormant in this state and is reserved for a later dynamic prism-phase reconstruction.

```bat
python siig_toolkit.py gmx-assemble-catalog hornet_full_armor --root extracted_gmx -o hornet_full_armor.gltf
```

See `docs/research/HORNET_RUNTIME_ASSEMBLY_2.10.0-dev5.md`.

## Writing or editing manifests

Every catalog can be written as editable JSON first:

```bat
python siig_toolkit.py gmx-assembly-template progressive_ufo -o progressive_ufo.assembly.json
python siig_toolkit.py gmx-assembly-template crab -o crab.assembly.json
python siig_toolkit.py gmx-assembly-template hornet_full_armor -o hornet.assembly.json
python siig_toolkit.py gmx-assemble hornet.assembly.json --root extracted_gmx -o hornet.gltf
```

Each instance uses a standard 16-value glTF column-major local-to-assembly matrix. Native GMX POSITION XYZ values and units are preserved; the exporter does not silently rescale bosses or reinterpret SIIG units as meters.

### Blender viewing note

SIIG boss models can be very large in their **native game units**. That is intentional. If a model is outside the current Blender view, use **Home / Frame All**, or select the boss root and use **Numpad `.` / Frame Selected**. Do not scale the authoritative assembly just to make navigation convenient unless you intentionally want a display-only copy.

## `pose_sample`

An assembly instance may include optional non-negative `pose_sample`. The exporter bakes that native GMX logical animation sample into the instance node hierarchy and deliberately omits that instance's animation channels from the combined static snapshot. An out-of-range sample is a hard error.

This is used when a multipart state depends on animated attachment nodes, such as CRAB and HORNET's A1 core sample.

## Evidence boundary

Unknown transforms remain hard errors. Built-in catalogs represent specific documented runtime states only; they do not claim that SIIG stores merged boss GMXs, nor that dynamic later phases are equivalent to those snapshots. Native scale is preserved by default. No proprietary validation GMX, executable, Ghidra export, ANM or footage is bundled.
