from __future__ import annotations

bl_info = {
    "name": "SIIG Asset Toolkit",
    "author": "SIIG Asset Toolkit project",
    "version": (0, 2, 1),
    "blender": (3, 6, 0),
    "location": "File > Import and 3D View > Sidebar > SIIG",
    "description": "Import SIIG GMX models/assemblies and organize logical parts for reliable visibility control",
    "category": "Import-Export",
}

import importlib.util
import os
import sys
import tempfile
from pathlib import Path
from typing import Iterable

import bpy
from bpy.props import BoolProperty, CollectionProperty, IntProperty, StringProperty
from bpy.types import AddonPreferences, Operator, OperatorFileListElement, Panel
from bpy_extras.io_utils import ImportHelper

_MODULE_NAME = "_siig_toolkit_blender_runtime"


def _preferences(context):
    addon = context.preferences.addons.get(__package__)
    return addon.preferences if addon else None


def _candidate_toolkits(context) -> Iterable[Path]:
    prefs = _preferences(context)
    if prefs and prefs.toolkit_path:
        selected = Path(bpy.path.abspath(prefs.toolkit_path))
        yield selected / "siig_toolkit.py" if selected.is_dir() else selected
    env = os.environ.get("SIIG_TOOLKIT_HOME")
    if env:
        selected = Path(env)
        yield selected / "siig_toolkit.py" if selected.is_dir() else selected
    here = Path(__file__).resolve()
    # When the readable source copy is used directly from an unpacked toolkit,
    # __file__ lives below addons/blender_addon_source/siig_blender/.  Walk
    # upward instead of assuming a fixed parent depth so both the source-tree
    # layout and future packaging layouts can discover the adjacent toolkit.
    for parent in here.parents:
        yield parent / "siig_toolkit.py"
    yield Path.cwd() / "siig_toolkit.py"


def _find_toolkit(context) -> Path:
    checked = []
    for candidate in _candidate_toolkits(context):
        checked.append(str(candidate))
        if candidate.is_file():
            return candidate.resolve()
    raise RuntimeError(
        "siig_toolkit.py was not found. Set the toolkit folder in Edit > Preferences > Add-ons > SIIG Asset Toolkit. "
        + "Checked: " + "; ".join(checked)
    )


def _load_toolkit(context):
    script = _find_toolkit(context)
    existing = sys.modules.get(_MODULE_NAME)
    if existing is not None and Path(getattr(existing, "__file__", "")).resolve() == script:
        return existing
    root = str(script.parent)
    if root not in sys.path:
        sys.path.insert(0, root)
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, script)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load SIIG toolkit from {script}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


def _new_objects(before: set[bpy.types.Object]) -> list[bpy.types.Object]:
    return [obj for obj in bpy.data.objects if obj not in before]


def _move_to_collection(objects: Iterable[bpy.types.Object], collection: bpy.types.Collection) -> None:
    """Move objects exclusively into collection.

    Exclusive membership is intentional: if a mesh remains linked to the scene/import
    collection as well as its SIIG part collection, hiding the part collection in Blender
    does not reliably hide that mesh through every remaining collection path.
    Parenting is independent of collection membership and remains untouched.
    """
    for obj in objects:
        if collection not in obj.users_collection:
            collection.objects.link(obj)
        for old in list(obj.users_collection):
            if old != collection:
                old.objects.unlink(obj)


def _custom_prop(obj: bpy.types.Object, key: str):
    try:
        return obj.get(key)
    except Exception:
        return None


def _is_siig_assembly_master(obj: bpy.types.Object, candidates: set[bpy.types.Object] | None = None) -> bool:
    # Blender's glTF importer normally preserves node extras as custom properties.
    # This is the authoritative path for toolkit-generated assembled glTFs.
    if _custom_prop(obj, "siigAssemblyModel") is not None:
        return True
    if _custom_prop(obj, "siigAssemblyRole") is not None:
        return True

    # Fallback for Blender builds/import settings that do not preserve extras.  The
    # toolkit names each logical master "part" and its native GMX root/meshes
    # "part:...".  Restrict the fallback to Empty nodes with a matching child so an
    # ordinary native mesh is never mistaken for a part master merely because of its name.
    if getattr(obj, "type", None) != "EMPTY" or ":" in obj.name:
        return False
    allowed = candidates if candidates is not None else set(bpy.data.objects)
    prefix = obj.name + ":"
    return any(child in allowed and child.name.startswith(prefix) for child in obj.children)


def _part_members(master: bpy.types.Object, masters: set[bpy.types.Object], allowed: set[bpy.types.Object]) -> list[bpy.types.Object]:
    """Return one logical part without crossing into an attached child-part master."""
    members: list[bpy.types.Object] = []
    stack = [master]
    seen: set[bpy.types.Object] = set()
    while stack:
        obj = stack.pop()
        if obj in seen or obj not in allowed:
            continue
        seen.add(obj)
        members.append(obj)
        for child in obj.children:
            if child not in allowed:
                continue
            if child in masters and child is not master:
                continue
            stack.append(child)
    return members


def _collection_label(text: str, prefix: str = "SIIG_PART_") -> str:
    safe = "".join(ch if ch.isalnum() or ch in " _-." else "_" for ch in text).strip()
    if not safe:
        safe = "part"
    # Blender datablock names are friendlier when kept compact; duplicate names are
    # automatically disambiguated by Blender (.001, .002, ...).
    return (prefix + safe)[:63]


def _organize_siig_parts(
    context,
    objects: Iterable[bpy.types.Object],
    *,
    root_name: str = "SIIG_Assembly",
) -> dict:
    """Create one Blender collection per logical assembled-GMX part.

    The toolkit intentionally preserves native solid/face (_F) and outline/edge (_E)
    objects as separate meshes.  A Blender object eye therefore cannot represent the
    whole logical part.  Part collections solve that UI mismatch: hiding the collection
    hides its master, solid pass, outline pass and internal transform nodes together.
    """
    candidates = {obj for obj in objects if obj is not None}
    if not candidates:
        return {"masters": 0, "collections": 0, "objects": 0, "unassigned": 0}

    masters = {obj for obj in candidates if _is_siig_assembly_master(obj, candidates)}
    if not masters:
        return {"masters": 0, "collections": 0, "objects": 0, "unassigned": len(candidates)}

    root = bpy.data.collections.new(_collection_label(root_name, "SIIG_"))
    context.scene.collection.children.link(root)
    assigned: set[bpy.types.Object] = set()
    created_collections = 0

    # Stable order makes the Outliner predictable even when Blender's object datablock
    # iteration order differs across versions.
    for master in sorted(masters, key=lambda obj: obj.name.lower()):
        collection = bpy.data.collections.new(_collection_label(master.name))
        root.children.link(collection)
        members = _part_members(master, masters, candidates)
        _move_to_collection(members, collection)
        assigned.update(members)
        collection["siig_logical_part"] = master.name
        model = _custom_prop(master, "siigAssemblyModel")
        role = _custom_prop(master, "siigAssemblyRole")
        if model is not None:
            collection["siig_assembly_model"] = str(model)
        if role is not None:
            collection["siig_assembly_role"] = str(role)
        created_collections += 1

    leftovers = sorted(candidates - assigned, key=lambda obj: obj.name.lower())
    if leftovers:
        misc = bpy.data.collections.new(_collection_label("MISC"))
        root.children.link(misc)
        _move_to_collection(leftovers, misc)
        misc["siig_logical_part"] = "unassigned"
        created_collections += 1

    root["siig_part_collection_root"] = True
    root["siig_part_count"] = len(masters)
    return {
        "masters": len(masters),
        "collections": created_collections,
        "objects": len(candidates),
        "unassigned": len(leftovers),
        "root": root.name,
    }


def _import_gltf_assembly(context, source: Path, organize_parts: bool = True) -> tuple[int, dict]:
    before = set(bpy.data.objects)
    result = bpy.ops.import_scene.gltf(filepath=str(source))
    if "FINISHED" not in result:
        raise RuntimeError(f"Blender glTF importer returned {result}")
    created = _new_objects(before)
    info = {"masters": 0, "collections": 0, "objects": len(created), "unassigned": len(created)}
    if organize_parts and created:
        info = _organize_siig_parts(context, created, root_name=source.stem)
    for obj in created:
        obj["siig_source_assembly"] = str(source)
    return len(created), info


def _import_one(context, source: Path, flip_v: bool, texture_root: str, group_collection: bool) -> tuple[int, dict]:
    toolkit = _load_toolkit(context)
    roots = [source.parent]
    if texture_root:
        roots.append(Path(bpy.path.abspath(texture_root)))
    before = set(bpy.data.objects)
    with tempfile.TemporaryDirectory(prefix="siig_blender_") as temp_dir:
        output = Path(temp_dir)
        metadata = toolkit.export_gmx_gltf_file(
            source,
            output,
            flip_v=flip_v,
            texture_roots=tuple(roots),
        )
        gltf = output / f"{source.stem}.gltf"
        if not gltf.is_file():
            raise RuntimeError(f"SIIG exporter did not create {gltf.name}")
        result = bpy.ops.import_scene.gltf(filepath=str(gltf))
        if "FINISHED" not in result:
            raise RuntimeError(f"Blender glTF importer returned {result}")
    created = _new_objects(before)
    if group_collection and created:
        collection = bpy.data.collections.new(f"SIIG_{source.stem}")
        context.scene.collection.children.link(collection)
        _move_to_collection(created, collection)
    for obj in created:
        obj["siig_source_gmx"] = str(source)
        obj["siig_toolkit_version"] = str(getattr(toolkit, "TOOLKIT_VERSION", "unknown"))
    return len(created), metadata


class SIIGAddonPreferences(AddonPreferences):
    bl_idname = __package__

    toolkit_path: StringProperty(
        name="Toolkit folder",
        description="Folder containing siig_toolkit.py, or the script itself",
        subtype="DIR_PATH",
    )
    default_texture_root: StringProperty(
        name="Default texture root",
        description="Optional folder searched recursively for textures referenced by GMX files",
        subtype="DIR_PATH",
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "toolkit_path")
        layout.prop(self, "default_texture_root")
        layout.label(text="The add-on calls the toolkit's verified GMX to glTF exporter locally.")


class SIIG_OT_import_gmx(Operator, ImportHelper):
    bl_idname = "import_scene.siig_gmx"
    bl_label = "Import SIIG GMX"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".gmx"
    filter_glob: StringProperty(default="*.gmx;*.GMX", options={"HIDDEN"})
    files: CollectionProperty(type=OperatorFileListElement)
    directory: StringProperty(subtype="DIR_PATH")
    flip_v: BoolProperty(name="Flip texture V", default=False)
    group_collection: BoolProperty(name="Collection per GMX", default=True)
    texture_root: StringProperty(name="Texture root", subtype="DIR_PATH")

    def invoke(self, context, event):
        prefs = _preferences(context)
        if prefs and prefs.default_texture_root and not self.texture_root:
            self.texture_root = prefs.default_texture_root
        return ImportHelper.invoke(self, context, event)

    def execute(self, context):
        paths = [Path(self.directory) / item.name for item in self.files] if self.files else [Path(self.filepath)]
        imported_objects = 0
        failures = []
        for path in paths:
            try:
                count, metadata = _import_one(context, path.resolve(), self.flip_v, self.texture_root, self.group_collection)
                imported_objects += count
                missing = metadata.get("missing_textures", []) if isinstance(metadata, dict) else []
                if missing:
                    self.report({"WARNING"}, f"{path.name}: {len(missing)} referenced texture(s) not found")
            except Exception as exc:
                failures.append(f"{path.name}: {exc}")
        if failures:
            self.report({"ERROR"}, " | ".join(failures[:4]))
            return {"CANCELLED"} if imported_objects == 0 else {"FINISHED"}
        self.report({"INFO"}, f"Imported {len(paths)} GMX file(s), {imported_objects} Blender object(s)")
        return {"FINISHED"}


class SIIG_OT_import_gmx_folder(Operator):
    bl_idname = "import_scene.siig_gmx_folder"
    bl_label = "Import GMX Folder"
    bl_options = {"REGISTER", "UNDO"}

    directory: StringProperty(name="Folder", subtype="DIR_PATH")
    recursive: BoolProperty(name="Recursive", default=True)
    flip_v: BoolProperty(name="Flip texture V", default=False)
    group_collection: BoolProperty(name="Collection per GMX", default=True)
    texture_root: StringProperty(name="Texture root", subtype="DIR_PATH")
    max_files: IntProperty(name="Maximum files", default=256, min=1, max=10000)

    def invoke(self, context, event):
        prefs = _preferences(context)
        if prefs and prefs.default_texture_root and not self.texture_root:
            self.texture_root = prefs.default_texture_root
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        root = Path(bpy.path.abspath(self.directory))
        iterator = root.rglob("*.gmx") if self.recursive else root.glob("*.gmx")
        paths = sorted(iterator, key=lambda p: p.as_posix().lower())
        if not paths:
            self.report({"ERROR"}, "No .gmx files were found")
            return {"CANCELLED"}
        if len(paths) > self.max_files:
            self.report({"ERROR"}, f"Found {len(paths)} GMX files; raise Maximum files to continue")
            return {"CANCELLED"}
        imported = 0
        failures = []
        for path in paths:
            try:
                count, _metadata = _import_one(context, path, self.flip_v, self.texture_root, self.group_collection)
                imported += count
            except Exception as exc:
                failures.append(f"{path.name}: {exc}")
        if failures:
            self.report({"WARNING"}, f"Imported {len(paths)-len(failures)}/{len(paths)} files; first error: {failures[0]}")
        else:
            self.report({"INFO"}, f"Imported {len(paths)} files, {imported} objects")
        return {"FINISHED"} if imported else {"CANCELLED"}


class SIIG_OT_import_assembly(Operator, ImportHelper):
    bl_idname = "import_scene.siig_assembly"
    bl_label = "Import SIIG Assembly"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".gltf"
    filter_glob: StringProperty(default="*.gltf;*.glb;*.GLTF;*.GLB", options={"HIDDEN"})
    organize_parts: BoolProperty(
        name="Logical part collections",
        description="Put each SIIG assembly master and its native solid/outline descendants in one hideable Blender collection",
        default=True,
    )

    def execute(self, context):
        source = Path(self.filepath).resolve()
        if source.suffix.lower() not in {".gltf", ".glb"}:
            self.report({"ERROR"}, "Choose a .gltf or .glb SIIG assembly")
            return {"CANCELLED"}
        try:
            count, info = _import_gltf_assembly(context, source, self.organize_parts)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        if self.organize_parts and not info.get("masters"):
            self.report({"WARNING"}, f"Imported {count} object(s), but no SIIG logical assembly masters were detected")
        else:
            self.report({"INFO"}, f"Imported {count} object(s); organized {info.get('masters', 0)} logical SIIG part(s)")
        return {"FINISHED"}


class SIIG_OT_organize_parts(Operator):
    bl_idname = "object.siig_organize_parts"
    bl_label = "Organize SIIG Part Collections"
    bl_description = "Group each assembled SIIG logical part so the Outliner collection eye hides its solid and outline objects together"
    bl_options = {"REGISTER", "UNDO"}

    selected_only: BoolProperty(
        name="Selected objects only",
        description="Organize only selected objects; disable to scan the current scene",
        default=False,
    )

    def execute(self, context):
        objects = list(context.selected_objects) if self.selected_only else list(context.scene.objects)
        info = _organize_siig_parts(context, objects, root_name="Organized_Parts")
        if not info.get("masters"):
            self.report({"WARNING"}, "No SIIG logical assembly masters were found. Import a toolkit-generated assembled glTF first.")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Organized {info['masters']} SIIG logical part(s) into {info['collections']} collection(s)")
        return {"FINISHED"}


class SIIG_PT_tools(Panel):
    bl_label = "SIIG Asset Toolkit"
    bl_idname = "SIIG_PT_tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "SIIG"

    def draw(self, context):
        layout = self.layout
        layout.operator(SIIG_OT_import_gmx.bl_idname, icon="IMPORT")
        layout.operator(SIIG_OT_import_gmx_folder.bl_idname, icon="FILE_FOLDER")
        layout.separator()
        layout.operator(SIIG_OT_import_assembly.bl_idname, icon="OUTLINER_COLLECTION")
        layout.operator(SIIG_OT_organize_parts.bl_idname, icon="GROUP")
        box = layout.box()
        box.label(text="Assembly visibility")
        box.label(text="Hide SIIG_PART_* collections in the Outliner")
        box.label(text="to hide solid + outline together.")
        try:
            path = _find_toolkit(context)
            layout.label(text=f"Toolkit: {path.parent.name}", icon="CHECKMARK")
        except Exception:
            layout.label(text="Set toolkit path in Add-on Preferences", icon="ERROR")


def _menu_import(self, context):
    self.layout.operator(SIIG_OT_import_gmx.bl_idname, text="Space Invaders Infinity Gene (.gmx)")
    self.layout.operator(SIIG_OT_import_assembly.bl_idname, text="SIIG Assembled Model (.gltf/.glb)")


_CLASSES = (
    SIIGAddonPreferences,
    SIIG_OT_import_gmx,
    SIIG_OT_import_gmx_folder,
    SIIG_OT_import_assembly,
    SIIG_OT_organize_parts,
    SIIG_PT_tools,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(_menu_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(_menu_import)
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
