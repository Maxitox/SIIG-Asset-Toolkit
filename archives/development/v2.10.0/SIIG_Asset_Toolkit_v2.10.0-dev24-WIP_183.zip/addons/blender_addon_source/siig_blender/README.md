# SIIG Blender Add-on 0.2.1

This add-on imports extracted SIIG `.gmx` models through the same verified GMX → glTF exporter shipped in `siig_toolkit.py`. It also imports toolkit-generated assembled `.gltf`/`.glb` scenes and organizes each logical SIIG component into its own Blender collection. It does not contain game assets and does not contact the network.

## Install

1. In Blender, open **Edit → Preferences → Add-ons**.
2. Choose **Install from Disk** and select `addons/SIIG_Blender_Addon_v0.2.1.zip`.
3. Enable **SIIG Asset Toolkit**.
4. Open the add-on preferences and select the folder containing `siig_toolkit.py`.

## Use

- **File → Import → Space Invaders Infinity Gene (.gmx)** imports one or several raw GMX files.
- **File → Import → SIIG Assembled Model (.gltf/.glb)** imports a Boss/Entity Assembler result.
- The **SIIG** sidebar also exposes **Organize SIIG Part Collections** for an assembly that was imported previously with Blender's normal glTF importer.
- For an assembled scene, hide/show the generated `SIIG_PART_*` **collection** in the Outliner to toggle one logical game part. This hides its native solid/face (`_F`) and outline/edge (`_E`) objects together.
- Recursive raw-GMX folder import, optional V flip, and an external texture root remain available.

The organizer uses glTF `siigAssemblyModel` / `siigAssemblyRole` extras when Blender preserves them and a conservative master/child-name fallback otherwise. Nested logical components remain separate collections, so hiding a CRAB claw, for example, does not implicitly absorb neighboring attached components. Object parenting and animation are not rewritten.

## Current boundaries

- The add-on imports through generated glTF; it does not edit or export/repack GMX.
- Face/outline meshes remain separate by design; the new collection grouping is a Blender visibility-control layer, not a destructive merge.
- Blender 3.6 or newer is the supported baseline. Source syntax, packaging, metadata/grouping contracts and exporter integration are regression-tested outside Blender; headless import/registration and unpacked-toolkit auto-discovery are also regression-tested outside Blender; final UI/operator behavior still requires an in-Blender runtime check.
