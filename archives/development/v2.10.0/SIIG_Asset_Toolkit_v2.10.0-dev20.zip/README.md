# Space Invaders Infinity Gene Asset Toolkit

**Version 2.10.0-dev18 — AXON exact two-ring runtime assembly**

SIIG Asset Toolkit is a dependency-light Python toolkit for researching and extracting assets from the Xbox 360, PlayStation 3, iOS, and Android releases of **Space Invaders Infinity Gene**. It accepts original outer packages, extracted game folders, or ZIP archives; extracts nested BBX resources; converts supported assets; builds a self-contained stage explorer; and records enough metadata to audit the result.

The toolkit is based on user-supplied retail/prototype files, cross-platform comparisons, and Ghidra exports from `default.xex`. It does not include game binaries or extracted copyrighted assets.

## 2.10.0-dev18 highlight — AXON exact two-ring runtime assembly

Dev18 reconstructs AXON without visually guessing its petal count or layout. Retail allocates a standalone A5 / `bos_012.gmx` whole-body representation and a separate 17-record pool containing one CA / `bos_012a.gmx` core plus sixteen CB / `bos_012b.gmx` petals. The CBs form two executable-defined staggered rings of eight. At the stable expanded phase-angle-0 snapshot, ring 1 is radius 75 at Y -3.0 with 0°/45°/.../315° table angles; ring 2 is radius 220 at Y -5.5 with 22.5°/67.5°/.../337.5°. `axon_native_body`, `axon_expanded_petals`, and `axon_exposed_core` keep the mutually exclusive runtime representations separate. Fresh retail validation gives 1/17/1 instances, 42/34/2 meshes, 76/84/20 nodes, and 32/0/0 animations. GUI 0.29.0-dev18 adds the form selector and manifest/export workflow. See `docs/research/AXON_RUNTIME_ASSEMBLY_2.10.0-dev18.md`.

## 2.10.0-dev17 highlight — SQUID two-phase native-locator assembly

Dev17 reconstructs SQUID as one animated A9 / `bos_016.gmx` body plus eight DA / `bos_016a.gmx` legs attached in strict runtime-record order to native `lt_000..lt_007` locators. Retail state 8 disables exactly those eight leg records and leaves the body active; June 10 independently retains the same eight-record disable transition. The toolkit exposes `squid_phase1_legs` and `squid_phase2_body`, preserving all eight native body animation clips rather than baking approximate transforms. Fresh retail exports validate 9 / 1 instances, 18 / 2 meshes, 44 / 12 nodes, and 8 animations in both phases. GUI 0.28.0-dev17 adds the phase selector and manifest/export workflow. See `docs/research/SQUID_RUNTIME_ASSEMBLY_2.10.0-dev17.md`.

## 2.10.0-dev16 highlight — PROGRESSIVE UFO classic formation

Dev16 adds the requested second PROGRESSIVE UFO pose as a separate `progressive_ufo_classic` catalog while leaving the original dev3 `progressive_ufo` preset unchanged. Retail Xbox major states 5 and 8 apply the same five-part table initialized at `0x82568180`; June 10 contains a byte-equivalent table at `0x825D95B0`, and retail PS3 independently preserves the same records. The classic pose uses the original A2+C2+C2+C3+C3 membership with exact runtime Euler composition rather than screenshot approximation. Fresh retail export validates 5 instances / 10 meshes / 20 nodes / 10 preserved native animations. GUI 0.27.0-dev16 adds an Original/Classic formation selector. See `docs/research/PROGRESSIVE_UFO_CLASSIC_FORMATION_2.10.0-dev16.md`.

## 2.10.0-dev15 highlight — GIGANTIC UFO complete locator hierarchy

Dev15 reconstructs GIGANTIC UFO's complete persistent visual hierarchy from retail Xbox, June 10 Xbox and retail PS3 renderer logic. `gigantic_ufo_complete` contains exactly one 0x9E / `bos_003.gmx` root plus thirty-six 0xB5 / `bos_003a.gmx` weapon modules attached in order to native `lt_001..lt_036` locators. Three 0xB4 renderer slots are helper/control slots, not model assets, and are deliberately excluded. Fresh retail export validates 37 instances / 74 meshes / 185 nodes / 0 animations with bounds about X/Y ±269.593 and Z -66.103..61.111. GUI 0.26.0-dev15 adds one-click GIGANTIC UFO manifest/export actions. See `docs/research/GIGANTIC_UFO_RUNTIME_ASSEMBLY_2.10.0-dev15.md`.

## 2.10.0-dev14 highlight — CENTIPEDE initial-combat ring assembly

Dev14 resolves CENTIPEDE as a fixed 32-link runtime chain with role-driven model swapping rather than 32 pairs rendered simultaneously. The canonical `centipede_initial_combat_ring` preset contains exactly **2× `bos_007.gmx` A0 endpoint forms + 30× `bos_007a.gmx` BE body forms** on the executable's radius-80 ring at 11.25° intervals. Destroying a body link severs the chain and promotes newly exposed ends to A0; destroying an existing endpoint enters the reform path. When fewer than six links remain, all survivors enter the independent runtime-randomized final phase, so dev14 deliberately does not invent static split/reform/final layouts. Retail Xbox, June 10 Xbox and retail PS3 preserve the same construction/threshold logic. Fresh retail export validates 32 instances / 64 meshes / 128 nodes. GUI 0.25.0-dev14 adds one-click CENTIPEDE assembly and manifest actions. See `docs/research/CENTIPEDE_RUNTIME_ASSEMBLY_DEV14.md`.

## 2.10.0-dev13 highlight — VERTEBRATE two-phase structural assembly

Dev13 reconstructs the two persistent VERTEBRATE body states from retail Xbox, June 10 Xbox and retail PS3 runtime behavior, then validates them against freshly extracted retail GMXs. `vertebrate_phase1_tower` contains exactly two `bos_017.gmx` endcaps plus thirty `bos_017a.gmx` pillar sections on the executable's 70-unit Y ladder. `vertebrate_phase2_endcaps` removes every pillar and rebases the two endcaps at the boss-local origin with effective Z rotations 90°/270°. The separate `bos_017b..j` attack auxiliaries are intentionally excluded. GUI 0.24.0-dev13 exposes both structural phases. See `docs/research/VERTEBRATE_RUNTIME_ASSEMBLY_2.10.0-dev13.md`.

## 2.10.0-dev12 highlight — UNKNOWN internal forms

Dev12 resolves UNKNOWN as one `bos_006.gmx` containing 14 named `uk01..uk14` branches with no native GMX animation. Retail Xbox, June 10 and retail PS3 independently preserve the same runtime form-selector architecture. Fresh retail-GMX validation proves `uk08` is visually identical to `uk01`, so the file contains 14 named branches but 13 unique visuals. Normal console gameplay cycles `uk01..uk12` at normalized 30 Hz (12 named selections / 11 unique visuals); state 0 forces `uk01`, while `uk13/uk14` remain registered but outside the normal cycle. GUI 0.23.0-dev12 exports any exact native form subtree without inventing multipart placement or a fake native animation. See `docs/research/UNKNOWN_INTERNAL_FORMS_2.10.0-dev12.md`.

## 2.10.0-dev11 highlight — BUTTERFLY four-phase assembly

Dev11 reconstructs all four BUTTERFLY forms from the retail executable loader table and the original retail GMXs. Phase 1 is `bos_011.gmx` alone; phases 2–4 attach exact C7/C8/C9 wing-module counts under native `lt_*` locators: 4 large squares; then 8 large + 10 small squares; then 8 large + 32 small squares + 8 elongated rectangles. The same ten loader records are independently present in June 10. Real-retail exports validate 1 / 5 / 19 / 49 instances while preserving the native body animations in phases 2–4. GUI 0.22.0-dev11 adds a four-phase selector and manifest/assembly actions. See `docs/research/BUTTERFLY_RUNTIME_ASSEMBLY_2.10.0-dev11.md`.

## 2.10.0-dev10 highlight — HORNET exposed core

Dev10 proves and exposes `hornet_exposed_core`, the deterministic high-level state-3 entry snapshot: one A1 / `bos_008.gmx` at native motion 0, sample 0, with all 125 subordinate records reset to state `-1` so neither BF armor nor C0 prisms are selected. Retail Xbox, June 10 Xbox and retail PS3 preserve the same reset architecture. The project owner re-supplied the original retail Xbox package, allowing direct extraction and real-GMX validation: one instance, two meshes, four glTF nodes, native bounds about ±13.8054. GUI 0.21.0-dev10 exposes full armor and exposed core separately. See `docs/research/HORNET_EXPOSED_CORE_2.10.0-dev10.md`.

## 2.10.0-dev9 highlight — ULTIMATE UFO assembly

Dev9 reconstructs ULTIMATE UFO's complete retail allocation hierarchy as **126 model instances** across A8 + D0–D9, with exact named `lt_###` attachment chains. The default `ultimate_ufo_complete` catalog is explicitly an allocation/hierarchy snapshot, not a simultaneous render-visibility claim. Eight additional state catalogs expose the controller families active under the retail collision/destructibility phase table. GUI 0.20.0-dev9 defaults to the complete hierarchy and keeps those activity subsets selectable. See `docs/research/ULTIMATE_UFO_RUNTIME_ASSEMBLY_2.10.0-dev9.md`.

## 2.10.0-dev8 highlight — MANDALA assembly

Dev8 adds `mandala_initial_combat`, the five-build executable-backed 40-instance MANDALA state-7 activation snapshot. It preserves native animations, excludes the later 32×BC phase, and is exposed as one-click **Assemble MANDALA** in GUI 0.19.0-dev8. See `docs/research/MANDALA_RUNTIME_ASSEMBLY_2.10.0-dev8.md`.

## 2.10.0-dev7 highlight — HORNET propagation

Dev7 adds the evidence-backed `hornet_propagation_SS_wave_WW` family for HORNET state 6. The seed is inherited from the same 13-way prism-wall choice; A1 is hidden, reached C0 prisms expand deterministically across the exact 5×9 grid, and Advanced GUI exposes explicit seed/wave controls. See `docs/research/HORNET_PROPAGATION_2.10.0-dev7.md`.

## Highlights through 2.10.0-dev14

- **New in 2.10.0-dev14:** CENTIPEDE adds `centipede_initial_combat_ring`, exactly 2×A0 `bos_007` endpoints + 30×BE `bos_007a` body links on a radius-80, 11.25° ring. Role transitions prove body cuts promote newly exposed ends to A0; endpoint destruction enters the reform path; at ≤5 survivors the game switches to independent randomized movers, so no fake static later-phase preset is provided. Real retail export validates 32 instances / 64 meshes / 128 nodes and GUI 0.25.0-dev14 exposes the canonical ring.
- **New in 2.10.0-dev13:** VERTEBRATE adds two exact structural catalogs. Phase 1 is 2×AA `bos_017` endcaps + 30×DB `bos_017a` pillars at Y `-630..1400` in 70-unit steps, with caps at Y `-608`/`1448`; phase 2 removes all pillars and rebases the two endcaps to origin at effective Z rotations 90°/270°. Real retail exports validate 32/2 instances and GUI 0.24.0-dev13 exposes both phases.
- **New in 2.10.0-dev12:** UNKNOWN exposes all 14 native `uk01..uk14` branches from one `bos_006.gmx`; real-retail comparison proves 13 unique visuals because `uk08 == uk01`. The normal console runtime cycles `uk01..uk12` at normalized 30 Hz, while state 0 forces `uk01`; `uk13/uk14` are renderer-registered but outside the traced normal 12-tick cycle. GUI 0.23.0-dev12 exports exact form subtrees.
- **New in 2.10.0-dev11:** BUTTERFLY adds four exact phase catalogs. Retail loader `0x82111F48` and June loader `0x8212B490` independently encode the same 10 records. Phase 1 is body-only; phase 2 is C4 + 4×C7 on `lt_001..004`; phase 3 is C5 + 8×C7 + 10×C8 on `lt_001..018`; phase 4 is C6 + 8×C7 + 32×C8 + 8×C9 on `lt_001..048`. Real retail exports validate 1/5/19/49 instances and preserve all three native body animations in phases 2–4. GUI 0.22.0-dev11 exposes the phase selector.
- **New in 2.10.0-dev10:** HORNET adds `hornet_exposed_core`, the executable-backed state-3 entry snapshot. Common reset restores A1 at motion 0/sample 0 and sets all 125 BF/C0 subordinate records to state `-1`; the result is independently cross-checked on retail Xbox, June 10 Xbox and retail PS3. Fresh extraction from the re-uploaded original retail Xbox STFS exactly matches the historical HORNET GMX/ANM hashes, and a real retail export validates 1 instance / 2 meshes / 4 nodes with bounds about ±13.8054. GUI 0.21.0-dev10 separates armor and exposed-core assembly.
- **New in 2.10.0-dev9:** ULTIMATE UFO adds `ultimate_ufo_complete`, the 126-instance constructor-baseline allocation hierarchy, plus eight state-specific controller-activity subsets (2, 3, 6, 7, 8, 9, 11, 12), exact D4/D5/D6/D7 `lt_###` hierarchy, D8/D9 late-state identities, and GUI selection. Retail and June executable structure are cross-checked; no real retail GMX export is claimed in this checkpoint because the proprietary `bos_015*.gmx` inputs are not bundled or present in the persistent research Library.
- **New in 2.10.0-dev8:** MANDALA adds the 40-instance executable-backed state-7 activation assembly with 20×B7, 2×B8/B9/BA/BB, and 12 structural 4A pieces; later 32×BC is excluded.
- **New in 2.10.0-dev7:** HORNET state 6 is recovered as a deterministic 13-seed propagation family. State 5 hides A1 and resets all 45 grid records; state 6 starts from the inherited dev6 prism-wall seed and alternates orthogonal/diagonal C0 expansion until full coverage. Procedural `hornet_propagation_SS_wave_WW` catalogs and Advanced GUI seed/wave controls expose exact activation snapshots without inventing a canonical random outcome.
- **New in 2.10.0-dev6:** HORNET prism-wall state 4 is an exact 13-outcome family: A1 occupies one recovered 5×9 grid cell and 44 C0 prisms occupy the others. Advanced mode exposes the runtime-valid slot selector.
- The dependency-free regression suite is now **96/96**.
- **New in 2.10.0-dev5:** HORNET now has an executable/model-backed full-armor assembly preset: A1 core plus exactly **125 BF armor cubes** on the sample-0 C1 5×5×5 formation lattice. C1 is now resolved as a real meshless animation rig; the parallel 125-object C0 prism pool is documented but omitted from this static state. GUI **Assemble HORNET** exports the 126 visible instances directly.
- **New in 2.10.0-dev5:** CRAB's beginner-facing `crab` preset now uses the deterministic first **landed/combat-ready** root sample 1. The dev4 airborne sample-167 reconstruction is preserved as `crab_first_visible`; no arbitrary recentering is applied.
- **New in 2.10.0-dev5:** project-owner Blender validation confirmed PROGRESSIVE UFO's slight C3 barrier tilt is native `bos_009b.gmx` bind orientation, not an assembly error. Native SIIG boss scale/units continue to be preserved; Blender Frame All/Selected is recommended rather than silent rescaling.
- Dev5 sealed at **87/87**; current dev7 regression coverage is **89/89**.
- **New in 2.10.0-dev4:** the desktop GUI now starts in **Simple mode**, with a Simple/Advanced switch and plain-language hover/focus help for Mod Workspace and GMX Workbench controls. Advanced mode preserves the full expert interface.
- **New in 2.10.0-dev4:** CRAB now has an executable/model-backed first-visible assembly preset. The root `bos_013.gmx` is baked at native sample **167**, the animated body shell `bos_013b.gmx` at sample **0**, and the remaining `CC/CE/CF` children are placed from the runtime locator/offset logic. `gmx-assemble-catalog crab` and GUI **Assemble CRAB** export the nine-part static formation.
- **New in 2.10.0-dev2:** disjoint rigid joint islands inside one glTF mesh are partitioned into separate native MESH/ARRY graphs, each inverse-bind rebaked and attached to its own BONE. Cross-joint triangles remain explicit errors.
- **New in 2.10.0-dev3:** the PROGRESSIVE UFO catalog now contains its executable-backed five-part runtime formation: body `(0,0,0)`, laser machines `(-90,0,-10)` / `(90,0,-10)`, and barrier machines `(-160,0,-50)` / `(160,0,-50)`, with zero local rotation. The result is cross-checked across June Xbox, retail Xbox, and retail PS3. `gmx-assemble-catalog progressive_ufo` exports the fully assembled scene directly.

- **New in 2.10.0-dev1:** rigid single-joint glTF skins may use a non-identity affine `inverseBindMatrices` entry. The compiler rebakes `POSITION` into joint bind-local space and transforms `NORMAL` with the correct inverse-transpose matrix before collapsing the result to SIIG's proven BONE→MESH representation.
- Singular bind transforms that cannot produce a valid normal matrix are rejected. Genuine blended/multi-joint weights remain unsupported because the retail GMX evidence still contains no per-vertex weight stream.
- The same rigid-bind compiler path remains shared by `gltf2gmx-new`, Mod Workspace, and the GMX Workbench.
- **New in dev7:** standard glTF `skins` / `JOINTS_0` / `WEIGHTS_0` can be imported when the mesh is truly rigid: every vertex must resolve to the same one-weight joint. The importer maps that safely to SIIG's proven BONE→MESH attachment representation.
- **No speculative blended skinning:** genuine multi-joint weights and secondary JOINTS/WEIGHTS sets are rejected. Non-identity affine inverse binds are now rebaked safely; supplied player/enemy GMXs (901 MESH records) still all use `skin_index=0xFFFF` and have no joint/weight ARRY semantics.
- **Template-free path includes rigid skins:** `gltf2gmx-new` can synthesize the joint BONE hierarchy and attach a rigidly skinned mesh without any original GMX.
- **New in dev6:** `gltf2gmx-new` compiles a native GMX directly from glTF without reading an original GMX template. It synthesizes the canonical decoded 0x30-byte root and enables the mesh/material/texture-reference/bone/animation builders proven in earlier checkpoints.
- The synthesized root recomputes total stream size and minXYZ/maxXYZ bounds. Still-unnamed root fields at `+0x08` and `+0x28..+0x2F` default to zero; advanced glTF extras can preserve empirically discovered values without claiming semantics.
- GMX Workbench now exposes **Create new GMX**. Template-backed import remains available and preferable when preserving opaque bytes from an existing model matters.
- External dev25 **306/306 mesh-bearing retail GMX** no-op evidence remains inherited and is not re-run from proprietary inputs.

- **New in dev5:** one glTF animation may drive several bones. The importer expands the clip into synchronized per-bone native `MOTN`/`ANIM` tracks on SIIG's proven 30 Hz runtime cadence.
- glTF `CUBICSPLINE` translation/rotation/scale channels are now accepted using spec-style Hermite interpolation; quaternion cubic samples are normalized after interpolation.
- Existing exported native animations remain byte-preserved during animation-aware imports unless `extras.gmxReplaceNativeAnimation=true` explicitly requests resampling/replacement.
- `mod-import-gltf` carries multi-bone animation clips through the same integrated GMX/TEX/BBX workspace flow. The built-in regression suite is now **80 tests**.

- **New in dev4:** donor-free `MOTN`/`ANIM` creation from ordinary glTF TRS channels established the native 30 Hz matrix compiler used by dev5.

- **New in dev3:** PNGs can synthesize canonical native Xbox 360/PS3 TEX wrappers without a same-layout TEX donor. Mod Workspace uses this automatically for new TXIF resources or dimension-changing texture edits.

- **New in dev2:** GMX import can synthesize native `MESH`/`ARRY` vertex declarations and `MTRL` parameter streams when no compatible donor exists. The Mod Workspace uses this automatically as a fallback during glTF import.

- New `mod-import-gltf` turns an edited glTF into a mod-workspace operation: it compiles the GMX/TXIF graph, rebuilds linked PNGs as native TEX, and stages everything without manual BBX surgery.
- When a new glTF texture creates a new TXIF filename, the workspace can append a new named BBX member. BBX identifiers/name tables/counts are rebuilt deterministically and verified.
- `.siigmod` packaging supports those member additions by emitting a baseline-dependent archive delta instead of redistributing a clean archive.
- The GUI Mod Workspace now exposes **Import glTF + TEX** alongside build/verify/package actions.
- The built-in suite is now **80 tests**. The external dev25 **306/306 mesh-bearing retail GMX** no-op gate remains inherited evidence rather than being re-run from proprietary inputs.
- Versioning policy has been formalized: feature-line minor versions are reviewed no later than `dev8`, so a single minor version should no longer accumulate dozens of development suffixes.

- `gltf2gmx-template --sync-texture-graph` extends dev27 scene synchronization into native `TXIF` texture references. A glTF `baseColorTexture` can now reuse or allocate a native TXIF and bind a compatible `DiffuseSampler` parameter automatically.
- glTF export preserves every TXIF index/flags/name even when the referenced texture image is unavailable, and annotates converted images/textures with native provenance when a TEX/DDS/PNG/JPEG can be located.
- The dev27 `SHAD`/`MTRL`/`BONE`/`PARE` scene compiler and dev26 `MESH`/`ARRY` graph compiler remain separate lower synchronization levels. Texture sync is a third, default-off advanced mode and implies both scene and mesh synchronization.
- `gmx-scene-report` now shows TXIF records and material texture bindings alongside BONE hierarchy, MTRL, MESH and SHAD relationships.
- The built-in suite is now **74 tests**. Dev25's external **306/306 mesh-bearing retail GMX** byte-identical no-op gate remains inherited evidence; dev28's new TXIF synthesis is structurally regression-tested without bundling proprietary corpus inputs.
- Dev28 creates GMX texture *references/bindings*, not the underlying console texture payload. Existing TEX/DDS conversion/rebuild workflows remain responsible for the referenced resource itself.
- Audio replacement/rebuilding remains deliberately deferred while GMX compiler/GUI work is prioritized.

- Added deterministic `.siigmod` packages with `mod-pack`, `mod-package-info`, and `mod-apply`. Packages store baseline-dependent binary deltas and metadata rather than clean source assets.
- Equal-size replacements use sparse changed-byte ranges; variable-size replacements use copy/data delta streams. Source, payload, and reconstructed target SHA-256 values are verified during application.
- Exercised the package layer against external retail `text.bin`: a one-character localization edit produced a 1,184-byte package with a **1-byte delta payload**, then rebuilt identically in a fresh workspace and passed `mod-verify`.
- Expanded external no-edit retail round-trip evidence to **2,197 completed byte-identical checks**, including **307/307 GMX**, **1,258/1,258 DAT**, **394/394 MAP**, **47/47 stage3D**, **30/30 stagewall**, 3/3 TEX, 2/2 ANM, 153/153 COL, systemfont, and localization.
- Optimized `png2col` for SIIG's normal opaque black/white masks while retaining the exact threshold fallback for arbitrary edited images.
- Expanded the dependency-free regression suite to **69 tests**.

- Added an integrated mod workspace: `mod-init`, `mod-list`, `mod-export`, `mod-export-archive`, `mod-stage`, `mod-stage-archive`, `mod-build`, and `mod-verify` now connect editable assets to native rebuilders and affected-BBX-only patch builds.
- Workspaces fingerprint the clean source rip, track editable baselines separately from staged native replacements, rebuild only changed BBX archives, and emit a machine-readable `MOD_BUILD_REPORT.json`.
- Xbox `.gz` BBX changes can be emitted as deterministic game-relative gzip patch files; raw BBX replacements are emitted directly. PS3 NPDRM/SDAT re-encryption remains an explicit packaging boundary.
- Upgraded GMX/localization evidence from synthetic-only fixtures to user-supplied retail corpus validation: **13/13** `player.bin` GMXs rebuilt byte-identically, retail `text.bin` rebuilt from **542 strings**, and retail `message.bin` rebuilt from **284 groups / 1295 strings per language**. Proprietary validation inputs are not bundled.
- Added a complete mod-workspace regression and expanded the dependency-free suite to **68 tests**.

- Expanded native asset functionalization from **7 to 11 of 14 known asset families** while keeping all 14 viewable/exportable.
- Added `stagewall-build` for deterministic wall/Xwall/stage-generator table compilation from CSV/JSON.
- Added `stage3d-build` for native Bmap/Xmap/map4/map5 `0x118` route/placement records, with optional template preservation of inactive/tail bytes.
- Added `gmx-edit-export` + `gmx-build`, a conservative fixed-layout GMX native editor for geometry/index arrays, texture references, material values, bone matrices, motion durations, and matrix-animation samples while preserving the original chunk graph.
- Added `text-build` and `message-build` for dedicated native localization compilation, including Unicode-readable message scripts mapped back to SIIG's language-specific glyph bytes before Shift-JIS repacking.
- Added byte-identical/synthetic structural regression gates for the new builders; the dependency-free suite now contains **67 tests**.
- Template-free GMX root/scene construction, native vertex/material schema synthesis, multi-bone animation import, and donor-free TEX creation are now implemented structurally. Remaining major GMX gaps include glTF skin/joint-weight import, platform shader microcode compilation, opaque field semantics, and runtime validation of fully original scenes; audio replacement remains deferred.

- Began the native asset-functionalization phase: extraction targets now have explicit viewing/editing/rebuild capability levels rather than a binary decoded/unknown status.
- `png2tex` supports both template-preserving rebuilds and donor-free canonical Xbox 360/PS3 TEX synthesis; Xbox synthesis follows the single layout confirmed across all supplied textures.
- Added `dat-build`, `map-build`, `anm-build`, and `png2col` for native script, map, animation-table, and collision-mask editing.
- Added `png2font` for rebuilding the XOR-obfuscated system-font CRP from an edited atlas.
- `map2png` now emits a lossless `*.map.edit.json`; full rips emit `validation/ASSET_CAPABILITIES.json`.
- Added `asset-capabilities` and byte-identical round-trip regression gates for TEX, DAT, MAP, ANM, and COL.
- Expanded the dependency-free regression suite to 62 tests.

- Traced all six named iOS `moveThe*` boss state machines to dedicated Xbox and PS3 console movers; the console dispatcher keeps the original mobile IDs **70..75 = 0x46..0x4B** exactly.
- Added direct semantic anchors for every original boss: THE MOON event sequencing, THE SUN's four-pair ±512→6144 ramp, GIGANTIC UFO's original +4096 path, LADYBUG's May-11 guard, MANDALA's 109/69 geometry coefficients, and UNKNOWN's original ±2560 motion.
- Recovered the exact May11→June10 constructor fingerprints lost at the dev19 continuity boundary: 87.947883%, 86.072423%, 87.995050%, 89.208633%, 92.691316%, and 92.075472%.
- Distinguished raw relocation-induced mnemonic changes from gameplay changes in June→retail GIGANTIC UFO/UNKNOWN, while isolating a genuine LADYBUG behavior retune between May 9 and May 11.
- Expanded the dependency-free regression suite to 56 tests.

- Extended `ios-console-lineage-info` with direct six-boss constructor/pool ancestry, the console `0x96..0xAB` enemy-handler family, World-5 integration chronology, and exact cross-build `Invinf_LoadScript` anchors.
- Preserved **29/30** Stage-3 subordinate pool type/capacity slots from iOS to console; only THE SUN type 38 changes from 36 to 60 objects, independently matching retail PS3.
- Located the major six-boss constructor refactor at May 11→June 10 while May9→May11 and June10→retail remain 100% mnemonic-sequence matches.
- Recorded concrete GLUTTONY, ULTIMATE UFO, and VERTEBRATE pool retunes and kept `0x9F` as the deliberate all-build null slot.
- Expanded the dependency-free regression suite to 55 tests.

- Added `ios-console-lineage-info` and source-only iOS→console function correspondence data for MAP loading/update/rendering, DAT timing/dispatch, and generator assembly.
- Proved iOS command timing as `authored_delta * runtime_fps / 30` and scroll speed as `authored_speed * 30 / runtime_fps`, establishing the same 30 Hz authored-time invariant later used by the console frame-multiplier model.
- Matched iOS `Invinf_LoadMap`, `calcMap`, and `drawMap2` to the console MAP subsystem, including the same 49-tile + X/Y reflection encoding.
- Corrected the effective iOS command frontier to `0x8D` (`analyzeScript2` extends beyond the primary `0x83` analyzer); console expands the language through `0xCE`.
- Matched the 24-block iOS generator to the console selection/append routines and decoded iOS generated-layer capacity as `6144 = 24×8×32` bytes per layer.
- Compared normal stages 1-1..3-6: 91.7% aggregate opcode-sequence LCS, with widespread parameter retuning and a major 3-6 rewrite.
- Expanded the dependency-free regression suite to 54 tests.

- Resolved the six Survival substitution gates as Evolution Tree stage-node status checks: unlocked Chimera Extra 31..36 stages run normally, while locked nodes substitute six predetermined existing Extra stages.
- Proved the crossover unlock chain: SILVER HAWK / INTER GRAY / BLACK FLY purchase states unlock Chimera A stages, and clearing each A stage unlocks its B counterpart.
- Traced `dischargeEnemyShot_FPS60` to map boss helper-pool type IDs to named projectile handlers, proving concrete original→V2 attack repertoire swaps for all six Stage-3 bosses.
- Recovered explicit V2-only behavior branches in THE SUN, GIGANTIC UFO, and UNKNOWN; UNKNOWN_V2 doubles several internal helper values and invokes the dedicated `setVer2Destroy` defeat action.
- Proved a C-1A/C-1B King Fossil boss-parameter difference: an executable-backed reload/countdown source changes 48→96, while another unresolved parameter changes 6→3.
- Added `mobile-exclusives-info`, a source-only JSON reference command for Survival/Chimera substitutions, terminal endings, and conservative V2 behavior/attack-pool mappings.
- Expanded the dependency-free regression suite to 53 tests.

- Corrected and closed the mobile Level-9 split: iOS `level9_stage1EX..6EX` are the six Chimera crossover stages; Android substitutes V2-based placeholder scripts/maps in those slots.
- Proved iOS DAT opcodes `0x52..0x54` as `KING_FOSSIL`, `TWILIGHT_MIRAGE`, and `APARTHEAD` from the ARMv7 `analyzeScript` jump table and retained constructors.
- Mapped Extra 23..28 / `level8_stage3EX..8EX` to the six DELETION missions and their Stage-3 V2 boss counterparts.
- Reconstructed the full 36-node Survival selection graph, terminal nodes 28..35, eight ending names, and achievement indices 52..59.
- Recorded six conditional Survival stage substitutions while leaving the controlling status-byte meaning unresolved.
- Added exact original/V2 entity-pool diffs plus Chimera boss constructor/helper/attack symbol tables and third-party gameplay-footage provenance.
- Expanded the dependency-free regression suite to 52 tests.

- Added clean-room mobile package research for the supplied iOS 4.1.0 IPA and Android 1.0.4 APK without bundling either package or extracted assets.
- Added `mobile-inventory`, `mobile-compare`, `tzip-extract`, and `mobile-map-info`, plus the dependency-free `siig_mobile.py` helper.
- Proved all 737 supplied mobile DAT files parse with the existing console DAT parser and documented the little-endian mobile MAP header variant across 493 MAP files.
- Matched the iOS and console generator MAP corpora at exactly 330 files / 645 nonempty layers; console cell capacity is exactly 2× while populated content is not simply duplicated.
- Isolated the iOS/Android authored-content split to the six Level-9 DAT/MAP pairs and proved their terminal opcodes 0x4C..0x51 as THE_MOON_V2, THE_SUN_V2, GIGANTIC_UFO_V2, LADYBUG_V2, MANDALA_V2, and UNKNOWN_V2.
- Recovered iOS symbol anchors for `Invinf_LoadScript`, `Invinf_LoadMap`, generator, Survival, map, and representative enemy/boss functions.
- Expanded the dependency-free regression suite to 51 tests.

- Audited the retail post-6200 Ultimate UFO reset path and proved the 6030 state-1 destruction and 6200 `bos_015k` shutdown do not clear camera gate `+0x11C`.
- Located the exact Xbox clear instruction at `0x8212DD20`: it is reached only through part 0/state 0, normally via generic vtable `+0x48` at `0x820FBEE8`.
- Excluded Normal 5-3 DAT cleanup and the generic lifetime watchdog as established ordinary reset triggers, and proved manager removal itself is destructor-only. No ordinary Normal 5-3 post-6200 `+0x48` caller is proven; the normal-ending camera-gate clear therefore remains a runtime-only question rather than an assumed event.
- Bracketed June 10 prototype Ultimate UFO debug-registration removal to ~427.367–427.400 s at the 5-3 completion white-out, while keeping this footage result observational rather than executable proof.

- Added `field-camera` for frame-by-frame procedural eye/target reconstruction from real `fld014` / `fld015` matrix animation plus an explicit camera preset.
- Validated normal-5-3 Ultimate UFO Mframes 5897..6300: all 404 real `fld015` samples are rear-follow under preset 4, including dynamic-X stress cases.
- Modeled the GMX serialized affine → runtime row-vector matrix representation bridge and decoded the retail timed-camera-transition gate used by Ultimate UFO reset.
- Recovered May prototype phase-12 Mframe-6200 direct `UltimateUfo::Vanish` behavior and documented the later ending split.

- Added `pa-route-info` and four machine-readable cross-build PA-route reference tables, using PS3 retail plus Xbox retail/June 10/May 11/May 9 executable evidence.
- Recovered the prototype debug name `Route::SetPaRoute`, proved the retail/June category-0 + state `(4,1)` gate, identified May 11's earlier state-only gate, and documented the missing corresponding May 9 setup branch.
- Proved the known retail setup selects `cam01_op1.gmx`; `cam02_op1.gmx` remains supported by `SetPaRoute` but without a proven retail activation callsite.
- Closed the special-stage reload chain: DAT `WARNING [12]` directly requests Bmap13/fld014 and `WARNING [14]` requests Bmap15/fld015 through executable transition state writes; boss spawn alone is not the trigger.
- Traced the common HP-zero dispatch into Ultimate UFO destruction state, recovered prototype `UltimateUfo::Vanish`, and documented the executable late-phase destruction actions at frames 6030 and 6200.
- May 9 debug HUD evidence now names Ultimate UFO Mframe/Sframe/state plus Umb/Tow/Fan/Ring col/dis status; project-owner footage supplies corroborating gameplay-role labels.
- Corrected dev11: May 9/May 11 runtime ID 0xD9 is bos_015k.gmx, the same late asset moved to ID 0xD8 in June/retail.
- Separated normal 5-3 from DLC Bonus 5-6 and proved the Bonus 5-6 immediate main-body destruction shortcut in both retail Xbox and PS3.
- Proved Ultimate UFO Mframe directly drives fld015.gmx in all five builds and reconstructed cam01 animated-to-procedural PA camera fallback.
- Real late fld015 matrices plus preset 4 produce a stable `(0,-60,+40)` relative eye offset along the late +Y route, classified conservatively as rear-follow geometry.
- Added `camera-preset`, a semantic inspector for the 32 retail camera presets with optional executable-backed dynamic horizontal-response evaluation.
- Resolved camera preset word 0 as perspective FOV degrees, word 1 as uniform scene/view scale, words 2–4 as the camera-eye offset, and words 5–7 as scene/view translation.
- Resolved words 8–10 as dynamic horizontal-response gain plus target/eye local-X response scales using normalized runtime coordinates; gameplay labels remain deliberately unguessed.
- Proved words 12–29 are three renderer fog profiles `{start, end, RGBA}` through `fogRange` and `vFogColor` consumers.
- Traced word 11 as one shared scalar forwarded to `collada_edge1`, `collada_face1`, and `collada_face2`; its virtual-setter meaning remains explicitly unresolved.
- Added `CAMERA_PRESETS_RUNTIME_SEMANTIC.csv` while retaining the untouched raw executable table and structural runtime table.
- Added procedural route orientation and `route-camera-playback`; dev7 corrects matrix-animation playback to the retail 30 Hz logical-frame clock and adds explicit animated camera/field exporters; the current dependency-free regression suite passes 53 tests.
- Added `route-resample`, reproducing the retail PS3 non-loop route segment builder at a user-supplied constant spacing: equal-distance linear subdivision, the exact straight/curve classifier, six-state tangent-axis selection, and cubic Hermite interpolation.
- Added `route-playback`, which applies caller-supplied DAT SCROLL_02 timing to the executable-backed route state machine, including loop wrapping and linear mid-segment spacing rebuilds. Route↔DAT pairing and route-object activation remain explicit caller inputs rather than inferred.
- Added runtime-initialized 32 × 30 camera-preset values plus a structural per-word schema derived from the camera initializer/consumer call chain; ambiguous gameplay labels remain unresolved.
- Added five-build executable-derived runtime entity/primitive registry tables with decoded 0x2C record fields and renderer-group selectors.
- `stage3dmap` exports the exact executable-ordered route-source control points and record-0 origin fallback as CSV/OBJ.
- Added `gmxtrack` for GMX matrix-animation CSV and translation-path OBJ export; validated the four retail route/camera GMXs and all six tracks.
- Validated direct extraction of the original retail Xbox 360 `LIVE` STFS and PS3 type-1 PKG supplied for this project.
- Added optional OpenSSL acceleration for finalized PS3 PKG AES-CTR with a dependency-free Python fallback and equivalence tests.
- Added internal authenticated decryption of SIIG's six NPDRM SDAT resources; TrueAncestor-style `.bin.gz.dat` files remain optional fallback inputs only.
- Added built-in Sony 989SND/SCREAM SBlk v3 parsing and PS-ADPCM WAV export for all 84 retail PS3 sound streams.
- Restored Stage Explorer v5 runtime scrolling: SCROLL_01/02/03 drive layers 0/1/2, with 30 Hz playback controls and 468 decoded scroll events across the retail stage corpus.
- Added content-addressed outer-package caching for `--resume`, avoiding repeated STFS/PKG/ZIP unpacking when the input hash is unchanged.
- Fixed the STFS `CON` first-hash-table initialization path and added a regression fixture.
- Integrated PS3 EBOOT-backed 3D placement, route-point, scroll, and timing corrections into the current source tree.

The v2.5 linked-data Asset Viewer and earlier format research remain included. This remains a development build while automatic PA-route activation timing, the word-11 material scalar, shader ISA work, Blender runtime validation, and project licensing remain open.

## Release folder layout

```text
SIIG_Asset_Toolkit_v2.8.0-dev26/
├── siig_toolkit.py and companion modules
├── SIIG_*.bat launchers
├── docs/          guides, format research, project records, release history
├── reference/     tables, provenance, samples, system-font support data
├── validation/    machine-readable validation reports
├── tools/         optional Ghidra helper
├── addons/        Blender add-on package and source
└── LICENSES/      required third-party notices
```

Use [`docs/README.md`](docs/README.md) as the central index.

## Requirements

- Python **3.10 or newer**.
- No third-party Python packages are required.
- FFmpeg is optional and only needed to decode Xbox 360 XMA2 streams to PCM WAV. Without FFmpeg, the toolkit still writes RIFF-wrapped `.xma` files and manifests.
- PS3 SIIG's six inner NPDRM SDAT resources are decrypted and authenticated internally. Matching `*.bin.gz.dat` files may still be supplied as a fallback for unsupported variants.

## Recommended first run

From Command Prompt or PowerShell in the toolkit folder:

```bat
python siig_toolkit.py --version
python siig_toolkit.py selftest
python siig_toolkit.py doctor "C:\path\to\game-package"
```

On Windows, `py -3` may be used instead of `python`.

## One-click full-game extraction

Drag an Xbox 360 STFS package, PS3 PKG, extracted game ZIP, or extracted game folder onto `SIIG_Rip_Game.bat`.

Command-line equivalent:

```bat
python siig_toolkit.py rip-game "C:\path\to\game-package" -o "C:\path\to\SIIG_Ripped" --resume
```

PS3 requires no external SDAT step for the supplied retail package:

```bat
python siig_toolkit.py rip-game "C:\Games\SIIG.pkg" -o "C:\Rips\SIIG_PS3" --resume
```

`--ps3-sdat-dir` remains available only as a fallback for pre-decrypted `.bin.gz.dat` payloads. `--rap` accepts a 16-byte RAP for workflow compatibility, but SIIG's six supplied SDAT resources do not require RAP-derived keys.

See `docs/guides/FULL_GAME_RIP.md` and `docs/guides/CONTAINER_INPUT_NOTES.md`. For native editing/rebuild workflows, see `docs/guides/NATIVE_ASSET_ROUNDTRIP.md`.

## Verify a completed rip

```bat
python siig_toolkit.py verify-output "C:\path\to\SIIG_Ripped"
```

Or drag the output folder onto `SIIG_Verify_Rip.bat`. Full verification checks report consistency, privacy, file sizes, SHA-256 hashes, and leftover partial files. Use `--quick` to omit hashing.

## Main capabilities

### Package and archive extraction

- Header-based Xbox 360 STFS detection: `CON `, `LIVE`, and `PIRS`.
- PlayStation 3 type-1 PKG extraction for finalized and non-finalized/debug packages.
- ZIP and extracted-directory inputs.
- BBX extraction for `01 42 42 58` containers, including unnamed resources, nested BBX archives, gzip wrappers, filename hierarchy, exact filename-hash verification, and CSV/JSON manifests.
- Configurable extraction limits and atomic writes.

### Repacking and modding research

- Rebuild edited TEX, DAT, MAP, ANM, COL, and system-font resources back to native game formats before BBX repacking.
- `asset-capabilities` reports which extracted families are viewable, editable, native-buildable, or still one-way.
- Rebuild extracted BBX directories from their manifests with canonical mode/hash/index/name/payload layout.
- Preserve unnamed resource identifiers and reserved header bytes.
- Recompute named hashes by default or preserve deliberate mismatches.
- Verify every output immediately and write a detailed repack report.
- Produce deterministic gzip-wrapped archives when requested.

### Asset browsing and Blender

- Generate a searchable offline asset browser with a small HTML shell and local linked payloads.
- Inspect images, browser-playable audio, text/CSV/JSON, hashes, GMX/glTF/OBJ structure, and interactive wireframes.
- Browse paginated cards with lazy thumbnails for converted and raw SIIG asset formats.
- Import GMX files into Blender 3.6+ with the bundled add-on, using the same exporter as the CLI.
- Serve an output directory on localhost when browsers restrict direct file access.

### Models and textures

- GMX → glTF 2.0 with indexed triangles/lines, positions, normals, UVs, vertex colors, hierarchy, rigid attachment, materials, textures, and transform animation.
- GMX → OBJ as a lightweight static-geometry option.
- Xbox 360 tiled TEX ↔ PNG using the original TEX as a rebuild template, preserving Xenos layout/padding/header fields.
- PS3 RSX-wrapped linear A8R8G8B8 TEX ↔ PNG using the original wrapper as a rebuild template.
- System-font XOR deobfuscation, 2048×3392 atlas export, native CRP pixel rebuild, 6,732-record glyph table, and AngelCode BMFont descriptor.

### Audio and localization

- Xbox 360 XACT3 XWB/XSB extraction, cue naming, XMA2 RIFF wrapping, and optional FFmpeg WAV decoding.
- Lossless preservation of ready-to-use WMA/AT3 media.
- PS3 Sony 989SND/SCREAM SBlk v3 parsing, stream naming, PS-ADPCM decoding, and built-in PCM WAV export; original banks are retained.
- `text.bin` and `message.bin` localization export to UTF-8 CSV, JSON, corrected scripts, raw scripts, and per-language text.

### Structured gameplay data

- DAT command streams to timed semantic CSV/JSON with absolute frames, executable-derived opcode names, confidence labels, lossless raw words, and CSV/JSON → native DAT rebuilding.
- MAP parsing for all three independently sized tile/sprite layers, plus lossless editable JSON → native MAP rebuilding.
- Categorical, grayscale, and verified atlas-backed MAP PNG output.
- Offline Stage Explorer v5 with runtime stage pairing, embedded atlases, MAP layer/composite views, SCROLL_01/02/03 playback, cell inspection, and DAT timeline filtering.
- COL one-bit collision masks ↔ PNG using an original-header template.
- ANM model/group clip ranges ↔ CSV/JSON, including native rebuild of start/end frames and loop behavior.
- Bmap/Xmap/map4/map5 3D path and GMX-placement tables to JSON/CSV/OBJ, including exact runtime route-source control points.
- Wall/Xwall repeat strips and `stage_generate.bin` candidate tables to JSON/CSV.
- Xenos compiled-shader headers, metadata strings, hashes, and raw microcode extraction.

### Research support

- `scan` for JSON descriptions of known formats.
- `tools/ghidra/ApplySIIGFunctionNames.java` for optional confirmed Ghidra labels.
- `gmxtrack` for decomposed GMX animation matrices and translation trajectories.
- Machine-readable validation tables and format notes, including the five-build runtime entity registry, raw/runtime-initialized camera presets, and route-resampler evidence.
- Privacy sanitizer for older JSON metadata.
- Source, license, attribution, and AI-assistance records.

## Common commands

### Inspect the environment and input

```bat
python siig_toolkit.py doctor "C:\path\to\input"
```

### Extract only the outer STFS/PKG container

```bat
python siig_toolkit.py unpack-container "C:\path\to\package" -o outer_files --clean
```

### Extract a BBX archive

```bat
python siig_toolkit.py extract player.bin -o extracted --convert-gltf --convert-tex
```

### Recursively extract a directory of BBX archives

```bat
python siig_toolkit.py extract game_bins -o extracted --recursive --convert-gltf --convert-tex
```

### Build or rebuild the stage explorer

```bat
python siig_toolkit.py stageviz "C:\path\to\SIIG_Ripped" -o stage_explorer
```

Open `stage_explorer\SIIG_Stage_Explorer.html`. The file is self-contained and makes no network requests.

### Render a MAP with a verified atlas

```bat
python siig_toolkit.py map2png level1_stage1.map -o map_preview ^
  --atlas fence1_512.png --atlas-step 30 --csv
```

Without `--atlas`, the command writes exact categorical or grayscale cell visualizations.

### Repack an extracted BBX

```bat
python siig_toolkit.py extract map.bin -o work
python siig_toolkit.py repack-bbx work\map -o map_repacked.bin
```

The second command reads `work\map\manifest.json`, writes atomically, verifies the new archive, and creates a `.repack.json` report. See `docs/guides/BBX_REPACK_NOTES.md` before modifying game data.

### Build and open the asset viewer

```bat
python siig_toolkit.py asset-viewer "C:\path\to\SIIG_Ripped" -o viewer
python siig_toolkit.py serve viewer
```

The server binds only to `127.0.0.1`. Keep `SIIG_Asset_Viewer.html` beside its generated `viewer_assets` directory; the viewer is intentionally no longer one giant self-contained file.

### Install the Blender add-on

Install `addons/SIIG_Blender_Addon_v0.1.0.zip` through Blender's Add-ons preferences, then point its preferences at this toolkit folder. See `docs/guides/BLENDER_ADDON_NOTES.md`.

### Decode 3D stage paths and placements

```bat
python siig_toolkit.py stage3dmap extracted\stage -o stage3d
```

### Export GMX animation tracks

```bat
python siig_toolkit.py gmxtrack extracted\route -o gmx_tracks
```

This writes one decomposed CSV and translation-path OBJ per supported ANIM track. ANIM timestamps are exported as seconds; the observed sample rate is derived from the data.

### Resample or play a 3D route

```bat
python siig_toolkit.py route-resample extracted\stage\Xmap3_1.bin -o route_fixed --spacing 100
python siig_toolkit.py route-playback extracted\stage\Xmap3_1.bin extracted\script\level3_stage1.dat -o route_runtime --frame-multiplier 2
```

`route-resample` is the deterministic fixed-spacing analysis path. `route-playback` applies SCROLL_02 timing from the DAT to the executable-backed route runtime. Pairing and route-object activation are not guessed; use `--start-frame` and `--loop` only when supported by the case being investigated.

### Decode wall strips and generator candidates

```bat
python siig_toolkit.py stagewall extracted\stage -o stagewall
```

### Inventory Xbox 360 compiled shaders

```bat
python siig_toolkit.py shader-info extracted\shader -o shader_metadata
```

### Decode localization

```bat
python siig_toolkit.py text2csv "C:\path\to\Media" -o localization
```

### Decode audio

```bat
python siig_toolkit.py xact2wav sound.bin -o audio
```

### Decode the system font

```bat
python siig_toolkit.py font2png systemfont.bin -o systemfont_decoded
```

### Convert extracted models

```bat
python siig_toolkit.py gmx2gltf extracted -o gltf
python siig_toolkit.py gmx2obj extracted -o obj
```

### Run the built-in regression suite

```bat
python siig_toolkit.py selftest
```

## Typical full-rip output

```text
SIIG_Ripped\
├── assets\                  extracted resources and direct conversions
├── decompressed_bbx\        normalized BBX archives
├── audio\                   audio manifests and converted streams
├── localization\            combined UTF-8 exports
├── ready_files\             directly usable media copied unchanged
├── stage_explorer\
│   ├── SIIG_Stage_Explorer.html
│   ├── STAGE_MANIFEST.json
│   └── README.txt
├── asset_viewer\
│   ├── SIIG_Asset_Viewer.html
│   └── ASSET_VIEWER_REPORT.json
├── structured\
│   ├── dat\                  timed DAT CSV/JSON
│   └── map\                  MAP layers, metadata, and optional atlas renders
├── systemfont\              decoded atlas and glyph data
└── validation\
    ├── RIP_REPORT.json
    ├── RIP_REPORT.txt
    ├── OUTPUT_MANIFEST.json
    └── OUTPUT_MANIFEST.sha256
```

Output varies by platform and available source assets.

## Safety and reproducibility

The toolkit treats input packages as untrusted. Outer-container extraction is bounded by file-count, per-file, total-byte, and ZIP-ratio limits. Paths are normalized, traversal and symlink entries are rejected, collisions are detected case-insensitively, writes are atomic, gzip output is bounded, and nested BBX extraction has depth and entry budgets.

Defaults are intentionally generous for SIIG but can be lowered:

```bat
python siig_toolkit.py rip-game game.zip -o SIIG_Ripped ^
  --max-files 10000 --max-total-bytes 8589934592 ^
  --max-file-bytes 2147483648 --max-zip-ratio 200
```

See `docs/guides/SECURITY_NOTES.md`. Keep original packages read-only and verify output before archiving or sharing research results. Repacking never changes the extraction directory, but modified archives must be tested only on copies; it does not update outer-package metadata or executable references.

## Accuracy boundaries

Confirmed facts are separated from unresolved semantics. In particular:

- MAP cells are confirmed 2D tile/sprite data, not 3D wall placements.
- MAP atlas mapping and flip behavior are confirmed. SCROLL_01/02/03 are confirmed as layer 0/1/2 X/Y velocity setters; player-facing names for those layers remain unresolved.
- The Stage Explorer v5 runtime viewport integrates the confirmed scroll vectors at the logical 30 Hz authoring timebase, but it is still not a complete frame-accurate gameplay renderer.
- The 3D stage path, placement, and wall-strip tables are decoded, but complete runtime reconstruction still requires camera/route behavior, auxiliary-vector semantics, collision, and DAT 3D-control playback.
- Direct STFS/PKG readers have synthetic boundary tests and have been validated against the supplied original retail Xbox 360 LIVE package and PS3 type-1 PKG.

## Ethics, licenses, and redistribution

- Do not redistribute game packages, binaries, extracted textures/audio/models, or self-contained explorers containing embedded game atlases without permission.
- The source-only toolkit release contains no game assets.
- External tools such as FFmpeg, Ghidra, XEXLoaderWV, vgmstream, and TrueAncestor are not bundled.
- OpenAI ChatGPT assistance is disclosed in `docs/project/AI_DISCLOSURE.md`.
- Explicit sources and adaptations are recorded in `reference/provenance/SOURCES.csv`, `reference/provenance/PROVENANCE.json`, `docs/project/SOURCE_AUDIT.md`, and `docs/project/THIRD_PARTY_NOTICES.md`.
- TCRF/the Cutting Room Floor was not used and is an explicitly excluded research source; see `docs/project/SOURCE_EXCLUSIONS.md`.
- No license has yet been selected for the toolkit's original project code. See `docs/project/PROJECT_LICENSE_STATUS.md` before redistribution.

### Development note: 2.8.0-dev14

Retail Mframe 6030 uses part state 1 and Mframe 6200 only disables the owned `bos_015k` object. Neither action clears camera-controller `+0x11C`. The proven clear is conditional on a later part-0/state-0 reset through vtable `+0x48`; a destructor-only manager removal is not equivalent. See `docs/research/ULTIMATE_UFO_FINAL_RESET_DEV14.md` and `reference/tables/ULTIMATE_UFO_FINAL_RESET_AUDIT.csv`.

### Development note: 2.8.0-dev13

`field-camera` reconstructs the executable-backed procedural camera for an explicit field GMX/preset/frame range. It does not guess preset activation or player coordinates; optional runtime X/Y values apply the proven dynamic horizontal response. The supplied retail `fld015` validates all 404 frames 5897..6300 as rear-follow under preset 4.

Example:

```bash
python siig_toolkit.py field-camera fld015.gmx --preset 4 --start-frame 5897 --end-frame 6300 -o ufo_late.csv
```

### Development note: 2.8.0-dev12
Dev12 supersedes dev11's prototype registry interpretation: the late owned GMX is `bos_015k.gmx` in May as well as June/retail; only the runtime type shifts from May `0xD9` to later `0xD8`. Normal 5-3 and Bonus 5-6 destruction policies are now separated, and late preset-4 + `fld015` is classified as rear-follow geometry with explicit remaining camera-writer caveats.


Dev17 adds locally authored Survival Evolution-gating, V2 attack-pool/behavior, and Chimera A/B tables/helpers derived from the retained user-supplied iOS executable/resources. It does not add or redistribute game binaries/assets. Existing third-party gameplay videos remain observational corroboration only; no footage is bundled.


### THE SUN assembly presets (dev19)

See `docs/research/THE_SUN_RUNTIME_ASSEMBLY_2.10.0-dev19.md`.

### All-boss matrix (dev20)

`boss-matrix` reports all 18 console boss families in one evidence-grade-aware view. Every family now has a canonical catalog; 13 have deep executable-backed runtime reconstruction and five (THE MOON, LADYBUG, OCTOPUS, WATER STRIDER, NO_NAME) intentionally remain native-inspection-only until their deeper state/auxiliary assemblies are recovered. Supply `--root` with an extracted GMX folder to validate all root models from fresh bytes. See `docs/research/ALL_BOSS_RECONSTRUCTION_MATRIX_2.10.0-dev20.md`.

