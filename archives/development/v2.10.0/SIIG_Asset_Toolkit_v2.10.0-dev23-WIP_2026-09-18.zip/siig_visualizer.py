#!/usr/bin/env python3
"""Offline SIIG visualizer simulator.

The dev22 renderer is split into evidence layers:

* DAT timing/state is decoded from the game.
* The 29-value Visualizer Check parameter surface and SHAPE resource order are
  recovered facts.
* June 10 Visualizer Check footage is the primary visual reference for the
  feedback/trailing-copy renderer.  The footage strongly supports a ping-pong
  feedback image that is magnified/rotated every update while a fresh SHAPE
  stamp is injected at the spawn point.

Exact sprite pixels and a few control semantics (notably Position Fix and Fix
Rotation) are still not proven from code, so those remain labelled as visual
approximations rather than being presented as exact runtime behavior.
"""
from __future__ import annotations

import json
from pathlib import Path

import siig_toolkit as toolkit

VISUALIZER_OPCODES = set(range(0xC8, 0xCF))
MAX_SCRIPT_BYTES = 8 * 1024 * 1024

# Exact resource order recovered from visualizer.bin.
SHAPE_RESOURCES = (
    "WhiteCircle",
    "line",
    "3line",
    "square",
    "triangle",
    "WhiteCircle2",
    "line2",
    "3line2",
    "square2",
    "triangle2",
)

# 29 Visualizer Check controls, in the recovered parameter-row order.
PARAMETER_FIELDS = (
    "magnify_scale_x_min",
    "magnify_scale_x_max",
    "magnify_scale_y_min",
    "magnify_scale_y_max",
    "magnify_a_min",
    "magnify_a_max",
    "bg_r",
    "bg_g",
    "bg_b",
    "bg_a",
    "shape",
    "position_fix",
    "position_free_x",
    "position_free_y",
    "rotation_base",
    "add_rotation",
    "fix_rotation",
    "scale_x_min",
    "scale_x_max",
    "scale_y_min",
    "scale_y_max",
    "rgb_r_min",
    "rgb_r_max",
    "rgb_g_min",
    "rgb_g_max",
    "rgb_b_min",
    "rgb_b_max",
    "rgb_a_min",
    "rgb_a_max",
)


def _find_media(input_path: Path) -> Path | None:
    candidates = (
        input_path / "assets" / "Media",
        input_path / "Media",
        input_path / "assets" / "USRDIR",
        input_path / "USRDIR",
        input_path,
    )
    for candidate in candidates:
        if (candidate / "script").is_dir():
            return candidate
    return None


def _visualizer_timelines(input_path: Path | None) -> list[dict]:
    if input_path is None:
        return []
    media = _find_media(input_path)
    if media is None:
        return []
    result: list[dict] = []
    for path in sorted((media / "script").glob("*.dat"), key=lambda p: p.name.lower()):
        try:
            if path.stat().st_size > MAX_SCRIPT_BYTES:
                continue
            parsed = toolkit.parse_dat_bytes(path.read_bytes())
        except Exception:
            continue
        events = []
        for record in parsed["records"]:
            if record["opcode"] not in VISUALIZER_OPCODES:
                continue
            events.append({
                "frame": record["absolute_frame"],
                "opcode": record["opcode_name"],
                "args": record["args_signed"],
                "fields": record["semantic"]["fields"],
            })
        if events:
            result.append({
                "script": path.name,
                "duration_frames": parsed["duration_frames"],
                "events": events,
            })
    return result


def _html(dataset: dict) -> str:
    payload = json.dumps(dataset, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    template = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SIIG Visualizer Simulator</title>
<style>
:root{color-scheme:dark;background:#08090d;color:#eef1f7;font:14px system-ui,sans-serif}*{box-sizing:border-box}body{margin:0}header{padding:12px 16px;background:#111621;border-bottom:1px solid #293247;display:flex;gap:12px;align-items:center;flex-wrap:wrap;position:sticky;top:0;z-index:5}h1{font-size:18px;margin:0 18px 0 0}button,select,input{background:#1a2130;color:#eef;border:1px solid #3a465e;border-radius:6px;padding:6px 8px}button{cursor:pointer}main{display:grid;grid-template-columns:minmax(330px,430px) 1fr;min-height:calc(100vh - 58px)}aside{padding:14px;border-right:1px solid #293247;overflow:auto}section{padding:14px;min-width:0}fieldset{border:1px solid #2e394f;border-radius:8px;margin:0 0 10px;padding:10px}legend{color:#b9c7df;padding:0 5px}.row{display:grid;grid-template-columns:1fr 112px;gap:8px;align-items:center;margin:5px 0}.pair{display:grid;grid-template-columns:1fr 1fr;gap:6px}.quad{display:grid;grid-template-columns:repeat(4,1fr);gap:5px}.muted{color:#9ba8bd}.notice{padding:9px;border:1px solid #5b4b27;background:#251f14;color:#f0d99d;border-radius:8px;margin-bottom:10px}.good{border-color:#335d41;background:#15251b;color:#bde6c6}.canvas-wrap{display:flex;justify-content:center;align-items:center;min-height:440px;background:#000;border:1px solid #263047;border-radius:9px;overflow:hidden}canvas{display:block;max-width:100%;height:auto;background:#000}.timeline{margin-top:12px;border:1px solid #293247;border-radius:8px;overflow:auto;max-height:36vh}table{width:100%;border-collapse:collapse}th,td{padding:6px 8px;border-bottom:1px solid #222a3b;text-align:left}th{position:sticky;top:0;background:#151c29}.mono{font-family:ui-monospace,monospace;font-size:12px}.status{margin-top:8px;color:#b9c7df;font-family:ui-monospace,monospace}.small{font-size:12px}.schema{max-height:180px;overflow:auto;margin-top:7px;border:1px solid #252f42;border-radius:6px;padding:6px}.schema code{display:block;color:#b8c4d8;padding:1px 0}@media(max-width:950px){main{display:block}aside{border-right:0;border-bottom:1px solid #293247}.canvas-wrap{min-height:300px}}
</style></head><body>
<header><h1>SIIG Visualizer Simulator · dev22 feedback model</h1><button id="play" type="button">Pause</button><button id="reset" type="button">Reset feedback</button><label>SHAPE <select id="shape"></select></label><label>Volume <input id="volume" type="range" min="0" max="1" step="0.001" value="0.41"></label></header>
<main><aside>
<div class="notice good"><b>Primary visual reference: June 10 Visualizer Check Mode.</b> The canvas now uses a feedback/trailing-copy renderer: the previous image is magnified and rotated every logical update, then a fresh SHAPE stamp is injected. This matches the expanding translucent copies seen in the game far more closely than the old procedural-ring model.</div>
<div class="notice small">Recovered facts are kept separate from approximation: 49 ParameterSet presets, 57 SequenceSet entries, 29 values per parameter row, and the exact 10-resource SHAPE order are treated as data. Exact sprite pixels plus the final semantics of <b>Position Fix</b> and <b>Fix Rotation</b> remain unresolved.</div>
<fieldset><legend>Feedback / magnify</legend>
<div class="row"><label>Magnify Scale X min/max</label><div class="pair"><input id="magxmin" type="number" step="0.001" value="1.030"><input id="magxmax" type="number" step="0.001" value="1.030"></div></div>
<div class="row"><label>Magnify Scale Y min/max</label><div class="pair"><input id="magymin" type="number" step="0.001" value="1.030"><input id="magymax" type="number" step="0.001" value="1.030"></div></div>
<div class="row"><label>Magnify A min/max</label><div class="pair"><input id="magamin" type="number" step="0.001" value="1.000"><input id="magamax" type="number" step="0.001" value="1.000"></div></div>
<div class="row"><label>Rotation Base (deg/update)</label><input id="rotbase" type="number" step="0.1" value="0.1"></div>
<div class="row"><label>Add Rotation</label><input id="rotadd" type="number" step="0.1" value="0.0"></div>
<div class="row"><label>Fix Rotation <span class="muted">(approx)</span></label><input id="rotfix" type="checkbox"></div>
</fieldset>
<fieldset><legend>Stamp / spawn</legend>
<div class="row"><label>Position Fix <span class="muted">(0/1 observed control)</span></label><input id="positionFix" type="number" step="1" value="0"></div>
<div class="row"><label>Position Free X/Y</label><div class="pair"><input id="posx" type="number" step="0.01" value="0"><input id="posy" type="number" step="0.01" value="0"></div></div>
<div class="row"><label>Scale X min/max</label><div class="pair"><input id="sxmin" type="number" step="0.05" value="1"><input id="sxmax" type="number" step="0.05" value="1"></div></div>
<div class="row"><label>Scale Y min/max</label><div class="pair"><input id="symin" type="number" step="0.05" value="1"><input id="symax" type="number" step="0.05" value="1"></div></div>
</fieldset>
<fieldset><legend>Background RGBA</legend>
<div class="quad"><input id="bgr" aria-label="BG R" type="number" min="0" max="255" value="0"><input id="bgg" aria-label="BG G" type="number" min="0" max="255" value="0"><input id="bgb" aria-label="BG B" type="number" min="0" max="255" value="0"><input id="bga" aria-label="BG A" type="number" min="0" max="255" value="0"></div>
</fieldset>
<fieldset><legend>Stamp RGBA min/max</legend>
<div class="row"><label>R min/max</label><div class="pair"><input id="rmin" type="number" min="0" max="255" value="128"><input id="rmax" type="number" min="0" max="255" value="255"></div></div>
<div class="row"><label>G min/max</label><div class="pair"><input id="gmin" type="number" min="0" max="255" value="0"><input id="gmax" type="number" min="0" max="255" value="0"></div></div>
<div class="row"><label>B min/max</label><div class="pair"><input id="bmin" type="number" min="0" max="255" value="0"><input id="bmax" type="number" min="0" max="255" value="0"></div></div>
<div class="row"><label>A min/max</label><div class="pair"><input id="amin" type="number" min="0" max="255" value="19"><input id="amax" type="number" min="0" max="255" value="255"></div></div>
</fieldset>
<fieldset><legend>Recovered parameter schema</legend><div class="muted small">29 fields / preset · 49 presets · 57 sequences</div><div id="schema" class="schema mono"></div></fieldset>
<fieldset><legend>Decoded stage visualizer timeline</legend><div class="row"><label>Script</label><select id="script"></select></div><div class="row"><label>Authored frame</label><input id="frame" type="range" min="0" max="0" value="0"></div><div class="status" id="scriptStatus">No DAT timeline loaded.</div></fieldset>
</aside><section><div class="canvas-wrap"><canvas id="canvas" width="960" height="540"></canvas></div><div class="status" id="status"></div><div class="timeline"><table><thead><tr><th>Frame</th><th>Opcode</th><th>Arguments</th></tr></thead><tbody id="events"></tbody></table></div></section></main>
<script id="data" type="application/json">__DATA__</script><script>
const DB=JSON.parse(document.getElementById('data').textContent),$=id=>document.getElementById(id),can=$('canvas'),ctx=can.getContext('2d',{alpha:true});
const W=can.width,H=can.height,feedback=[document.createElement('canvas'),document.createElement('canvas')];for(const c of feedback){c.width=W;c.height=H}let front=0,running=true,last=performance.now(),accum=0,logicalFrames=0,rotationAccum=0;const STEP=1/60;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,Number(v)||0)),num=id=>Number($(id).value)||0,mix=(a,b,t)=>a+(b-a)*t,rad=d=>d*Math.PI/180;
const volume=()=>clamp(num('volume'),0,1),mixControl=(a,b)=>mix(num(a),num(b),volume());
function colorNow(){const v=volume();return [clamp(mix(num('rmin'),num('rmax'),v),0,255),clamp(mix(num('gmin'),num('gmax'),v),0,255),clamp(mix(num('bmin'),num('bmax'),v),0,255),clamp(mix(num('amin'),num('amax'),v),0,255)]}
function resetFeedback(){for(const c of feedback)c.getContext('2d').clearRect(0,0,W,H);front=0;logicalFrames=0;rotationAccum=0;drawDisplay()}
function shapeStamp(g,name,cx,cy,sx,sy,rgba,stampAngle){g.save();g.translate(cx,cy);g.rotate(stampAngle);g.scale(sx,sy);g.strokeStyle=`rgba(${rgba[0]|0},${rgba[1]|0},${rgba[2]|0},${rgba[3]/255})`;g.fillStyle=g.strokeStyle;g.lineCap='round';g.lineJoin='round';const r=42;switch(name){case 'WhiteCircle':g.lineWidth=8;g.beginPath();g.arc(0,0,r,0,Math.PI*2);g.stroke();break;case 'line':g.lineWidth=8;g.beginPath();g.moveTo(-64,0);g.lineTo(64,0);g.stroke();break;case '3line':g.lineWidth=7;for(const y of [-17,0,17]){g.beginPath();g.moveTo(-58,y);g.lineTo(58,y);g.stroke()}break;case 'square':g.lineWidth=8;g.strokeRect(-42,-42,84,84);break;case 'triangle':g.lineWidth=8;g.beginPath();g.moveTo(0,-52);g.lineTo(48,36);g.lineTo(-48,36);g.closePath();g.stroke();break;case 'WhiteCircle2':g.beginPath();g.arc(0,0,r,0,Math.PI*2);g.fill();break;case 'line2':g.lineWidth=18;g.beginPath();g.moveTo(-64,0);g.lineTo(64,0);g.stroke();break;case '3line2':g.lineWidth=15;for(const y of [-21,0,21]){g.beginPath();g.moveTo(-58,y);g.lineTo(58,y);g.stroke()}break;case 'square2':g.fillRect(-42,-42,84,84);break;case 'triangle2':g.beginPath();g.moveTo(0,-52);g.lineTo(48,36);g.lineTo(-48,36);g.closePath();g.fill();break}g.restore()}
function logicalStep(){const src=feedback[front],dst=feedback[1-front],g=dst.getContext('2d',{alpha:true});g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='copy';g.clearRect(0,0,W,H);g.globalCompositeOperation='source-over';const ba=clamp(num('bga'),0,255)/255;if(ba>0){g.fillStyle=`rgba(${clamp(num('bgr'),0,255)|0},${clamp(num('bgg'),0,255)|0},${clamp(num('bgb'),0,255)|0},${ba})`;g.fillRect(0,0,W,H)}const mx=Math.max(0.001,mixControl('magxmin','magxmax')),my=Math.max(0.001,mixControl('magymin','magymax')),ma=clamp(mixControl('magamin','magamax'),0,2);const rotStep=num('rotbase')+num('rotadd')*volume();const fix=Number.isFinite(num('positionFix'))?Math.round(num('positionFix')):0;const freeX=num('posx'),freeY=num('posy');const cx=W/2+(fix?0:freeX),cy=H/2+(fix?0:freeY);g.save();g.globalAlpha=Math.min(1,ma);g.translate(cx,cy);g.rotate(rad(rotStep));g.scale(mx,my);g.translate(-cx,-cy);g.drawImage(src,0,0);g.restore();rotationAccum+=rotStep;const rgba=colorNow(),sx=mixControl('sxmin','sxmax'),sy=mixControl('symin','symax');const stampAngle=$('rotfix').checked?rad(-rotationAccum):0;shapeStamp(g,$('shape').value,cx,cy,sx,sy,rgba,stampAngle);front=1-front;logicalFrames++}
function drawDisplay(){ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,W,H);ctx.fillStyle='#000';ctx.fillRect(0,0,W,H);ctx.drawImage(feedback[front],0,0);const v=volume(),name=$('shape').value;const mx=mixControl('magxmin','magxmax'),my=mixControl('magymin','magymax'),ma=mixControl('magamin','magamax');$('status').textContent=`${name} · volume ${v.toFixed(3)} · feedback scale ${mx.toFixed(3)}×${my.toFixed(3)} · feedback A ${ma.toFixed(3)} · rotation/update ${(num('rotbase')+num('rotadd')*v).toFixed(2)}° · ${logicalFrames} logical frames`;}
function tick(now){let dt=Math.min(0.1,(now-last)/1000);last=now;if(running){accum+=dt;while(accum>=STEP){logicalStep();accum-=STEP}drawDisplay()}requestAnimationFrame(tick)}
for(const name of DB.evidence.shape_resources){const o=document.createElement('option');o.value=name;o.textContent=`${DB.evidence.shape_resources.indexOf(name)} · ${name}`;$('shape').appendChild(o)}$('shape').value='WhiteCircle';
$('schema').innerHTML=DB.evidence.parameter_fields.map((x,i)=>`<code>${String(i).padStart(2,'0')} · ${x}</code>`).join('');
$('play').onclick=()=>{running=!running;$('play').textContent=running?'Pause':'Play';last=performance.now()};$('reset').onclick=resetFeedback;
for(const el of document.querySelectorAll('input,select')){if(['script','frame'].includes(el.id))continue;el.addEventListener('input',()=>{if(!running)drawDisplay()})}
const sel=$('script'),frame=$('frame'),events=$('events'),scriptStatus=$('scriptStatus'),timelines=DB.timelines||[];if(timelines.length){for(const t of timelines){const o=document.createElement('option');o.value=t.script;o.textContent=t.script;sel.appendChild(o)}}else{const o=document.createElement('option');o.textContent='No decoded DAT timeline';o.value='';sel.appendChild(o);sel.disabled=true;frame.disabled=true}
function renderTimeline(){const t=timelines.find(x=>x.script===sel.value);events.innerHTML='';if(!t){scriptStatus.textContent='No DAT timeline loaded.';return}frame.max=t.duration_frames||0;const f=Number(frame.value);let active=false,display=false,seq=null,volumeScale=null,changeTime=null;for(const e of t.events){const tr=document.createElement('tr');tr.innerHTML=`<td>${e.frame}</td><td>${e.opcode}</td><td class="mono">${e.args.join(' ')||'—'}</td>`;events.appendChild(tr);if(e.frame>f)continue;if(e.opcode==='VL_START')active=true;if(e.opcode==='VL_END')active=false;if(e.opcode==='VL_DISP_ON')display=true;if(e.opcode==='VL_DISP_OFF')display=false;if(e.opcode==='VL_SEQUENCESET')seq=e.args[0];if(e.opcode==='VL_VOLUME_SCALE')volumeScale=e.args[0];if(e.opcode==='VL_CHANGETIME')changeTime=e.args[0]}scriptStatus.textContent=`frame ${f} · active ${active?'yes':'no'} · display ${display?'on':'off'} · sequence ${seq??'—'} · change time ${changeTime??'—'} · volume scale ${volumeScale??'—'}`}
sel.onchange=()=>{frame.value='0';renderTimeline()};frame.oninput=renderTimeline;renderTimeline();resetFeedback();requestAnimationFrame(tick);
</script></body></html>'''
    return template.replace("__DATA__", payload)


def build_visualizer_simulator(input_path: Path | None, output: Path) -> dict:
    timelines = _visualizer_timelines(input_path)
    dataset = {
        "format": "SIIG_VISUALIZER_SIMULATOR",
        "version": 2,
        "timelines": timelines,
        "evidence": {
            "primary_visual_reference": "June 10 Visualizer Check Mode footage",
            "runtime_assets": ["visualizerSet.bin.gz.sdat", "ParameterSet.nut", "SequenceSet.nut"],
            "parameter_preset_count": 49,
            "sequence_count": 57,
            "parameter_width": 29,
            "parameter_fields": list(PARAMETER_FIELDS),
            "shape_resources": list(SHAPE_RESOURCES),
            "dat_opcodes": ["VL_START", "VL_END", "VL_DISP_ON", "VL_DISP_OFF", "VL_SEQUENCESET", "VL_CHANGETIME", "VL_VOLUME_SCALE"],
            "render_model": "ping-pong framebuffer feedback: magnify/rotate prior image, then inject one fresh shape stamp",
            "footage_backed_defaults": {
                "magnify_scale_x": 1.030,
                "magnify_scale_y": 1.030,
                "magnify_a": 1.000,
                "shape": 0,
                "position_fix": 0,
                "position_free": [0, 0],
                "rotation_base": 0.1,
                "add_rotation": 0.0,
                "fix_rotation": 0,
                "scale_x": 1.0,
                "scale_y": 1.0,
                "rgb_r": [128, 255],
                "rgb_g": [0, 0],
                "rgb_b": [0, 0],
                "rgb_a": [19, 255],
            },
            "unresolved": [
                "exact pixel content of the ten visualizer shape sprites",
                "final code-level semantics of Position Fix",
                "final code-level semantics of Fix Rotation",
                "exact update/compositing order until the renderer path is traced in executable code",
            ],
        },
    }
    output.mkdir(parents=True, exist_ok=True)
    path = output / "SIIG_Visualizer_Simulator.html"
    toolkit.write_text_atomic(path, _html(dataset), encoding="utf-8")
    report = {
        "format": dataset["format"],
        "version": dataset["version"],
        "timeline_count": len(timelines),
        "event_count": sum(len(item["events"]) for item in timelines),
        "parameter_preset_count": 49,
        "sequence_count": 57,
        "shape_count": len(SHAPE_RESOURCES),
        "html": path.name,
    }
    toolkit.write_json_private(output / "VISUALIZER_SIMULATOR_MANIFEST.json", report, ensure_ascii=False)
    return report
