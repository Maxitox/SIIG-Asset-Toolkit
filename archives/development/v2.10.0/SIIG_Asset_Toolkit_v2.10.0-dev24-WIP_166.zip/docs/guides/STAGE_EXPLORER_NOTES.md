# Offline stage explorer v6

Run after extraction:

```text
python siig_toolkit.py stageviz <SIIG_Ripped> -o stage_explorer
```

The generated HTML is self-contained and makes no network requests. The locator accepts the Xbox `Media/script` + `Media/map` layout and the PS3 `USRDIR/script` + `USRDIR/map` layout directly; platform-native folders do not need to be renamed.

## MAP rendering

Verified resource mapping: 6 → `fence1_512.png`, 7 → `fence2_512.png`, 8 → `fence6_512a.png`, 9 → `fence3_512.png`. Tiles use the confirmed 7×7 atlas, 144-pixel pitch, 96×96 source rectangles, one-based IDs 1–49, and 0x40/0x80 X/Y reflections.

## Runtime scroll playback

Explorer v6 carries decoded SCROLL events into the dataset:

- `SCROLL_01` → MAP layer 0 X/Y velocity
- `SCROLL_02` → MAP layer 1 X/Y velocity
- `SCROLL_03` → MAP layer 2 X/Y velocity

The runtime viewport integrates the signed 8.8 velocities and plays at the logical 30 Hz authoring timebase established by executable analysis. Across the retained retail explorer corpus there are 92 entries, 78 runtime pairings, and 468 scroll events. Playback controls support play/pause, single-frame stepping, seeking, and speed multipliers.

## Limits

The zero-scroll composite remains useful for layer inspection, while the runtime viewport adds confirmed 2D scrolling. This is not yet a complete gameplay renderer: camera/route transforms, all 3D stage behavior, entity simulation, and player-facing layer names remain outside the demonstrated scope.

## Level 4/5 3D layout and model-size proxy preview

For main level 4/5 stage entries, the explorer also reads the fixed `0x118` stage-placement table. The route line is derived from the executable-backed 800-unit cell steps and each used placement is located at `cell_center + stored placement position`.

When the corresponding extracted `<name>.gmx` is available anywhere in the rip's asset tree, the explorer reads only the proven GMX-root geometry AABB and applies the recovered stage-placement transform to its eight corners. The native row-vector order is `S × Rz(z) × Rx(x) × Ry(y) × T`: scale uses the recovered runtime value (`stored_scale × 5`), the stored degree rotations are converted to radians, then the recovered placement origin is applied. Orbit, top-down, and POV views all draw that transformed wire box. Clicking a placement reports the model name, record/slot, local and preview positions, runtime scale, stored rotation degrees, and native AABB.

This closes the former Euler-order approximation without turning Stage Explorer into a frame-accurate gameplay renderer. Route-follow cameras, entity/gameplay simulation, collision, and other unmodeled 3D-control side effects retain their documented boundaries. See `reference/research/STAGE_PLACEMENT_TRANSFORM_DEV24.md`.
