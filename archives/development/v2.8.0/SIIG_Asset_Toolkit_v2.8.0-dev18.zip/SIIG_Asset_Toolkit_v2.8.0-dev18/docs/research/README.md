# Research

Prototype and cross-build research notes.

- [`PROTOTYPE_NOTES.md`](PROTOTYPE_NOTES.md)
- [`RUNTIME_ENTITY_CAMERA_ROUTE_RESEARCH.md`](RUNTIME_ENTITY_CAMERA_ROUTE_RESEARCH.md) — five-build entity registry, Bmap/Xmap route-source behavior, route/camera GMX tracks, and raw camera presets.

- [`PA_ROUTE_ACTIVATION_RESEARCH.md`](PA_ROUTE_ACTIVATION_RESEARCH.md) — cross-build `Route::SetPaRoute` gates, boss/field correlations, and activation limits.
- [`BOSS_PA_ROUTE_TIMELINES_DEV9.md`](BOSS_PA_ROUTE_TIMELINES_DEV9.md) — Water Strider looping course and Ultimate UFO finite phase/hold timeline.

- `ULTIMATE_UFO_LATE_OBJECT_DEV11.md` — historical dev11 late-object note; its May `bos_015l` interpretation is superseded by dev12.

- [`ULTIMATE_UFO_DEBUG_STATE_DEV12.md`](ULTIMATE_UFO_DEBUG_STATE_DEV12.md) — May 9 debug HUD, Mframe/Sframe/state mechanics, named part-status bytes, and corrected bos_015k lineage.
- [`ULTIMATE_UFO_STAGE_VARIANTS_CAMERA_DEV12.md`](ULTIMATE_UFO_STAGE_VARIANTS_CAMERA_DEV12.md) — normal 5-3 vs Bonus 5-6 destruction policy, Mframe→fld015 synchronization, PA camera lifecycle, and late rear-follow geometry.

- [`ULTIMATE_UFO_CAMERA_RECONSTRUCTION_DEV13.md`](ULTIMATE_UFO_CAMERA_RECONSTRUCTION_DEV13.md) — GMX/runtime matrix convention, `field-camera`, 404-frame rear-follow validation, transition gate, and final-Vanish evolution.

- [`MOBILE_LINEAGE_DEV15.md`](MOBILE_LINEAGE_DEV15.md) — mobile package/format lineage, generator continuity, Level-9 split, and executable naming anchors.

- [`MOBILE_V2_SURVIVAL_CHIMERA_DEV16.md`](MOBILE_V2_SURVIVAL_CHIMERA_DEV16.md) — executable-backed DELETION/V2 mappings, Survival graph/endings, and resolved Chimera Level-9 crossover branch.

- [`MOBILE_SURVIVAL_V2_BEHAVIOR_DEV17.md`](MOBILE_SURVIVAL_V2_BEHAVIOR_DEV17.md) — Evolution Tree-gated Survival Chimera substitutions, V2 projectile-pool/behavior differences, and Chimera A/B boss parameters.

- [`IOS_CONSOLE_CODE_LINEAGE_DEV18.md`](IOS_CONSOLE_CODE_LINEAGE_DEV18.md) — executable-backed iOS→console MAP/DAT/timing/generator correspondences, opcode-language expansion, and shared-stage structural comparison.
