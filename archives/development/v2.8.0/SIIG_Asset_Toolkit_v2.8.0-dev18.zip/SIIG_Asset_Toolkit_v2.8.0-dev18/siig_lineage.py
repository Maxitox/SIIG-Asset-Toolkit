#!/usr/bin/env python3
"""Executable-backed iOS -> console SIIG code-lineage reference data.

This module contains only derived metadata and equations. It does not contain
proprietary executable bytes or decompiled game code.
"""
from __future__ import annotations

from typing import Any


IOS_CONSOLE_FUNCTION_LINEAGE = (
    {
        "subsystem": "MAP loader",
        "ios_symbol": "Invinf_LoadMap",
        "ios_address_armv7": "0x000900CC",
        "console_xbox_address": "0x82239190",
        "console_role": "load/allocate MAP layers",
        "confidence": "high",
        "preserved": "layer count; width/height descriptors; one cell buffer per layer; row-major u8 cells",
        "changed": "mobile MAP integer headers are little-endian; console headers are big-endian; resource packaging/path changed",
    },
    {
        "subsystem": "MAP runtime update",
        "ios_symbol": "calcMap",
        "ios_address_armv7": "0x0008D020",
        "console_xbox_address": "0x82239608",
        "console_role": "update MAP scrolling and visible ranges",
        "confidence": "high",
        "preserved": "three per-layer X/Y velocities; fixed-point position accumulation; clamped visible row/column ranges",
        "changed": "console implementation is reorganized around the console runtime and renderer",
    },
    {
        "subsystem": "MAP cell renderer",
        "ios_symbol": "drawMap2",
        "ios_address_armv7": "0x0008E5EC",
        "console_xbox_address": "0x8223AC28 + 0x8223A1B0",
        "console_role": "decode cells and submit 49-tile reflected variants",
        "confidence": "high",
        "preserved": "cell&0x3F tile code; 0 empty; tile indices 0..48 after subtract-one; 0x40 X reflection; 0x80 Y reflection",
        "changed": "platform-specific draw/geometry submission path",
    },
    {
        "subsystem": "MAP scroll command",
        "ios_symbol": "analyzeScript2 + setMapLayerSpeed",
        "ios_address_armv7": "0x00093CFC + 0x0008CFC4",
        "console_xbox_address": "0x820FB578 dispatcher; 2D scroll handlers in same script subsystem",
        "console_role": "SCROLL_01/02/03 set MAP layer 0/1/2 X/Y velocities",
        "confidence": "high",
        "preserved": "opcodes 0x6E/0x6F/0x70; three layer channels; speed normalization against 30-Hz authored timebase",
        "changed": "console SCROLL_01 Y also drives 3D wall/background; SCROLL_02 Y also drives 3D route/camera/field",
    },
    {
        "subsystem": "authored DAT loader",
        "ios_symbol": "Invinf_LoadScript",
        "ios_address_armv7": "0x0008FEFC",
        "console_xbox_address": None,
        "console_role": "shared DAT loader/index representation (exact Xbox address not yet pinned)",
        "confidence": "high-structural",
        "preserved": "version-1 command stream; big-endian 16-bit words; flattened word-data buffer plus per-command starting-word index; delta-frame timing",
        "changed": "console exact loader address still unresolved in retained reference exports",
    },
    {
        "subsystem": "script execution",
        "ios_symbol": "analyzeScript + analyzeScript_FPS60 + analyzeScript2",
        "ios_address_armv7": "0x00011C68 + 0x001308B4 + 0x00093CFC",
        "console_xbox_address": "0x820FB578",
        "console_role": "SgScript::AnalyzeScript candidate / June dispatcher",
        "confidence": "high-architectural",
        "preserved": "same low-range DAT command language and 30-Hz authored timing model",
        "changed": "mobile duplicates the primary enemy dispatcher for 30/60 Hz; console consolidates timing through a runtime frame multiplier and extends the command vocabulary through 0xCE",
    },
    {
        "subsystem": "generator DAT block loader",
        "ios_symbol": "stageScriptBlockLoad(NSString*,int)",
        "ios_address_armv7": "0x000DF89C",
        "console_xbox_address": "0x8226BC48",
        "console_role": "generator DAT block loading/assembly",
        "confidence": "high-structural",
        "preserved": "same DAT block serialization; append into generator script/index buffers; cumulative timeline across blocks",
        "changed": "console implementation/address naming reconstructed from debug executable rather than retained source symbols",
    },
    {
        "subsystem": "generator MAP initialization",
        "ios_symbol": "stageGenerateMapInit",
        "ios_address_armv7": "0x000E0128",
        "console_xbox_address": None,
        "console_role": "generator output-map buffer initialization (exact console routine not yet isolated)",
        "confidence": "high-mobile / unresolved-console-address",
        "preserved": "three generated output layers and fixed reusable-block assembly model",
        "changed": "console generator resources have exactly twice the total stored cell capacity; exact buffer-growth transformation remains unresolved",
    },
    {
        "subsystem": "generator MAP assembly",
        "ios_symbol": "stageGenerateMap",
        "ios_address_armv7": "0x000E06D8",
        "console_xbox_address": "0x8226CB28 + 0x8226CD30",
        "console_role": "append generator MAP blocks + choose/load 24 named blocks",
        "confidence": "high",
        "preserved": "24-block generated stage; a_%03d.map..j_%03d.map naming family; three-layer map assembly; same 330-map generator family",
        "changed": "console split selection and append responsibilities into distinct recovered routines; stored MAP corpus capacity doubled",
    },
)


CONSOLE_OPCODE_EXPANSION = (
    {"range": "0x96-0xAB", "family": "new/expanded console enemies and 3D bosses", "examples": "CIRCLE_INVADER, GREED, WRATH, WATER_STRIDER, ULTIMATE_UFO, SQUID, VERTEBRATE, NO_NAME"},
    {"range": "0xB4-0xBE", "family": "3D stage controls", "examples": "3D Back Scroll, 3D Wall Scroll, 3D Back Color, 3D Camera Change 01, 3D Demo, 3D Back Animation, 3D Field Rotate Control"},
    {"range": "0xC8-0xCE", "family": "Visualizer controls", "examples": "VL_START, VL_END, VL_DISP_ON/OFF, VL_SEQUENCESET, VL_CHANGETIME, VL_VOLUME_SCALE"},
)


def ios_console_lineage_reference() -> dict[str, Any]:
    """Return source-only executable-lineage facts used by dev18 research."""
    return {
        "format": "SIIG_IOS_CONSOLE_CODE_LINEAGE",
        "schema_version": 1,
        "mobile_command_dispatch": {
            "primary_analyzer": {"symbol": "analyzeScript", "serialized_opcode_min": 0x02, "serialized_opcode_max": 0x83},
            "fps60_primary_analyzer": {"symbol": "analyzeScript_FPS60", "serialized_opcode_min": 0x02, "serialized_opcode_max": 0x83},
            "secondary_analyzer": {"symbol": "analyzeScript2", "serialized_opcode_min": 0x6E, "serialized_opcode_max": 0x8D},
            "effective_mobile_frontier": 0x8D,
            "console_table_frontier": 0xCE,
            "note": "0x83 is only the primary iOS analyzer frontier; 0x84..0x8D are handled by analyzeScript2.",
        },
        "timing_model": {
            "authored_hz": 30,
            "ios_delta_runtime_formula": "runtime_delta = authored_delta * runtime_fps / 30",
            "ios_scroll_runtime_formula": "runtime_speed = authored_speed * 30 / runtime_fps",
            "console_duration_formula": "runtime_updates = authored_ticks * frame_multiplier",
            "console_velocity_formula": "runtime_velocity = authored_velocity / frame_multiplier",
            "console_update_hz_formula": "runtime_updates_per_second = 30 * frame_multiplier",
            "interpretation": "same 30-Hz authored-time invariant; console centralizes the 30/60 timing policy that mobile partly handled with duplicated primary analyzers",
        },
        "generator_model": {
            "ios_output_layers": 3,
            "ios_bytes_per_output_layer": 6144,
            "ios_block_iterations": 24,
            "ordinary_block_width": 8,
            "ordinary_block_height": 32,
            "capacity_identity": "6144 = 24 * 8 * 32",
            "ios_generator_map_files": 330,
            "ios_nonempty_generator_layers": 645,
            "ios_generator_cells": 121472,
            "console_generator_map_files": 330,
            "console_nonempty_generator_layers": 645,
            "console_generator_cells": 242944,
            "console_to_ios_cell_ratio": 2.0,
            "warning": "nonzero cells are not doubled, so the console corpus is not a simple byte duplication of the mobile maps",
        },
        "function_lineage": [dict(x) for x in IOS_CONSOLE_FUNCTION_LINEAGE],
        "console_opcode_expansion": [dict(x) for x in CONSOLE_OPCODE_EXPANSION],
        "evidence_policy": {
            "high": "both sides have instruction-level or executable-backed structural evidence",
            "high-structural": "behavior/data structure matches strongly but exact console symbol/address attribution is incomplete",
            "no_binary_distribution": True,
        },
    }
