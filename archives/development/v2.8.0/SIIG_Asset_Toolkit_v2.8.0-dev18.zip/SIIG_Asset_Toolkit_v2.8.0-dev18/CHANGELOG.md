# Changelog

## 2.8.0-dev18

- Added executable-backed iOS→console code-lineage mappings and `ios-console-lineage-info`.
- Matched mobile MAP loading, runtime scrolling/visibility, cell decoding, and 24-block generator assembly to their recovered console counterparts.
- Proved the shared 30 Hz authored-time equations on iOS and related them to the console frame-multiplier architecture.
- Corrected the effective mobile script-dispatch frontier to 0x8D and documented the console expansion through 0xCE.
- Added 18-stage opcode-structure comparison showing strong skeleton continuity with extensive parameter/content retuning.
- Added dev18 lineage tables/report/validation and expanded the selftest suite to 54 tests.
- Kept sealed dev17 and earlier checkpoints unchanged.

## 2.8.0-dev17

- Resolved `survivalStageConvertTable` gating as Evolution Tree stage-node status checks rather than a Survival-private status array.
- Proved the six Chimera Survival substitutions and their exact fallback stages, plus the purchase/clear unlock chain for Extra 31..36.
- Added `mobile-exclusives-info` with source-only Survival ending/substitution and V2 behavior/attack-pool reference data.
- Traced `dischargeEnemyShot_FPS60` and mapped original/V2 constructor pool type IDs to named retained projectile handlers, establishing concrete attack-repertoire swaps for all six V2 bosses.
- Documented explicit main-type behavior branches in THE SUN, GIGANTIC UFO, and UNKNOWN, including UNKNOWN_V2 helper doubling sites and `setVer2Destroy`.
- Proved King Fossil C-1A/C-1B boss-argument differences and the 48→96 executable-backed reload/countdown source.
- Added dev17 research tables/report/validation and expanded the dependency-free selftest suite to 53 tests.
- Kept dev16 sealed/frozen; dev17 is branched from the validated dev16 release.

## 2.8.0-dev16 — 2026-09-10

- Corrected the six iOS Level-9 resources as Chimera crossover stages and documented Android's V2-based replacement stubs separately from DELETION.
- Proved script opcodes 0x52/0x53/0x54 as KING_FOSSIL / TWILIGHT_MIRAGE / APARTHEAD from iOS ARMv7 executable dispatch.
- Added executable-backed DELETION V2 mappings, original/V2 entity-pool diffs, and the all-six-V2 `level8_stage9EX` observation.
- Reconstructed the 36-node Survival selection graph, terminal-node ending mapping, achievement indices, and six conditional stage substitutions.
- Added Chimera resource/title/boss mappings and retained crossover constructor/attack-symbol anchors.
- Credited MaxTheMurdererV2 gameplay videos as third-party observational evidence; no footage is bundled.
- Expanded the synthetic regression suite from 51 to 52 tests.

## 2.8.0-dev15 — 2026-09-10

- Added iOS/Android mobile lineage research and four mobile commands: `mobile-inventory`, `mobile-compare`, `tzip-extract`, and `mobile-map-info`.
- Added a dependency-free TZIP parser for SIIG's zlib + Apple binary-plist resource dictionaries.
- Added little-endian mobile MAP parsing while keeping console MAP parsing separate and big-endian.
- Validated 737 mobile DAT and 493 mobile MAP files with zero parse failures.
- Documented iOS/Android package provenance boundaries, 330/645 generator continuity, Level-9 replacement opcodes 0x4C..0x51, and iOS executable symbol anchors.
- Expanded the synthetic regression suite from 46 to 51 tests.

## 2.8.0-dev14 — 2026-09-10

- Audited the June/retail Ultimate UFO ending after Mframe 6200 and separated destruction, owned-object shutdown, entity removal, and part-0/state-0 reset.
- Proved that retail camera gate `+0x11C` is not cleared by the 6030 or 6200 phase actions; the clear remains conditional on a later part-0 `+0x48` reset through `0x8212DCB0` (`0x8212DD20` store).
- Excluded Normal 5-3 DAT cleanup, `DEL_ZAKO`, destructor-only manager removal, and the 25,200-unit lifetime watchdog as established ordinary route-end callers.
- Added the machine-readable final-reset audit and one regression check.
- Finalized the static-analysis boundary: no ordinary Normal 5-3 post-6200 `+0x48` caller is proven, so part-0/state-0 is documented as a conditional clear mechanism rather than an assumed ordinary-ending event.
- Added the June 10 project-owner footage boundary (~427.367–427.400 s in Normal seg6) showing the Ultimate UFO debug registration disappearing with the stage-completion white-out; retained it strictly as observational evidence.

## 2.8.0-dev13 — 2026-09-07

- Added `field-camera` for frame-by-frame procedural camera reconstruction from fld014/fld015 GMX matrices and an explicit camera preset.
- Added the executable/asset-backed GMX serialized-affine to runtime row-vector matrix conversion.
- Validated all 404 normal-5-3 late fld015 frames 5897..6300 as rear-follow for preset 4; measured 59.859..72.111 units behind the route tangent.
- Confirmed extreme dynamic horizontal-response values change lateral framing without breaking rear-follow classification in the late route.
- Decoded retail camera controller +0x11C as a timed-preset-transition acceptance gate and proved Ultimate UFO normal part-0/state-0 reset clears it on Xbox and PS3.
- Recovered May 9/May 11 phase-12 Mframe-6200 direct UltimateUfo::Vanish(part 0) behavior and documented the later 6030/6200 ending split.
- Added three machine-readable dev13 research tables and expanded self-tests to 45 checks.

## 2.8.0-dev12 — 2026-09-07

- Corrected dev11's prototype runtime-registry interpretation: May 9/May 11 ID `0xD9` is `bos_015k.gmx`; later builds use ID `0xD8` for the same model.
- Decoded the May 9 Ultimate UFO debug HUD (`Mframe`, `Sframe`, `state`, `L2:SKIP`) and named the eight phase bytes as Umb/Tow/Fan/Ring `col`/`dis` pairs.
- Proved `L2:SKIP` clears Sframe and recovered the Mframe/Sframe advance relationship.
- Added distinct normal 5-3 and DLC Bonus 5-6 Ultimate UFO profiles; proved the Bonus 5-6 immediate main-body destruction shortcut on retail Xbox and PS3.
- Closed direct Mframe -> `fld015.gmx` frame synchronization across all five executable builds.
- Reconstructed the PA animated-camera -> procedural-camera fallback and rejected preset 4 as an HP-zero-triggered switch.
- Evaluated real late `fld015` matrices with preset 4 and classified the normal late route as rear-follow geometry, with explicit remaining caveats.
- Audited all five direct PS3 camera-preset setter callers; none is Ultimate UFO, tightening preset-4 persistence while retaining an indirect-call caveat.
- Expanded the dependency-free regression suite to 43 tests.

## 2.8.0-dev11 — 2026-09-06

- Closed the special-stage reload parameter chain: retail DAT opcode `0x78` (`WARNING`) writes its first argument into transition state; values 12 and 14 select Bmap13/fld014 and Bmap15/fld015 respectively.
- Verified real retail scripts place `WARNING [12]` before Water Strider and `WARNING [14]` before Ultimate UFO, upgrading the former boss/field correlations to direct script→executable→reload evidence.
- Traced common HP-zero dispatch into Ultimate UFO's part-state/destruction lifecycle and recovered the May-prototype debug symbol `UltimateUfo::Vanish`.
- Documented executable-backed Ultimate UFO late-phase destruction actions at frames 6030 and 6200 while retaining airlock/rear-camera gameplay labels as unresolved.
- Added machine-readable special-stage reload and Ultimate UFO death-chain tables plus regression coverage.

## 2.8.0-dev9 — 2026-09-06

- Recovered executable-backed Water Strider 0..1440 looping route table and Ultimate UFO finite retail/prototype phase tables.
- Added cross-build boss function mapping, hold/resume documentation, helpers, CSV tables, and regression coverage.
- Preserved unresolved camera-angle semantics and cam02 activation as explicit limits.


## 2.8.0-dev8

- Added `pa-route-info` for executable-backed PA-route gate, camera-selection, and DAT boss-correlation inspection.
- Cross-mapped `Route::SetPaRoute` across PS3 retail, Xbox retail, June 10, May 11, and May 9 using prototype debug strings plus function/vtable shape.
- Proved retail Xbox/PS3 and June 10 require category 0 plus runtime state `+0x218 == 4` / `+0x21C == 1`; May 11 uses the state-only gate; the corresponding May 9 setup does not activate the branch.
- Added `PA_ROUTE_BUILD_GATES.csv`, `PA_ROUTE_FUNCTIONS.csv`, `PA_ROUTE_CAMERA_SELECTIONS.csv`, and `PA_ROUTE_BOSS_MAPPING.csv`.
- Proved known retail stage setup selects PA-route camera index 0 (`cam01_op1.gmx`); index 1/cam02 remains unproven as a retail activation callsite.
- Added conservative Water Strider -> fld014/Bmap13 and Ultimate UFO -> fld015/Bmap15 boss-field correlations, explicitly labeled strong correlation rather than direct callsite proof.
- Real retail PS3 validation scans all 76 DAT files and identifies six Water Strider/Ultimate UFO occurrences with zero parse failures.
- Expanded the dependency-free regression suite to 35 tests.

## 2.8.0-dev7

- Corrected channel-type-12 GMX matrix-animation timing from raw authoring timestamps to the retail logical-frame sampler: `matrices[logical_frame % frame_count]` at the engine's 30 Hz logical clock.
- `gmxtrack` now separates `runtime_seconds_30hz` from `raw_authoring_time`; glTF animation keys use sample-index/30 while preserving the raw float table in metadata.
- Decoded the 0x1C route/field animation descriptor as `{name[16], start_frame, end_frame, loop_flag}`.
- Added `camera-animation` for the explicit retail `cam1`/`int1` 0..199 non-loop camera controller, including `FieldPos` translation and frame-multiplier update cadence.
- Added `field-animation` for explicit `fld014`/`fld015` descriptor-frame matrix evaluation without inferring stage activation.
- Proved `fld015` is 0..6300 non-loop (6,301 samples) and `fld014` is 0..1440 loop with frame 1440 wrapping to sample 0 (1,440 samples).
- Proved both `cam01_op1` and `cam02_op1` use the same camera descriptor end 200; this path never reaches cam02 samples 200..299.
- Expanded the dependency-free regression suite to 34 tests.
- Real retail validation covers all four camera/field GMXs and corrected glTF runtime spans.

## 2.8.0-dev6

- Added executable-backed procedural route orientation state to `RouteRuntimeState`, preserving Hermite-sample update ordering before same-update next-segment preparation.
- Reconstructed row-vector route orientation as `Rz(roll+offsetZ) × Rx(pitch+offsetX) × Ry(yaw+offsetY)` with retail pitch/yaw updates from moving Hermite samples.
- Added `camera_world_state()` for the proven procedural camera path: route/stage-frame eye-offset transform, FieldPos target, and transformed word-8/9/10 dynamic local-X response.
- Added `route-camera-playback`, explicitly combining caller-supplied route/DAT/preset/runtime-coordinate inputs without inferring activation timelines.
- Added `--emit-every` output decimation to combined playback; every runtime update is still simulated.
- Expanded route-playback CSV state with procedural pitch/yaw/roll and row-vector orientation matrix columns.
- Expanded the dependency-free regression suite to 31 tests.
- Real-corpus orientation stress at 100-unit analysis spacing: six route files exercise Hermite orientation for 356 total orientation updates.
- Explicit `Xmap3_1.bin + level3_stage1.dat` combined-camera validation simulates 265,020 runtime updates, applies seven SCROLL_02 events, and terminates normally; preset 0 / runtime (213,233) are validation inputs, not inferred gameplay activation.

## 2.8.0-dev5

- Added `camera-preset` for semantic inspection of retail camera presets and optional runtime-coordinate response evaluation.
- Proved preset word 0 is perspective FOV in degrees and word 1 is uniform scene/view scale.
- Proved words 2–4 form the camera-eye offset transformed by the active route/stage orientation and added to `FieldPos`; words 5–7 are scene/view translation.
- Resolved words 8–10 as dynamic horizontal-response gain, target local-X scale, and eye local-X scale in retail PS3 `0x00157540`.
- Proved words 12–29 are three fog profiles `{start, end, RGBA}` through renderer `fogRange` and `vFogColor` consumers.
- Traced word 11 as a shared scalar forwarded unchanged to `collada_edge1`, `collada_face1`, and `collada_face2`; its exact virtual-setter semantic remains unresolved.
- Added `CAMERA_PRESETS_RUNTIME_SEMANTIC.csv` and upgraded `CAMERA_PRESET_SCHEMA.csv` with evidence-backed names while preserving the untouched raw table.
- Expanded the dependency-free regression suite to 29 tests.

## 2.8.0-dev4

- Added executable-backed dynamic route runtime state (`RouteRuntimeState`) with non-loop termination, modulo loop wrapping, and per-update source/sample progression.
- Added exact signed SCROLL_02 Y-to-spacing conversion from PS3 retail `0x0014E408`, including PPC truncation-toward-zero behavior.
- Reproduced the retail linear mid-segment spacing-change path: remaining linear samples are discarded and rebuilt from current `FieldPos`; active Hermite segments intentionally do not rebuild on spacing changes.
- Added `route-playback`, explicitly coupling one caller-supplied stage3d route and DAT script through authored-frame → runtime-update SCROLL_02 timing.
- Added explicit `--start-frame`, `--end-frame`, `--frame-multiplier`, `--loop`, and `--max-updates` controls rather than guessing route-object activation or filename pairing.
- Expanded the dependency-free regression suite to 28 tests.
- Real-corpus runtime stress gate: all 46 resampleable retail route tables survive non-loop spacing-change and loop-wrap smoke stepping; the one route-empty file remains skipped.
- Explicit filename-correspondence examples `Xmap2_1 + level2_stage1.dat` and `Xmap3_1 + level3_stage1.dat` validate DAT-coupled playback, including seven live spacing rebuilds in the latter. These examples are validation candidates, not a claim that every route↔DAT pairing is solved.

## 2.8.0-dev3

- Added executable-backed fixed-spacing non-loop route resampling (`route-resample`).
- Reproduced linear write-after-step sampling, straight/curve classification, six-state tangent-axis transitions, cubic Hermite sampling, and the final look-ahead source-point rule.
- Added runtime-initialized camera presets reconstructed from all 160 initializer writes, while retaining the untouched raw 32 × 30 table.
- Added a 30-word structural camera-preset schema documenting vec3/group layouts, interpolation behavior, consumer addresses, confidence, and unresolved semantics.
- Real-corpus route validation at a deterministic 100-unit analysis spacing: 46 resampleable files, one route-empty file skipped, 19,471 segments, 155,690 samples, 62 Hermite segments, zero conversion failures.
- Expanded the built-in regression suite to 26 tests.
- Dynamic SCROLL_02 spacing changes and looping-route wrap behavior remain explicitly outside the fixed-spacing exporter.

## 2.8.0-dev2

- Added five-build executable-derived runtime entity/primitive registry tables and decoded 0x2C record fields.
- Resolved render-group selectors to Offset Opacity / Offset Translucent / Offset Terminate / Non Opacity.
- `stage3dmap` now exports executable-ordered runtime route-source control points plus record-0 origin fallback.
- Added `gmxtrack` for decomposed GMX matrix-animation CSV and translation trajectory OBJ export.
- Added raw 32 × 30 camera-preset table and two route-animation descriptors from PS3 retail.
- Expanded the dependency-free self-test suite to 24 checks.


## 2.8.0-dev1

- Validated the supplied original retail Xbox 360 LIVE STFS and PS3 type-1 PKG directly.
- Added optional OpenSSL AES-CTR acceleration for finalized PKG extraction with Python fallback/equivalence testing.
- Added internal authenticated decryption of SIIG's six NPDRM SDATs and standalone `sdat-decrypt`.
- Added built-in Sony 989SND/SCREAM SBlk v3 parsing plus PS-ADPCM WAV export and standalone `sblk2wav`; 84/84 retail PS3 streams decode.
- Restored Stage Explorer v5 runtime SCROLL_01/02/03 playback with 30 Hz controls and source-level regeneration.
- Added content-addressed outer-container staging for `--resume` and `--no-outer-cache` override.
- Fixed the STFS `CON` first-hash-table initialization path.
- Integrated PS3 EBOOT-backed Bmap/Xmap placement, route-point, scroll, and timing corrections.
- Expanded `selftest` to 23 dependency-free cases, including cross-platform Stage Explorer root detection.
- Added explicit retained-native placeholders for WMA/XMA/AT3 and XACT data so Asset Viewer coverage reports do not mislabel intentionally non-browser-native files as missing previews.
- Fixed Stage Explorer discovery for the PS3 `USRDIR/script` and `USRDIR/map` layout.
- Updated credits/provenance for OpenSSL acceleration and vgmstream Sony bank/PS-ADPCM cross-checks.

## 2.5.1

- Reorganized the release root into `docs/`, `reference/`, `validation/`, `tools/`, and `addons/`.
- Added a central documentation index and folder-level README files.
- Updated runtime resource lookups and all documentation references to the new paths.
- Retained fallbacks for legacy root-level data-table locations.
- Reduced root-level files from 75 to 18 with no content removed.

## 2.5.0

- Replaced the monolithic Asset Viewer with a linked-data layout: compact HTML, external inventory, thumbnails, and deferred preview shards.
- Removed base64 media embedding and added pagination plus intersection-based lazy loading.
- Added direct GMX/OBJ wireframes, TEX previews, MAP/DAT/ANM thumbnails, WAV waveforms, and explicit empty/animation-only placeholders.
- Added matching converted-asset previews for source TEX, GMX, OBJ, and audio files.
- Fixed related glTF payload keys and excluded viewer output during in-tree rebuilds.
- Added detailed viewer size/coverage reporting and validation of all generated relative references.
- Validated 1,016/1,016 previewable thumbnails and reduced the tested HTML document by 99.934%.

## 2.4.0

- Corrected standalone ANM parsing to 16-byte names, start/end frames, and loop flags; added group/clip indexes.
- Added `stage3dmap` for Bmap/Xmap/map4/map5 0x118-byte 3D path and placement records.
- Added `stagewall` for wall/Xwall repeat strips and `stage_generate.bin` enabled candidates.
- Added `shader-info` for Xenos shader stages, bounded microcode, metadata strings, and hashes.
- Added automatic full-rip structured exports and `scan` recognition for these formats.
- Corrected SCROLL_01/02 to 8.8 fixed-point values and documented SCROLL_03 as a June 10 no-op.
- Expanded the built-in regression suite from 11 to 15 tests.
- Added Ghidra-backed stage/ANM/shader notes and a real-corpus validation report.

## 2.3.0

- Added `repack-bbx` with canonical archive layout, named/unnamed resources, seeded hashes, sorted indexes, preserved reserved bytes, deterministic gzip, atomic output, and mandatory post-build verification.
- Extended extraction manifests with payload SHA-256, original archive SHA-256/size, reserved header bytes, alignment, and sorted-index metadata.
- Verified the unchanged supplied retail `map.bin` as a byte-for-byte extract/repack round trip.
- Added the SIIG Blender Add-on 0.1.0 for single, multi-file, and recursive-folder GMX import through the toolkit's existing glTF exporter.
- Added `asset-viewer`, a searchable offline HTML inventory with bounded media previews, text inspection, glTF summaries, and interactive wireframe views.
- Added `serve`, bound to localhost, for viewing generated HTML without `file://` restrictions.
- `rip-game` now generates an asset viewer automatically unless disabled.
- Added drag-and-drop launchers for BBX extraction/repacking, viewer generation, and local serving.
- Expanded `selftest` from 9 to 11 checks with BBX repacker and HTML viewer tests.
- Added dedicated repacker, asset viewer, Blender add-on, and excluded-source documentation.

## 2.2.0

- Integrated the verified MAP atlas renderer into the main toolkit. Resource IDs 6, 7, 8, and 9 resolve to `fence1_512`, `fence2_512`, `fence6_512a`, and `fence3_512`; tile IDs 1–49 use the confirmed 7×7 atlas layout and X/Y reflections.
- Upgraded `stageviz` to explorer format v4 with embedded game atlases, zero-scroll layer composites, cell inspection, safe HTML escaping, and categorical fallback when an atlas is absent.
- Added optional atlas-backed output to `map2png` through `--atlas`, `--atlas-step`, and `--no-atlas-composite`.
- `rip-game` now generates the offline stage explorer automatically unless `--no-stageviz` is used.
- Added deterministic `OUTPUT_MANIFEST.json` and `.sha256` files plus `verify-output` for privacy, size, hash, partial-file, and report validation.
- Added `doctor`, global `--version`, and a built-in `selftest` covering AES, BBX, DAT, MAP, bounded gzip, PNG/atlas rendering, ZIP safety, privacy redaction, and output tamper detection.
- Hardened ZIP, STFS, and PKG extraction with configurable file-count/size limits, duplicate-path checks, traversal and symlink rejection, and atomic `.siig-part` writes.
- Added bounded gzip expansion, nested-BBX depth/resource budgets, Windows-reserved-name handling, case-insensitive output collision avoidance, and stricter platform ambiguity detection.
- Resume profiles now include the toolkit version so changed converter behavior cannot silently reuse stale output.
- Restored and updated the credits, AI disclosure, provenance, source audit, third-party notices, project-license status, and attribution policy in the package.
- Added security and testing documentation and expanded full-rip reports with elapsed time, explorer status, extraction limits, and manifest status.

## 2.1

- Added direct Xbox 360 STFS input to `rip-game` for `CON `, `LIVE`, and `PIRS` packages.
- Added direct PlayStation 3 PKG input for finalized and non-finalized/debug type-1 packages.
- Added dependency-free STFS block-chain/hash-table extraction and PS3 PKG AES/debug-stream decryption.
- Added `unpack-container` for outer-package-only extraction and `container-selftest` for the AES known-answer test.
- Added magic-based input detection; package filenames no longer need a particular extension.
- Added outer-container totals and input type to full-game validation reports.
- Preserved the separate PS3 NPDRM SDAT step: TrueAncestor `.bin.gz.dat` files are still discovered beside the PKG or through `--ps3-sdat-dir`.
- Validated synthetic STFS level-0/1/2 boundaries, chained files, finalized/debug PKGs, and both supplied extracted retail releases.
- Added `docs/guides/CONTAINER_INPUT_NOTES.md` and updated the drag-and-drop launcher.


## 2.0

- Corrected the MAP interpretation using the June 10 XEX renderer path.
- Confirmed `0` as empty, tile IDs `1..49`, `0x40` as X flip, and `0x80` as Y flip.
- Confirmed a 30-unit tile grid and three independently scrolling layers.
- Added runtime tile-set resource IDs for all 75 stage-table entries.
- Updated the offline explorer with verified tile and flip views.
- Documented generator MAPs as reusable 2D tile-pattern blocks.
- Removed the unsupported assumption that these MAP cells place 3D wall models.
- Kept exact tile-set filenames and layer gameplay roles explicitly unresolved.

## 1.9

- Added conservative XEX-backed DAT semantic decoding with categories, summaries, confidence levels and proven field names.
- Added `stageviz`, a self-contained offline MAP/DAT explorer with searchable frame timelines and three MAP bit views.
- Reconstructed the 75 stage/script pairings, two MAP-only slots and trial variant from the June 10 executable tables.
- Added explicit reporting for 12 expected-but-absent level-4/5 MAP names and 14 package MAPs unreferenced by the runtime table.
- Added `reference/tables/STAGE_PAIRING.csv`, `reference/tables/DAT_SEMANTIC_SCHEMAS.csv` and `docs/guides/STAGE_EXPLORER_NOTES.md`.
- Validated semantic export on all 1,334 June 10 DAT files with zero failures; the explorer contains 17,335 commands from all 76 stage scripts and no absolute source paths.


## 1.8

- Confirmed the shared DAT format from the June 10 DebugOpt `stageScriptBlockLoad` routine.
- Added `dat2csv`, delta-to-absolute frame conversion, full signed/hex argument preservation, and the executable-derived 207-slot opcode-name table.
- Confirmed the MAP layer format from `stageGenerate2DMap`.
- Added `map2png` with categorical/grayscale palettes, optional nearest-neighbor scaling, numeric CSV grids, and JSON metadata.
- Added DAT/MAP recognition to `scan`.
- `rip-game` now converts all extracted DAT and MAP resources automatically.
- Validated 5,244 DAT files containing 96,750 commands and 1,576 MAP files containing 4,728 layers across May 9, May 11, June 10 and retail Xbox 360 builds with zero parse failures.

## 1.7

- Added `.col` collision-mask decoding to PNG.
- Added standalone `.anm` table decoding to CSV and JSON.
- `rip-game` now converts COL and ANM resources automatically.
- Added prototype-analysis notes based on the May 9, May 11 and June 10 Xbox 360 builds.

## 1.6.0

- Added `rip-game` for original Xbox 360/PS3 directories and ZIP archives.
- Added automatic platform detection from `default.xex` and `EBOOT.BIN`.
- Added PS3 RSX TEX to PNG support and PS3 system-font atlas decoding.
- Added TrueAncestor `.bin.gz.dat` discovery for NPDRM/SDAT payloads.
- Added deterministic archive ancestry, decompressed BBX preservation, resume-state hashes, ready-file copying, and privacy-safe validation reports.
- Added drag-and-drop `SIIG_Rip_Game.bat`.
- Xbox 360 WMA files are preserved unchanged; PS3 Sony SBlk audio banks are extracted losslessly as `.bnk` for vgmstream.

## 1.5.1

- Removed absolute input, output, FFmpeg, and glTF filesystem routes from generated JSON metadata.
- JSON manifests now retain only privacy-safe filenames and archive-relative paths.
- Added `sanitize-json` to clean metadata generated by v1.5 or earlier in place.
- Sanitized the bundled glTF samples.

## 1.5

- Added `gmx2gltf` and `extract --convert-gltf`.
- Decoded GMX `TXIF`, `SHAD`, `MTRL`, `PARE`, `BONE`, `MOTN`, and `ANIM` chunk relationships.
- Added glTF 2.0 hierarchy, rigid mesh attachment, materials, vertex colors, texture assignment, and transform-animation export.
- Added automatic conversion of the shared uncompressed `ptn_001.dds` texture to PNG.
- Added `docs/formats/GMX_GLTF_NOTES.md` and detailed GMX output in `scan`.
- Validated 486 GMX files, 1,938 meshes, 3,298 nodes, 776 materials, and 913 animation tracks with zero conversion failures.

## 1.4

- Added `text2csv` for direct decoding of `text.bin`, `message.bin`, or a directory containing both.
- Recovered the 542-row `text.bin` key/translation table across Japanese, English, French, Italian, German and Spanish.
- Parsed all 284 Squirrel-style `message.bin` arrays and 1,295 strings per language.
- Added Unicode correction for the legacy language-specific accented-glyph codes while retaining untouched raw scripts.
- Added combined CSV/JSON, per-language text files, metadata, and `docs/formats/LOCALIZATION_NOTES.md`.

## 1.3

- Added `xact2wav` for direct conversion from `sound.bin`, extracted XWB files, or XWB/XSB directories.
- Added standard big-endian XACT3 wave-bank parsing and XSB cue-name recovery.
- Added RIFF XMA2 wrapper generation and optional FFmpeg PCM WAV decoding.
- Validated all 86 SIIG streams: 83 SE cues plus BGM007, BGM008_MIX_C and BGM_XACT_SE33.
- Added per-bank CSV/JSON manifests with channels, sample rates, sample counts and loop metadata.

## 1.2

- Added `font2png` for `systemfont.bin`, `.gz`, or extracted `systemfont.crp`.
- Confirmed from `default.xex` that `systemfont.crp` is XOR-obfuscated bytewise with key `0xF1`.
- Added automatic CRP conversion when `extract --convert-tex` is used.
- Added `reference/systemfont/systemfont_glyphs.csv` with all 6,732 executable-resident glyph records, atlas coordinates, widths, left insets and known aliases.
- Added `reference/systemfont/systemfont.fnt` AngelCode BMFont descriptor for the 6,730 native Unicode mappings.
- Added CRP detection to `scan`.

## 1.1

- Fixed TEX untile addressing.
- Added the missing Y[3] XOR in the Xenos pipe selector.
- Eliminated repeating 8-row jitter/scrambling in converted PNG files.
- Revalidated all 54 supplied TEX files with zero conversion failures.

## 1.0

- Initial BBX extraction, GMX-to-OBJ and TEX-to-PNG release.
