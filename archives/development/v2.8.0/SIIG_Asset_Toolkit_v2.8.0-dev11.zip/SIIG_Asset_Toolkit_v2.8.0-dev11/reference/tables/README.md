# Reference tables

CSV tables used by the toolkit and retained for independent review. Runtime-required files include `STAGE_PAIRING.csv`, `STAGE_TILE_SETS.csv`, and `TILE_SET_TEXTURES.csv`.

Executable-derived research tables through 2.8.0-dev5:

- `ENTITY_RUNTIME_REGISTRY.csv` — five-build 0x2C runtime entity/primitive records with decoded fields and raw words.
- `ENTITY_RUNTIME_REGISTRY_BUILD_DIFF.csv` — exact-index differences between May, June, retail Xbox, and retail PS3 registries.
- `ENTITY_RUNTIME_REGISTRY_SUMMARY.json` — counts and normalized equality checks.
- `ROUTE_ANIMATION_DESCRIPTORS.csv` — two retail route-model descriptors with unresolved flag retained raw.
- `CAMERA_PRESETS_RAW.csv` — all 32 × 30 retail PS3 camera-preset words with hex/int/float views; field semantics intentionally unnamed.

- `CAMERA_PRESETS_RUNTIME.csv` — all 32 camera presets after the executable's 160 runtime initializer writes, with conservative structural field names.
- `CAMERA_PRESETS_RUNTIME_SEMANTIC.csv` — the same 32 runtime presets with dev5 evidence-backed camera/fog names and the unresolved shared material scalar retained explicitly.
- `CAMERA_PRESET_SCHEMA.csv` — per-word structural schema, consumer addresses, transition behavior, confidence, and unresolved semantic notes.

- `PA_ROUTE_BUILD_GATES.csv` — PS3 retail/Xbox retail/June 10/May 11/May 9 PA-route activation-gate comparison.
- `PA_ROUTE_FUNCTIONS.csv` — cross-build `Route::SetPaRoute`, activation-wrapper, and setup function correspondences.
- `PA_ROUTE_CAMERA_SELECTIONS.csv` — cam01/cam02 selection support and retail-activation evidence.
- `PA_ROUTE_BOSS_MAPPING.csv` — conservative Water Strider/Ultimate UFO to field-descriptor/Bmap correlations with confidence labels.
- `PA_ROUTE_BOSS_FUNCTIONS.csv` — cross-build Ultimate UFO / Water Strider executable function map.
- `WATER_STRIDER_ROUTE_SEGMENTS.csv` — retail/June/PS3 17-segment 0..1440 Water Strider course table.
- `ULTIMATE_UFO_ROUTE_PHASES.csv` — retail/June/PS3 and May prototype Ultimate UFO phase tables.

- `ULTIMATE_UFO_LATE_OBJECTS.csv` — cross-build executable identity of the late Ultimate UFO owned model used by phases 11/final-disable.
