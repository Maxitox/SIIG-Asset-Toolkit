#!/usr/bin/env python3
"""Desktop control center for the SIIG Asset Toolkit.

The GUI intentionally wraps the existing audited CLI instead of duplicating format logic.
It uses only the Python standard library (Tkinter) and launches toolkit commands in a
background thread so long extraction/build operations do not freeze the window.
"""
from __future__ import annotations

import json
import os
import queue
import shlex
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path
from typing import Callable, Optional

ROOT = Path(__file__).resolve().parent
TOOLKIT = ROOT / "siig_toolkit.py"
VERSION_FILE = ROOT / "VERSION.txt"
GUI_VERSION = "0.1.0-dev25"


def toolkit_version() -> str:
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return "unknown"


def diagnostics() -> dict:
    try:
        import tkinter as tk  # noqa: F401
        tkinter_ok = True
    except Exception:
        tkinter_ok = False
    return {
        "gui_version": GUI_VERSION,
        "toolkit_version": toolkit_version(),
        "toolkit_exists": TOOLKIT.is_file(),
        "tkinter_available": tkinter_ok,
        "python": sys.version.split()[0],
        "tabs": ["Game Rip", "Mod Workspace", "GMX Workbench", "Utilities"],
        "principle": "GUI wraps the existing CLI; format logic stays in audited toolkit code",
    }


def _open_path(path: Path) -> None:
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception:
        if path.is_file() and path.suffix.lower() in {".html", ".htm"}:
            webbrowser.open(path.resolve().as_uri())


def main() -> int:
    if "--check" in sys.argv:
        print(json.dumps(diagnostics(), indent=2))
        return 0
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except Exception as exc:
        print(f"Tkinter is unavailable: {exc}", file=sys.stderr)
        return 2

    class App(tk.Tk):
        def __init__(self) -> None:
            super().__init__()
            self.title(f"SIIG Asset Toolkit {toolkit_version()} — Desktop")
            self.geometry("1120x780")
            self.minsize(900, 650)
            self._queue: queue.Queue = queue.Queue()
            self._busy = False
            self._buttons: list[ttk.Button] = []
            self._status = tk.StringVar(value="Ready")
            self._build_ui()
            self.after(80, self._poll_queue)

        def _build_ui(self) -> None:
            outer = ttk.Frame(self, padding=10)
            outer.pack(fill="both", expand=True)
            header = ttk.Frame(outer)
            header.pack(fill="x", pady=(0, 8))
            ttk.Label(header, text="SIIG Asset Toolkit", font=("TkDefaultFont", 16, "bold")).pack(side="left")
            ttk.Label(header, text=f"  {toolkit_version()}  •  GUI {GUI_VERSION}").pack(side="left", padx=6)
            ttk.Label(header, textvariable=self._status).pack(side="right")

            note = ttk.Label(
                outer,
                text="Desktop control center. All native parsing/building still uses the same audited CLI code underneath.",
                foreground="#555555",
            )
            note.pack(fill="x", pady=(0, 8))

            self.tabs = ttk.Notebook(outer)
            self.tabs.pack(fill="both", expand=True)
            self._tab_game(ttk.Frame(self.tabs, padding=12))
            self._tab_mod(ttk.Frame(self.tabs, padding=12))
            self._tab_gmx(ttk.Frame(self.tabs, padding=12))
            self._tab_util(ttk.Frame(self.tabs, padding=12))

            log_frame = ttk.LabelFrame(outer, text="Task log", padding=6)
            log_frame.pack(fill="both", expand=False, pady=(10, 0))
            self.log = tk.Text(log_frame, height=12, wrap="word")
            scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
            self.log.configure(yscrollcommand=scroll.set)
            self.log.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")
            toolbar = ttk.Frame(outer)
            toolbar.pack(fill="x", pady=(5, 0))
            ttk.Button(toolbar, text="Clear log", command=lambda: self.log.delete("1.0", "end")).pack(side="left")
            ttk.Button(toolbar, text="Copy log", command=self._copy_log).pack(side="left", padx=5)

        def _entry_row(self, parent, row: int, label: str, var, kind: str = "file", save: bool = False, filetypes=None) -> None:
            ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=4)
            ttk.Entry(parent, textvariable=var).grid(row=row, column=1, sticky="ew", pady=4)
            def browse() -> None:
                initial = Path(var.get()).expanduser() if var.get() else Path.home()
                if kind == "dir":
                    value = filedialog.askdirectory(initialdir=str(initial if initial.is_dir() else initial.parent))
                elif save:
                    value = filedialog.asksaveasfilename(initialdir=str(initial.parent), initialfile=initial.name, filetypes=filetypes or [("All files", "*.*")])
                else:
                    value = filedialog.askopenfilename(initialdir=str(initial if initial.is_dir() else initial.parent), filetypes=filetypes or [("All files", "*.*")])
                if value:
                    var.set(value)
            ttk.Button(parent, text="Browse…", command=browse).grid(row=row, column=2, padx=(8, 0), pady=4)
            parent.columnconfigure(1, weight=1)

        def _action(self, parent, text: str, command: Callable[[], None], row: int, col: int = 0, span: int = 1) -> None:
            button = ttk.Button(parent, text=text, command=command)
            button.grid(row=row, column=col, columnspan=span, sticky="ew", padx=4, pady=4)
            self._buttons.append(button)

        def _tab_game(self, tab) -> None:
            self.tabs.add(tab, text="Game Rip")
            self.game_input = tk.StringVar()
            self.game_output = tk.StringVar(value=str(Path.cwd() / "SIIG_Ripped"))
            self.game_resume = tk.BooleanVar(value=True)
            ttk.Label(tab, text="Full-game extraction and verification", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
            self._entry_row(tab, 1, "Game/package", self.game_input)
            self._entry_row(tab, 2, "Rip output", self.game_output, kind="dir")
            ttk.Checkbutton(tab, text="Resume/reuse unchanged work", variable=self.game_resume).grid(row=3, column=1, sticky="w", pady=4)
            actions = ttk.Frame(tab); actions.grid(row=4, column=0, columnspan=3, sticky="ew", pady=8)
            for c in range(4): actions.columnconfigure(c, weight=1)
            self._action(actions, "Rip game", self._rip_game, 0, 0)
            self._action(actions, "Verify rip", lambda: self._run(["verify-output", self.game_output.get()]), 0, 1)
            self._action(actions, "Build asset viewer", self._build_viewer, 0, 2)
            self._action(actions, "Open rip folder", lambda: _open_path(Path(self.game_output.get())), 0, 3)
            ttk.Label(tab, text="The full rip automatically converts supported models/textures/scripts and writes validation reports.", wraplength=850).grid(row=5, column=0, columnspan=3, sticky="w", pady=4)

        def _tab_mod(self, tab) -> None:
            self.tabs.add(tab, text="Mod Workspace")
            self.mod_rip = tk.StringVar()
            self.mod_ws = tk.StringVar(value=str(Path.cwd() / "SIIG_Mod_Workspace"))
            ttk.Label(tab, text="Mod project / .siigmod workflow", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
            self._entry_row(tab, 1, "Verified rip", self.mod_rip, kind="dir")
            self._entry_row(tab, 2, "Workspace", self.mod_ws, kind="dir")
            actions = ttk.Frame(tab); actions.grid(row=3, column=0, columnspan=3, sticky="ew", pady=8)
            for c in range(4): actions.columnconfigure(c, weight=1)
            self._action(actions, "Initialize", lambda: self._run(["mod-init", self.mod_rip.get(), "-o", self.mod_ws.get()]), 0, 0)
            self._action(actions, "List assets", lambda: self._run(["mod-list", self.mod_ws.get()]), 0, 1)
            self._action(actions, "Build changes", lambda: self._run(["mod-build", self.mod_ws.get()]), 0, 2)
            self._action(actions, "Verify build", lambda: self._run(["mod-verify", self.mod_ws.get()]), 0, 3)
            self._action(actions, "Pack .siigmod…", self._pack_mod, 1, 0)
            self._action(actions, "Inspect .siigmod…", self._inspect_mod, 1, 1)
            self._action(actions, "Apply .siigmod…", self._apply_mod, 1, 2)
            self._action(actions, "Open workspace", lambda: _open_path(Path(self.mod_ws.get())), 1, 3)
            ttk.Label(tab, text="Asset export/staging remains available through the workspace files; later GUI revisions can add per-resource editors here.", wraplength=850).grid(row=4, column=0, columnspan=3, sticky="w", pady=4)

        def _tab_gmx(self, tab) -> None:
            self.tabs.add(tab, text="GMX Workbench")
            self.gmx_template = tk.StringVar()
            self.gmx_gltf = tk.StringVar()
            self.gmx_output = tk.StringVar()
            self.gmx_json = tk.StringVar()
            self.gmx_flip = tk.BooleanVar(value=False)
            ttk.Label(tab, text="GMX model workbench", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
            self._entry_row(tab, 1, "Native GMX template", self.gmx_template, filetypes=[("SIIG GMX", "*.gmx"), ("All files", "*.*")])
            self._entry_row(tab, 2, "Edited glTF", self.gmx_gltf, filetypes=[("glTF 2.0", "*.gltf"), ("All files", "*.*")])
            self._entry_row(tab, 3, "Output GMX", self.gmx_output, save=True, filetypes=[("SIIG GMX", "*.gmx")])
            self._entry_row(tab, 4, "Editable GMX JSON", self.gmx_json, save=True, filetypes=[("JSON", "*.json")])
            ttk.Checkbutton(tab, text="Flip UV V on glTF import/export", variable=self.gmx_flip).grid(row=5, column=1, sticky="w", pady=4)
            actions = ttk.Frame(tab); actions.grid(row=6, column=0, columnspan=3, sticky="ew", pady=8)
            for c in range(4): actions.columnconfigure(c, weight=1)
            self._action(actions, "Inspect GMX", self._inspect_gmx, 0, 0)
            self._action(actions, "Export glTF", self._export_gltf, 0, 1)
            self._action(actions, "Import glTF → GMX", self._import_gltf, 0, 2)
            self._action(actions, "Export editable JSON", self._export_gmx_json, 0, 3)
            self._action(actions, "Build JSON → GMX", self._build_gmx_json, 1, 0)
            self._action(actions, "Open model folder", lambda: _open_path(Path(self.gmx_template.get()).parent), 1, 1)
            ttk.Label(
                tab,
                text=("dev25 topology import can change vertex/index counts inside an existing native GMX mesh graph. "
                      "Materials, shaders, bones, attachments and animation chunk identities remain template-owned. "
                      "This is intentionally one step short of arbitrary from-scratch GMX graph synthesis."),
                wraplength=900,
            ).grid(row=7, column=0, columnspan=3, sticky="w", pady=8)

        def _tab_util(self, tab) -> None:
            self.tabs.add(tab, text="Utilities")
            self.util_input = tk.StringVar()
            self.viewer_input = tk.StringVar()
            self.viewer_output = tk.StringVar(value=str(Path.cwd() / "siig_asset_viewer"))
            ttk.Label(tab, text="Validation and browser utilities", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
            self._entry_row(tab, 1, "Doctor input (optional)", self.util_input)
            self._entry_row(tab, 2, "Asset directory", self.viewer_input, kind="dir")
            self._entry_row(tab, 3, "Viewer output", self.viewer_output, kind="dir")
            actions = ttk.Frame(tab); actions.grid(row=4, column=0, columnspan=3, sticky="ew", pady=8)
            for c in range(4): actions.columnconfigure(c, weight=1)
            self._action(actions, "Doctor", self._doctor, 0, 0)
            self._action(actions, "Run selftests", lambda: self._run(["selftest"]), 0, 1)
            self._action(actions, "Asset capabilities", lambda: self._run(["asset-capabilities"]), 0, 2)
            self._action(actions, "Build viewer", self._util_viewer, 0, 3)
            ttk.Button(tab, text="Open toolkit documentation folder", command=lambda: _open_path(ROOT / "docs")).grid(row=5, column=0, sticky="w", padx=4, pady=4)

        def _copy_log(self) -> None:
            self.clipboard_clear(); self.clipboard_append(self.log.get("1.0", "end-1c"))

        def _append(self, text: str) -> None:
            self.log.insert("end", text)
            self.log.see("end")

        def _set_busy(self, busy: bool) -> None:
            self._busy = busy
            for button in self._buttons:
                try: button.configure(state="disabled" if busy else "normal")
                except Exception: pass
            self._status.set("Working…" if busy else "Ready")

        def _run(self, args: list[str], on_done: Optional[Callable[[int], None]] = None) -> None:
            args = [str(x) for x in args if str(x) != ""]
            if self._busy:
                messagebox.showinfo("SIIG Toolkit", "Another toolkit task is already running.")
                return
            if not TOOLKIT.is_file():
                messagebox.showerror("SIIG Toolkit", f"Missing {TOOLKIT}")
                return
            self._set_busy(True)
            cmd = [sys.executable, str(TOOLKIT), *args]
            self._append("\n$ " + " ".join(shlex.quote(x) for x in cmd) + "\n")
            def worker() -> None:
                code = 1
                try:
                    proc = subprocess.Popen(cmd, cwd=str(ROOT), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
                    assert proc.stdout is not None
                    for line in proc.stdout:
                        self._queue.put(("line", line))
                    code = proc.wait()
                except Exception as exc:
                    self._queue.put(("line", f"GUI launcher error: {exc}\n"))
                self._queue.put(("done", code, on_done))
            threading.Thread(target=worker, daemon=True).start()

        def _poll_queue(self) -> None:
            try:
                while True:
                    item = self._queue.get_nowait()
                    if item[0] == "line": self._append(item[1])
                    elif item[0] == "done":
                        code, callback = item[1], item[2]
                        self._append(f"[exit {code}]\n")
                        self._set_busy(False)
                        if callback: callback(code)
            except queue.Empty:
                pass
            self.after(80, self._poll_queue)

        def _rip_game(self) -> None:
            if not self.game_input.get(): return messagebox.showerror("Game rip", "Choose an input first.")
            args = ["rip-game", self.game_input.get(), "-o", self.game_output.get()]
            if self.game_resume.get(): args.append("--resume")
            self._run(args)

        def _build_viewer(self) -> None:
            root = Path(self.game_output.get())
            out = root / "asset_viewer"
            self._run(["asset-viewer", str(root), "-o", str(out)], lambda code: _open_path(out / "index.html") if code == 0 else None)

        def _pack_mod(self) -> None:
            out = filedialog.asksaveasfilename(defaultextension=".siigmod", filetypes=[("SIIG mod package", "*.siigmod")])
            if out: self._run(["mod-pack", self.mod_ws.get(), "-o", out])

        def _inspect_mod(self) -> None:
            path = filedialog.askopenfilename(filetypes=[("SIIG mod package", "*.siigmod"), ("All files", "*.*")])
            if path: self._run(["mod-package-info", path])

        def _apply_mod(self) -> None:
            path = filedialog.askopenfilename(filetypes=[("SIIG mod package", "*.siigmod"), ("All files", "*.*")])
            if path:
                if not self.mod_rip.get():
                    return messagebox.showerror("Apply mod", "Choose the verified source rip first.")
                self._run(["mod-apply", path, self.mod_rip.get(), self.mod_ws.get(), "--build"])

        def _inspect_gmx(self) -> None:
            if self.gmx_template.get(): self._run(["scan", self.gmx_template.get()])

        def _export_gltf(self) -> None:
            template = Path(self.gmx_template.get())
            if not template.is_file(): return messagebox.showerror("GMX", "Choose a native GMX first.")
            out = filedialog.askdirectory(title="Choose glTF output directory")
            if not out: return
            args = ["gmx2gltf", str(template), "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            def done(code: int) -> None:
                if code == 0:
                    gltf = Path(out) / (template.stem + ".gltf")
                    if gltf.exists(): self.gmx_gltf.set(str(gltf))
            self._run(args, done)

        def _import_gltf(self) -> None:
            template = Path(self.gmx_template.get()); gltf = Path(self.gmx_gltf.get())
            if not template.is_file() or not gltf.is_file(): return messagebox.showerror("GMX", "Choose both the native GMX template and edited glTF.")
            out = self.gmx_output.get() or str(template.with_name(template.stem + ".edited.gmx")); self.gmx_output.set(out)
            args = ["gltf2gmx-template", str(gltf), "--template", str(template), "-o", out]
            if self.gmx_flip.get(): args.append("--flip-v")
            self._run(args)

        def _export_gmx_json(self) -> None:
            template = Path(self.gmx_template.get())
            if not template.is_file(): return messagebox.showerror("GMX", "Choose a native GMX first.")
            out = self.gmx_json.get() or str(template.with_suffix(".gmx.edit.json")); self.gmx_json.set(out)
            self._run(["gmx-edit-export", str(template), "-o", out])

        def _build_gmx_json(self) -> None:
            template = Path(self.gmx_template.get()); doc = Path(self.gmx_json.get())
            if not template.is_file() or not doc.is_file(): return messagebox.showerror("GMX", "Choose a GMX template and editable JSON.")
            out = self.gmx_output.get() or str(template.with_name(template.stem + ".edited.gmx")); self.gmx_output.set(out)
            self._run(["gmx-build", str(doc), "--template", str(template), "-o", out])

        def _doctor(self) -> None:
            args = ["doctor"]
            if self.util_input.get(): args.append(self.util_input.get())
            self._run(args)

        def _util_viewer(self) -> None:
            if not self.viewer_input.get(): return messagebox.showerror("Asset viewer", "Choose an asset directory first.")
            out = Path(self.viewer_output.get())
            self._run(["asset-viewer", self.viewer_input.get(), "-o", str(out)], lambda code: _open_path(out / "index.html") if code == 0 else None)

    app = App()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
