# Source-provenance audit report

Audit date: 2026-09-10  
Development tree reviewed: SIIG Asset Toolkit 2.8.0-dev25

## Scope

Reviewed bundled Python/Java source, launchers, add-on source, documentation, provenance tables, and release-layout files for vendored dependencies, copied/adapted logic, external-process calls, game assets, and unresolved attribution.

## Findings

- No third-party Python package, executable, shared library, emulator, decompiler, OpenSSL binary, FFmpeg binary, or vgmstream binary/source is bundled.
- One direct code adaptation remains identified: `xg_address_2d_tiled_offset`, an independent Python translation/adaptation of Xenia's Xenos tiled-texture addressing. The BSD 3-Clause notice remains bundled. The historical exact Xenia commit/file consulted was not preserved; that limitation remains explicit.
- The XMA2 RIFF wrapper is locally written against public Microsoft/DirectXTK structure documentation.
- AES-128, STFS, PS3 PKG, debug package streaming, extraction-safety policy, and NPDRM SDAT handling are locally authored clean-room code. FIPS-197 is the AES normative/known-answer reference.
- Finalized PS3 PKG extraction may invoke an installed OpenSSL executable as an optional acceleration backend. OpenSSL is external and not bundled; Python AES-CTR remains the fallback and is equivalence-tested.
- The new Sony SBlk v3/PS-ADPCM implementation is locally authored for the supplied SIIG bank. vgmstream `src/meta/bnk_sony.c` and `src/coding/psx_decoder.c` were explicitly consulted as behavioral/field-layout cross-checks. No vgmstream code was copied or vendored.
- BBX, GMX, SIIG TEX wrappers, system font, localization, COL, ANM, DAT, MAP, stage tables, atlas mapping, Bmap/Xmap, wall/generator, and shader-container work remains based on user-supplied binaries, Ghidra exports, synthetic fixtures, and corpus validation.
- Stage Explorer v5 source was reconstructed from the project's own retained validated generated explorer plus current executable-backed semantics; no third-party UI code was introduced.
- The Blender add-on, Asset Viewer, BBX repacker, localhost server, and resume-cache implementation are locally authored.
- TCRF/The Cutting Room Floor remains explicitly excluded.

## Real-package validation

The project now possesses and has directly exercised the supplied original retail Xbox 360 LIVE STFS and PS3 type-1 PKG. This supersedes older notes claiming those exact packages were unavailable. Retail regressions reach 2,593 resources with zero BBX hash mismatches/archive failures on both platforms; PS3 validates six internally decrypted SDATs / 18 authenticated blocks and 84 Sony WAV streams, while Xbox validates 86 XACT WAV streams.

## Current source-only validation

The 2.8.0-dev25 source tree passes 71/71 built-in tests. A packaging audit found zero proprietary game-asset extensions, zero external executable/container magic, zero bundled binary members inside the locally authored Blender add-on ZIP, zero private runtime paths, and zero Python bytecode. `reference/provenance/SOURCES.csv` contains 24 source/reference rows with a consistent 10-column schema.


Dev2 adds executable-derived runtime registry, route-source, GMX animation-track, route-descriptor, and raw camera-preset outputs. These additions were derived from the retained five-build Ghidra exports and supplied retail corpus; no new third-party code was copied or vendored. The changed paths were revalidated on all 47 retail Bmap/Xmap-layout files and all four route/camera GMXs.

Dev3 adds a locally authored executable-backed route resampler and runtime camera-preset tables. The route implementation is derived directly from the retained PS3 retail PPC listing/decompilation at functions `0x00158790`, `0x00158A28`, `0x00158D38`, `0x00159298`, `0x00159560`, and `0x0015A338`; no external spline library/code is used. The camera runtime table applies the 160 initializer writes traced at `0x0015C7F0` and preserves uncertain semantics structurally. No new third-party source or binary dependency was introduced.

Dev4 adds locally authored runtime route state and DAT-coupling code derived from the same retained PS3 retail executable: SCROLL_02 conversion at `0x0014E408`, route advancement at `0x00159560`, and route initialization at `0x0015A338`. No external spline, animation, or timing library is used. The new state machine was stress-stepped on all 46 resampleable retail route tables in both non-loop and loop modes, and DAT coupling was additionally exercised on explicit filename-correspondence candidates without claiming a complete global pairing map. No new third-party source or binary dependency was introduced.

Dev5 adds locally authored camera-preset semantic helpers derived directly from retained PS3 retail consumers at `0x00155300`, `0x00157540`, `0x00157A10`, `0x0015B910`, `0x0020D69C`, and `0x0020E984`, plus the renderer `fogRange`/`vFogColor` paths. The untouched raw preset table remains bundled for auditability. No third-party camera/math package or copied implementation was introduced. Word 11 remains explicitly unresolved rather than receiving a guessed material-property name.

Dev6 adds locally authored procedural route-orientation matrix/state helpers and combined procedural camera-world playback derived from the retained PS3 retail route/camera consumers. No third-party matrix, camera, scenegraph, or animation library is used. The combined command requires caller-supplied route/DAT/preset/runtime-coordinate inputs and explicitly excludes animated `cam1`/`int1` and `fld014`/`fld015` modes rather than inferring unsupported activation state.

Dev7 corrects matrix-animation timing and adds animated camera/field evaluators derived directly from the retained PS3 retail executable. Channel-type-12 matrix sampling is implemented as the executable's direct `logical_frame % frame_count` lookup; the raw float timestamp table is preserved as metadata rather than treated as runtime time. No third-party animation/interpolation library or copied code was introduced.

Dev8 adds locally authored PA-route research helpers and four machine-readable cross-build tables derived only from the retained user-supplied PS3 retail, Xbox 360 retail, June 10, May 11, and May 9 Ghidra exports plus the supplied retail DAT corpus. No new third-party source, executable, library, emulator, or online code was introduced. Prototype debug strings are used to recover names such as `Route::SetPaRoute`, while retail/PS3 correspondences are recorded by executable address and function/vtable shape. Strong correlations are explicitly labeled as such rather than promoted to direct-call proof.

Independent post-processing validation also passed on both supplied retail rips: Stage Explorer v5 generated 92 entries / 78 runtime pairings on both Xbox `Media` and PS3 `USRDIR` layouts; Asset Viewer coverage reached 3,520/3,520 Xbox and 3,991/3,991 PS3 previewable thumbnails with zero missing; full hash/privacy verification checked 9,855 Xbox files and 11,195 PS3 files with zero issues.

Dev24 adds locally authored `.siigmod` binary-delta packaging and application code using only Python's standard library. The format stores source/target hashes, copy/sparse instructions, and changed target-byte payloads; it does not bundle clean source assets. External retail corpus validation expanded to 2,197 completed byte-identical no-edit rebuild checks across GMX/TEX/DAT/MAP/ANM/stage tables/COL/systemfont/localization, while proprietary corpus files remain outside the release. No new third-party code, package, executable, or binary dependency was introduced.

## AI disclosure

OpenAI ChatGPT assisted with analysis, code drafting, tests, documentation, and packaging. The project can enumerate explicit sources intentionally consulted, but cannot enumerate the model's full training corpus or latent influences. See `AI_DISCLOSURE.md`.

## Remaining publication gates

- Select a license for original project code before public redistribution.
- Preserve Xenia's BSD notice and all provenance records.
- Keep proprietary game packages/assets and generated game-data viewers out of a source-only public release.
- Perform in-Blender UI/operator validation when Blender is available.
- Continue source-overlap/license review whenever future code is copied or adapted.
- Record exact upstream commit/file whenever feasible for all future external code references.

Dev9 adds only locally authored tables/helpers/documentation derived from the retained five-build Ghidra exports. No executable bytes or proprietary game assets are bundled. Retail Xbox and PS3 literal boss-route tables were byte-matched against June 10 during validation; prototype timing deltas remain documentary data only.

Dev14 adds a locally authored Ultimate UFO final-reset audit table, helper, regression test, and research note derived from retained Xbox 360 retail and PS3 executable listings plus retail DAT records. It records the exact camera-gate clear precondition and separates proven negative results at Mframes 6030/6200 from the still-unresolved ordinary higher-level reset caller. No footage or executable bytes are bundled.


Dev15 adds locally authored mobile package/format inspection and comparison code derived from the user-supplied iOS 4.1.0 IPA and Android 1.0.4 APK research copies. The packages themselves and all extracted assets/executables are excluded from the source-only release. TZIP, mobile MAP, DEX-header, binary-AXML, Mach-O metadata and package-integrity helpers use Python's standard library only.

Dev16 adds locally authored mobile-exclusive research tables, shared DAT opcode labels, and a Chimera opcode regression derived from retained iOS executable symbols/resources plus user-supplied research packages. Third-party MaxTheMurdererV2 gameplay videos are credited as observational corroboration only and are not bundled. No video, crossover music, stage data, mobile executable, IPA, or APK content is included.

Dev17 adds locally authored Survival Evolution Tree gating/substitution references, V2 enemy-shot dispatch/attack-pool mappings, conservative V2 mover-branch summaries, and Chimera A/B boss-argument documentation derived from retained iOS executable/resource analysis. No new third-party code or binary dependency was introduced; existing gameplay-video references remain observational provenance only and no footage is bundled.


Dev18 adds locally authored iOS→console MAP/DAT/timing/generator lineage metadata derived from retained user-supplied iOS ARMv7 and console Ghidra exports plus decoded resource tables. No executable bytes, decompiled proprietary code, IPA/APK content, or stage payloads are bundled.

Dev19 extends that source-only lineage into six original Stage-3 boss constructor/pool ancestry, the Xbox 0x96..0xAB enemy-handler family, World-5 integration chronology, and exact authored-DAT-loader anchors. The release explicitly preserves the continuity boundary where raw handler pointer values and exact per-boss May11→June10 similarity scores were not retained instead of reconstructing them speculatively. No new third-party source or binary dependency was introduced.
Dev20 extends the source-only lineage into the six original mobile boss gameplay movers using re-supplied project-owner Ghidra exports for May 9, May 11, June 10, retail Xbox and retail PS3 plus the retained iOS ARMv7 research copy. Only derived addresses, instruction fingerprints, constants, equations and semantic summaries are included. No XEX/EBOOT/Mach-O bytes or decompiled proprietary code are bundled. The local Mach-O metadata repair used to disassemble the modified iOS research copy is an analysis-only working file and is excluded from the package. No new third-party source or binary dependency was introduced.



Dev22 adds locally authored native rebuilders for the completely mapped stagewall/generator and `0x118` stage3D table records, a template-preserving fixed-layout GMX field editor, and dedicated `text.bin` / `message.bin` localization compilers. These builders are derived from the project's existing clean-room parsers, supplied-corpus structure research, and synthetic byte-roundtrip fixtures. The release does not bundle a GMX, localization archive, audio bank, game executable, or other proprietary validation input. GMX native rebuild and localization byte-identity regression claims in dev22 are intentionally limited to synthetic structural fixtures unless separately noted; real runtime acceptance remains outside the source-only release gate. No new third-party dependency or copied external implementation was introduced.

Dev23 adds the locally authored mod-workspace orchestration layer above the existing clean-room native builders. Its real-corpus round-trip validation used user-supplied retail `player.bin`, `text.bin`, and `message.bin` as external test inputs only: all 13 player GMXs and both localization archives passed byte-identical no-op rebuild checks. Only derived hashes/counts are retained in the source-only validation report; proprietary inputs, extracted assets, and rebuilt test payloads are excluded. The workspace project file may intentionally store the user's local source-rip path at runtime, but no such runtime workspace or private path is bundled in the release. Xbox gzip patch generation is locally authored; PS3 NPDRM/SDAT re-encryption remains unsupported. No new third-party dependency or copied external implementation was introduced.
