# Space Invaders Infinity Gene Asset Toolkit

**Version 2.8.0-dev10 — executable-backed special-stage reload and Ultimate UFO death-transition research development build**

SIIG Asset Toolkit is a dependency-light Python toolkit for researching and extracting assets from the Xbox 360 and PlayStation 3 releases of **Space Invaders Infinity Gene**. It accepts original outer packages, extracted game folders, or ZIP archives; extracts nested BBX resources; converts supported assets; builds a self-contained stage explorer; and records enough metadata to audit the result.

The toolkit is based on user-supplied retail/prototype files, cross-platform comparisons, and Ghidra exports from `default.xex`. It does not include game binaries or extracted copyrighted assets.

## Highlights through 2.8.0-dev10

- Added `pa-route-info` and four machine-readable cross-build PA-route reference tables, using PS3 retail plus Xbox retail/June 10/May 11/May 9 executable evidence.
- Recovered the prototype debug name `Route::SetPaRoute`, proved the retail/June category-0 + state `(4,1)` gate, identified May 11's earlier state-only gate, and documented the missing corresponding May 9 setup branch.
- Proved the known retail setup selects `cam01_op1.gmx`; `cam02_op1.gmx` remains supported by `SetPaRoute` but without a proven retail activation callsite.
- Closed the special-stage reload chain: DAT `WARNING [12]` directly requests Bmap13/fld014 and `WARNING [14]` requests Bmap15/fld015 through executable transition state writes; boss spawn alone is not the trigger.
- Traced the common HP-zero dispatch into Ultimate UFO destruction state, recovered prototype `UltimateUfo::Vanish`, and documented the executable late-phase destruction actions at frames 6030 and 6200.
- Human labels for the observed airlock escape/final rear-camera shot remain intentionally unresolved until their specific camera consumer is recovered.
- Added `camera-preset`, a semantic inspector for the 32 retail camera presets with optional executable-backed dynamic horizontal-response evaluation.
- Resolved camera preset word 0 as perspective FOV degrees, word 1 as uniform scene/view scale, words 2–4 as the camera-eye offset, and words 5–7 as scene/view translation.
- Resolved words 8–10 as dynamic horizontal-response gain plus target/eye local-X response scales using normalized runtime coordinates; gameplay labels remain deliberately unguessed.
- Proved words 12–29 are three renderer fog profiles `{start, end, RGBA}` through `fogRange` and `vFogColor` consumers.
- Traced word 11 as one shared scalar forwarded to `collada_edge1`, `collada_face1`, and `collada_face2`; its virtual-setter meaning remains explicitly unresolved.
- Added `CAMERA_PRESETS_RUNTIME_SEMANTIC.csv` while retaining the untouched raw executable table and structural runtime table.
- Added procedural route orientation and `route-camera-playback`; dev7 corrects matrix-animation playback to the retail 30 Hz logical-frame clock and adds explicit animated camera/field exporters; the current dependency-free regression suite passes 38 tests.
- Added `route-resample`, reproducing the retail PS3 non-loop route segment builder at a user-supplied constant spacing: equal-distance linear subdivision, the exact straight/curve classifier, six-state tangent-axis selection, and cubic Hermite interpolation.
- Added `route-playback`, which applies caller-supplied DAT SCROLL_02 timing to the executable-backed route state machine, including loop wrapping and linear mid-segment spacing rebuilds. Route↔DAT pairing and route-object activation remain explicit caller inputs rather than inferred.
- Added runtime-initialized 32 × 30 camera-preset values plus a structural per-word schema derived from the camera initializer/consumer call chain; ambiguous gameplay labels remain unresolved.
- Added five-build executable-derived runtime entity/primitive registry tables with decoded 0x2C record fields and renderer-group selectors.
- `stage3dmap` exports the exact executable-ordered route-source control points and record-0 origin fallback as CSV/OBJ.
- Added `gmxtrack` for GMX matrix-animation CSV and translation-path OBJ export; validated the four retail route/camera GMXs and all six tracks.
- Validated direct extraction of the original retail Xbox 360 `LIVE` STFS and PS3 type-1 PKG supplied for this project.
- Added optional OpenSSL acceleration for finalized PS3 PKG AES-CTR with a dependency-free Python fallback and equivalence tests.
- Added internal authenticated decryption of SIIG's six NPDRM SDAT resources; TrueAncestor-style `.bin.gz.dat` files remain optional fallback inputs only.
- Added built-in Sony 989SND/SCREAM SBlk v3 parsing and PS-ADPCM WAV export for all 84 retail PS3 sound streams.
- Restored Stage Explorer v5 runtime scrolling: SCROLL_01/02/03 drive layers 0/1/2, with 30 Hz playback controls and 468 decoded scroll events across the retail stage corpus.
- Added content-addressed outer-package caching for `--resume`, avoiding repeated STFS/PKG/ZIP unpacking when the input hash is unchanged.
- Fixed the STFS `CON` first-hash-table initialization path and added a regression fixture.
- Integrated PS3 EBOOT-backed 3D placement, route-point, scroll, and timing corrections into the current source tree.

The v2.5 linked-data Asset Viewer and earlier format research remain included. This remains a development build while automatic PA-route activation timing, the word-11 material scalar, shader ISA work, Blender runtime validation, and project licensing remain open.

## Release folder layout

```text
SIIG_Asset_Toolkit_v2.8.0-dev10/
├── siig_toolkit.py and companion modules
├── SIIG_*.bat launchers
├── docs/          guides, format research, project records, release history
├── reference/     tables, provenance, samples, system-font support data
├── validation/    machine-readable validation reports
├── tools/         optional Ghidra helper
├── addons/        Blender add-on package and source
└── LICENSES/      required third-party notices
```

Use [`docs/README.md`](docs/README.md) as the central index.

## Requirements

- Python **3.10 or newer**.
- No third-party Python packages are required.
- FFmpeg is optional and only needed to decode Xbox 360 XMA2 streams to PCM WAV. Without FFmpeg, the toolkit still writes RIFF-wrapped `.xma` files and manifests.
- PS3 SIIG's six inner NPDRM SDAT resources are decrypted and authenticated internally. Matching `*.bin.gz.dat` files may still be supplied as a fallback for unsupported variants.

## Recommended first run

From Command Prompt or PowerShell in the toolkit folder:

```bat
python siig_toolkit.py --version
python siig_toolkit.py selftest
python siig_toolkit.py doctor "C:\path\to\game-package"
```

On Windows, `py -3` may be used instead of `python`.

## One-click full-game extraction

Drag an Xbox 360 STFS package, PS3 PKG, extracted game ZIP, or extracted game folder onto `SIIG_Rip_Game.bat`.

Command-line equivalent:

```bat
python siig_toolkit.py rip-game "C:\path\to\game-package" -o "C:\path\to\SIIG_Ripped" --resume
```

PS3 requires no external SDAT step for the supplied retail package:

```bat
python siig_toolkit.py rip-game "C:\Games\SIIG.pkg" -o "C:\Rips\SIIG_PS3" --resume
```

`--ps3-sdat-dir` remains available only as a fallback for pre-decrypted `.bin.gz.dat` payloads. `--rap` accepts a 16-byte RAP for workflow compatibility, but SIIG's six supplied SDAT resources do not require RAP-derived keys.

See `docs/guides/FULL_GAME_RIP.md` and `docs/guides/CONTAINER_INPUT_NOTES.md`.

## Verify a completed rip

```bat
python siig_toolkit.py verify-output "C:\path\to\SIIG_Ripped"
```

Or drag the output folder onto `SIIG_Verify_Rip.bat`. Full verification checks report consistency, privacy, file sizes, SHA-256 hashes, and leftover partial files. Use `--quick` to omit hashing.

## Main capabilities

### Package and archive extraction

- Header-based Xbox 360 STFS detection: `CON `, `LIVE`, and `PIRS`.
- PlayStation 3 type-1 PKG extraction for finalized and non-finalized/debug packages.
- ZIP and extracted-directory inputs.
- BBX extraction for `01 42 42 58` containers, including unnamed resources, nested BBX archives, gzip wrappers, filename hierarchy, exact filename-hash verification, and CSV/JSON manifests.
- Configurable extraction limits and atomic writes.

### Repacking and modding research

- Rebuild extracted BBX directories from their manifests with canonical mode/hash/index/name/payload layout.
- Preserve unnamed resource identifiers and reserved header bytes.
- Recompute named hashes by default or preserve deliberate mismatches.
- Verify every output immediately and write a detailed repack report.
- Produce deterministic gzip-wrapped archives when requested.

### Asset browsing and Blender

- Generate a searchable offline asset browser with a small HTML shell and local linked payloads.
- Inspect images, browser-playable audio, text/CSV/JSON, hashes, GMX/glTF/OBJ structure, and interactive wireframes.
- Browse paginated cards with lazy thumbnails for converted and raw SIIG asset formats.
- Import GMX files into Blender 3.6+ with the bundled add-on, using the same exporter as the CLI.
- Serve an output directory on localhost when browsers restrict direct file access.

### Models and textures

- GMX → glTF 2.0 with indexed triangles/lines, positions, normals, UVs, vertex colors, hierarchy, rigid attachment, materials, textures, and transform animation.
- GMX → OBJ as a lightweight static-geometry option.
- Xbox 360 tiled TEX → PNG with Xenos bank/pipe addressing and endian/channel conversion.
- PS3 RSX-wrapped linear A8R8G8B8 TEX → PNG.
- System-font XOR deobfuscation, 2048×3392 atlas export, 6,732-record glyph table, and AngelCode BMFont descriptor.

### Audio and localization

- Xbox 360 XACT3 XWB/XSB extraction, cue naming, XMA2 RIFF wrapping, and optional FFmpeg WAV decoding.
- Lossless preservation of ready-to-use WMA/AT3 media.
- PS3 Sony 989SND/SCREAM SBlk v3 parsing, stream naming, PS-ADPCM decoding, and built-in PCM WAV export; original banks are retained.
- `text.bin` and `message.bin` localization export to UTF-8 CSV, JSON, corrected scripts, raw scripts, and per-language text.

### Structured gameplay data

- DAT command streams to timed semantic CSV/JSON with absolute frames, executable-derived opcode names, confidence labels, and lossless raw words.
- MAP parsing for all three independently sized tile/sprite layers.
- Categorical, grayscale, and verified atlas-backed MAP PNG output.
- Offline Stage Explorer v5 with runtime stage pairing, embedded atlases, MAP layer/composite views, SCROLL_01/02/03 playback, cell inspection, and DAT timeline filtering.
- COL one-bit collision masks to PNG.
- ANM model/group clip ranges to CSV/JSON, including start/end frames and loop behavior.
- Bmap/Xmap/map4/map5 3D path and GMX-placement tables to JSON/CSV/OBJ, including exact runtime route-source control points.
- Wall/Xwall repeat strips and `stage_generate.bin` candidate tables to JSON/CSV.
- Xenos compiled-shader headers, metadata strings, hashes, and raw microcode extraction.

### Research support

- `scan` for JSON descriptions of known formats.
- `tools/ghidra/ApplySIIGFunctionNames.java` for optional confirmed Ghidra labels.
- `gmxtrack` for decomposed GMX animation matrices and translation trajectories.
- Machine-readable validation tables and format notes, including the five-build runtime entity registry, raw/runtime-initialized camera presets, and route-resampler evidence.
- Privacy sanitizer for older JSON metadata.
- Source, license, attribution, and AI-assistance records.

## Common commands

### Inspect the environment and input

```bat
python siig_toolkit.py doctor "C:\path\to\input"
```

### Extract only the outer STFS/PKG container

```bat
python siig_toolkit.py unpack-container "C:\path\to\package" -o outer_files --clean
```

### Extract a BBX archive

```bat
python siig_toolkit.py extract player.bin -o extracted --convert-gltf --convert-tex
```

### Recursively extract a directory of BBX archives

```bat
python siig_toolkit.py extract game_bins -o extracted --recursive --convert-gltf --convert-tex
```

### Build or rebuild the stage explorer

```bat
python siig_toolkit.py stageviz "C:\path\to\SIIG_Ripped" -o stage_explorer
```

Open `stage_explorer\SIIG_Stage_Explorer.html`. The file is self-contained and makes no network requests.

### Render a MAP with a verified atlas

```bat
python siig_toolkit.py map2png level1_stage1.map -o map_preview ^
  --atlas fence1_512.png --atlas-step 30 --csv
```

Without `--atlas`, the command writes exact categorical or grayscale cell visualizations.

### Repack an extracted BBX

```bat
python siig_toolkit.py extract map.bin -o work
python siig_toolkit.py repack-bbx work\map -o map_repacked.bin
```

The second command reads `work\map\manifest.json`, writes atomically, verifies the new archive, and creates a `.repack.json` report. See `docs/guides/BBX_REPACK_NOTES.md` before modifying game data.

### Build and open the asset viewer

```bat
python siig_toolkit.py asset-viewer "C:\path\to\SIIG_Ripped" -o viewer
python siig_toolkit.py serve viewer
```

The server binds only to `127.0.0.1`. Keep `SIIG_Asset_Viewer.html` beside its generated `viewer_assets` directory; the viewer is intentionally no longer one giant self-contained file.

### Install the Blender add-on

Install `addons/SIIG_Blender_Addon_v0.1.0.zip` through Blender's Add-ons preferences, then point its preferences at this toolkit folder. See `docs/guides/BLENDER_ADDON_NOTES.md`.

### Decode 3D stage paths and placements

```bat
python siig_toolkit.py stage3dmap extracted\stage -o stage3d
```

### Export GMX animation tracks

```bat
python siig_toolkit.py gmxtrack extracted\route -o gmx_tracks
```

This writes one decomposed CSV and translation-path OBJ per supported ANIM track. ANIM timestamps are exported as seconds; the observed sample rate is derived from the data.

### Resample or play a 3D route

```bat
python siig_toolkit.py route-resample extracted\stage\Xmap3_1.bin -o route_fixed --spacing 100
python siig_toolkit.py route-playback extracted\stage\Xmap3_1.bin extracted\script\level3_stage1.dat -o route_runtime --frame-multiplier 2
```

`route-resample` is the deterministic fixed-spacing analysis path. `route-playback` applies SCROLL_02 timing from the DAT to the executable-backed route runtime. Pairing and route-object activation are not guessed; use `--start-frame` and `--loop` only when supported by the case being investigated.

### Decode wall strips and generator candidates

```bat
python siig_toolkit.py stagewall extracted\stage -o stagewall
```

### Inventory Xbox 360 compiled shaders

```bat
python siig_toolkit.py shader-info extracted\shader -o shader_metadata
```

### Decode localization

```bat
python siig_toolkit.py text2csv "C:\path\to\Media" -o localization
```

### Decode audio

```bat
python siig_toolkit.py xact2wav sound.bin -o audio
```

### Decode the system font

```bat
python siig_toolkit.py font2png systemfont.bin -o systemfont_decoded
```

### Convert extracted models

```bat
python siig_toolkit.py gmx2gltf extracted -o gltf
python siig_toolkit.py gmx2obj extracted -o obj
```

### Run the built-in regression suite

```bat
python siig_toolkit.py selftest
```

## Typical full-rip output

```text
SIIG_Ripped\
├── assets\                  extracted resources and direct conversions
├── decompressed_bbx\        normalized BBX archives
├── audio\                   audio manifests and converted streams
├── localization\            combined UTF-8 exports
├── ready_files\             directly usable media copied unchanged
├── stage_explorer\
│   ├── SIIG_Stage_Explorer.html
│   ├── STAGE_MANIFEST.json
│   └── README.txt
├── asset_viewer\
│   ├── SIIG_Asset_Viewer.html
│   └── ASSET_VIEWER_REPORT.json
├── structured\
│   ├── dat\                  timed DAT CSV/JSON
│   └── map\                  MAP layers, metadata, and optional atlas renders
├── systemfont\              decoded atlas and glyph data
└── validation\
    ├── RIP_REPORT.json
    ├── RIP_REPORT.txt
    ├── OUTPUT_MANIFEST.json
    └── OUTPUT_MANIFEST.sha256
```

Output varies by platform and available source assets.

## Safety and reproducibility

The toolkit treats input packages as untrusted. Outer-container extraction is bounded by file-count, per-file, total-byte, and ZIP-ratio limits. Paths are normalized, traversal and symlink entries are rejected, collisions are detected case-insensitively, writes are atomic, gzip output is bounded, and nested BBX extraction has depth and entry budgets.

Defaults are intentionally generous for SIIG but can be lowered:

```bat
python siig_toolkit.py rip-game game.zip -o SIIG_Ripped ^
  --max-files 10000 --max-total-bytes 8589934592 ^
  --max-file-bytes 2147483648 --max-zip-ratio 200
```

See `docs/guides/SECURITY_NOTES.md`. Keep original packages read-only and verify output before archiving or sharing research results. Repacking never changes the extraction directory, but modified archives must be tested only on copies; it does not update outer-package metadata or executable references.

## Accuracy boundaries

Confirmed facts are separated from unresolved semantics. In particular:

- MAP cells are confirmed 2D tile/sprite data, not 3D wall placements.
- MAP atlas mapping and flip behavior are confirmed. SCROLL_01/02/03 are confirmed as layer 0/1/2 X/Y velocity setters; player-facing names for those layers remain unresolved.
- The Stage Explorer v5 runtime viewport integrates the confirmed scroll vectors at the logical 30 Hz authoring timebase, but it is still not a complete frame-accurate gameplay renderer.
- The 3D stage path, placement, and wall-strip tables are decoded, but complete runtime reconstruction still requires camera/route behavior, auxiliary-vector semantics, collision, and DAT 3D-control playback.
- Direct STFS/PKG readers have synthetic boundary tests and have been validated against the supplied original retail Xbox 360 LIVE package and PS3 type-1 PKG.

## Ethics, licenses, and redistribution

- Do not redistribute game packages, binaries, extracted textures/audio/models, or self-contained explorers containing embedded game atlases without permission.
- The source-only toolkit release contains no game assets.
- External tools such as FFmpeg, Ghidra, XEXLoaderWV, vgmstream, and TrueAncestor are not bundled.
- OpenAI ChatGPT assistance is disclosed in `docs/project/AI_DISCLOSURE.md`.
- Explicit sources and adaptations are recorded in `reference/provenance/SOURCES.csv`, `reference/provenance/PROVENANCE.json`, `docs/project/SOURCE_AUDIT.md`, and `docs/project/THIRD_PARTY_NOTICES.md`.
- TCRF/the Cutting Room Floor was not used and is an explicitly excluded research source; see `docs/project/SOURCE_EXCLUSIONS.md`.
- No license has yet been selected for the toolkit's original project code. See `docs/project/PROJECT_LICENSE_STATUS.md` before redistribution.
