- `RELEASE_VALIDATION_2.8.0-dev23.json` — dev23 aggregate development release gate.
- `SELFTEST_2.8.0-dev23.json` — 68 dependency-free regression tests.
- `REAL_CORPUS_ROUNDTRIP_DEV23.json` — retail Xbox GMX/text/message no-op byte-roundtrip validation; derived hashes/counts only.
- `MOD_WORKSPACE_VALIDATION_DEV23.json` — mod workspace integration validation.
- `SOURCE_ONLY_AUDIT_2.8.0-dev23.json` — dev23 source/package hygiene audit.

- `RELEASE_VALIDATION_2.8.0-dev22.json` — dev22 aggregate development release gate.
- `SELFTEST_2.8.0-dev22.json` — 67 dependency-free regression tests.
- `ASSET_FUNCTIONALIZATION_DEV22.json` — dev22 capability matrix: 11/14 native round-trip families.
- `SOURCE_ONLY_AUDIT_2.8.0-dev22.json` — dev22 source/package hygiene audit.

- `RELEASE_VALIDATION_2.8.0-dev21.json` — dev21 aggregate development release gate.
- `SELFTEST_2.8.0-dev21.json` — 62 dependency-free regression tests.
- `ASSET_FUNCTIONALIZATION_DEV21.json` — viewing/editing/native-build capability matrix for known asset families.
- `SOURCE_ONLY_AUDIT_2.8.0-dev21.json` — dev21 source/package hygiene audit.

- `RELEASE_VALIDATION_2.8.0-dev20.json` — dev20 aggregate development release gate.
- `SELFTEST_2.8.0-dev20.json` — 56 dependency-free regression tests.
- `IOS_CONSOLE_BOSS_MOVER_LINEAGE_DEV20.json` — original-six iOS→console state-machine/mover ancestry validation.
- `SOURCE_ONLY_AUDIT_2.8.0-dev20.json` — dev20 source/package hygiene audit.
# Validation reports

- `RELEASE_VALIDATION_2.8.0-dev19.json` — dev19 aggregate development release gate.
- `SELFTEST_2.8.0-dev19.json` — 55 dependency-free regression tests.
- `IOS_CONSOLE_ENEMY_HANDLER_LINEAGE_DEV19.json` — direct boss-pool/constructor, enemy-handler, World-5 chronology and loader-address validation.
- `SOURCE_ONLY_AUDIT_2.8.0-dev19.json` — dev19 source/package hygiene audit.

- `RELEASE_VALIDATION_2.8.0-dev18.json` — dev18 aggregate development release gate.
- `SELFTEST_2.8.0-dev18.json` — 54 dependency-free regression tests.
- `IOS_CONSOLE_CODE_LINEAGE_DEV18.json` — iOS→console MAP/DAT/timing/generator lineage validation.
- `SOURCE_ONLY_AUDIT_2.8.0-dev18.json` — dev18 source/package hygiene audit.

- `RELEASE_VALIDATION_2.8.0-dev17.json` — dev17 aggregate development release gate.
- `SELFTEST_2.8.0-dev17.json` — 53 dependency-free regression tests.
- `MOBILE_EXCLUSIVES_DEV17.json` — Survival/V2 behavior and Chimera validation.
- `SOURCE_ONLY_AUDIT_2.8.0-dev17.json` — dev17 source/package hygiene audit.

- `RELEASE_VALIDATION_2.8.0-dev16.json` — dev16 aggregate development release gate.
- `SELFTEST_2.8.0-dev16.json` — 52 dependency-free regression tests.
- `MOBILE_EXCLUSIVES_DEV16.json` — executable/resource-backed DELETION, Survival and Chimera validation.
- `SOURCE_ONLY_AUDIT_2.8.0-dev16.json` — dev16 source/package hygiene audit.

- `RELEASE_VALIDATION_2.8.0-dev15.json` — dev15 aggregate development release gate.
- `SELFTEST_2.8.0-dev15.json` — 51 dependency-free regression tests.
- `MOBILE_LINEAGE_DEV15.json` — real supplied iOS/Android mobile corpus and lineage validation.
- `SOURCE_ONLY_AUDIT_2.8.0-dev15.json` — dev15 source/package hygiene audit.


- `RELEASE_VALIDATION_2.8.0-dev14.json` — dev14 aggregate development release gate.
- `SELFTEST_2.8.0-dev14.json` — 46 dependency-free regression tests.
- `ULTIMATE_UFO_FINAL_RESET_DEV14.json` — final-reset caller, timer, script-cleanup, manager-removal, and camera-gate evidence audit.
- `SOURCE_ONLY_AUDIT_2.8.0-dev14.json` — dev14 source/package hygiene audit.

- `RELEASE_VALIDATION_2.8.0-dev13.json` — dev13 aggregate development release gate.
- `SELFTEST_2.8.0-dev13.json` — 45 dependency-free regression tests.
- `ULTIMATE_UFO_CAMERA_RECONSTRUCTION_DEV13.json` — matrix bridge, full-window field-camera, transition-gate and final-Vanish validation.
- `SOURCE_ONLY_AUDIT_2.8.0-dev13.json` — dev13 source/package hygiene audit.

- `RELEASE_VALIDATION_2.8.0-dev12.json` — dev12 aggregate development release gate.
- `SELFTEST_2.8.0-dev12.json` — 43 dependency-free regression tests.
- `ULTIMATE_UFO_DEV12_VALIDATION.json` — five-build HUD/state, stage-variant, Mframe/fld015, camera lifecycle and late-geometry validation.
- `SOURCE_ONLY_AUDIT_2.8.0-dev12.json` — dev12 source/package hygiene audit.

- `SPECIAL_STAGE_DEATH_VALIDATION_2.8.0-dev10.json` — dev10 real retail DAT + five-build executable evidence for special reload and UFO destruction-chain research.
- `SELFTEST_2.8.0-dev10.json` — dev10 38/38 self-test report.
- `SOURCE_ONLY_AUDIT_2.8.0-dev10.json` — dev10 source/package hygiene audit.
- `RELEASE_VALIDATION_2.8.0-dev10.json` — dev10 release gate.
- `BOSS_ROUTE_VALIDATION_2.8.0-dev9.json` — dev9 five-build executable-backed Water Strider / Ultimate UFO route validation.
- `SELFTEST_2.8.0-dev9.json` — dev9 36/36 self-test report.
- `SOURCE_ONLY_AUDIT_2.8.0-dev9.json` — dev9 source/package hygiene audit.

- `SELFTEST_2.8.0-dev8.json` — 35-test dev8 regression report.
- `PA_ROUTE_VALIDATION_2.8.0-dev8.json` — five-build PA-route gate + real 76-DAT corpus validation.
- `RELEASE_VALIDATION_2.8.0-dev8.json` — dev8 inherited/targeted/source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev8.json` — dev8 source/package hygiene audit.
- `SELFTEST_2.8.0-dev7.json` — 34-test dev7 regression report.
- `ANIMATED_RUNTIME_VALIDATION_2.8.0-dev7.json` — real four-GMX runtime timing/camera/field/glTF gate.
- `RELEASE_VALIDATION_2.8.0-dev7.json` — dev7 inherited/targeted/source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev7.json` — dev7 source/package hygiene audit.
- `SELFTEST_2.8.0-dev6.json` — 31-test dev6 regression report.
- `RUNTIME_CAMERA_ROUTE_VALIDATION_2.8.0-dev6.json` — real-corpus procedural orientation and explicit route-camera playback gate.
- `RELEASE_VALIDATION_2.8.0-dev6.json` — dev6 inherited/targeted/source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev6.json` — dev6 source/package hygiene audit.
# Validation reports

Machine-readable reports from release and corpus testing. Historical version numbers are retained in filenames so results are not confused with current runs.

- `SELFTEST_2.8.0-dev5.json` — 29-test dev5 regression report.
- `CAMERA_SEMANTIC_VALIDATION_2.8.0-dev5.json` — 32-preset semantic-table and dynamic-response gate.
- `RELEASE_VALIDATION_2.8.0-dev5.json` — dev5 inherited/targeted/source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev5.json` — dev5 source/package hygiene audit.
- `SELFTEST_2.8.0-dev4.json` — 28-test dev4 regression report.
- `RELEASE_VALIDATION_2.8.0-dev4.json` — dev4 dynamic-route/DAT targeted real-corpus and source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev4.json` — dev4 source/package hygiene audit.
- `SELFTEST_2.8.0-dev3.json` — 26-test dev3 regression report.
- `RELEASE_VALIDATION_2.8.0-dev3.json` — dev3 targeted real-corpus and source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev3.json` — dev3 source/package hygiene audit.
