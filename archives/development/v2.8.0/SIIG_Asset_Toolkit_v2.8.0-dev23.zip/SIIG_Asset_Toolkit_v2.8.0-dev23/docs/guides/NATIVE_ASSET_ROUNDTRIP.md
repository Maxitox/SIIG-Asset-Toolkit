# Native asset round-trip editing

`2.8.0-dev23` continues the asset-functionalization phase: extracted files are not only decoded for inspection, but can increasingly be edited in ordinary desktop formats and compiled back to native SIIG resources.

The design rule is conservative. When a format contains platform/GPU-specific or still-unproven structure, the builder uses an **original file as a template** and preserves bytes the edit does not need to change. Deterministic full synthesis is used only where the record layout is fully accounted for.

For project-level orchestration of these builders, see [`MOD_WORKSPACE.md`](MOD_WORKSPACE.md).

## Current native-build paths

### TEX: PNG -> native Xbox 360 / PS3 TEX

```bat
python siig_toolkit.py tex2png ptn_001.tex -o texture_edit
python siig_toolkit.py png2tex texture_edit\ptn_001.png --template ptn_001.tex -o ptn_001_mod.tex
```

The image dimensions/layout must remain compatible with the template. Xbox rebuilds preserve the Xenos resource metadata, tiling/endian/channel layout, pitch, padding, and unaddressed bytes; PS3 rebuilds preserve the RSX wrapper and replace the logical pixel payload. An unchanged export/rebuild cycle is byte-identical in the regression fixture.

### System font: edited atlas -> native CRP

```bat
python siig_toolkit.py font2png systemfont.bin.gz -o font_edit
python siig_toolkit.py png2font font_edit\systemfont_atlas.png --template systemfont.bin.gz -o systemfont_mod.crp
```

This currently edits atlas pixels only; executable glyph metrics are not rewritten.

### DAT: CSV/JSON -> native script

```bat
python siig_toolkit.py dat2csv level5_stage3.dat -o dat_edit
python siig_toolkit.py dat-build dat_edit\level5_stage3.dat.csv -o level5_stage3_mod.dat
```

Raw numeric opcodes/parameters remain editable even when their higher-level semantics are unresolved. Unchanged parse/build is byte-identical.

### MAP: editable JSON -> native byte grid

```bat
python siig_toolkit.py map2png level1_stage1.map -o map_edit --csv
python siig_toolkit.py map-build map_edit\level1_stage1.map.edit.json -o level1_stage1_mod.map
```

Cell bytes preserve the one-based tile ID plus X/Y reflection bits. Unchanged parse/build is byte-identical.

### ANM: CSV/JSON -> native range table

```bat
python siig_toolkit.py anm2csv enemy.anm -o anm_edit
python siig_toolkit.py anm-build anm_edit\enemy.anm.csv -o enemy_mod.anm
```

Model/group name, start/end frame and loop value can be edited.

### COL: PNG -> native one-bit collision mask

```bat
python siig_toolkit.py col2png wall.col -o col_edit
python siig_toolkit.py png2col col_edit\wall.png --template wall.col -o wall_mod.col
```

The original header is preserved and edited pixels are repacked into the native bit mask.

### Stage wall / Xwall / generator tables: CSV/JSON -> native table

Export a table with the existing `stagewall` command, edit the generated CSV or `*.stagewall.edit.json`, then rebuild:

```bat
python siig_toolkit.py stagewall wall.bin -o wall_edit
python siig_toolkit.py stagewall-build wall_edit\wall.bin.stagewall.edit.json -o wall_mod.bin
```

For CSV input, the kind can be forced explicitly:

```bat
python siig_toolkit.py stagewall-build stage_generate.csv --kind generator_candidates -o stage_generate_mod.bin
```

Each native record is completely accounted for as a 16-byte name plus a big-endian 32-bit value. Canonical unchanged records rebuild byte-identically.

### Bmap / Xmap / map4 / map5: editable 3D route/placement JSON -> native table

```bat
python siig_toolkit.py stage3dmap Bmap15.bin -o stage3d_edit
python siig_toolkit.py stage3d-build stage3d_edit\Bmap15.bin.stage3d.edit.json -o Bmap15_mod.bin
```

Every active record is exactly `0x118` bytes: four placement slots, one cell-step vector, and five route/control-point vectors. A fully described edit document can synthesize these records deterministically. To retain any inactive records or tail bytes from an original file, supply the original as a template:

```bat
python siig_toolkit.py stage3d-build Bmap15.bin.stage3d.edit.json --template Bmap15.bin -o Bmap15_mod.bin
```

A zero cell-step remains the native end sentinel and is rejected for active synthesized records.

### GMX: fixed-layout native template editing

Export a native GMX edit document:

```bat
python siig_toolkit.py gmx-edit-export bos_015k.gmx -o bos_015k.gmx.edit.json
```

After editing supported fields, rebuild against the exact original GMX:

```bat
python siig_toolkit.py gmx-build bos_015k.gmx.edit.json --template bos_015k.gmx -o bos_015k_mod.gmx
```

The edit document is `SIIG_GMX_TEMPLATE_EDIT_V1` and carries the template SHA-256 by default. Supported edits preserve counts, chunk order, chunk sizes, and the proprietary chunk graph while allowing changes to:

- fixed-count float/ushort `ARRY` data, including geometry and indices;
- `TXIF` texture-reference names;
- editable `MTRL` float/vector/matrix/texture parameter values;
- BONE names and 4×4 static matrices;
- MOTN durations;
- ANIM key-time values and 4×4 serialized matrices.

Changing array counts/types, material shader indices, attachment topology, animation target/channel/frame count, or constructing arbitrary new chunk graphs is **not** claimed. `--ignore-template-hash` exists only for deliberately applying a document to another structurally compatible template.

The current automated GMX rebuild gate uses structurally representative synthetic fixtures. The supplied retail GMX corpus was previously validated for parsing/export, but dev22 does **not** claim a real-corpus byte-roundtrip or runtime-mod acceptance test for the new builder.

### `text.bin`: CSV/JSON -> native localization BBX

Decode first:

```bat
python siig_toolkit.py text2csv text.bin -o localization
```

Then rebuild from `text_strings_raw.csv`, `text_strings.csv`, or `text_strings.json`:

```bat
python siig_toolkit.py text-build localization\text\text_strings.csv --template text.bin -o text_mod.bin
```

The native BBX mode, seed/header/identifiers, payload order, newline convention, and trailing-newline behavior come from the template. Readable values collapse real line breaks/tabs back to the game's literal source escapes. Use `--raw` or `--no-raw` to override filename-based raw/readable inference.

### `message.bin`: readable Squirrel scripts -> native localization BBX

After `text2csv` produces six `message_<language>_readable.nut` files:

```bat
python siig_toolkit.py message-build localization\message --template message.bin -o message_mod.bin
```

Readable Unicode accents are converted back to SIIG's language-specific single-byte glyph substitutions and then encoded as Shift-JIS. `--raw` instead consumes `message_<language>_raw.nut`. Group/order/count consistency is checked across all six languages before packing.

The current builder byte-identity regressions use canonical synthetic localization fixtures; arbitrary runtime text changes still require emulator/hardware validation.

## Putting edited resources back into BBX

Replace the corresponding native resource inside the directory produced by `extract`, then run:

```bat
python siig_toolkit.py repack-bbx extracted_archive -o modified.bin
```

Use the original `manifest.json`. The repacker preserves/reconstructs named hashes, unnamed identifiers, resource order, BBX mode/seed/reserved header, sorted lookup index, and alignment.

This yields the current modding loop:

```text
original package
  -> BBX extraction
  -> native resource
  -> editable PNG/CSV/JSON/NUT
  -> native resource rebuild
  -> BBX repack
  -> game/emulator test
```

A structurally valid native file is not proof that every semantic edit is accepted by the game. Runtime acceptance remains a separate validation step.

## Capability matrix

```bat
python siig_toolkit.py asset-capabilities
python siig_toolkit.py asset-capabilities -o ASSET_CAPABILITIES.json
```

Full-game rips also write `validation/ASSET_CAPABILITIES.json`. In dev22, 11 of 14 known asset families have a native rebuild path and all 14 have a view/export/archive path.

## Remaining reverse-build targets

The three known families that remain genuinely one-way are:

1. Xbox XACT/XMA2 banks: native replacement-bank construction.
2. PS3 SBlk/VAG/989SND banks: native replacement-bank construction.
3. Xenos compiled shaders: instruction-level disassembly/translation or a compatible compiler path.

Within GMX, the next major step is **topology-changing glTF/Blender -> GMX synthesis**, including new array/chunk sizes, attachment graphs, and newly constructed chunk graphs. That is more ambitious than the safe template-preserving editor introduced in dev22.
