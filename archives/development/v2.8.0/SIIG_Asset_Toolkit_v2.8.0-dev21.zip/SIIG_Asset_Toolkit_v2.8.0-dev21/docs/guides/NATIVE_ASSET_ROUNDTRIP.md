# Native asset round-trip editing

`2.8.0-dev21` begins the asset-functionalization phase: extracted files are not only decoded for inspection, but can increasingly be edited in ordinary desktop formats and compiled back to the native SIIG resource format.

The design rule is conservative: when a native format contains platform/GPU-specific layout fields, the builder uses an **original file as a template** and preserves all header, padding, unused-component, and layout bytes that the edit does not need to change. This avoids inventing unverified runtime fields.

## Current native-build paths

### TEX: PNG -> native Xbox 360 / PS3 TEX

First export the original texture:

```bat
python siig_toolkit.py tex2png ptn_001.tex -o texture_edit
```

Edit the PNG without changing its dimensions, then rebuild it with the original TEX as the layout template:

```bat
python siig_toolkit.py png2tex texture_edit\ptn_001.png --template ptn_001.tex -o ptn_001_mod.tex
```

For Xbox 360 this preserves the 0x34-byte D3D/Xenos resource header, fetch constants, physical pitch, tiling, endian mode, channel swizzle, padding, and unaddressed GPU bytes. Logical pixels are retiled into the template's original addresses. PS3 rebuilds preserve the RSX wrapper and replace only the logical A8R8G8B8 pixel payload.

An unchanged `TEX -> PNG -> TEX` cycle is regression-tested byte-for-byte.

### System font: edited atlas -> encrypted CRP

Export:

```bat
python siig_toolkit.py font2png systemfont.bin.gz -o font_edit
```

Edit `systemfont_atlas.png` at its original dimensions, then rebuild the XOR-obfuscated CRP:

```bat
python siig_toolkit.py png2font font_edit\systemfont_atlas.png --template systemfont.bin.gz -o systemfont_mod.crp
```

This currently edits atlas pixels only. The 6,732-record executable glyph metric table is not rewritten.

### DAT: CSV/JSON -> native script

Export:

```bat
python siig_toolkit.py dat2csv level5_stage3.dat -o dat_edit
```

Edit `delta_frame`, `opcode`, or `args_signed` in the CSV, then compile:

```bat
python siig_toolkit.py dat-build dat_edit\level5_stage3.dat.csv -o level5_stage3_mod.dat
```

The JSON emitted beside the CSV may be used instead. Unknown opcodes and parameters remain editable because the native builder works from raw numeric values rather than requiring a complete semantic label set.

An unchanged parse/build cycle is byte-identical.

### MAP: editable JSON -> native byte grid

`map2png` now additionally writes `*.map.edit.json` containing every layer as an explicit row grid.

```bat
python siig_toolkit.py map2png level1_stage1.map -o map_edit --csv
python siig_toolkit.py map-build map_edit\level1_stage1.map.edit.json -o level1_stage1_mod.map
```

Cell values remain the exact game byte: lower six bits are the one-based tile ID, `0x40` flips X, and `0x80` flips Y.

An unchanged parse/edit-JSON/build cycle is byte-identical.

### ANM: CSV/JSON -> native range table

```bat
python siig_toolkit.py anm2csv enemy.anm -o anm_edit
python siig_toolkit.py anm-build anm_edit\enemy.anm.csv -o enemy_mod.anm
```

Model/group name, start frame, end frame and loop value can be edited. Unchanged records rebuild byte-identically.

### COL: PNG -> native one-bit collision mask

```bat
python siig_toolkit.py col2png wall.col -o col_edit
python siig_toolkit.py png2col col_edit\wall.png --template wall.col -o wall_mod.col
```

The original 16-byte header is preserved. Pixels above the default 128 white/alpha threshold become collision bits. `--threshold` and `--invert` are available for deliberate mask conversion.

An unchanged exported black/white PNG rebuilds byte-identically.

## Putting edited resources back into BBX

The native builders operate on individual extracted resources. Once a native file has been rebuilt, replace the corresponding file inside the directory produced by `extract`, then run the existing BBX repacker:

```bat
python siig_toolkit.py repack-bbx extracted_archive -o modified.bin
```

Use the original `manifest.json`. Named hashes, unnamed identifiers, resource order, archive mode, seed, reserved header bytes, sorted lookup index, and alignment are preserved/reconstructed by the repacker.

This creates a complete first-generation modding loop:

```text
original package
  -> BBX extraction
  -> native resource
  -> editable PNG/CSV/JSON
  -> native resource rebuild
  -> BBX repack
  -> game/emulator test
```

Acceptance of modified resources by real hardware/emulators remains a runtime validation step. A byte-valid native file is not proof that every arbitrary semantic edit is accepted by the game.

## Capability matrix

Run:

```bat
python siig_toolkit.py asset-capabilities
```

or save it:

```bat
python siig_toolkit.py asset-capabilities -o ASSET_CAPABILITIES.json
```

Full-game rips also write `validation/ASSET_CAPABILITIES.json`. The matrix separates structural decoding from viewing, editable interchange, native rebuild, and remaining gaps.

## Next reverse-build targets

The major native formats that remain one-way are:

1. GMX: glTF/Blender -> native model/scene compiler.
2. Bmap/Xmap/map4/map5 route tables: JSON/CSV -> native 0x118-byte records.
3. Wall/Xwall/stage_generate tables: CSV/JSON -> native tables.
4. Localization: dedicated `text.bin` / `message.bin` compilers rather than raw-payload editing.
5. Xbox XACT/XMA2 and PS3 SBlk/VAG: replacement-bank rebuild workflows.
6. Xenos shaders: instruction-level disassembly/translation or a compatible compiler path.

Those are now tracked as functionalization gaps rather than simply "unknown file formats."
