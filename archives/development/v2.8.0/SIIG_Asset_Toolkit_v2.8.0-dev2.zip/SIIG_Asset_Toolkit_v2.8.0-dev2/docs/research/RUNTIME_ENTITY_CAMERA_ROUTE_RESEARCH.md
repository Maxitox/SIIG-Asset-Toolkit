# Runtime entity, route, and camera research

This note records executable-backed findings integrated in SIIG Asset Toolkit 2.8.0-dev2. It is intentionally conservative: fields are named only when their use is demonstrated by the Xbox 360/PS3 executables or by the supplied game corpus.

## Runtime entity registry

The game keeps a fixed-stride runtime resource/primitive registry. In PS3 retail, `0x00175D08(runtime_type)` returns `0x004B5C40 + runtime_type * 0x2C`; `0x00175D2C` reports 0xF0 entries. Retail Xbox 360 and June 10 use the same 240-entry logical table; May 9 and May 11 use 241 entries.

Each 0x2C-byte record contains eleven big-endian 32-bit words. The PS3 constructor at `0x00175FB0` and helper `0x00166488` establish this interpretation:

| word | interpreted field | evidence |
|---:|---|---|
| 0 | GMX/model-name pointer | looked up as a resident GMX resource when nonzero |
| 1 | primitive geometry mode | values 0/1 select two primitive construction paths; `-1` for model-backed entries |
| 2 | texture resource ID | nonnegative values are looked up through the texture/resource manager; `-1` means no primitive texture |
| 3 | primitive state flag | low byte is forwarded to the primitive render-state helper |
| 4 | primitive width | used as width/half-extent input |
| 5 | primitive height | used as height/half-extent input |
| 6 | atlas X | divided by texture width for U coordinates |
| 7 | atlas Y | divided by texture height for V coordinates |
| 8 | atlas width | added to X and normalized for the opposite U edge |
| 9 | atlas height | added to Y and normalized for the opposite V edge |
| 10 | render-group selector | mapped through four renderer groups |

The four selector values resolve to literal engine group names:

0. `Offset Opacity`
1. `Offset Translucent`
2. `Offset Terminate`
3. `Non Opacity`

The supplied retail registry only uses groups 0 and 3. Group 3 is concentrated in the `bos_015` model family.

### Cross-build shape

Normalized for relocated pointers:

- May 9 and May 11 are identical: 241 entries, 131 model-backed, 22 primitive-backed, 88 unconfigured.
- June 10, retail Xbox 360, and retail PS3 are identical: 240 entries, 129 model-backed, 22 primitive-backed, 89 unconfigured.
- June introduces an unused registry slot at runtime type `0xB4`, shifting following entries by +1.
- The May registry entries for `bos_015e.gmx` and `bos_015f.gmx` are absent from the later registry. After those two omissions, the remaining tail has a net -1 shift relative to May.

This describes **registry membership only**. It does not, by itself, prove that a corresponding GMX file was deleted from a build.

See `reference/tables/ENTITY_RUNTIME_REGISTRY.csv`, `ENTITY_RUNTIME_REGISTRY_BUILD_DIFF.csv`, and `ENTITY_RUNTIME_REGISTRY_SUMMARY.json`.

## Bmap/Xmap route source

Each active 0x118-byte Bmap/Xmap record has five optional vectors at `+0xDC`. PS3 retail function `0x0015E5D8` scans slots 0 through 4, appending every nonzero vector. `0x0015E7D0` performs this for every active record in record order. If record 0 contributes no route point, the runtime appends an origin vector before continuing.

Across the supplied 47 same-layout files:

- active records: 19,563
- nonzero route-point vectors: 19,562
- populated slot: slot 2 only
- records using more than one slot: 0
- origin fallback: exactly once, for `Bmap16.bin`

The toolkit now exports this exact source sequence as `.route_source.csv` and `.route_source.obj`. These are **control/source points, not the engine-resampled spline**. The existing `primary_route_point`/initial `FieldPos` semantics remain separate: record 0 slot 2 is used when present, otherwise placement slot 0 position is used for initial `FieldPos`.

## Route animation models

The separate `/3ddata/route.bin.gz` BBX contains `fld015.gmx` and `fld014.gmx`. Executable descriptors at PS3 retail `0x00532814` identify the two names and a frame-limit value:

- `fld015`: limit 6300
- `fld014`: limit 1440

The final descriptor word is retained as a raw flag because its complete gameplay meaning has not been proven.

GMX animation timestamps show:

- `fld015.gmx`: 6,301 samples, 0.0..262.5 seconds, approximately 24 Hz
- `fld014.gmx`: 1,440 samples, 0.0..59.9583 seconds, approximately 24 Hz

`gmxtrack` exports the decomposed matrix samples and translation trajectory without imposing a frame-rate constant; the observed rate is calculated from timestamps.

## Camera animation models and preset table

The camera subsystem loads `/3ddata/camera.bin.gz` and selects `cam01_op1.gmx` or `cam02_op1.gmx`. Both contain animation tracks for literal bones/nodes `cam1` and `int1`:

- `cam01_op1.gmx`: two 200-sample tracks, ending at about 8.29167 s
- `cam02_op1.gmx`: two 300-sample tracks, ending at about 12.4583 s
- observed cadence: approximately 24 Hz

PS3 retail function `0x0015B4C0` exposes a 32-entry table at `0x0053284C`, with 30 32-bit words (0x78 bytes) per preset. `0x0015B524` consumes those records. The complete table is preserved in `reference/tables/CAMERA_PRESETS_RAW.csv` with hex, integer, and float interpretations for every word.

The individual preset words are **not assigned gameplay names yet**. Several are clearly used as camera/state values, but naming all 30 fields without a complete call-chain proof would overstate the evidence.

## Remaining boundaries

- Reproduce the engine's spline sampling/tangent generation exactly, not merely its control-point source.
- Name camera preset fields only where downstream use proves semantics.
- Couple the route spline, field animation, camera preset state, and `cam1`/`int1` tracks into a single playback model.
- Continue instruction-level RSX/Xenos shader analysis.
