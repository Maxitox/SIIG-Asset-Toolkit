# Reference tables

CSV tables used by the toolkit and retained for independent review. Runtime-required files include `STAGE_PAIRING.csv`, `STAGE_TILE_SETS.csv`, and `TILE_SET_TEXTURES.csv`.

Executable-derived research tables added in 2.8.0-dev2:

- `ENTITY_RUNTIME_REGISTRY.csv` — five-build 0x2C runtime entity/primitive records with decoded fields and raw words.
- `ENTITY_RUNTIME_REGISTRY_BUILD_DIFF.csv` — exact-index differences between May, June, retail Xbox, and retail PS3 registries.
- `ENTITY_RUNTIME_REGISTRY_SUMMARY.json` — counts and normalized equality checks.
- `ROUTE_ANIMATION_DESCRIPTORS.csv` — two retail route-model descriptors with unresolved flag retained raw.
- `CAMERA_PRESETS_RAW.csv` — all 32 × 30 retail PS3 camera-preset words with hex/int/float views; field semantics intentionally unnamed.
