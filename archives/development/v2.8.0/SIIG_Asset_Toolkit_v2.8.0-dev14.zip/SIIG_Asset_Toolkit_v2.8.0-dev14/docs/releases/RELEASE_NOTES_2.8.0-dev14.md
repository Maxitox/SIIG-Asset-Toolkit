# SIIG Asset Toolkit 2.8.0-dev14 release notes

Dev14 audits the June/retail Ultimate UFO ending after Mframe 6200 and makes the remaining uncertainty narrower and explicit.

- Proved the retail Mframe-6030 phase invokes part 0 with state 1, so it is not the camera-gate clear.
- Proved the Mframe-6200 phase only disables the owned `bos_015k` object and has no part-state or vtable `+0x48` dispatch.
- Located the exact Xbox camera-gate clear at instruction `0x8212DD20` inside `0x8212DCB0`; it requires part 0/state 0 outside the Extra/Bonus 5-6 exception.
- Traced generic vtable `+0x48` at `0x820FBEE8` into that part-0/state-0 clear mechanism.
- Confirmed camera-controller construction (`0x820ECFD8`) and accepted preset changes (`0x820ECDF0`) set the gate to 1 rather than clearing it.
- Excluded Normal 5-3 DAT cleanup and destructor-only manager removal as ordinary sources of the gate clear.
- Classified the 25,200-timer-unit generic lifetime path as a watchdog, not an established normal route-end trigger.
- Added `ULTIMATE_UFO_FINAL_RESET_AUDIT.csv` and a dedicated regression check, raising the dependency-free suite to 46 checks.

The ordinary higher-level caller that invokes a later part-0 `+0x48` reset remains unresolved. Visible disappearance in footage is not treated as proof that this reset ran.
