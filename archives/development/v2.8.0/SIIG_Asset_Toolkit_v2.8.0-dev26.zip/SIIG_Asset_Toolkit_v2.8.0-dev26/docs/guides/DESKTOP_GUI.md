# Desktop GUI (dev25)

Dev25 adds the first unified desktop control center for the SIIG Asset Toolkit. It is intentionally a **thin UI over the existing audited CLI**: format parsers/builders remain in `siig_toolkit.py`, while the GUI launches those same commands in background tasks and streams their output into a shared task log.

## Launch

On Windows, double-click:

```text
SIIG_GUI.bat
```

Or run directly:

```text
python siig_gui.py
```

The GUI uses Python's standard-library Tkinter only. No web service or network connection is required.

## Tabs

### Game Rip

Choose an Xbox 360/PS3 package, ZIP, or extracted game input and an output folder. The GUI can run `rip-game`, `verify-output`, generate the offline Asset Viewer, and open the rip folder.

### Mod Workspace

Choose a verified `SIIG_Ripped` tree and a mod-workspace directory. The first GUI exposes project initialization, listing, building, verification, `.siigmod` packaging/inspection/application, and workspace opening. Fine-grained per-resource export/staging remains available through the existing workspace files/CLI and is a planned GUI expansion.

### GMX Workbench

The GMX workbench is the main dev25 modeling surface. It exposes:

- native GMX inspection;
- GMX -> glTF export;
- **edited glTF -> native GMX topology-changing template import**;
- lossless fixed-layout editable JSON export/build for geometry/material/bone/animation values;
- UV-flip symmetry for applications that need inverted V coordinates.

The new glTF importer may change vertex and index counts and resizes native `ARRY` chunks, repairs `MESH.index_count`, the GMX total size, and the root geometry AABB. It deliberately preserves the template's mesh/chunk identities, materials, shaders, bone attachments, and animation graph.

### Utilities

Runs `doctor`, the full self-test suite, `asset-capabilities`, and the offline Asset Viewer generator.

## Current GUI boundary

This is the first control-center release, not a replacement for every advanced CLI switch. The intended direction is to move normal extraction/modding/GMX workflows into graphical panels while retaining the CLI as an automation/research interface.

## Privacy and provenance

The GUI does not upload game files. It invokes the local source-only toolkit against user-selected local paths. The release continues to contain no proprietary SIIG assets or executables.
