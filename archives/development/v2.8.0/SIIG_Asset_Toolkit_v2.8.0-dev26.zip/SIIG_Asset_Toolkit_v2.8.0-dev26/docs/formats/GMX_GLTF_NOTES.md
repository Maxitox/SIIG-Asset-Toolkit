# GMX → glTF notes

Version 1.5 adds a glTF 2.0 exporter for the game's GMX scene/model files. Unlike the older OBJ exporter, this path preserves the GMX scene graph, material assignments, vertex colors, and embedded transform animation tracks.

## Confirmed GMX relationships

GMX is a sequential big-endian chunk stream. The exporter uses these confirmed links:

- `TXIF` records name texture resources such as `ptn_001.dds`.
- `SHAD` records name the material shader (`no_texture` or `texture` in the supplied corpus).
- `MTRL` records reference one `SHAD` and contain typed parameters.
- `PARE` records store a signed parent bone index followed by its child bone indices.
- `BONE` records contain a 4×4 local transform and encoded material/mesh attachments.
- `MESH` records reference position, normal, UV, color and index `ARRY` records.
- `MOTN` records describe one motion track and its duration.
- `ANIM` records target one bone and store key times followed by one 4×4 transform per key.

### BONE attachment references

The final 16 bytes of a `BONE` record contain an attachment count and encoded references:

```text
high 16 bits  2  → MTRL index
high 16 bits  3  → MESH index
low  16 bits     → referenced record index
```

Every mesh-bearing bone in the supplied corpus has one material reference and one mesh reference.

### PARE hierarchy

```text
+0x10  u32  child count
+0x14  s32  parent bone index (-1 means scene root)
+0x18  u32[] child bone indices
```

### Material parameters

After the fixed MTRL header, each parameter has a 48-byte name and two 32-bit fields:

```text
type 0  float scalar/vector; second field is component count
type 1  4×4 matrix array; second field is matrix count
type 2  texture sampler; second field is TXIF index
```

Observed parameters are `mWVP`, `DiffuseSampler`, `DiffuseColor`, `DiffuseAlpha`, and `EmissiveColor`.

### Animation tracks

```text
ANIM +0x08  encoded motion index (index in upper 16 bits)
ANIM +0x10  target BONE index
ANIM +0x14  channel type (12 in every supplied file)
ANIM +0x18  key count
ANIM +0x1C  values per key (16 in every supplied file)
ANIM +0x20  float32 key times
             followed immediately by key_count × 16 float32 matrices
```

BONE matrices use the engine's row-vector storage convention. ANIM matrices use the transposed conventional row-major form. The exporter normalizes both conventions and decomposes each animation matrix into glTF translation, quaternion rotation, and scale channels.

## glTF output

For each input GMX, the exporter writes:

```text
model.gltf       JSON scene description
model.gltf.bin   geometry and animation buffers
model.gltf.json  conversion summary/diagnostics
_textures/       converted texture dependencies when present
```

The glTF contains:

- indexed triangles and lines;
- positions, normals, UVs and vertex colors;
- GMX bone hierarchy as glTF nodes;
- mesh attachment to the correct bone;
- diffuse color, alpha, emissive color and texture assignment;
- `KHR_materials_unlit` materials, matching the simple SIIG shader parameter set;
- one glTF animation per GMX `ANIM`/`MOTN` track.

The supplied textured GMX files all reference `ptn_001.dds`, an uncompressed 128×128 ARGB8888 DDS. The exporter converts it to PNG automatically when the DDS is available in the GMX directory or a `--texture-root` search directory.

## Usage

```bat
python siig_toolkit.py gmx2gltf "C:\path\to\extracted" -o gltf
```

When texture files live elsewhere:

```bat
python siig_toolkit.py gmx2gltf "C:\path\to\gmx" -o gltf --texture-root "C:\path\to\all_extracted_assets"
```

Directly during BBX extraction:

```bat
python siig_toolkit.py extract "C:\path\to\3ddata" -o extracted --convert-gltf
```

Add `--flip-v` only when the destination application expects inverted V coordinates.

## Validation

The final exporter was run over the complete supplied `3ddata` corpus:

```text
486 GMX files
1,938 meshes/primitives
3,298 hierarchy nodes
776 materials
913 animation tracks
0 conversion failures
0 hierarchy cycles or unreachable nodes
0 missing texture references
```

Representative static, textured, multi-mesh and animated files were also loaded with an independent glTF reader.

## Limitations

- The GMX files do not contain per-vertex skin weights; geometry is attached rigidly to scene nodes rather than exported as a skinned mesh.
- Each `ANIM` chunk is exported as its own animation. The engine may trigger several tracks together during gameplay; that higher-level grouping is not stored explicitly in the GMX chunk stream recovered so far.
- The source shader programs are not translated to equivalent custom glTF shaders. Materials use standard unlit PBR fields so they remain portable.
- Standalone `.anm` resources, if encountered outside GMX, are not handled by this exporter.

## Metadata privacy

As of toolkit v1.5.1, companion `.gltf.json` files contain only the glTF filename,
not the absolute source or output directory. The glTF document itself uses relative
URIs for `.bin` buffers and textures.


## Native template editing (dev22)

Dev22 adds a conservative reverse path for an **existing fixed-layout GMX**:

```bat
python siig_toolkit.py gmx-edit-export model.gmx -o model.gmx.edit.json
python siig_toolkit.py gmx-build model.gmx.edit.json --template model.gmx -o model_mod.gmx
```

The `SIIG_GMX_TEMPLATE_EDIT_V1` document exposes fixed-count float/ushort arrays, TXIF names, material parameter values, bone names/matrices, motion durations, animation key times, and serialized animation matrices. The builder patches those proven fields in place while retaining chunk order, sizes, references, padding, and all unexposed bytes.

This is deliberately narrower than a general glTF/Blender compiler. Array counts/types, mesh/material attachment topology, shader indices, animation target/channel/frame counts, and new chunk-graph construction remain fixed. The template SHA-256 is enforced by default.

The new native-builder regression uses a structurally representative synthetic GMX fixture. Previous corpus validation still covers reading/exporting 486 supplied GMX files, but a native byte-roundtrip over that real corpus and runtime acceptance of modified GMX files are not claimed by dev22.

## Topology-changing glTF template compiler (dev25)

Dev25 adds the first topology-changing reverse path:

```bat
python siig_toolkit.py gltf2gmx-template edited.gltf --template original.gmx -o edited.gmx
```

Unlike `gmx-build`, this path may change the **vertex and index counts** of existing GMX meshes. The compiler maps glTF meshes back to native `MESH` identities (using `extras.gmxMeshIndex` written by `gmx2gltf`), rebuilds the referenced position/normal/UV/color/index `ARRY` chunks, preserves 0x10 chunk alignment, updates `MESH.index_count`, reassembles the sequential GMX chunk stream, updates the root total-size field, and recalculates the root geometry AABB.

The AABB interpretation at GMX root `+0x10..+0x27` was checked against all 13 retail `player.bin` GMXs: the six floats exactly equal min XYZ / max XYZ of decoded `IN.position` arrays in every file.

### Retail no-op validation

The new path was exercised on the external user-supplied retail corpus used by dev24. Of 307 GMX files, 306 contain native `MESH` geometry and are applicable to glTF topology import; **all 306/306 rebuilt byte-for-byte identically after GMX -> glTF -> GMX import with no edits**. The remaining `bos_008c.gmx` contains no `MESH` chunks and is explicitly classified as not applicable rather than a failed geometry import. Proprietary corpus inputs are not bundled.

A separate topology smoke edit on retail `plr_001.gmx` increased one mesh from 328 to 329 vertices and 656 to 658 indices. The native GMX resized from 49,600 to 49,680 bytes, reparsed successfully, and the root max-X bound changed to the injected 20.0 coordinate. This proves structural topology/count rewriting; it does **not** by itself prove arbitrary edited-model runtime acceptance by the retail executable.

### Remaining compiler boundary

The compiler still inherits the template's:

- number and identity of `MESH` / `ARRY` chunks;
- material/shader graph;
- bone attachment graph;
- primitive mode;
- uint16 index representation;
- motion/animation chunk graph.

Therefore dev25 is a topology-changing **template compiler**, not yet a from-scratch GMX graph authoring system. Adding/removing whole native meshes/chunks, synthesizing material/bone graphs, and broader glTF animation import remain the next GMX research targets.
## Whole MESH/ARRY graph synchronization (dev26)

Dev26 extends the topology compiler with an explicit graph-synchronization mode:

```bat
python siig_toolkit.py gltf2gmx-template edited.gltf --template original.gmx -o edited.gmx --sync-mesh-graph
```

Without this flag, dev25 behavior is preserved: native `MESH`/`ARRY` identities are inherited from the template. With the flag enabled, the glTF mesh list becomes the desired native mesh set. Existing meshes carrying `extras.gmxMeshIndex` are retained/updated; existing native meshes omitted from the glTF are deleted; and glTF meshes without an existing native identity are synthesized as new `MESH` plus owned `ARRY` nodes.

A synthesized mesh clones one compatible template mesh's proven native vertex declaration/header fields. `extras.gmxCloneMeshIndex` can select the donor explicitly. Fresh uint16 `MESH` and `ARRY` identities are allocated, while geometry payloads come from the new glTF primitive. ARRY deletion is reference-counted, so an array shared by a retained mesh is never removed merely because another mesh was deleted.

Existing `BONE` records are repaired when their mesh target is deleted. A new mesh can request attachment to one existing bone with `extras.gmxAttachBoneIndex`; if the bone already owns a retained different mesh, the compiler rejects the request rather than silently changing scene ownership. New BONE/PARE/MTRL/SHAD records are not created yet.

The final graph verifier rejects duplicate native identities, dangling MESH→ARRY links, mismatched index counts, and dangling BONE→MESH links before emitting success. The built-in dev26 regression proves a byte-identical graph-sync no-op, addition of a second complete mesh graph with fresh identities, and replacement/deletion of an attached mesh with BONE repair.

### Current boundary after dev26

Dev26 is now a **template-hosted mesh-graph compiler**, not merely a fixed mesh-count compiler. It still depends on an original GMX for non-geometry graph/layout knowledge. The next major steps are new BONE/PARE hierarchy nodes, MTRL/SHAD/TXIF relationship synthesis, arbitrary vertex-declaration construction instead of cloning, then eventual from-scratch GMX creation.

