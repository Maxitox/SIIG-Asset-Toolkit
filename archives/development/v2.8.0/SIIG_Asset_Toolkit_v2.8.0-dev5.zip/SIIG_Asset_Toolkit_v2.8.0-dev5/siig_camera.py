"""Executable-backed SIIG retail camera-preset helpers.

The 32 x 30 preset table is preserved separately as raw executable data. This
module operates on the runtime-initialized semantic table whose names are only
assigned where downstream retail-PS3 consumers prove their role.

Key evidence:
- 0x0015B524: preset copy/activation
- 0x0015BBA8: preset transition/interpolation
- 0x00155300: projection, uniform scale, scene/view translation, view matrix
- 0x00157A10: camera-eye offset transformed through active stage/route frame
- 0x00157540: dynamic eye/target horizontal response
- 0x0015B910 -> 0x0020D69C/0x0020E984: shared model/material scalar
- 0x0020E984 plus renderer paths 0x003756AC/0x003756E8: fog color/range

Word 11 remains intentionally unnamed semantically: it is proven to be a
shared scalar forwarded to collada_edge1/collada_face1/collada_face2 material
nodes, but the virtual setter's exact meaning is not yet established.
"""
from __future__ import annotations

import csv
import math
import struct
from pathlib import Path
from typing import Mapping, Sequence


def _f32(value: float) -> float:
    return struct.unpack(">f", struct.pack(">f", float(value)))[0]


def _vec3(values: Sequence[float]) -> tuple[float, float, float]:
    if len(values) != 3:
        raise ValueError("expected exactly three components")
    return (_f32(values[0]), _f32(values[1]), _f32(values[2]))


def _default_table_path() -> Path:
    return Path(__file__).resolve().parent / "reference" / "tables" / "CAMERA_PRESETS_RUNTIME_SEMANTIC.csv"


def load_camera_presets(path: str | Path | None = None) -> list[dict]:
    table = Path(path) if path is not None else _default_table_path()
    with table.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != 32:
        raise ValueError(f"camera preset table must contain 32 rows; found {len(rows)}")
    return rows


def _float(row: Mapping[str, str], key: str) -> float:
    return _f32(float(row[key]))


def camera_preset_info(index: int, *, table_path: str | Path | None = None) -> dict:
    rows = load_camera_presets(table_path)
    if not 0 <= int(index) < len(rows):
        raise ValueError(f"camera preset index out of range: {index}")
    row = rows[int(index)]
    fog = []
    for profile in range(3):
        prefix = f"fog{profile}_"
        fog.append({
            "profile_index": profile,
            "start": _float(row, prefix + "start"),
            "end": _float(row, prefix + "end"),
            "color_rgba": [
                _float(row, prefix + "color_r"),
                _float(row, prefix + "color_g"),
                _float(row, prefix + "color_b"),
                _float(row, prefix + "color_a"),
            ],
        })
    return {
        "preset_index": int(index),
        "fov_degrees": _float(row, "fov_degrees"),
        "fov_radians": _f32(_float(row, "fov_degrees") * _f32(math.pi) / _f32(180.0)),
        "uniform_scene_view_scale": _float(row, "uniform_scene_view_scale"),
        "camera_eye_offset": [
            _float(row, "camera_eye_offset_x"),
            _float(row, "camera_eye_offset_y"),
            _float(row, "camera_eye_offset_z"),
        ],
        "scene_view_translation": [
            _float(row, "scene_view_translation_x"),
            _float(row, "scene_view_translation_y"),
            _float(row, "scene_view_translation_z"),
        ],
        "dynamic_horizontal_response": {
            "gain": _float(row, "dynamic_horizontal_response_gain"),
            "target_local_x_scale": _float(row, "dynamic_target_local_x_scale"),
            "eye_local_x_scale": _float(row, "dynamic_eye_local_x_scale"),
        },
        "shared_model_material_scalar_unresolved": _float(row, "shared_model_material_scalar_unresolved"),
        "fog_profiles": fog,
        "evidence": {
            "preset_activation": "retail PS3 0x0015B524",
            "preset_interpolation": "retail PS3 0x0015BBA8",
            "projection_and_scene_transform": "retail PS3 0x00155300",
            "eye_offset_transform": "retail PS3 0x00157A10",
            "dynamic_response": "retail PS3 0x00157540",
            "shared_scalar_forwarding": "retail PS3 0x0015B910 -> 0x0020D69C/0x0020E984",
            "fog_uniforms": "retail PS3 0x003756AC vFogColor; 0x003756E8 fogRange",
        },
    }


def dynamic_horizontal_offsets(
    preset: Mapping[str, object] | int,
    runtime_x: float,
    runtime_y: float,
    *,
    table_path: str | Path | None = None,
) -> dict:
    """Evaluate the pre-transform local-X dynamic camera response.

    Retail 0x00157540 normalizes runtime coordinates as (x-213)/213 and
    (y-5)/228. Word 8 becomes max(0, gain/uniform_scale). Words 9 and 10
    separately scale target and eye local-X translations. The resulting local
    translations are subsequently transformed through the active stage/route
    frame by the game; this helper intentionally stops before that transform.
    """
    info = camera_preset_info(int(preset), table_path=table_path) if isinstance(preset, int) else dict(preset)
    scale = _f32(float(info["uniform_scene_view_scale"]))
    if scale == 0.0:
        raise ValueError("uniform scene/view scale is zero; retail gain division is undefined")
    dyn = info["dynamic_horizontal_response"]
    assert isinstance(dyn, Mapping)
    gain = _f32(float(dyn["gain"]))
    target_scale = _f32(float(dyn["target_local_x_scale"]))
    eye_scale = _f32(float(dyn["eye_local_x_scale"]))
    nx = _f32(_f32(float(runtime_x) - _f32(213.0)) / _f32(213.0))
    ny = _f32(_f32(float(runtime_y) - _f32(5.0)) / _f32(228.0))
    normalized_gain = _f32(gain / scale)
    if normalized_gain < 0.0:
        normalized_gain = 0.0
    common = _f32(_f32(nx * normalized_gain) * ny)
    target = _f32(common * target_scale)
    eye = _f32(common * eye_scale)
    return {
        "runtime_x": _f32(runtime_x),
        "runtime_y": _f32(runtime_y),
        "normalized_x": nx,
        "normalized_y": ny,
        "gain_over_uniform_scale_clamped": normalized_gain,
        "target_local_x": target,
        "eye_local_x": eye,
        "scope": "pre_stage_route_transform_local_x_response",
        "evidence": "retail PS3 0x00157540",
    }
