#!/usr/bin/env python3
"""
Space Invaders Infinity Gene cross-platform asset toolkit.

Confirmed by cross-checking the game files with the default.xex Ghidra export:
- Extracts BBX containers (magic 01 42 42 58), including unnamed and nested entries.
- Verifies the game-specific filename hash.
- Exports GMX geometry, hierarchy, materials and transform animations to glTF 2.0, with OBJ retained for static geometry.
- Decrypts the XOR-obfuscated systemfont CRP and exports its 2048x3392 glyph atlas.
- Extracts XACT3 XWB/XSB banks and wraps Xbox 360 XMA2 streams for FFmpeg/vgmstream conversion.
- Decodes text.bin and message.bin localization databases to UTF-8 CSV/JSON/text.
- Converts one-bit COL collision masks to PNG and standalone ANM frame-range tables to CSV/JSON.
- Decodes Bmap/Xmap 3D stage paths, wall strips, generator candidates, and Xbox 360 compiled shader containers/microcode.
- Decodes DAT command streams to timed semantic CSV/JSON, MAP byte-grid layers, atlas-backed previews, and a self-contained stage explorer.
- Accepts Xbox 360 STFS packages and PlayStation 3 PKG files directly, with bounded atomic extraction.
- Rebuilds extracted BBX archives, generates an offline asset browser, and supports the optional Blender importer.
- Produces deterministic output manifests, diagnostics, verification, and a built-in regression self-test.

Python 3.10+; standard library only.
"""

from __future__ import annotations

import argparse
import csv
from array import array
from functools import lru_cache
import gzip
import hashlib
import hmac
import io
import json
import math
import os
import re
import shutil
import stat
import struct
import subprocess
import sys
import tempfile
import time
import zipfile
import zlib
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Iterator, Optional, Sequence

from siig_containers import (
    ContainerError,
    DEFAULT_EXTRACTION_LIMITS,
    ExtractionLimits,
    aes_self_test,
    detect_container_kind,
    unpack_outer_container,
)
from siig_npdrm import SdatError, decrypt_sdat_bytes, decrypt_sdat_file
from siig_sony_bnk import SonyBnkError, decode_psx_adpcm_mono, export_sony_sblk_wav_file, parse_sony_sblk_v3
from siig_camera import (
    camera_preset_info,
    camera_world_state,
    dynamic_horizontal_offsets,
    field_state_from_gmx_matrix,
    gmx_serialized_affine_to_runtime_row,
)
from siig_pa_route import (
    BOSS_FIELD_CORRELATIONS,
    SPECIAL_STAGE_RELOAD_CHAIN,
    ULTIMATE_UFO_DEATH_CHAIN,
    ULTIMATE_UFO_LATE_OBJECTS,
    ULTIMATE_UFO_DEBUG_HUD,
    ULTIMATE_UFO_PART_STATUS_OBJECTS,
    ULTIMATE_UFO_STAGE_PROFILES,
    ULTIMATE_UFO_MFRAME_ROUTE_CHAIN,
    PA_CAMERA_LIFECYCLE,
    ULTIMATE_UFO_LATE_CAMERA_GEOMETRY,
    ULTIMATE_UFO_LATE_CAMERA_CONCLUSION,
    ULTIMATE_UFO_CAMERA_TRANSITION_GATE,
    ULTIMATE_UFO_FINAL_VANISH_EVOLUTION,
    ULTIMATE_UFO_FINAL_RESET_AUDIT,
    PS3_CAMERA_PRESET_DIRECT_CALLERS,
    BUILD_GATES as PA_ROUTE_BUILD_GATES,
    CAMERA_SELECTIONS as PA_ROUTE_CAMERA_SELECTIONS,
    analyze_parsed_dat as analyze_pa_route_dat,
    camera_selection as pa_route_camera_selection,
    evaluate_gate as evaluate_pa_route_gate,
    reference_snapshot as pa_route_reference_snapshot,
    water_strider_route_frame,
    ultimate_ufo_phase,
    special_stage_reload_for_warning,
    ultimate_ufo_death_sequence,
    ultimate_ufo_late_objects,
    ultimate_ufo_stage_profile,
    ultimate_ufo_mframe_route_chain,
    pa_camera_lifecycle,
    ultimate_ufo_late_camera_geometry,
    ultimate_ufo_camera_transition_gate,
    ultimate_ufo_final_vanish_evolution,
    ultimate_ufo_final_reset_audit,
    stage_category as pa_route_stage_category,
)
from siig_route import (
    DIRECTION_NAMES as ROUTE_DIRECTION_NAMES,
    classify_curve as classify_route_curve,
    resample_curve_segment,
    resample_linear_segment,
    resample_route_constant_spacing,
    RouteRuntimeState,
    mat3_identity,
    scroll02_spacing_from_script_y,
    update_direction_state as update_route_direction_state,
)

BBX_MAGIC = b"\x01BBX"
GMX_MAGIC = b"GMX\x00"
MAP_MAGIC = b"MAP\x00"
GL_FLOAT = 0x1406
GL_UNSIGNED_SHORT = 0x1403
GL_LINES = 0x0001
GL_TRIANGLES = 0x0004
TEX_HEADER_SIZE = 0x34
XENOS_TEXFMT_8_8_8_8 = 6
SYSTEMFONT_CRP_XOR = 0xF1
MAX_GZIP_OUTPUT_BYTES = 1024 * 1024 * 1024
MAX_BBX_RECURSION_DEPTH = 32
MAX_BBX_TOTAL_ENTRIES = 500_000
XWB_MAGIC_BE = b"DNBW"
XWB_MAGIC_LE = b"WBND"
XSB_MAGIC_BE = b"KBDS"
XSB_MAGIC_LE = b"SDBK"
WAVEBANK_FLAGS_COMPACT = 0x00020000
XENOS_ENDIAN_NAMES = {0: "none", 1: "8in16", 2: "8in32", 3: "16in32"}
XENOS_TEXTURE_FORMAT_NAMES = {
    0: "1_REVERSE", 1: "1", 2: "8", 3: "1_5_5_5", 4: "5_6_5", 5: "6_5_5",
    6: "8_8_8_8", 7: "2_10_10_10", 8: "8_A", 9: "8_B", 10: "8_8",
    18: "DXT1", 19: "DXT2_3", 20: "DXT4_5", 49: "DXN", 60: "CTX1",
}

SIIG_SCRIPT_OPCODE_NAMES: tuple[Optional[str], ...] = (
    'CLASSIC_INVADER',  # 0x00
    'CLASSIC_UFO',  # 0x01
    'NORMAL_INVADER',  # 0x02
    'BARRIER_INVADER',  # 0x03
    'TURN_INVADER',  # 0x04
    'SIDE_INVADER',  # 0x05
    'GAMMA_INVADER',  # 0x06
    'V_INVADER',  # 0x07
    'STRAIGHT_INVADER',  # 0x08
    'S_LASER_INVADER',  # 0x09
    'WARP_INVADER',  # 0x0A
    'TELEPORTER',  # 0x0B
    None,  # 0x0C
    'ALARM_UFO',  # 0x0D
    'SCRATCHER',  # 0x0E
    'ASSAILANT',  # 0x0F
    'LINER',  # 0x10
    'FORTRESS',  # 0x11
    'FORTRESS2',  # 0x12
    'CRAWLER',  # 0x13
    'SWINDLER',  # 0x14
    'CUTTLEFISH',  # 0x15
    'HATCH',  # 0x16
    'SCRAMBLE_INVADER',  # 0x17
    'TENTACLE',  # 0x18
    'SHADOW',  # 0x19
    'REVOLVER1',  # 0x1A
    'REVOLVER2',  # 0x1B
    'ATTACKER',  # 0x1C
    'STORMER',  # 0x1D
    'CONSPIRATOR',  # 0x1E
    'CONSPIRATOR2',  # 0x1F
    None,  # 0x20
    'EXPANDER',  # 0x21
    'SPRINKLER',  # 0x22
    None,  # 0x23
    'ELEMENT1',  # 0x24
    'ELEMENT2',  # 0x25
    'ELEMENT3',  # 0x26
    'SLUGGARD',  # 0x27
    'GUSHER',  # 0x28
    'PRIDE',  # 0x29
    'SLOTH',  # 0x2A
    'KEEPER',  # 0x2B
    'OPPRESSOR',  # 0x2C
    None,  # 0x2D
    None,  # 0x2E
    None,  # 0x2F
    None,  # 0x30
    None,  # 0x31
    'DIFFUSER',  # 0x32
    'DIFFUSER2',  # 0x33
    None,  # 0x34
    'SATORU_UFO',  # 0x35
    'SPIDER',  # 0x36
    'JOLYNE',  # 0x37
    'VANITY',  # 0x38
    None,  # 0x39
    None,  # 0x3A
    None,  # 0x3B
    None,  # 0x3C
    None,  # 0x3D
    None,  # 0x3E
    None,  # 0x3F
    None,  # 0x40
    None,  # 0x41
    None,  # 0x42
    None,  # 0x43
    None,  # 0x44
    None,  # 0x45
    'THE_MOON',  # 0x46
    'THE_SUN',  # 0x47
    'GIGANTIC_UFO',  # 0x48
    'LADYBUG',  # 0x49
    'MANDALA',  # 0x4A
    'UNKNOWN',  # 0x4B
    None,  # 0x4C
    None,  # 0x4D
    None,  # 0x4E
    None,  # 0x4F
    None,  # 0x50
    None,  # 0x51
    None,  # 0x52
    None,  # 0x53
    None,  # 0x54
    None,  # 0x55
    None,  # 0x56
    None,  # 0x57
    None,  # 0x58
    None,  # 0x59
    'SHUTTER1',  # 0x5A
    'SHUTTER2',  # 0x5B
    'SHUTTER3',  # 0x5C
    'SHUTTER_KEY',  # 0x5D
    'CONTAINER',  # 0x5E
    'PIPE_LINE',  # 0x5F
    None,  # 0x60
    None,  # 0x61
    None,  # 0x62
    None,  # 0x63
    None,  # 0x64
    None,  # 0x65
    None,  # 0x66
    None,  # 0x67
    None,  # 0x68
    None,  # 0x69
    None,  # 0x6A
    None,  # 0x6B
    None,  # 0x6C
    None,  # 0x6D
    'SCROLL_01',  # 0x6E
    'SCROLL_02',  # 0x6F
    'SCROLL_03',  # 0x70
    'DEL_ZAKO',  # 0x71
    'DEL_M_BOSS',  # 0x72
    'DEL_L_BOSS',  # 0x73
    'DEL_ALL_ENEMY',  # 0x74
    'DEL_ALL_ENEMY_SHOT',  # 0x75
    'EMERGENCY',  # 0x76
    'EMERGENCY_END',  # 0x77
    'WARNING',  # 0x78
    'BACKGROUND_01',  # 0x79
    'BACKGROUND_02',  # 0x7A
    'BACKGROUND_03',  # 0x7B
    'BACKGROUND_04',  # 0x7C
    'BACKGROUND_05',  # 0x7D
    'BACKGROUND_06',  # 0x7E
    'BACKGROUND_07',  # 0x7F
    'BACKGROUND_GRADATION',  # 0x80
    'ENEMY_APPEAR_CONTINUOUSLY',  # 0x81
    'BOSS_RUSH',  # 0x82
    'BOSS_RUSH_END',  # 0x83
    'BACKGROUND_08',  # 0x84
    'BACKGROUND_11',  # 0x85
    'BACKGROUND_12',  # 0x86
    'BACKGROUND_13',  # 0x87
    'BACKGROUND_14',  # 0x88
    'BACKGROUND_15',  # 0x89
    'BACKGROUND_16',  # 0x8A
    'BACKGROUND_17',  # 0x8B
    'BACKGROUND_18',  # 0x8C
    'BACKGROUND_GRADATION_END',  # 0x8D
    'SCRIPT LOOP',  # 0x8E
    'NONE_COMMAND',  # 0x8F
    None,  # 0x90
    None,  # 0x91
    None,  # 0x92
    None,  # 0x93
    None,  # 0x94
    None,  # 0x95
    'CIRCLE_INVADER',  # 0x96
    None,  # 0x97
    None,  # 0x98
    'GREED',  # 0x99
    'LINE_INVADER',  # 0x9A
    'WRATH',  # 0x9B
    'GLUTTONY',  # 0x9C
    None,  # 0x9D
    'SG_GIGANTIC_UFO',  # 0x9E
    None,  # 0x9F
    'CENTIPEDE',  # 0xA0
    'HONET',  # 0xA1
    'PROGRESSIVE_UFO',  # 0xA2
    'OCTOPUS',  # 0xA3
    'BUTTERFLY',  # 0xA4
    None,  # 0xA5
    'WATER_STRIDER',  # 0xA6
    None,  # 0xA7
    'ULTIMATE_UFO',  # 0xA8
    'SQUID',  # 0xA9
    'VERTEBRATE',  # 0xAA
    'NO_NAME',  # 0xAB
    None,  # 0xAC
    None,  # 0xAD
    None,  # 0xAE
    None,  # 0xAF
    None,  # 0xB0
    None,  # 0xB1
    None,  # 0xB2
    None,  # 0xB3
    '3D Back Scroll',  # 0xB4
    '3D Wall Scroll',  # 0xB5
    '3D Back Color',  # 0xB6
    '3D Camera Change 01',  # 0xB7
    '3D Camera Change 02',  # 0xB8
    '3D Demo',  # 0xB9
    'DEL_LV4_BOSS',  # 0xBA
    'DEL_LV5_BOSS',  # 0xBB
    '3D Back Animation',  # 0xBC
    '3D Back Rotate',  # 0xBD
    '3D Field Rotate Control',  # 0xBE
    None,  # 0xBF
    None,  # 0xC0
    None,  # 0xC1
    None,  # 0xC2
    None,  # 0xC3
    None,  # 0xC4
    None,  # 0xC5
    None,  # 0xC6
    None,  # 0xC7
    'VL_START',  # 0xC8
    'VL_END',  # 0xC9
    'VL_DISP_ON',  # 0xCA
    'VL_DISP_OFF',  # 0xCB
    'VL_SEQUENCESET',  # 0xCC
    'VL_CHANGETIME',  # 0xCD
    'VL_VOLUME_SCALE',  # 0xCE
)



class FormatError(ValueError):
    pass


def be_u16(data: bytes, off: int) -> int:
    if off < 0 or off + 2 > len(data):
        raise FormatError(f"u16 read outside file at 0x{off:X}")
    return struct.unpack_from(">H", data, off)[0]


def be_u32(data: bytes, off: int) -> int:
    if off < 0 or off + 4 > len(data):
        raise FormatError(f"u32 read outside file at 0x{off:X}")
    return struct.unpack_from(">I", data, off)[0]


def read_c_string(data: bytes, off: int, max_len: int = 4096) -> str:
    if off <= 0 or off >= len(data):
        return ""
    end_limit = min(len(data), off + max_len)
    end = data.find(b"\0", off, end_limit)
    if end < 0:
        raise FormatError(f"unterminated string at 0x{off:X}")
    raw = data[off:end]
    return raw.decode("utf-8", errors="replace")


def safe_relative_path(name: str, fallback: str) -> Path:
    # Preserve legitimate archive subdirectories (notably sound/se and sound/bgm)
    # while preventing absolute paths and traversal outside the output folder.
    raw_parts = name.replace("\\", "/").split("/") if name else []
    parts: list[str] = []
    reserved = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}
    for raw in raw_parts[:64]:
        part = raw.strip()
        if part in {"", ".", ".."}:
            continue
        part = re.sub(r"[\x00-\x1F<>:\"|?*]", "_", part).rstrip(" .")[:120]
        if part and part.split(".", 1)[0].upper() in reserved:
            part = "_" + part
        if part:
            parts.append(part)
    if not parts:
        parts = [fallback]
    return Path(*parts)


def privacy_safe_path(value: object) -> str:
    """Return a metadata-safe filename without parent directories."""
    text = str(value or "").strip()
    if not text:
        return ""
    normalized = text.replace("\\", "/")
    return normalized.rstrip("/").rsplit("/", 1)[-1]


def privacy_safe_source_label(value: object) -> str:
    """Keep archive-entry suffixes while removing the local filesystem route."""
    text = str(value or "").strip()
    if not text:
        return ""
    normalized = text.replace("\\", "/")
    # Nested archive labels use :<entry index>. Preserve those suffixes, while
    # not treating the drive colon in C:/... as an archive suffix.
    match = re.search(r"(?::\d+)+$", normalized)
    suffix = match.group(0) if match else ""
    base_text = normalized[: -len(suffix)] if suffix else normalized
    return base_text.rstrip("/").rsplit("/", 1)[-1] + suffix


def scrub_private_text(value: object) -> str:
    """Redact absolute routes embedded in diagnostic text."""
    text = str(value or "")
    # Windows absolute paths.
    text = re.sub(
        r"(?i)(?<![A-Za-z0-9_])[A-Z]:[\\/](?:[^\r\n<>:\"|?*]+[\\/])*[^\r\n<>:\"|?*]*",
        lambda m: privacy_safe_path(m.group(0)) or "<redacted>",
        text,
    )
    # POSIX absolute paths. Limit matching to path-like strings with at least
    # two components to avoid altering game-internal names such as /sound.bin.
    text = re.sub(
        r"(?<![A-Za-z0-9_])/(?:[^/\s:]+/)+[^/\s:]*",
        lambda m: privacy_safe_path(m.group(0)) or "<redacted>",
        text,
    )
    return text


def sanitize_json_value(value: object, key: str = "") -> object:
    """Recursively remove absolute filesystem routes from JSON-compatible data."""
    path_keys = {
        "source", "source_file", "source_path", "file", "path", "input",
        "output", "gltf", "ffmpeg", "xma_file", "wav_file", "destination",
    }
    if isinstance(value, dict):
        return {str(k): sanitize_json_value(v, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [sanitize_json_value(item, key) for item in value]
    if isinstance(value, tuple):
        return [sanitize_json_value(item, key) for item in value]
    if isinstance(value, str):
        normalized = value.replace("\\", "/")
        is_absolute = normalized.startswith("/") or bool(re.match(r"(?i)^[A-Z]:/", normalized))
        if key.lower() in path_keys and is_absolute:
            return privacy_safe_path(value)
        return scrub_private_text(value)
    return value


def _portable_path_exists(path: Path) -> bool:
    if path.exists():
        return True
    try:
        return any(child.name.casefold() == path.name.casefold() for child in path.parent.iterdir())
    except OSError:
        return False


def write_bytes_atomic(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".siig-part")
    temp.unlink(missing_ok=True)
    try:
        temp.write_bytes(data)
        os.replace(temp, path)
    except Exception:
        temp.unlink(missing_ok=True)
        raise


def write_text_atomic(path: Path, text: str, *, encoding: str = "utf-8") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".siig-part")
    temp.unlink(missing_ok=True)
    try:
        temp.write_text(text, encoding=encoding)
        os.replace(temp, path)
    except Exception:
        temp.unlink(missing_ok=True)
        raise


def write_json_private(path: Path, value: object, *, ensure_ascii: bool = True) -> None:
    write_text_atomic(
        path,
        json.dumps(sanitize_json_value(value), ensure_ascii=ensure_ascii, indent=2),
        encoding="utf-8",
    )


def unique_path(path: Path) -> Path:
    if not _portable_path_exists(path):
        return path
    stem, suffix = path.stem, path.suffix
    for n in range(1, 100000):
        candidate = path.with_name(f"{stem}_{n}{suffix}")
        if not _portable_path_exists(candidate):
            return candidate
    raise RuntimeError(f"could not find unique output name for {path}")


def rotl32(value: int, count: int) -> int:
    count &= 31
    value &= 0xFFFFFFFF
    if count == 0:
        return value
    return ((value << count) | (value >> (32 - count))) & 0xFFFFFFFF


def _s8(value: int) -> int:
    return value - 256 if value & 0x80 else value


def bbx_name_hash(name: str | bytes, seed: int = 0) -> int:
    """Reimplementation of default.xex Function_824739D0.

    BBX filenames in this title are ASCII. Passing bytes preserves arbitrary byte names.
    """
    raw = name.encode("utf-8") if isinstance(name, str) else bytes(name)
    result = 0
    running_sum = 0
    seed &= 0xFFFFFFFF

    for byte in raw:
        signed_byte = _s8(byte)
        running_sum = (running_sum + signed_byte) & 0xFFFFFFFF
        shift = running_sum & 31

        left = ((signed_byte & 0xFFFFFFFF) << shift) & 0xFFFFFFFF
        right_count = 32 - shift
        if right_count >= 32:
            shifted = -1 if signed_byte < 0 else 0
        else:
            shifted = signed_byte >> right_count

        # The PPC code sign-extends the low byte after the right shift.
        low = shifted & 0xFF
        sign_extended_low = _s8(low) & 0xFFFFFFFF
        rotated_seed = rotl32(seed, byte & 31)
        result = (result + rotated_seed + (left | sign_extended_low)) & 0xFFFFFFFF

    return result


@dataclass
class BBXEntry:
    index: int
    data_offset: int
    data_size: int
    name_offset: int
    identifier: int
    name: str
    hash_matches: Optional[bool]


@dataclass
class BBXArchive:
    data: bytes
    count: int
    mode: int
    hash_seed: int
    entries: list[BBXEntry]
    sorted_index: list[tuple[int, int]]

    @classmethod
    def parse(cls, data: bytes) -> "BBXArchive":
        if len(data) < 0x20:
            raise FormatError("file is too small for a BBX header")
        if data[:4] != BBX_MAGIC:
            raise FormatError(f"bad BBX magic: {data[:4].hex(' ')}")

        count = be_u32(data, 0x04)
        mode = be_u32(data, 0x08)
        hash_seed = be_u32(data, 0x0C)
        table_end = 0x20 + count * 0x10
        if table_end > len(data):
            raise FormatError(
                f"BBX entry table exceeds file: count={count}, end=0x{table_end:X}, size=0x{len(data):X}"
            )

        entries: list[BBXEntry] = []
        for index in range(count):
            rec = 0x20 + index * 0x10
            data_offset, data_size, name_offset, identifier = struct.unpack_from(">4I", data, rec)
            if data_offset > len(data) or data_size > len(data) - data_offset:
                raise FormatError(
                    f"entry {index}: payload outside file (offset=0x{data_offset:X}, size=0x{data_size:X})"
                )
            name = read_c_string(data, name_offset) if name_offset else ""
            match = None if not name else bbx_name_hash(name, hash_seed) == identifier
            entries.append(
                BBXEntry(index, data_offset, data_size, name_offset, identifier, name, match)
            )

        # The executable uses a sorted {hash,index} table for modes 0 and 1.
        sorted_index: list[tuple[int, int]] = []
        if mode < 2:
            index_end = table_end + count * 8
            if index_end <= len(data):
                for i in range(count):
                    h, resource_index = struct.unpack_from(">2I", data, table_end + i * 8)
                    if resource_index >= count:
                        # Avoid treating payload bytes as a table in malformed/unusual files.
                        sorted_index = []
                        break
                    sorted_index.append((h, resource_index))

        return cls(data, count, mode, hash_seed, entries, sorted_index)

    def payload(self, entry: BBXEntry) -> bytes:
        return self.data[entry.data_offset : entry.data_offset + entry.data_size]


def align_up(value: int, alignment: int = 16) -> int:
    if alignment < 1 or alignment & (alignment - 1):
        raise ValueError("alignment must be a positive power of two")
    return (value + alignment - 1) & ~(alignment - 1)


@dataclass
class BBXBuildEntry:
    name: str
    payload: bytes
    identifier: Optional[int] = None
    source_file: str = ""


def build_bbx_bytes(
    entries: Sequence[BBXBuildEntry],
    *,
    mode: int = 0,
    hash_seed: int = 0,
    header_reserved: bytes = b"\x00" * 16,
    preserve_identifiers: bool = False,
) -> bytes:
    """Build a canonical SIIG BBX archive.

    The verified layout is header, entry table, optional sorted hash table for modes
    0/1, NUL-terminated names, then 16-byte-aligned payloads.  Named identifiers are
    recomputed by default; unnamed entries require an explicit identifier.
    """
    if len(header_reserved) != 16:
        raise FormatError("BBX reserved header region must be exactly 16 bytes")
    if not 0 <= mode <= 0xFFFFFFFF or not 0 <= hash_seed <= 0xFFFFFFFF:
        raise FormatError("BBX mode and hash seed must fit unsigned 32-bit values")
    if len(entries) > 0xFFFFFFFF:
        raise FormatError("too many BBX entries")

    normalized: list[tuple[str, bytes, int]] = []
    for index, entry in enumerate(entries):
        try:
            encoded = entry.name.encode("utf-8") if entry.name else b""
        except UnicodeEncodeError as exc:
            raise FormatError(f"entry {index}: filename is not UTF-8 encodable") from exc
        if b"\x00" in encoded:
            raise FormatError(f"entry {index}: filename contains a NUL byte")
        if entry.name:
            computed = bbx_name_hash(encoded, hash_seed)
            identifier = int(entry.identifier) & 0xFFFFFFFF if preserve_identifiers and entry.identifier is not None else computed
        else:
            if entry.identifier is None:
                raise FormatError(f"entry {index}: unnamed BBX resources require an identifier")
            identifier = int(entry.identifier) & 0xFFFFFFFF
        normalized.append((entry.name, bytes(entry.payload), identifier))

    count = len(normalized)
    table_end = 0x20 + count * 0x10
    index_size = count * 8 if mode < 2 else 0
    cursor = table_end + index_size
    name_offsets: list[int] = []
    name_blob = bytearray()
    for name, _payload, _identifier in normalized:
        if not name:
            name_offsets.append(0)
            continue
        name_offsets.append(cursor + len(name_blob))
        name_blob.extend(name.encode("utf-8"))
        name_blob.append(0)
    data_cursor = align_up(cursor + len(name_blob), 16)
    data_offsets: list[int] = []
    for _name, payload, _identifier in normalized:
        data_offsets.append(data_cursor)
        data_cursor = align_up(data_cursor + len(payload), 16)

    output = bytearray(data_cursor)
    output[:4] = BBX_MAGIC
    struct.pack_into(">III", output, 4, count, mode & 0xFFFFFFFF, hash_seed & 0xFFFFFFFF)
    output[0x10:0x20] = header_reserved
    for index, ((name, payload, identifier), name_offset, data_offset) in enumerate(zip(normalized, name_offsets, data_offsets)):
        struct.pack_into(">4I", output, 0x20 + index * 0x10, data_offset, len(payload), name_offset, identifier)
        output[data_offset:data_offset + len(payload)] = payload
    if mode < 2:
        for slot, (identifier, resource_index) in enumerate(sorted((item[2], index) for index, item in enumerate(normalized))):
            struct.pack_into(">2I", output, table_end + slot * 8, identifier, resource_index)
    output[table_end + index_size:table_end + index_size + len(name_blob)] = name_blob
    return bytes(output)


def _parse_int_auto(value: object, *, label: str) -> int:
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        try:
            return int(value.strip(), 0)
        except ValueError as exc:
            raise FormatError(f"invalid {label}: {value!r}") from exc
    raise FormatError(f"invalid {label}: {value!r}")


def load_bbx_repack_manifest(
    input_dir: Path,
    manifest_path: Path,
    *,
    include_extra: bool = False,
) -> tuple[list[BBXBuildEntry], dict]:
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise FormatError(f"could not read BBX manifest {manifest_path}: {exc}") from exc
    rows = manifest.get("entries")
    if not isinstance(rows, list):
        raise FormatError("BBX manifest has no entries array")
    root = input_dir.resolve()
    entries: list[BBXBuildEntry] = []
    referenced: set[str] = set()
    casefolded: set[str] = set()
    for position, row in enumerate(rows):
        if not isinstance(row, dict):
            raise FormatError(f"manifest entry {position} is not an object")
        relative = row.get("output_file")
        if not isinstance(relative, str) or not relative:
            raise FormatError(f"manifest entry {position} has no output_file")
        safe = safe_relative_path(relative, "")
        if not safe or safe.as_posix() != Path(relative.replace('\\', '/')).as_posix():
            raise FormatError(f"manifest entry {position} has an unsafe output path: {relative!r}")
        candidate = (root / safe).resolve()
        try:
            candidate.relative_to(root)
        except ValueError as exc:
            raise FormatError(f"manifest entry escapes input directory: {relative!r}") from exc
        if not candidate.is_file():
            raise FormatError(f"manifest payload is missing: {relative}")
        folded = safe.as_posix().casefold()
        if folded in casefolded:
            raise FormatError(f"manifest payload path collides case-insensitively: {relative}")
        casefolded.add(folded)
        referenced.add(safe.as_posix())
        name = row.get("name")
        if not isinstance(name, str):
            name = ""
        identifier = _parse_int_auto(row.get("identifier"), label=f"entry {position} identifier")
        entries.append(BBXBuildEntry(name=name, payload=candidate.read_bytes(), identifier=identifier, source_file=safe.as_posix()))

    if include_extra:
        reserved = {"manifest.json", "manifest.csv"}
        extras = []
        for candidate in input_dir.rglob("*"):
            if not candidate.is_file():
                continue
            relative = candidate.relative_to(input_dir).as_posix()
            if relative in referenced or relative in reserved or relative.endswith(".siig-part"):
                continue
            extras.append((relative.casefold(), relative, candidate))
        for _key, relative, candidate in sorted(extras):
            folded = relative.casefold()
            if folded in casefolded:
                raise FormatError(f"extra payload collides case-insensitively: {relative}")
            casefolded.add(folded)
            entries.append(BBXBuildEntry(name=relative, payload=candidate.read_bytes(), identifier=None, source_file=relative))

    return entries, manifest


def verify_bbx_build(data: bytes, expected: Sequence[BBXBuildEntry], *, mode: int, hash_seed: int) -> dict:
    archive = BBXArchive.parse(data)
    issues: list[str] = []
    if archive.count != len(expected):
        issues.append(f"entry count {archive.count} != {len(expected)}")
    if archive.mode != mode:
        issues.append(f"mode {archive.mode} != {mode}")
    if archive.hash_seed != hash_seed:
        issues.append(f"hash seed 0x{archive.hash_seed:08X} != 0x{hash_seed:08X}")
    for index, item in enumerate(expected[:archive.count]):
        parsed = archive.entries[index]
        if parsed.name != item.name:
            issues.append(f"entry {index} name mismatch")
        if archive.payload(parsed) != item.payload:
            issues.append(f"entry {index} payload mismatch")
    return {"ok": not issues, "issues": issues, "count": archive.count, "mode": archive.mode, "hash_seed": archive.hash_seed}


def maybe_decompress(data: bytes, *, max_output: int = MAX_GZIP_OUTPUT_BYTES) -> bytes:
    if data[:2] != b"\x1F\x8B":
        return data
    if max_output < 1:
        raise FormatError("maximum gzip output must be at least one byte")
    output = bytearray()
    try:
        with gzip.GzipFile(fileobj=io.BytesIO(data), mode="rb") as handle:
            while True:
                chunk = handle.read(min(1024 * 1024, max_output + 1 - len(output)))
                if not chunk:
                    break
                output.extend(chunk)
                if len(output) > max_output:
                    raise FormatError(
                        f"gzip output exceeds safety limit ({max_output} bytes)"
                    )
    except gzip.BadGzipFile:
        raise
    except EOFError as exc:
        raise FormatError(f"truncated gzip stream: {exc}") from exc
    return bytes(output)


def xor_systemfont_crp(data: bytes) -> bytes:
    """Decrypt the systemfont.crp payload used by SIIG.

    default.xex Function_8215B010 XORs every byte with 0xF1 before
    passing the result to the normal Xbox 360 texture loader.
    """
    return bytes(byte ^ SYSTEMFONT_CRP_XOR for byte in data)


def looks_like_tex(data: bytes) -> bool:
    if len(data) < TEX_HEADER_SIZE:
        return False
    try:
        words = struct.unpack_from(">13I", data, 0)
    except struct.error:
        return False
    # All SIIG TEX samples are a 0x1C-byte D3D resource header followed by a
    # six-dword Xenos texture fetch constant and pixel data.
    if words[:5] != (3, 1, 0, 0, 0):
        return False
    fetch0, fetch1, fetch2 = words[7], words[8], words[9]
    width = (fetch2 & 0x1FFF) + 1
    height = ((fetch2 >> 13) & 0x1FFF) + 1
    fmt = fetch1 & 0x3F
    return (fetch0 & 3) == 2 and 0 < width <= 8192 and 0 < height <= 8192 and fmt < 64


def looks_like_ps3_tex(data: bytes) -> bool:
    """Recognize SIIG's PS3 RSX texture wrapper.

    The PS3 build stores a 0x80-byte header followed by linear A8R8G8B8
    pixels. Width and height are big-endian 16-bit values at 0x20/0x22.
    """
    if len(data) < 0x80 or data[:4] != b"\x02\x00\x00\xFF":
        return False
    try:
        data_offset = be_u32(data, 0x10)
        payload_size = be_u32(data, 0x14)
        width = be_u16(data, 0x20)
        height = be_u16(data, 0x22)
    except FormatError:
        return False
    if data_offset != 0x80 or not (0 < width <= 8192 and 0 < height <= 8192):
        return False
    expected = width * height * 4
    return payload_size >= expected and data_offset + expected <= len(data)


def looks_like_any_tex(data: bytes) -> bool:
    return looks_like_tex(data) or looks_like_ps3_tex(data)


def looks_like_systemfont_crp(data: bytes) -> bool:
    if len(data) < TEX_HEADER_SIZE:
        return False
    decrypted_header = bytes(byte ^ SYSTEMFONT_CRP_XOR for byte in data[:0x80])
    return looks_like_any_tex(decrypted_header)


def sniff_extension(payload: bytes) -> str:
    if payload.startswith(GMX_MAGIC):
        return ".gmx"
    if payload.startswith(MAP_MAGIC):
        return ".map"
    if payload.startswith(BBX_MAGIC):
        return ".bbx"
    if payload.startswith(b"RIFF"):
        return ".riff"
    if payload.startswith(b"FSGX"):
        return ".fsgx"
    if payload.startswith((XWB_MAGIC_BE, XWB_MAGIC_LE)):
        return ".xwb"
    if payload.startswith((XSB_MAGIC_BE, XSB_MAGIC_LE)):
        return ".xsb"
    if looks_like_any_tex(payload):
        return ".tex"
    if b"klBS" in payload[:0x40]:
        return ".bnk"
    if looks_like_systemfont_crp(payload):
        return ".crp"
    return ".bin"


def extract_bbx_bytes(
    data: bytes,
    output_dir: Path,
    source_label: str,
    recursive: bool = False,
    convert_gmx: bool = False,
    convert_gltf: bool = False,
    convert_tex: bool = False,
    flip_v: bool = False,
    *,
    _depth: int = 0,
    _budget: Optional[dict[str, int]] = None,
) -> dict:
    if _depth > MAX_BBX_RECURSION_DEPTH:
        raise FormatError(
            f"nested BBX depth exceeds safety limit ({MAX_BBX_RECURSION_DEPTH})"
        )
    archive = BBXArchive.parse(data)
    if _budget is None:
        _budget = {"entries": 0}
    _budget["entries"] = _budget.get("entries", 0) + archive.count
    if _budget["entries"] > MAX_BBX_TOTAL_ENTRIES:
        raise FormatError(
            f"nested BBX resource count exceeds safety limit ({MAX_BBX_TOTAL_ENTRIES})"
        )
    output_dir.mkdir(parents=True, exist_ok=True)

    manifest_rows: list[dict] = []
    nested_results: list[dict] = []
    gltf_candidates: list[Path] = []

    for entry in archive.entries:
        payload = archive.payload(entry)
        fallback = f"{entry.index:04d}_{entry.identifier:08X}{sniff_extension(payload)}"
        relative_output = safe_relative_path(entry.name, fallback)
        destination = unique_path(output_dir / relative_output)
        destination.parent.mkdir(parents=True, exist_ok=True)
        write_bytes_atomic(destination, payload)

        row = asdict(entry)
        row.update(
            {
                "output_file": destination.relative_to(output_dir).as_posix(),
                "payload_magic": payload[:8].hex(" ").upper(),
                "payload_sha256": hashlib.sha256(payload).hexdigest(),
            }
        )
        manifest_rows.append(row)

        if convert_gltf and payload.startswith(GMX_MAGIC):
            gltf_candidates.append(destination)

        if convert_gmx and payload.startswith(GMX_MAGIC):
            try:
                chunks = parse_gmx_chunks(payload)
                if any(chunk.tag == "MESH" for chunk in chunks):
                    export_gmx_obj_bytes(payload, destination.with_suffix(".obj"), flip_v=flip_v)
                else:
                    scan_meta = {
                        "source_size": len(payload),
                        "mesh_count": 0,
                        "note": "This GMX has no MESH chunks; it may be hierarchy/animation-only.",
                        "chunks": [
                            {"offset": c.offset, "tag": c.tag, "size": c.size} for c in chunks
                        ],
                    }
                    write_json_private(destination.with_suffix(".gmx.json"), scan_meta)
            except Exception as exc:
                print(f"warning: GMX conversion failed for {destination}: {exc}", file=sys.stderr)

        if convert_tex and (destination.suffix.lower() == ".tex" or looks_like_any_tex(payload)):
            try:
                export_tex_png_bytes(payload, destination.with_suffix(".png"))
            except Exception as exc:
                print(f"warning: TEX conversion failed for {destination}: {exc}", file=sys.stderr)
        elif convert_tex and (destination.suffix.lower() == ".crp" or looks_like_systemfont_crp(payload)):
            try:
                decrypted = xor_systemfont_crp(payload)
                png_path = destination.with_name(destination.stem + "_atlas.png")
                meta = export_tex_png_bytes(decrypted, png_path)
                meta.update({"source_format": "SIIG systemfont CRP", "xor_key": "0xF1"})
                write_json_private(png_path.with_suffix(png_path.suffix + ".json"), meta)
            except Exception as exc:
                print(f"warning: CRP font conversion failed for {destination}: {exc}", file=sys.stderr)

        if recursive and payload.startswith(BBX_MAGIC):
            nested_dir = output_dir / f"{destination.stem}_nested"
            nested_results.append(
                extract_bbx_bytes(
                    payload,
                    nested_dir,
                    f"{source_label}:{entry.index}",
                    recursive=True,
                    convert_gmx=convert_gmx,
                    convert_gltf=convert_gltf,
                    convert_tex=convert_tex,
                    flip_v=flip_v,
                    _depth=_depth + 1,
                    _budget=_budget,
                )
            )

    # Convert GMX after all archive entries have been written so referenced DDS/TEX
    # resources in the same archive are available to the material exporter.
    for gmx_path in gltf_candidates:
        try:
            relative = gmx_path.relative_to(output_dir).with_suffix(".gltf")
            export_gmx_gltf_file(
                gmx_path,
                output_dir,
                flip_v=flip_v,
                texture_roots=(output_dir,),
                relative_path=relative,
            )
        except Exception as exc:
            print(f"warning: glTF conversion failed for {gmx_path}: {exc}", file=sys.stderr)

    manifest_csv = output_dir / "manifest.csv"
    fields = [
        "index",
        "name",
        "output_file",
        "data_offset",
        "data_size",
        "name_offset",
        "identifier",
        "hash_matches",
        "payload_magic",
        "payload_sha256",
    ]
    with manifest_csv.open("w", newline="", encoding="utf-8") as fp:
        writer = csv.DictWriter(fp, fieldnames=fields)
        writer.writeheader()
        for row in manifest_rows:
            writer.writerow({field: row.get(field) for field in fields})

    metadata = {
        "source": privacy_safe_source_label(source_label),
        "magic": "01 42 42 58",
        "count": archive.count,
        "mode": archive.mode,
        "hash_seed": f"0x{archive.hash_seed:08X}",
        "header_reserved_hex": archive.data[0x10:0x20].hex(),
        "source_size": len(archive.data),
        "source_sha256": hashlib.sha256(archive.data).hexdigest(),
        "payload_alignment": 16,
        "has_sorted_hash_index": bool(archive.sorted_index),
        "sorted_index": [{"identifier": identifier, "entry_index": index} for identifier, index in archive.sorted_index],
        "entries": manifest_rows,
        "nested": nested_results,
    }
    write_json_private(output_dir / "manifest.json", metadata)
    return metadata


def extract_bbx_file(
    path: Path,
    output_root: Path,
    recursive: bool,
    convert_gmx: bool,
    convert_gltf: bool,
    convert_tex: bool,
    flip_v: bool,
) -> dict:
    data = maybe_decompress(path.read_bytes())
    if not data.startswith(BBX_MAGIC):
        raise FormatError(f"{path}: decompressed data is not BBX")
    out = output_root / path.name
    # Strip multiple packaging suffixes for a clean output directory.
    for suffix in (".sdat", ".gz", ".bin"):
        if out.name.lower().endswith(suffix):
            out = out.with_name(out.name[: -len(suffix)])
    return extract_bbx_bytes(
        data, out, path.name, recursive, convert_gmx, convert_gltf, convert_tex, flip_v
    )



@dataclass
class XWBEntry:
    index: int
    name: str
    codec: str
    channels: int
    sample_rate: int
    bits_per_sample: int
    block_align: int
    num_samples: int
    data_offset: int
    data_size: int
    loop_begin: int
    loop_length: int
    flags: int


@dataclass
class XWBInfo:
    version: int
    endian: str
    bank_name: str
    bank_flags: int
    alignment: int
    data_offset: int
    data_size: int
    entries: list[XWBEntry]


def looks_like_xwb(data: bytes) -> bool:
    return len(data) >= 0x34 and data[:4] in (XWB_MAGIC_BE, XWB_MAGIC_LE)


def _xact_u32(data: bytes, off: int, endian: str) -> int:
    if off < 0 or off + 4 > len(data):
        raise FormatError(f"XACT u32 read outside file at 0x{off:X}")
    return struct.unpack_from(endian + "I", data, off)[0]


def _xact_s32(data: bytes, off: int, endian: str) -> int:
    if off < 0 or off + 4 > len(data):
        raise FormatError(f"XACT s32 read outside file at 0x{off:X}")
    return struct.unpack_from(endian + "i", data, off)[0]


def _printable_ascii_strings(data: bytes, min_length: int = 3) -> list[str]:
    pattern = rb"[\x20-\x7E]{" + str(min_length).encode("ascii") + rb",}"
    return [m.group().decode("ascii", errors="replace") for m in re.finditer(pattern, data)]


def parse_xsb_cue_names(data: bytes, total_waves: int, bank_name: str) -> list[str]:
    """Extract cue names from the simple XACT3 XSB banks used by SIIG.

    This game has one cue per wave. The large SE bank stores the 83 cue names
    consecutively, while the single-wave BGM banks store bank/wavebank names
    followed by the cue name.
    """
    if not data.startswith((XSB_MAGIC_BE, XSB_MAGIC_LE)):
        return []
    strings = [s for s in _printable_ascii_strings(data) if s not in {"KBDS", "SDBK"}]
    if total_waves == 1:
        return [strings[-1]] if strings else []
    if len(strings) >= total_waves:
        return strings[:total_waves]
    return strings


def parse_xwb(data: bytes, cue_names: Optional[Sequence[str]] = None) -> XWBInfo:
    """Parse standard (non-compact) XACT wave banks.

    SIIG uses big-endian XACT3 version 46 banks with standard 24-byte entries
    and XMA2 streams. Little-endian banks and the older standard segment layouts
    are accepted where their fields are compatible.
    """
    if not looks_like_xwb(data):
        raise FormatError("not an XACT XWB wave bank")
    endian = ">" if data[:4] == XWB_MAGIC_BE else "<"
    endian_name = "big" if endian == ">" else "little"
    version = _xact_u32(data, 0x04, endian)
    segment = 0x08 if version <= 41 else 0x0C

    base_offset = _xact_u32(data, segment + 0x00, endian)
    entry_offset = _xact_u32(data, segment + 0x08, endian)
    entry_segment_size = _xact_u32(data, segment + 0x0C, endian)

    if version <= 21:
        suboffset = 0x08
    elif version == 22:
        suboffset = base_offset - 0x20
    else:
        suboffset = 0x10
    data_offset = _xact_u32(data, segment + 0x10 + suboffset, endian)
    data_size = _xact_u32(data, segment + 0x14 + suboffset, endian)

    if base_offset <= 0 or base_offset + 8 > len(data):
        raise FormatError("invalid XWB bank-data segment")
    bank_flags = _xact_u32(data, base_offset + 0x00, endian)
    total = _xact_s32(data, base_offset + 0x04, endian)
    if total <= 0 or total > 100000:
        raise FormatError(f"invalid XWB stream count {total}")
    name_size = 0x10 if version <= 21 else 0x40
    raw_name = data[base_offset + 0x08 : base_offset + 0x08 + name_size]
    bank_name = raw_name.split(b"\0", 1)[0].decode("ascii", errors="replace")
    base_fields = base_offset + 0x08 + name_size
    entry_size = _xact_u32(data, base_fields + 0x00, endian)
    alignment = _xact_u32(data, base_fields + 0x08, endian)

    if bank_flags & WAVEBANK_FLAGS_COMPACT:
        raise FormatError("compact XWB entries are not supported by the built-in SIIG converter")
    if entry_size < 0x18:
        raise FormatError(f"unsupported XWB entry size 0x{entry_size:X}")
    if entry_offset + total * entry_size > len(data):
        raise FormatError("XWB entry table extends beyond the file")
    if entry_segment_size < total * entry_size:
        raise FormatError("XWB entry segment is smaller than its entry table")

    names = list(cue_names or [])
    entries: list[XWBEntry] = []
    codecs = ("PCM", "XMA2", "MS_ADPCM", "XWMA")
    for index in range(total):
        off = entry_offset + index * entry_size
        entry_info, packed_format, relative_offset, stream_size, loop_begin, loop_length = struct.unpack_from(
            endian + "6I", data, off
        )
        if version <= 41:
            raise FormatError(f"built-in audio conversion currently requires XACT3 v42+, found v{version}")
        bits_flag = (packed_format >> 31) & 1
        block_align = (packed_format >> 23) & 0xFF
        sample_rate = (packed_format >> 5) & 0x3FFFF
        channels = (packed_format >> 2) & 0x7
        tag = packed_format & 0x3
        absolute_offset = data_offset + relative_offset
        if absolute_offset > len(data) or stream_size > len(data) - absolute_offset:
            raise FormatError(f"XWB stream {index} extends beyond the file")
        fallback = f"{bank_name or 'wave'}_{index + 1:03d}"
        name = names[index] if index < len(names) and names[index] else fallback
        entries.append(
            XWBEntry(
                index=index,
                name=name,
                codec=codecs[tag],
                channels=channels,
                sample_rate=sample_rate,
                bits_per_sample=8 if bits_flag == 0 else 16,
                block_align=block_align,
                num_samples=entry_info >> 4,
                data_offset=absolute_offset,
                data_size=stream_size,
                loop_begin=loop_begin,
                loop_length=loop_length,
                flags=entry_info & 0xF,
            )
        )
    return XWBInfo(version, endian_name, bank_name, bank_flags, alignment, data_offset, data_size, entries)


def _xma_channel_mask(channels: int) -> int:
    return {1: 0x4, 2: 0x3, 3: 0x7, 4: 0x33, 5: 0x37, 6: 0x3F}.get(
        channels, (1 << channels) - 1
    )


def build_xma2_riff(raw_xma: bytes, entry: XWBEntry) -> bytes:
    """Wrap one raw XACT XMA2 stream in a standard RIFF/WAVE header."""
    if entry.codec != "XMA2":
        raise FormatError(f"RIFF wrapper requested for non-XMA2 codec {entry.codec}")
    if entry.channels <= 0 or entry.sample_rate <= 0:
        raise FormatError("invalid XMA2 channel count or sample rate")
    bytes_per_block = 0x10000
    block_count = max(1, (len(raw_xma) + bytes_per_block - 1) // bytes_per_block)
    avg_bytes_per_sec = max(1, round(len(raw_xma) * entry.sample_rate / max(1, entry.num_samples)))
    wave_format = struct.pack(
        "<HHIIHHH",
        0x0166,
        entry.channels,
        entry.sample_rate,
        avg_bytes_per_sec,
        entry.channels * 2,
        16,
        34,
    )
    extra = struct.pack(
        "<HIIIIIIIBBH",
        (entry.channels + 1) // 2,
        _xma_channel_mask(entry.channels),
        entry.num_samples,
        bytes_per_block,
        0,
        entry.num_samples,
        entry.loop_begin,
        entry.loop_length,
        255 if entry.loop_length else 0,
        4,
        block_count,
    )
    fmt_payload = wave_format + extra
    body = (
        b"WAVE"
        + b"fmt "
        + struct.pack("<I", len(fmt_payload))
        + fmt_payload
        + b"data"
        + struct.pack("<I", len(raw_xma))
        + raw_xma
    )
    return b"RIFF" + struct.pack("<I", len(body)) + body


def _safe_audio_name(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._")
    return cleaned or "stream"


def export_xwb_audio_bytes(
    xwb_data: bytes,
    output_dir: Path,
    source_label: str,
    xsb_data: Optional[bytes] = None,
    ffmpeg_path: Optional[str] = None,
    keep_xma: bool = False,
) -> dict:
    preliminary = parse_xwb(xwb_data)
    cue_names = parse_xsb_cue_names(xsb_data or b"", len(preliminary.entries), preliminary.bank_name)
    info = parse_xwb(xwb_data, cue_names)
    output_dir.mkdir(parents=True, exist_ok=True)
    ffmpeg = ffmpeg_path or shutil.which("ffmpeg")
    rows: list[dict] = []
    decode_failures = 0

    for entry in info.entries:
        raw = xwb_data[entry.data_offset : entry.data_offset + entry.data_size]
        stem = f"{entry.index + 1:03d}_{_safe_audio_name(entry.name)}"
        encoded_path = output_dir / f"{stem}.xma"
        wav_path = output_dir / f"{stem}.wav"
        decoded = False
        error = ""
        if entry.codec == "XMA2":
            encoded_path.write_bytes(build_xma2_riff(raw, entry))
            if ffmpeg:
                result = subprocess.run(
                    [
                        ffmpeg,
                        "-y",
                        "-hide_banner",
                        "-loglevel",
                        "error",
                        "-i",
                        str(encoded_path),
                        "-c:a",
                        "pcm_s16le",
                        str(wav_path),
                    ],
                    capture_output=True,
                    text=True,
                )
                decoded = result.returncode == 0 and wav_path.exists()
                if not decoded:
                    decode_failures += 1
                    error = result.stderr.strip()[-1000:]
                elif not keep_xma:
                    encoded_path.unlink(missing_ok=True)
        else:
            error = f"built-in converter does not yet handle {entry.codec}"
            decode_failures += 1

        row = asdict(entry)
        row.update(
            {
                "xma_file": encoded_path.name if encoded_path.exists() else "",
                "wav_file": wav_path.name if wav_path.exists() else "",
                "decoded": decoded,
                "error": error,
            }
        )
        rows.append(row)

    manifest = {
        "source": privacy_safe_source_label(source_label),
        "format": "XACT XWB",
        "version": info.version,
        "endian": info.endian,
        "bank_name": info.bank_name,
        "bank_flags": f"0x{info.bank_flags:08X}",
        "alignment": info.alignment,
        "stream_count": len(info.entries),
        "ffmpeg": privacy_safe_path(ffmpeg) if ffmpeg else None,
        "decode_failures": decode_failures,
        "entries": rows,
    }
    write_json_private(output_dir / "xwb_manifest.json", manifest)
    if rows:
        with (output_dir / "xwb_manifest.csv").open("w", newline="", encoding="utf-8") as fp:
            writer = csv.DictWriter(fp, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    return manifest


def _collect_xact_from_bbx(data: bytes, prefix: Path = Path()) -> dict[str, bytes]:
    archive = BBXArchive.parse(data)
    collected: dict[str, bytes] = {}
    for entry in archive.entries:
        payload = archive.payload(entry)
        fallback = f"{entry.index:04d}_{entry.identifier:08X}{sniff_extension(payload)}"
        rel = prefix / safe_relative_path(entry.name, fallback)
        if payload.startswith(BBX_MAGIC):
            collected.update(_collect_xact_from_bbx(payload, prefix / f"{rel.stem}_nested"))
        elif payload.startswith((XWB_MAGIC_BE, XWB_MAGIC_LE)) or rel.suffix.lower() == ".xwb":
            collected[rel.as_posix()] = payload
        elif payload.startswith((XSB_MAGIC_BE, XSB_MAGIC_LE)) or rel.suffix.lower() == ".xsb":
            collected[rel.as_posix()] = payload
    return collected


def _decode_xact_collection(
    files: dict[str, bytes], output_root: Path, source_label: str, ffmpeg_path: Optional[str], keep_xma: bool
) -> tuple[int, int]:
    success = 0
    failures = 0
    lower_lookup = {name.lower(): data for name, data in files.items()}
    for name, data in sorted(files.items()):
        if not name.lower().endswith(".xwb") and not looks_like_xwb(data):
            continue
        rel = Path(name)
        xsb_name = rel.with_suffix(".xsb").as_posix().lower()
        xsb_data = lower_lookup.get(xsb_name)
        target = output_root / rel.parent / rel.stem
        try:
            result = export_xwb_audio_bytes(
                data, target, f"{source_label}:{name}", xsb_data=xsb_data, ffmpeg_path=ffmpeg_path, keep_xma=keep_xma
            )
            print(
                f"{name}: {result['stream_count']} stream(s), "
                f"{result['decode_failures']} decode failure(s) -> {target}"
            )
            success += result["stream_count"] - result["decode_failures"]
            failures += result["decode_failures"]
        except Exception as exc:
            failures += 1
            print(f"ERROR {name}: {exc}", file=sys.stderr)
    return success, failures


def command_xact2wav(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    ffmpeg_path = args.ffmpeg or shutil.which("ffmpeg")
    if args.ffmpeg and not Path(args.ffmpeg).exists() and not shutil.which(args.ffmpeg):
        raise FormatError(f"FFmpeg executable not found: {args.ffmpeg}")

    if input_path.is_file():
        data = maybe_decompress(input_path.read_bytes())
        if data.startswith(BBX_MAGIC):
            files = _collect_xact_from_bbx(data)
            success, failures = _decode_xact_collection(
                files, output, str(input_path), ffmpeg_path, args.keep_xma
            )
        elif looks_like_xwb(data):
            xsb_path = input_path.with_suffix(".xsb")
            xsb_data = xsb_path.read_bytes() if xsb_path.exists() else None
            result = export_xwb_audio_bytes(
                data, output / input_path.stem, str(input_path), xsb_data, ffmpeg_path, args.keep_xma
            )
            success = result["stream_count"] - result["decode_failures"]
            failures = result["decode_failures"]
        else:
            raise FormatError("input is not sound.bin/BBX or an XWB wave bank")
    elif input_path.is_dir():
        files: dict[str, bytes] = {}
        for path in input_path.rglob("*"):
            if not path.is_file():
                continue
            try:
                head = path.read_bytes()[:4]
            except OSError:
                continue
            if path.suffix.lower() in {".xwb", ".xsb"} or head in (XWB_MAGIC_BE, XWB_MAGIC_LE, XSB_MAGIC_BE, XSB_MAGIC_LE):
                files[path.relative_to(input_path).as_posix()] = path.read_bytes()
        success, failures = _decode_xact_collection(
            files, output, str(input_path), ffmpeg_path, args.keep_xma
        )
    else:
        raise FileNotFoundError(input_path)

    if not ffmpeg_path:
        print(
            "FFmpeg was not found. RIFF-wrapped .xma files were written, but WAV decoding was skipped. "
            "Install FFmpeg or use vgmstream-cli to convert them.",
            file=sys.stderr,
        )
    print(f"completed: {success} decoded stream(s), {failures} failure(s)")
    return 1 if failures and not success else 0


@dataclass
class TEXInfo:
    width: int
    height: int
    physical_pitch: int
    format: int
    format_name: str
    endianness: int
    endianness_name: str
    tiled: bool
    swizzle: tuple[int, int, int, int]
    payload_size: int
    fetch_dwords: tuple[int, int, int, int, int, int]


def parse_tex(data: bytes) -> TEXInfo:
    if not looks_like_tex(data):
        raise FormatError("not a recognized SIIG Xbox 360 TEX file")
    words = struct.unpack_from(">13I", data, 0)
    fetch = words[7:13]
    d0, d1, d2, d3, _d4, _d5 = fetch
    width = (d2 & 0x1FFF) + 1
    height = ((d2 >> 13) & 0x1FFF) + 1
    pitch_units = (d0 >> 22) & 0x1FF
    physical_pitch = pitch_units * 32 if pitch_units else ((width + 31) & ~31)
    fmt = d1 & 0x3F
    endian = (d1 >> 6) & 3
    swizzle_word = (d3 >> 1) & 0xFFF
    swizzle = tuple((swizzle_word >> (component * 3)) & 7 for component in range(4))
    return TEXInfo(
        width=width,
        height=height,
        physical_pitch=physical_pitch,
        format=fmt,
        format_name=XENOS_TEXTURE_FORMAT_NAMES.get(fmt, f"unknown_{fmt}"),
        endianness=endian,
        endianness_name=XENOS_ENDIAN_NAMES.get(endian, f"unknown_{endian}"),
        tiled=bool(d0 >> 31),
        swizzle=swizzle,  # type: ignore[arg-type]
        payload_size=len(data) - TEX_HEADER_SIZE,
        fetch_dwords=fetch,  # type: ignore[arg-type]
    )


def xg_address_2d_tiled_offset(x: int, y: int, width: int, texel_pitch: int) -> int:
    """Return the Xenos byte address of one 2D tiled texel/block.

    This follows Xenia's current bit-decomposed texture-address implementation.
    The older commonly copied XGAddress2DTiledOffset formula omits the Y[3]
    XOR in the pipe selector, which produces the characteristic 8-row
    jitter/scrambling seen in the first toolkit build.

    ``width`` is the physical pitch in texels/blocks and must be 32-aligned.
    ``texel_pitch`` is the byte size of one texel/block and must be a power of 2.
    """
    aligned_width = (width + 31) & ~31
    if texel_pitch <= 0 or texel_pitch & (texel_pitch - 1):
        raise FormatError(f"invalid tiled texel pitch {texel_pitch}")
    bytes_per_block_log2 = texel_pitch.bit_length() - 1

    # Macro-tile origin and 8x16 micro-tile offset, measured in blocks.
    outer_blocks = (
        ((y >> 5) * (aligned_width >> 5) + (x >> 5)) << 6
    )
    inner_blocks = (((y >> 1) & 0b111) << 3) | (x & 0b111)
    outer_inner_bytes = (outer_blocks | inner_blocks) << bytes_per_block_log2

    # Xenos bank/pipe selection. The Y[3] XOR is essential.
    bank = (y >> 4) & 0b1
    pipe = ((x >> 3) & 0b11) ^ (((y >> 3) & 0b1) << 1)
    y_lsb = y & 0b1

    return (
        (y_lsb << 4)
        | (pipe << 6)
        | (bank << 11)
        | (outer_inner_bytes & 0x0F)
        | (((outer_inner_bytes >> 4) & 0x01) << 5)
        | (((outer_inner_bytes >> 5) & 0x07) << 8)
        | ((outer_inner_bytes >> 8) << 12)
    )


@lru_cache(maxsize=4)
def _xg_tiled_offset_table(width: int, height: int, physical_pitch: int, texel_pitch: int) -> array:
    # Compact 32-bit table; caching is especially valuable here because SIIG has
    # many textures with identical 1152x1152 layouts.
    offsets = array("I")
    append = offsets.append
    for y in range(height):
        for x in range(width):
            append(xg_address_2d_tiled_offset(x, y, physical_pitch, texel_pitch))
    return offsets


def _apply_xenos_endian(pixel: bytes, endian: int) -> bytes:
    if len(pixel) != 4:
        raise FormatError("truncated 32-bit TEX pixel")
    if endian == 0:
        return pixel
    if endian == 1:  # 8-in-16
        return bytes((pixel[1], pixel[0], pixel[3], pixel[2]))
    if endian == 2:  # 8-in-32
        return pixel[::-1]
    if endian == 3:  # 16-in-32
        return bytes((pixel[2], pixel[3], pixel[0], pixel[1]))
    raise FormatError(f"unsupported Xenos endian mode {endian}")


def _apply_xenos_swizzle(components: bytes, swizzle: tuple[int, int, int, int]) -> bytes:
    out = bytearray(4)
    for i, selector in enumerate(swizzle):
        if selector < 4:
            out[i] = components[selector]
        elif selector == 4:
            out[i] = 0
        elif selector == 5:
            out[i] = 255
        else:
            raise FormatError(f"unsupported Xenos swizzle selector {selector}")
    return bytes(out)


def decode_tex_rgba(data: bytes) -> tuple[TEXInfo, bytes]:
    info = parse_tex(data)
    if info.format != XENOS_TEXFMT_8_8_8_8:
        raise FormatError(
            f"TEX PNG conversion currently supports 8_8_8_8 (6), got {info.format_name} ({info.format})"
        )
    payload = data[TEX_HEADER_SIZE:]
    width = info.width
    height = info.height
    physical_pitch = info.physical_pitch
    rgba = bytearray(width * height * 4)

    # This is the exact combination used by every SIIG TEX sample examined:
    # k8in32 plus Z,Y,X,W swizzle. Keep a specialized path because the game has
    # many 1152x1152 images and avoiding per-pixel temporary objects is much faster.
    common_layout = info.endianness == 2 and info.swizzle == (2, 1, 0, 3)
    tiled = info.tiled
    payload_len = len(payload)
    if tiled:
        source_offsets: Iterable[int] = _xg_tiled_offset_table(width, height, physical_pitch, 4)
    else:
        source_offsets = (
            (y * physical_pitch + x) * 4 for y in range(height) for x in range(width)
        )
    target = 0
    for pixel_number, source in enumerate(source_offsets):
        if source + 4 > payload_len:
            x = pixel_number % width
            y = pixel_number // width
            raise FormatError(
                f"TEX pixel ({x},{y}) maps beyond payload at 0x{source:X} "
                f"(payload 0x{payload_len:X})"
            )
        if common_layout:
            # Raw GPU bytes ABCD -> k8in32 DCBA -> ZYXW swizzle BCDA.
            rgba[target] = payload[source + 1]
            rgba[target + 1] = payload[source + 2]
            rgba[target + 2] = payload[source + 3]
            rgba[target + 3] = payload[source]
        else:
            components = _apply_xenos_endian(payload[source : source + 4], info.endianness)
            pixel = _apply_xenos_swizzle(components, info.swizzle)
            rgba[target : target + 4] = pixel
        target += 4
    return info, bytes(rgba)


@dataclass
class PS3TEXInfo:
    width: int
    height: int
    data_offset: int
    payload_size: int
    format_name: str = "RSX_A8R8G8B8_LINEAR"
    platform: str = "ps3"


def parse_ps3_tex(data: bytes) -> PS3TEXInfo:
    if not looks_like_ps3_tex(data):
        raise FormatError("not a recognized SIIG PS3 TEX file")
    return PS3TEXInfo(
        width=be_u16(data, 0x20),
        height=be_u16(data, 0x22),
        data_offset=be_u32(data, 0x10),
        payload_size=be_u32(data, 0x14),
    )


def decode_ps3_tex_rgba(data: bytes) -> tuple[PS3TEXInfo, bytes]:
    info = parse_ps3_tex(data)
    expected = info.width * info.height * 4
    raw = data[info.data_offset : info.data_offset + expected]
    if len(raw) != expected:
        raise FormatError("truncated PS3 TEX pixel payload")
    rgba = bytearray(expected)
    # RSX bytes are A,R,G,B. PNG expects R,G,B,A.
    for offset in range(0, expected, 4):
        alpha, red, green, blue = raw[offset : offset + 4]
        rgba[offset : offset + 4] = bytes((red, green, blue, alpha))
    return info, bytes(rgba)


def decode_any_tex_rgba(data: bytes):
    if looks_like_tex(data):
        info, rgba = decode_tex_rgba(data)
        metadata = asdict(info)
        metadata["platform"] = "xbox360"
        metadata["fetch_dwords"] = [f"0x{value:08X}" for value in info.fetch_dwords]
        metadata["swizzle"] = list(info.swizzle)
        return metadata, info.width, info.height, rgba
    if looks_like_ps3_tex(data):
        info, rgba = decode_ps3_tex_rgba(data)
        return asdict(info), info.width, info.height, rgba
    raise FormatError("not a recognized SIIG Xbox 360 or PS3 TEX file")


def _png_chunk(tag: bytes, payload: bytes) -> bytes:
    return struct.pack(">I", len(payload)) + tag + payload + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF)


def write_rgba_png(path: Path, width: int, height: int, rgba: bytes) -> None:
    if len(rgba) != width * height * 4:
        raise ValueError("RGBA byte count does not match dimensions")
    rows = b"".join(b"\x00" + rgba[y * width * 4 : (y + 1) * width * 4] for y in range(height))
    png = (
        b"\x89PNG\r\n\x1a\n"
        + _png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
        + _png_chunk(b"IDAT", zlib.compress(rows, 1))
        + _png_chunk(b"IEND", b"")
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(png)


def export_tex_png_bytes(data: bytes, png_path: Path) -> dict:
    metadata, width, height, rgba = decode_any_tex_rgba(data)
    write_rgba_png(png_path, width, height, rgba)
    write_json_private(png_path.with_suffix(png_path.suffix + ".json"), metadata)
    return metadata


def export_tex_file(path: Path, output_root: Path) -> dict:
    return export_tex_png_bytes(path.read_bytes(), output_root / f"{path.stem}.png")


@dataclass
class GMXChunk:
    offset: int
    tag: str
    size: int
    raw: bytes


@dataclass
class GMXArray:
    chunk: GMXChunk
    array_index: int
    flags: int
    semantic: str
    slot: int
    components: int
    gl_type: int
    count: int
    values: list[tuple[float | int, ...]]


@dataclass
class GMXMesh:
    chunk: GMXChunk
    mesh_index: int
    flags: int
    primitive_mode: int
    unknown_14: int
    index_count: int
    skin_index: int
    array_refs: list[int]


def parse_gmx_chunks(data: bytes) -> list[GMXChunk]:
    if len(data) < 0x30 or not data.startswith(GMX_MAGIC):
        raise FormatError("not a GMX file")
    root_size = be_u32(data, 0x04)
    total_size = be_u32(data, 0x0C)
    if root_size < 8 or root_size > len(data):
        raise FormatError(f"invalid GMX root size 0x{root_size:X}")
    if total_size == 0:
        total_size = len(data)
    if total_size > len(data):
        raise FormatError(f"GMX reports size 0x{total_size:X}, file is only 0x{len(data):X}")

    chunks: list[GMXChunk] = []
    pos = 0
    while pos < total_size:
        if pos + 8 > total_size:
            raise FormatError(f"truncated GMX chunk header at 0x{pos:X}")
        raw_tag = data[pos : pos + 4]
        tag = raw_tag.rstrip(b"\0").decode("ascii", errors="replace")
        size = be_u32(data, pos + 4)
        if size < 8 or pos + size > total_size:
            raise FormatError(f"invalid {tag!r} chunk size 0x{size:X} at 0x{pos:X}")
        chunks.append(GMXChunk(pos, tag, size, data[pos : pos + size]))
        pos += size
    if pos != total_size:
        raise FormatError(f"GMX chunks end at 0x{pos:X}, expected 0x{total_size:X}")
    return chunks


def parse_gmx_array(chunk: GMXChunk) -> GMXArray:
    raw = chunk.raw
    if chunk.tag != "ARRY" or len(raw) < 0x30:
        raise FormatError("invalid ARRY chunk")
    array_index = be_u16(raw, 0x08)
    flags = be_u16(raw, 0x0A)
    semantic = raw[0x10:0x20].split(b"\0", 1)[0].decode("ascii", errors="replace")
    slot = be_u32(raw, 0x20)
    components = be_u32(raw, 0x24)
    gl_type = be_u32(raw, 0x28)
    count = be_u32(raw, 0x2C)
    if components < 1 or components > 16:
        raise FormatError(f"ARRY {array_index}: implausible component count {components}")

    if gl_type == GL_FLOAT:
        scalar_size = 4
        fmt_char = "f"
    elif gl_type == GL_UNSIGNED_SHORT:
        scalar_size = 2
        fmt_char = "H"
    else:
        raise FormatError(f"ARRY {array_index}: unsupported GL type 0x{gl_type:X}")

    byte_count = count * components * scalar_size
    if 0x30 + byte_count > len(raw):
        raise FormatError(
            f"ARRY {array_index}: data exceeds chunk ({count}*{components}*{scalar_size})"
        )
    flat = struct.unpack_from(f">{count * components}{fmt_char}", raw, 0x30)
    values = [tuple(flat[i : i + components]) for i in range(0, len(flat), components)]
    return GMXArray(chunk, array_index, flags, semantic, slot, components, gl_type, count, values)


def parse_gmx_mesh(chunk: GMXChunk) -> GMXMesh:
    raw = chunk.raw
    if chunk.tag != "MESH" or len(raw) < 0x20:
        raise FormatError("invalid MESH chunk")
    mesh_index = be_u16(raw, 0x08)
    flags = be_u16(raw, 0x0A)
    primitive_mode = be_u32(raw, 0x10)
    unknown_14 = be_u32(raw, 0x14)
    index_count = be_u32(raw, 0x18)
    skin_index = be_u16(raw, 0x1C)
    ref_count = be_u16(raw, 0x1E)
    if 0x20 + ref_count * 2 > len(raw):
        raise FormatError(f"MESH {mesh_index}: reference list exceeds chunk")
    refs = list(struct.unpack_from(f">{ref_count}H", raw, 0x20)) if ref_count else []
    return GMXMesh(chunk, mesh_index, flags, primitive_mode, unknown_14, index_count, skin_index, refs)


def _array_by_semantic(arrays: Sequence[GMXArray], semantic: str) -> Optional[GMXArray]:
    for arr in arrays:
        if arr.semantic == semantic:
            return arr
    return None


def _index_array(arrays: Sequence[GMXArray]) -> Optional[GMXArray]:
    for arr in arrays:
        if arr.gl_type == GL_UNSIGNED_SHORT and arr.components == 1:
            return arr
    return None


def export_gmx_obj_bytes(data: bytes, obj_path: Path, flip_v: bool = False) -> dict:
    chunks = parse_gmx_chunks(data)
    arrays = {arr.array_index: arr for arr in (parse_gmx_array(c) for c in chunks if c.tag == "ARRY")}
    meshes = [parse_gmx_mesh(c) for c in chunks if c.tag == "MESH"]
    if not meshes:
        raise FormatError("GMX contains no MESH chunks")

    obj_path.parent.mkdir(parents=True, exist_ok=True)
    metadata: dict = {
        "source_size": len(data),
        "chunk_count": len(chunks),
        "chunk_tags": [c.tag for c in chunks],
        "mesh_count": len(meshes),
        "meshes": [],
    }

    v_base = 0
    vt_base = 0
    vn_base = 0
    lines: list[str] = [
        "# Space Invaders Infinity Gene GMX export",
        "# Geometry decoded from big-endian GMX ARRY/MESH chunks.",
    ]

    for ordinal, mesh in enumerate(meshes):
        referenced = [arrays[idx] for idx in mesh.array_refs if idx in arrays]
        pos = _array_by_semantic(referenced, "IN.position")
        normal = _array_by_semantic(referenced, "IN.normal")
        uv = _array_by_semantic(referenced, "IN.texuv")
        color = _array_by_semantic(referenced, "IN.color")
        indices = _index_array(referenced)
        if pos is None or indices is None:
            raise FormatError(
                f"MESH {mesh.mesh_index}: missing position or index array (refs={mesh.array_refs})"
            )
        if pos.components < 3:
            raise FormatError(f"MESH {mesh.mesh_index}: position array has {pos.components} components")
        if indices.count != mesh.index_count:
            raise FormatError(
                f"MESH {mesh.mesh_index}: index count mismatch {indices.count} != {mesh.index_count}"
            )

        name = f"mesh_{ordinal:03d}_{mesh.mesh_index}"
        lines.append(f"\no {name}")
        for value in pos.values:
            lines.append(f"v {value[0]:.9g} {value[1]:.9g} {value[2]:.9g}")
        if uv is not None:
            for value in uv.values:
                u = float(value[0])
                v = 1.0 - float(value[1]) if flip_v else float(value[1])
                lines.append(f"vt {u:.9g} {v:.9g}")
        if normal is not None:
            for value in normal.values:
                lines.append(f"vn {value[0]:.9g} {value[1]:.9g} {value[2]:.9g}")

        idx = [int(v[0]) for v in indices.values]
        vertex_count = pos.count
        if any(i >= vertex_count for i in idx):
            bad = max(idx)
            raise FormatError(
                f"MESH {mesh.mesh_index}: index {bad} exceeds vertex count {vertex_count}"
            )

        def vertex_ref(i: int) -> str:
            vi = v_base + i + 1
            has_uv = uv is not None and i < uv.count
            has_normal = normal is not None and i < normal.count
            if has_uv and has_normal:
                return f"{vi}/{vt_base + i + 1}/{vn_base + i + 1}"
            if has_uv:
                return f"{vi}/{vt_base + i + 1}"
            if has_normal:
                return f"{vi}//{vn_base + i + 1}"
            return str(vi)

        if mesh.primitive_mode == GL_TRIANGLES:
            if len(idx) % 3:
                raise FormatError(f"MESH {mesh.mesh_index}: triangle index count is not divisible by 3")
            for i in range(0, len(idx), 3):
                lines.append("f " + " ".join(vertex_ref(x) for x in idx[i : i + 3]))
            primitive = "triangles"
        elif mesh.primitive_mode == GL_LINES:
            if len(idx) % 2:
                raise FormatError(f"MESH {mesh.mesh_index}: line index count is not divisible by 2")
            for i in range(0, len(idx), 2):
                lines.append("l " + " ".join(str(v_base + x + 1) for x in idx[i : i + 2]))
            primitive = "lines"
        else:
            raise FormatError(
                f"MESH {mesh.mesh_index}: unsupported primitive mode 0x{mesh.primitive_mode:X}"
            )

        metadata["meshes"].append(
            {
                "mesh_index": mesh.mesh_index,
                "primitive_mode": f"0x{mesh.primitive_mode:X}",
                "primitive": primitive,
                "index_count": mesh.index_count,
                "vertex_count": pos.count,
                "array_refs": mesh.array_refs,
                "has_normals": normal is not None,
                "has_uv": uv is not None,
                "has_color": color is not None,
                "skin_index": mesh.skin_index,
            }
        )

        v_base += pos.count
        if uv is not None:
            vt_base += uv.count
        if normal is not None:
            vn_base += normal.count

    obj_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    meta_path = obj_path.with_suffix(obj_path.suffix + ".json")
    write_json_private(meta_path, metadata)
    return metadata


def export_gmx_file(path: Path, output_root: Path, flip_v: bool) -> dict:
    out = output_root / f"{path.stem}.obj"
    return export_gmx_obj_bytes(path.read_bytes(), out, flip_v=flip_v)


@dataclass
class GMXTextureRef:
    index: int
    flags: int
    name: str


@dataclass
class GMXShader:
    index: int
    flags: int
    name: str


@dataclass
class GMXMaterialParameter:
    name: str
    type_code: int
    count: int
    value: object


@dataclass
class GMXMaterial:
    index: int
    flags: int
    name: str
    shader_index: int
    parameters: list[GMXMaterialParameter]


@dataclass
class GMXParentGroup:
    parent: int
    children: list[int]


@dataclass
class GMXBone:
    index: int
    flags: int
    name: str
    matrix: tuple[float, ...]
    material_index: Optional[int]
    mesh_index: Optional[int]


@dataclass
class GMXMotion:
    index: int
    duration: float


@dataclass
class GMXAnimationTrack:
    index: int
    target_bone: int
    channel_type: int
    times: tuple[float, ...]
    matrices: list[tuple[float, ...]]


GMX_MATRIX_RUNTIME_HZ = 30.0


def gmx_matrix_runtime_times(track: GMXAnimationTrack) -> tuple[float, ...]:
    """Runtime key times for SIIG channel_type-12 matrix animation.

    Retail code indexes the matrix array directly with logical_frame % frame_count.
    The float table preceding the matrices is preserved as authoring metadata but is
    not consulted by this runtime sampling path.
    """
    return tuple(index / GMX_MATRIX_RUNTIME_HZ for index in range(len(track.matrices)))


def gmx_matrix_at_logical_frame(track: GMXAnimationTrack, logical_frame: int) -> tuple[float, ...]:
    if not track.matrices:
        raise FormatError("GMX matrix animation track has no samples")
    return track.matrices[int(logical_frame) % len(track.matrices)]


def _fixed_ascii(raw: bytes, offset: int, length: int) -> str:
    return raw[offset : offset + length].split(b"\0", 1)[0].decode("ascii", errors="replace")


def parse_gmx_texture_ref(chunk: GMXChunk) -> GMXTextureRef:
    if chunk.tag != "TXIF" or chunk.size != 0x30:
        raise FormatError("invalid TXIF chunk")
    return GMXTextureRef(be_u16(chunk.raw, 0x08), be_u16(chunk.raw, 0x0A), _fixed_ascii(chunk.raw, 0x10, 0x20))


def parse_gmx_shader(chunk: GMXChunk) -> GMXShader:
    if chunk.tag != "SHAD" or chunk.size != 0x30:
        raise FormatError("invalid SHAD chunk")
    return GMXShader(be_u16(chunk.raw, 0x08), be_u16(chunk.raw, 0x0A), _fixed_ascii(chunk.raw, 0x10, 0x20))


def parse_gmx_material(chunk: GMXChunk) -> GMXMaterial:
    if chunk.tag != "MTRL" or chunk.size < 0x38:
        raise FormatError("invalid MTRL chunk")
    index = be_u16(chunk.raw, 0x08)
    flags = be_u16(chunk.raw, 0x0A)
    name = _fixed_ascii(chunk.raw, 0x10, 0x20)
    shader_index = be_u32(chunk.raw, 0x30)
    parameter_count = be_u32(chunk.raw, 0x34)
    offset = 0x38
    parameters: list[GMXMaterialParameter] = []
    for _ in range(parameter_count):
        if offset + 0x38 > len(chunk.raw):
            raise FormatError(f"MTRL {index}: truncated parameter header")
        param_name = _fixed_ascii(chunk.raw, offset, 0x30)
        type_code = be_u32(chunk.raw, offset + 0x30)
        count = be_u32(chunk.raw, offset + 0x34)
        value_offset = offset + 0x38
        if type_code == 0:  # float vector/scalar
            byte_count = count * 4
            if value_offset + byte_count > len(chunk.raw):
                raise FormatError(f"MTRL {index}: float parameter exceeds chunk")
            value: object = tuple(struct.unpack_from(f">{count}f", chunk.raw, value_offset)) if count else tuple()
            offset = value_offset + byte_count
        elif type_code == 1:  # one or more 4x4 matrices
            byte_count = count * 0x40
            if value_offset + byte_count > len(chunk.raw):
                raise FormatError(f"MTRL {index}: matrix parameter exceeds chunk")
            value = [tuple(struct.unpack_from(">16f", chunk.raw, value_offset + i * 0x40)) for i in range(count)]
            offset = value_offset + byte_count
        elif type_code == 2:  # texture/sampler reference; the count field is the TXIF index
            value = count
            offset = value_offset
        else:
            raise FormatError(f"MTRL {index}: unsupported parameter type {type_code}")
        parameters.append(GMXMaterialParameter(param_name, type_code, count, value))
    if any(chunk.raw[offset:]):
        raise FormatError(f"MTRL {index}: unexpected non-zero trailing bytes")
    return GMXMaterial(index, flags, name, shader_index, parameters)


def parse_gmx_parent_group(chunk: GMXChunk) -> GMXParentGroup:
    if chunk.tag != "PARE" or chunk.size < 0x18:
        raise FormatError("invalid PARE chunk")
    child_count = be_u32(chunk.raw, 0x10)
    parent = struct.unpack_from(">i", chunk.raw, 0x14)[0]
    end = 0x18 + child_count * 4
    if end > len(chunk.raw):
        raise FormatError("PARE child list exceeds chunk")
    children = list(struct.unpack_from(f">{child_count}I", chunk.raw, 0x18)) if child_count else []
    return GMXParentGroup(parent, children)


def parse_gmx_bone(chunk: GMXChunk) -> GMXBone:
    if chunk.tag != "BONE" or chunk.size != 0x80:
        raise FormatError("invalid BONE chunk")
    index = be_u16(chunk.raw, 0x08)
    flags = be_u16(chunk.raw, 0x0A)
    name = _fixed_ascii(chunk.raw, 0x10, 0x20)
    matrix = tuple(struct.unpack_from(">16f", chunk.raw, 0x30))
    attachment_count = be_u32(chunk.raw, 0x70)
    if attachment_count > 3:
        raise FormatError(f"BONE {index}: too many attachment references ({attachment_count})")
    material_index: Optional[int] = None
    mesh_index: Optional[int] = None
    for i in range(attachment_count):
        encoded = be_u32(chunk.raw, 0x74 + i * 4)
        ref_type = encoded >> 16
        ref_index = encoded & 0xFFFF
        if ref_type == 2:
            material_index = ref_index
        elif ref_type == 3:
            mesh_index = ref_index
    return GMXBone(index, flags, name, matrix, material_index, mesh_index)


def parse_gmx_motion(chunk: GMXChunk) -> GMXMotion:
    if chunk.tag != "MOTN" or chunk.size != 0x20:
        raise FormatError("invalid MOTN chunk")
    encoded_index = be_u32(chunk.raw, 0x08)
    if encoded_index & 0xFFFF:
        raise FormatError("MOTN index has unexpected low bits")
    duration = struct.unpack_from(">f", chunk.raw, 0x14)[0]
    return GMXMotion(encoded_index >> 16, duration)


def parse_gmx_animation(chunk: GMXChunk) -> GMXAnimationTrack:
    if chunk.tag != "ANIM" or chunk.size < 0x20:
        raise FormatError("invalid ANIM chunk")
    encoded_index = be_u32(chunk.raw, 0x08)
    if encoded_index & 0xFFFF:
        raise FormatError("ANIM index has unexpected low bits")
    target_bone = be_u32(chunk.raw, 0x10)
    channel_type = be_u32(chunk.raw, 0x14)
    frame_count = be_u32(chunk.raw, 0x18)
    value_count = be_u32(chunk.raw, 0x1C)
    if channel_type != 12 or value_count != 16:
        raise FormatError(
            f"ANIM {encoded_index >> 16}: unsupported channel/value layout {channel_type}/{value_count}"
        )
    times_offset = 0x20
    values_offset = times_offset + frame_count * 4
    required = values_offset + frame_count * value_count * 4
    if required > len(chunk.raw):
        raise FormatError(f"ANIM {encoded_index >> 16}: data exceeds chunk")
    times = tuple(struct.unpack_from(f">{frame_count}f", chunk.raw, times_offset))
    flat = struct.unpack_from(f">{frame_count * value_count}f", chunk.raw, values_offset)
    matrices = [tuple(flat[i : i + value_count]) for i in range(0, len(flat), value_count)]
    if any(chunk.raw[required:]):
        raise FormatError(f"ANIM {encoded_index >> 16}: unexpected non-zero trailing bytes")
    return GMXAnimationTrack(encoded_index >> 16, target_bone, channel_type, times, matrices)


def _transpose_4x4(values: Sequence[float]) -> tuple[float, ...]:
    if len(values) != 16:
        raise ValueError("matrix must contain 16 values")
    return tuple(float(values[c * 4 + r]) for r in range(4) for c in range(4))


def _det3(m: Sequence[Sequence[float]]) -> float:
    return (
        m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
        - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
    )


def _quat_from_matrix3(m: Sequence[Sequence[float]]) -> tuple[float, float, float, float]:
    trace = m[0][0] + m[1][1] + m[2][2]
    if trace > 0.0:
        s = math.sqrt(trace + 1.0) * 2.0
        w = 0.25 * s
        x = (m[2][1] - m[1][2]) / s
        y = (m[0][2] - m[2][0]) / s
        z = (m[1][0] - m[0][1]) / s
    elif m[0][0] > m[1][1] and m[0][0] > m[2][2]:
        s = math.sqrt(max(0.0, 1.0 + m[0][0] - m[1][1] - m[2][2])) * 2.0
        w = (m[2][1] - m[1][2]) / s
        x = 0.25 * s
        y = (m[0][1] + m[1][0]) / s
        z = (m[0][2] + m[2][0]) / s
    elif m[1][1] > m[2][2]:
        s = math.sqrt(max(0.0, 1.0 + m[1][1] - m[0][0] - m[2][2])) * 2.0
        w = (m[0][2] - m[2][0]) / s
        x = (m[0][1] + m[1][0]) / s
        y = 0.25 * s
        z = (m[1][2] + m[2][1]) / s
    else:
        s = math.sqrt(max(0.0, 1.0 + m[2][2] - m[0][0] - m[1][1])) * 2.0
        w = (m[1][0] - m[0][1]) / s
        x = (m[0][2] + m[2][0]) / s
        y = (m[1][2] + m[2][1]) / s
        z = 0.25 * s
    length = math.sqrt(x * x + y * y + z * z + w * w)
    if length <= 1e-12:
        return (0.0, 0.0, 0.0, 1.0)
    return (x / length, y / length, z / length, w / length)


def decompose_standard_matrix(matrix: Sequence[float]) -> tuple[tuple[float, float, float], tuple[float, float, float, float], tuple[float, float, float], float]:
    """Decompose a conventional row-major, column-vector affine matrix.

    Returns translation, quaternion (x,y,z,w), scale, and a simple orthogonality error.
    """
    if len(matrix) != 16:
        raise ValueError("matrix must contain 16 values")
    translation = (float(matrix[3]), float(matrix[7]), float(matrix[11]))
    columns = [
        [float(matrix[0]), float(matrix[4]), float(matrix[8])],
        [float(matrix[1]), float(matrix[5]), float(matrix[9])],
        [float(matrix[2]), float(matrix[6]), float(matrix[10])],
    ]
    scales = [math.sqrt(sum(value * value for value in column)) for column in columns]
    for i, scale in enumerate(scales):
        if scale <= 1e-12:
            columns[i] = [1.0 if row == i else 0.0 for row in range(3)]
            scales[i] = 0.0
        else:
            columns[i] = [value / scale for value in columns[i]]
    rotation = [[columns[col][row] for col in range(3)] for row in range(3)]
    if _det3(rotation) < 0.0:
        scales[0] = -scales[0]
        for row in range(3):
            rotation[row][0] = -rotation[row][0]
    error = max(
        abs(sum(rotation[row][a] * rotation[row][b] for row in range(3)))
        for a in range(3)
        for b in range(a + 1, 3)
    )
    quaternion = _quat_from_matrix3(rotation)
    return translation, quaternion, (scales[0], scales[1], scales[2]), error


def _gmx_track_safe_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._")
    return value or "unnamed"


def export_gmx_tracks_bytes(data: bytes, output_dir: Path, *, source_name: str = "") -> dict:
    """Export GMX matrix-animation tracks as decomposed CSV and OBJ trajectories.

    For channel_type 12, retail SIIG indexes matrices directly by the integer 30 Hz
    logical animation frame. The raw float table is retained as authoring metadata.
    """
    chunks = parse_gmx_chunks(data)
    bones = {item.index: item for item in (parse_gmx_bone(c) for c in chunks if c.tag == "BONE")}
    motions = {item.index: item for item in (parse_gmx_motion(c) for c in chunks if c.tag == "MOTN")}
    animations = [parse_gmx_animation(c) for c in chunks if c.tag == "ANIM"]
    if not animations:
        raise FormatError("GMX contains no supported matrix animation tracks")
    output_dir.mkdir(parents=True, exist_ok=True)
    source_stem = _gmx_track_safe_name(Path(source_name).stem if source_name else "gmx")
    manifest_tracks: list[dict] = []
    for track in animations:
        bone = bones.get(track.target_bone)
        bone_name = bone.name if bone and bone.name else f"bone_{track.target_bone}"
        safe_bone = _gmx_track_safe_name(bone_name)
        base = output_dir / f"{source_stem}.track_{track.index:03d}.{safe_bone}"
        csv_path = base.with_suffix(base.suffix + ".csv")
        obj_path = base.with_suffix(base.suffix + ".obj")
        rows: list[dict] = []
        previous_rotation: Optional[tuple[float, float, float, float]] = None
        raw_deltas: list[float] = []
        max_error = 0.0
        translations: list[tuple[float, float, float]] = []
        runtime_times = gmx_matrix_runtime_times(track)
        for frame_index, (raw_time, runtime_time, matrix) in enumerate(zip(track.times, runtime_times, track.matrices)):
            translation, rotation, scale, error = decompose_standard_matrix(matrix)
            if previous_rotation is not None and sum(a * b for a, b in zip(previous_rotation, rotation)) < 0.0:
                rotation = tuple(-value for value in rotation)
            previous_rotation = rotation
            if frame_index:
                raw_deltas.append(float(raw_time) - float(track.times[frame_index - 1]))
            max_error = max(max_error, float(error))
            translations.append(translation)
            rows.append({
                "sample_index": frame_index,
                "runtime_logical_frame": frame_index,
                "runtime_seconds_30hz": float(runtime_time),
                "raw_authoring_time": float(raw_time),
                "translation_x": translation[0], "translation_y": translation[1], "translation_z": translation[2],
                "rotation_x": rotation[0], "rotation_y": rotation[1], "rotation_z": rotation[2], "rotation_w": rotation[3],
                "scale_x": scale[0], "scale_y": scale[1], "scale_z": scale[2],
                "decomposition_error": float(error),
            })
        fields = list(rows[0].keys()) if rows else ["sample_index", "runtime_logical_frame", "runtime_seconds_30hz", "raw_authoring_time"]
        with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader(); writer.writerows(rows)
        with obj_path.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(f"# SIIG GMX translation trajectory: {Path(source_name).name if source_name else source_stem}\n")
            handle.write(f"# track {track.index}, target {bone_name}; runtime matrix clock 30 Hz\n")
            for x, y, z in translations:
                handle.write(f"v {x:.9g} {y:.9g} {z:.9g}\n")
            if len(translations) >= 2:
                handle.write("l " + " ".join(str(i + 1) for i in range(len(translations))) + "\n")
        median_raw_delta = 0.0
        if raw_deltas:
            ordered = sorted(raw_deltas)
            mid = len(ordered) // 2
            median_raw_delta = ordered[mid] if len(ordered) % 2 else (ordered[mid - 1] + ordered[mid]) * 0.5
        raw_observed_hz = (1.0 / median_raw_delta) if median_raw_delta > 0 else 0.0
        raw_motion_duration = motions.get(track.index).duration if track.index in motions else (float(track.times[-1]) if track.times else 0.0)
        manifest_tracks.append({
            "track_index": track.index,
            "target_bone_index": track.target_bone,
            "target_bone_name": bone_name,
            "sample_count": len(track.matrices),
            "runtime_clock_hz": GMX_MATRIX_RUNTIME_HZ,
            "runtime_start_seconds": 0.0,
            "runtime_last_sample_seconds": float(runtime_times[-1]) if runtime_times else 0.0,
            "runtime_sample_span_seconds": (len(track.matrices) / GMX_MATRIX_RUNTIME_HZ) if track.matrices else 0.0,
            "raw_authoring_start": float(track.times[0]) if track.times else 0.0,
            "raw_authoring_end": float(track.times[-1]) if track.times else 0.0,
            "raw_motion_duration": float(raw_motion_duration),
            "raw_median_sample_interval": median_raw_delta,
            "raw_observed_sample_rate_hz": raw_observed_hz,
            "max_decomposition_error": max_error,
            "csv": csv_path.name,
            "translation_obj": obj_path.name,
        })
    manifest = {
        "format": "SIIG_GMX_TRACKS",
        "source_name": Path(source_name).name if source_name else "",
        "track_count": len(manifest_tracks),
        "runtime_time_unit": "seconds_at_30hz_logical_frame_clock",
        "raw_time_field": "authoring_metadata_not_used_by_retail_matrix_sampler",
        "tracks": manifest_tracks,
        "note": "Retail channel_type-12 sampling uses matrices[logical_frame % frame_count]; raw float times are preserved separately.",
    }
    write_json_private(output_dir / f"{source_stem}.gmxtrack.json", manifest, ensure_ascii=False)
    return manifest


def command_gmxtrack(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    candidates = [input_path] if input_path.is_file() else list(iter_candidate_files(input_path))
    success = 0
    failures = 0
    for path in candidates:
        try:
            if path.read_bytes()[:4] != GMX_MAGIC:
                continue
            manifest = export_gmx_tracks_bytes(path.read_bytes(), output, source_name=path.name)
            print(f"{path}: {manifest['track_count']} track(s)")
            success += 1
        except (FormatError, OSError, struct.error) as exc:
            print(f"warning: GMX track export failed for {path}: {exc}", file=sys.stderr)
            failures += 1
    if success == 0 and failures == 0:
        raise FormatError("no GMX animation files found")
    print(f"completed: {success} GMX file(s), {failures} failure(s)")
    return 0 if failures == 0 else 1


def _gmx_matrix_tracks_by_bone_name(data: bytes) -> dict[str, GMXAnimationTrack]:
    chunks = parse_gmx_chunks(data)
    bones = {item.index: item for item in (parse_gmx_bone(c) for c in chunks if c.tag == "BONE")}
    tracks: dict[str, GMXAnimationTrack] = {}
    for chunk in chunks:
        if chunk.tag != "ANIM":
            continue
        track = parse_gmx_animation(chunk)
        bone = bones.get(track.target_bone)
        if bone is None or not bone.name:
            continue
        tracks[bone.name] = track
    return tracks


def _matrix_translation(matrix: Sequence[float]) -> tuple[float, float, float]:
    if len(matrix) != 16:
        raise FormatError("matrix animation sample does not contain 16 floats")
    return (float(matrix[3]), float(matrix[7]), float(matrix[11]))


def export_camera_animation_bytes(
    data: bytes,
    output_csv: Path,
    *,
    source_name: str = "",
    field_pos: tuple[float, float, float] = (0.0, 0.0, 0.0),
    frame_multiplier: int = 2,
    emit_every: int = 1,
) -> dict:
    """Evaluate the retail animated-camera controller for an explicit camera GMX.

    Retail registers one non-loop `cam` descriptor with frames [0, 200). The
    controller advances its logical-frame accumulator by 1/frame_multiplier and
    samples the `cam1` (eye) and `int1` (target) matrix tracks by integer frame.
    """
    if frame_multiplier not in (1, 2):
        raise ValueError("frame_multiplier must be 1 or 2")
    if emit_every < 1:
        raise ValueError("emit_every must be >= 1")
    tracks = _gmx_matrix_tracks_by_bone_name(data)
    try:
        eye_track = tracks["cam1"]
        target_track = tracks["int1"]
    except KeyError as exc:
        raise FormatError("camera GMX must contain cam1 and int1 matrix tracks") from exc
    descriptor_end = 200
    if len(eye_track.matrices) < descriptor_end or len(target_track.matrices) < descriptor_end:
        raise FormatError("camera GMX contains fewer than 200 runtime matrix samples")
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []
    accumulator = 0.0
    update_index = 0
    sampled_frames: set[int] = set()
    while accumulator < descriptor_end:
        logical_frame = int(accumulator)
        sampled_frames.add(logical_frame)
        eye_local = _matrix_translation(gmx_matrix_at_logical_frame(eye_track, logical_frame))
        target_local = _matrix_translation(gmx_matrix_at_logical_frame(target_track, logical_frame))
        if update_index % emit_every == 0:
            rows.append({
                "runtime_update": update_index,
                "logical_frame": logical_frame,
                "runtime_seconds": update_index / (30.0 * frame_multiplier),
                "eye_x": eye_local[0] + field_pos[0],
                "eye_y": eye_local[1] + field_pos[1],
                "eye_z": eye_local[2] + field_pos[2],
                "target_x": target_local[0] + field_pos[0],
                "target_y": target_local[1] + field_pos[1],
                "target_z": target_local[2] + field_pos[2],
            })
        update_index += 1
        accumulator += 1.0 / frame_multiplier
    fields = [
        "runtime_update", "logical_frame", "runtime_seconds",
        "eye_x", "eye_y", "eye_z", "target_x", "target_y", "target_z",
    ]
    with output_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)
    report = {
        "format": "SIIG_CAMERA_ANIMATION_RUNTIME",
        "source_name": Path(source_name).name if source_name else "",
        "descriptor": {"name": "cam", "start_frame": 0, "end_frame": 200, "loop": False},
        "frame_multiplier": frame_multiplier,
        "runtime_update_hz": 30 * frame_multiplier,
        "logical_frame_hz": 30,
        "runtime_updates_simulated": update_index,
        "sampled_logical_frame_min": min(sampled_frames) if sampled_frames else None,
        "sampled_logical_frame_max": max(sampled_frames) if sampled_frames else None,
        "distinct_logical_frames": len(sampled_frames),
        "rows_emitted": len(rows),
        "emit_every": emit_every,
        "field_pos": list(field_pos),
        "note": "The retail animated-camera path exits at logical frame 200; cam02 samples 200..299 are not reached by this controller.",
    }
    write_json_private(output_csv.with_suffix(".json"), report, ensure_ascii=False)
    return report


FIELD_ANIMATION_DESCRIPTORS = {
    "fld015": {"start_frame": 0, "end_frame": 6300, "loop": False},
    "fld014": {"start_frame": 0, "end_frame": 1440, "loop": True},
}


def export_field_animation_bytes(
    data: bytes,
    output_csv: Path,
    *,
    source_name: str = "",
    emit_every: int = 1,
) -> dict:
    """Export the executable-backed field-model descriptor frame domain.

    The route controller accepts externally supplied integer frames and samples the
    named field node's matrix. fld014's descriptor endpoint 1440 wraps to matrix 0;
    fld015 frame 6300 addresses its final (6301st) matrix sample.
    """
    if emit_every < 1:
        raise ValueError("emit_every must be >= 1")
    tracks = _gmx_matrix_tracks_by_bone_name(data)
    target_names = [name for name in FIELD_ANIMATION_DESCRIPTORS if name in tracks]
    if len(target_names) != 1:
        raise FormatError("field GMX must contain exactly one fld014 or fld015 matrix track")
    target = target_names[0]
    track = tracks[target]
    descriptor = FIELD_ANIMATION_DESCRIPTORS[target]
    start_frame = int(descriptor["start_frame"]); end_frame = int(descriptor["end_frame"])
    expected_min_samples = 6301 if target == "fld015" else 1440
    if len(track.matrices) < expected_min_samples:
        raise FormatError(f"{target} has too few runtime matrix samples")
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []
    for frame in range(start_frame, end_frame + 1):
        if (frame - start_frame) % emit_every:
            continue
        sample_index = frame % len(track.matrices)
        matrix = gmx_matrix_at_logical_frame(track, frame)
        translation, rotation, scale, error = decompose_standard_matrix(matrix)
        rows.append({
            "logical_frame": frame,
            "runtime_seconds_30hz": frame / 30.0,
            "sample_index": sample_index,
            "translation_x": translation[0], "translation_y": translation[1], "translation_z": translation[2],
            "rotation_x": rotation[0], "rotation_y": rotation[1], "rotation_z": rotation[2], "rotation_w": rotation[3],
            "scale_x": scale[0], "scale_y": scale[1], "scale_z": scale[2],
            "decomposition_error": error,
        })
    fields = list(rows[0].keys()) if rows else ["logical_frame", "runtime_seconds_30hz", "sample_index"]
    with output_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)
    report = {
        "format": "SIIG_FIELD_ANIMATION_RUNTIME",
        "source_name": Path(source_name).name if source_name else "",
        "target": target,
        "descriptor": {"name": target, **descriptor},
        "matrix_sample_count": len(track.matrices),
        "logical_frame_hz": 30,
        "rows_emitted": len(rows),
        "emit_every": emit_every,
        "endpoint_sample_index": end_frame % len(track.matrices),
        "note": "This is an explicit descriptor-frame evaluation; stage activation and external frame-driver timing are not inferred.",
    }
    write_json_private(output_csv.with_suffix(".json"), report, ensure_ascii=False)
    return report


def _vec3_sub(a: Sequence[float], b: Sequence[float]) -> tuple[float, float, float]:
    return (float(a[0]) - float(b[0]), float(a[1]) - float(b[1]), float(a[2]) - float(b[2]))


def _vec3_len(v: Sequence[float]) -> float:
    return math.sqrt(float(v[0]) ** 2 + float(v[1]) ** 2 + float(v[2]) ** 2)


def _vec3_normalize(v: Sequence[float]) -> tuple[float, float, float]:
    length = _vec3_len(v)
    if length <= 1e-12:
        return (0.0, 0.0, 0.0)
    return (float(v[0]) / length, float(v[1]) / length, float(v[2]) / length)


def _vec3_dot(a: Sequence[float], b: Sequence[float]) -> float:
    return float(a[0]) * float(b[0]) + float(a[1]) * float(b[1]) + float(a[2]) * float(b[2])


def export_field_camera_reconstruction_bytes(
    data: bytes,
    output_csv: Path,
    *,
    source_name: str = "",
    preset: int,
    start_frame: int | None = None,
    end_frame: int | None = None,
    runtime_x: float | None = None,
    runtime_y: float | None = None,
    emit_every: int = 1,
) -> dict:
    """Reconstruct procedural camera world state directly from a field GMX.

    The command consumes the serialized GMX matrix stream, converts each sample
    to the runtime row-vector representation, extracts FieldPos/orientation, and
    evaluates the executable-backed retail camera preset.  This models the
    post-animated-camera procedural path; it does not infer when a preset became
    active and it does not invent player coordinates when they are unavailable.
    """
    if emit_every < 1:
        raise ValueError("emit_every must be >= 1")
    if (runtime_x is None) != (runtime_y is None):
        raise ValueError("runtime_x and runtime_y must be supplied together")

    tracks = _gmx_matrix_tracks_by_bone_name(data)
    target_names = [name for name in FIELD_ANIMATION_DESCRIPTORS if name in tracks]
    if len(target_names) != 1:
        raise FormatError("field GMX must contain exactly one fld014 or fld015 matrix track")
    target = target_names[0]
    track = tracks[target]
    descriptor = FIELD_ANIMATION_DESCRIPTORS[target]
    desc_start = int(descriptor["start_frame"])
    desc_end = int(descriptor["end_frame"])
    start = desc_start if start_frame is None else int(start_frame)
    end = desc_end if end_frame is None else int(end_frame)
    if start < desc_start or end > desc_end or start > end:
        raise ValueError(f"frame range must stay inside {target} descriptor {desc_start}..{desc_end}")
    if target == "fld015" and len(track.matrices) < 6301:
        raise FormatError("fld015 has too few runtime matrix samples")
    if target == "fld014" and len(track.matrices) < 1440:
        raise FormatError("fld014 has too few runtime matrix samples")

    preset_info = camera_preset_info(preset)

    def state_for(frame: int) -> dict:
        matrix = gmx_matrix_at_logical_frame(track, frame)
        field = field_state_from_gmx_matrix(matrix)
        camera = camera_world_state(
            preset_info,
            field["field_position"],
            field["orientation_matrix_row_vector"],
            runtime_x=runtime_x,
            runtime_y=runtime_y,
        )
        return {"field": field, "camera": camera}

    cache: dict[int, dict] = {}
    for frame in range(max(desc_start, start - 1), min(desc_end, end + 1) + 1):
        cache[frame] = state_for(frame)

    rows: list[dict] = []
    behind_values: list[float] = []
    classifications: dict[str, int] = {}
    for frame in range(start, end + 1):
        if (frame - start) % emit_every:
            continue
        current = cache[frame]
        field = current["field"]["field_position"]
        camera = current["camera"]
        eye = camera["eye"]
        camera_target = camera["target"]

        if frame > desc_start and frame < desc_end:
            tangent_delta = _vec3_sub(
                cache[frame + 1]["field"]["field_position"],
                cache[frame - 1]["field"]["field_position"],
            )
        elif frame < desc_end:
            tangent_delta = _vec3_sub(cache[frame + 1]["field"]["field_position"], field)
        elif frame > desc_start:
            tangent_delta = _vec3_sub(field, cache[frame - 1]["field"]["field_position"])
        else:
            tangent_delta = (0.0, 0.0, 0.0)
        tangent = _vec3_normalize(tangent_delta)
        eye_from_target = _vec3_sub(eye, camera_target)
        along_route = _vec3_dot(eye_from_target, tangent)
        behind = max(0.0, -along_route)
        tangent_speed = _vec3_len(tangent_delta)
        if tangent_speed <= 1e-10:
            classification = "route_static_or_hold"
        elif along_route < -1e-4:
            classification = "rear_follow"
            behind_values.append(behind)
        elif along_route > 1e-4:
            classification = "forward_lead"
        else:
            classification = "side_follow"
        classifications[classification] = classifications.get(classification, 0) + 1

        orientation = current["field"]["orientation_matrix_row_vector"]
        rows.append({
            "logical_frame": frame,
            "runtime_seconds_30hz": frame / 30.0,
            "field_x": field[0], "field_y": field[1], "field_z": field[2],
            "eye_x": eye[0], "eye_y": eye[1], "eye_z": eye[2],
            "target_x": camera_target[0], "target_y": camera_target[1], "target_z": camera_target[2],
            "eye_minus_target_x": eye_from_target[0],
            "eye_minus_target_y": eye_from_target[1],
            "eye_minus_target_z": eye_from_target[2],
            "route_tangent_x": tangent[0], "route_tangent_y": tangent[1], "route_tangent_z": tangent[2],
            "eye_along_route": along_route,
            "behind_route_distance": behind,
            "world_z_eye_above_target": float(eye[2]) - float(camera_target[2]),
            "route_motion_span": tangent_speed,
            "follow_classification": classification,
            "orientation_r00": orientation[0][0], "orientation_r01": orientation[0][1], "orientation_r02": orientation[0][2],
            "orientation_r10": orientation[1][0], "orientation_r11": orientation[1][1], "orientation_r12": orientation[1][2],
            "orientation_r20": orientation[2][0], "orientation_r21": orientation[2][1], "orientation_r22": orientation[2][2],
        })

    output_csv.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys()) if rows else ["logical_frame"]
    with output_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    report = {
        "format": "SIIG_FIELD_CAMERA_RECONSTRUCTION",
        "source_name": Path(source_name).name if source_name else "",
        "field_track": target,
        "descriptor": {"name": target, **descriptor},
        "preset": preset_info,
        "frame_range": {"start": start, "end": end, "emit_every": emit_every},
        "runtime_coordinates": {
            "x": runtime_x,
            "y": runtime_y,
            "dynamic_response_applied": runtime_x is not None,
        },
        "rows_emitted": len(rows),
        "classification_counts": classifications,
        "rear_follow_behind_distance": {
            "min": min(behind_values) if behind_values else None,
            "max": max(behind_values) if behind_values else None,
            "mean": (sum(behind_values) / len(behind_values)) if behind_values else None,
        },
        "matrix_conversion": {
            "serialized": "GMX row-major / column-vector affine, translation at flat indices 3/7/11",
            "runtime": "row-vector affine, translation in final row",
            "operation": "transpose_4x4",
            "evidence": [
                "real cam01_op1/fld015 GMX ANIM matrix layout",
                "retail PS3 0x0036A154 runtime translation matrix",
                "retail PS3 0x00369BE4 matrix multiply",
                "retail PS3 0x00157A10 procedural/animated camera consumption",
            ],
        },
        "evidence": {
            "field_node_getter": "retail PS3 0x00159D58 copies the SgModel node matrix into the route controller",
            "procedural_camera": "retail PS3 0x00157A10 / 0x00157540",
            "camera_preset": "retail PS3 0x0015B524 and CAMERA_PRESETS_RUNTIME_SEMANTIC.csv",
        },
        "limitations": [
            "This reconstructs the procedural camera only; cam01/cam02 animated mode must be evaluated separately.",
            "Preset activation timing is caller/stage supplied; this command does not infer it from a DAT.",
            "Without runtime X/Y input, dynamic horizontal response is intentionally omitted rather than guessed.",
            "Player screen/world position is not derivable from the field GMX alone.",
        ],
    }
    write_json_private(output_csv.with_suffix(".json"), report, ensure_ascii=False)
    return report


def command_field_camera(args: argparse.Namespace) -> int:
    path = Path(args.input)
    output = Path(args.output)
    if output.suffix.lower() != ".csv":
        output = output / f"{path.stem}.field_camera.csv"
    report = export_field_camera_reconstruction_bytes(
        path.read_bytes(),
        output,
        source_name=path.name,
        preset=args.preset,
        start_frame=args.start_frame,
        end_frame=args.end_frame,
        runtime_x=args.runtime_x,
        runtime_y=args.runtime_y,
        emit_every=args.emit_every,
    )
    counts = report["classification_counts"]
    print(
        f"{path}: {report['rows_emitted']} frame row(s), preset {args.preset}, "
        f"rear-follow={counts.get('rear_follow', 0)}"
    )
    print(f"CSV: {output}")
    print(f"JSON: {output.with_suffix('.json')}")
    return 0


def command_camera_animation(args: argparse.Namespace) -> int:
    path = Path(args.input)
    output = Path(args.output)
    if output.suffix.lower() != ".csv":
        output = output / f"{path.stem}.camera_animation.csv"
    report = export_camera_animation_bytes(
        path.read_bytes(), output, source_name=path.name,
        field_pos=(args.field_x, args.field_y, args.field_z),
        frame_multiplier=args.frame_multiplier, emit_every=args.emit_every,
    )
    print(f"{path}: {report['runtime_updates_simulated']} updates, {report['rows_emitted']} row(s)")
    return 0


def command_field_animation(args: argparse.Namespace) -> int:
    path = Path(args.input)
    output = Path(args.output)
    if output.suffix.lower() != ".csv":
        output = output / f"{path.stem}.field_animation.csv"
    report = export_field_animation_bytes(path.read_bytes(), output, source_name=path.name, emit_every=args.emit_every)
    print(f"{path}: {report['target']} descriptor, {report['rows_emitted']} row(s)")
    return 0


def _dds_mask_channel(value: int, mask: int) -> int:
    if mask == 0:
        return 255
    shift = (mask & -mask).bit_length() - 1
    bits = (mask >> shift).bit_length()
    raw = (value & mask) >> shift
    maximum = (1 << bits) - 1
    return int(round(raw * 255 / maximum)) if maximum else 0


def decode_uncompressed_dds_rgba(data: bytes) -> tuple[int, int, bytes]:
    if len(data) < 128 or data[:4] != b"DDS ":
        raise FormatError("not a DDS file")
    if struct.unpack_from("<I", data, 4)[0] != 124:
        raise FormatError("unsupported DDS header size")
    height = struct.unpack_from("<I", data, 12)[0]
    width = struct.unpack_from("<I", data, 16)[0]
    pf_flags = struct.unpack_from("<I", data, 80)[0]
    fourcc = data[84:88]
    rgb_bits = struct.unpack_from("<I", data, 88)[0]
    masks = struct.unpack_from("<4I", data, 92)
    if fourcc != b"\0\0\0\0" or not (pf_flags & 0x40) or rgb_bits != 32:
        raise FormatError("only uncompressed 32-bit RGB(A) DDS is supported")
    byte_count = width * height * 4
    if 128 + byte_count > len(data):
        raise FormatError("DDS pixel payload is truncated")
    output = bytearray(byte_count)
    rmask, gmask, bmask, amask = masks
    for i in range(width * height):
        value = struct.unpack_from("<I", data, 128 + i * 4)[0]
        output[i * 4 + 0] = _dds_mask_channel(value, rmask)
        output[i * 4 + 1] = _dds_mask_channel(value, gmask)
        output[i * 4 + 2] = _dds_mask_channel(value, bmask)
        output[i * 4 + 3] = _dds_mask_channel(value, amask) if amask else 255
    return width, height, bytes(output)


class GltfBufferBuilder:
    def __init__(self) -> None:
        self.data = bytearray()
        self.buffer_views: list[dict] = []
        self.accessors: list[dict] = []

    def add_view(self, payload: bytes, target: Optional[int] = None) -> int:
        while len(self.data) % 4:
            self.data.append(0)
        offset = len(self.data)
        self.data.extend(payload)
        view: dict = {"buffer": 0, "byteOffset": offset, "byteLength": len(payload)}
        if target is not None:
            view["target"] = target
        self.buffer_views.append(view)
        return len(self.buffer_views) - 1

    def add_accessor(
        self,
        payload: bytes,
        component_type: int,
        value_type: str,
        count: int,
        *,
        target: Optional[int] = None,
        minimum: Optional[Sequence[float]] = None,
        maximum: Optional[Sequence[float]] = None,
    ) -> int:
        view_index = self.add_view(payload, target)
        accessor: dict = {
            "bufferView": view_index,
            "componentType": component_type,
            "count": count,
            "type": value_type,
        }
        if minimum is not None:
            accessor["min"] = [float(x) for x in minimum]
        if maximum is not None:
            accessor["max"] = [float(x) for x in maximum]
        self.accessors.append(accessor)
        return len(self.accessors) - 1


def _pack_float_tuples(values: Sequence[Sequence[float]]) -> bytes:
    flat = [float(component) for value in values for component in value]
    return struct.pack(f"<{len(flat)}f", *flat)


def _minmax_tuples(values: Sequence[Sequence[float]], components: int) -> tuple[list[float], list[float]]:
    return (
        [min(float(value[i]) for value in values) for i in range(components)],
        [max(float(value[i]) for value in values) for i in range(components)],
    )


def _find_texture_file(name: str, source_path: Optional[Path], texture_roots: Sequence[Path]) -> Optional[Path]:
    candidates: list[Path] = []
    if source_path is not None:
        candidates.append(source_path.parent / name)
    for root in texture_roots:
        candidates.append(root / name)
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    basename = Path(name).name.lower()
    search_roots: list[Path] = []
    if source_path is not None:
        search_roots.append(source_path.parent)
    search_roots.extend(texture_roots)
    seen: set[Path] = set()
    for root in search_roots:
        if root in seen or not root.is_dir():
            continue
        seen.add(root)
        for path in root.rglob("*"):
            if path.is_file() and path.name.lower() == basename:
                return path
    return None


def export_gmx_gltf_bytes(
    data: bytes,
    gltf_path: Path,
    *,
    source_path: Optional[Path] = None,
    texture_roots: Sequence[Path] = (),
    flip_v: bool = False,
) -> dict:
    chunks = parse_gmx_chunks(data)
    arrays = {arr.array_index: arr for arr in (parse_gmx_array(c) for c in chunks if c.tag == "ARRY")}
    meshes = {mesh.mesh_index: mesh for mesh in (parse_gmx_mesh(c) for c in chunks if c.tag == "MESH")}
    texture_refs = {item.index: item for item in (parse_gmx_texture_ref(c) for c in chunks if c.tag == "TXIF")}
    shaders = {item.index: item for item in (parse_gmx_shader(c) for c in chunks if c.tag == "SHAD")}
    materials = {item.index: item for item in (parse_gmx_material(c) for c in chunks if c.tag == "MTRL")}
    parent_groups = [parse_gmx_parent_group(c) for c in chunks if c.tag == "PARE"]
    bones = {item.index: item for item in (parse_gmx_bone(c) for c in chunks if c.tag == "BONE")}
    motions = {item.index: item for item in (parse_gmx_motion(c) for c in chunks if c.tag == "MOTN")}
    animations = [parse_gmx_animation(c) for c in chunks if c.tag == "ANIM"]

    gltf_path.parent.mkdir(parents=True, exist_ok=True)
    builder = GltfBufferBuilder()
    document: dict = {
        "asset": {"version": "2.0", "generator": "SIIG Asset Toolkit"},
        "scene": 0,
        "scenes": [{"nodes": []}],
        "nodes": [],
        "meshes": [],
        "materials": [],
        "buffers": [],
        "bufferViews": builder.buffer_views,
        "accessors": builder.accessors,
        "extras": {
            "sourceFormat": "Space Invaders Infinity Gene GMX",
            "chunkTags": [chunk.tag for chunk in chunks],
        },
    }

    image_indexes: dict[int, int] = {}
    texture_indexes: dict[int, int] = {}
    converted_textures: list[str] = []
    missing_textures: list[str] = []
    if texture_refs:
        document["images"] = []
        document["textures"] = []
        document["samplers"] = [{"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497}]
        texture_dir = gltf_path.parent / "_textures"
        for index, texture_ref in sorted(texture_refs.items()):
            source_texture = _find_texture_file(texture_ref.name, source_path, texture_roots)
            if source_texture is None:
                missing_textures.append(texture_ref.name)
                continue
            try:
                source_bytes = source_texture.read_bytes()
                if source_bytes.startswith(b"DDS "):
                    width, height, rgba = decode_uncompressed_dds_rgba(source_bytes)
                    destination = texture_dir / f"{source_texture.stem}.png"
                    if not destination.exists():
                        write_rgba_png(destination, width, height, rgba)
                elif looks_like_tex(source_bytes):
                    destination = texture_dir / f"{source_texture.stem}.png"
                    if not destination.exists():
                        export_tex_png_bytes(source_bytes, destination)
                elif source_texture.suffix.lower() in {".png", ".jpg", ".jpeg"}:
                    destination = texture_dir / source_texture.name
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    if not destination.exists() and source_texture.resolve() != destination.resolve():
                        shutil.copy2(source_texture, destination)
                else:
                    missing_textures.append(texture_ref.name)
                    continue
                uri = destination.relative_to(gltf_path.parent).as_posix()
                image_indexes[index] = len(document["images"])
                document["images"].append({"uri": uri, "name": texture_ref.name})
                texture_indexes[index] = len(document["textures"])
                document["textures"].append({"sampler": 0, "source": image_indexes[index], "name": texture_ref.name})
                converted_textures.append(uri)
            except Exception:
                missing_textures.append(texture_ref.name)

    material_map: dict[int, int] = {}
    uses_unlit = False
    for index, material in sorted(materials.items()):
        params = {parameter.name: parameter for parameter in material.parameters}
        diffuse = params.get("DiffuseColor")
        alpha = params.get("DiffuseAlpha")
        emissive = params.get("EmissiveColor")
        color_values = list(diffuse.value) if diffuse and diffuse.type_code == 0 else [1.0, 1.0, 1.0]
        while len(color_values) < 3:
            color_values.append(1.0)
        alpha_value = float(alpha.value[0]) if alpha and alpha.type_code == 0 and alpha.value else 1.0
        pbr: dict = {
            "baseColorFactor": [float(color_values[0]), float(color_values[1]), float(color_values[2]), alpha_value],
            "metallicFactor": 0.0,
            "roughnessFactor": 1.0,
        }
        sampler_param = params.get("DiffuseSampler")
        requested_texture: Optional[int] = None
        if sampler_param and sampler_param.type_code == 2:
            requested_texture = int(sampler_param.value)
            if requested_texture in texture_indexes:
                pbr["baseColorTexture"] = {"index": texture_indexes[requested_texture]}
        shader_name = shaders.get(material.shader_index).name if material.shader_index in shaders else ""
        gltf_material: dict = {
            "name": material.name or f"material_{index}",
            "pbrMetallicRoughness": pbr,
            "doubleSided": True,
            "extensions": {"KHR_materials_unlit": {}},
            "extras": {
                "gmxMaterialIndex": index,
                "gmxShader": shader_name,
                "requestedTextureIndex": requested_texture,
                "parameters": {
                    parameter.name: parameter.value for parameter in material.parameters if parameter.name != "mWVP"
                },
            },
        }
        uses_unlit = True
        if emissive and emissive.type_code == 0 and len(emissive.value) >= 3:
            gltf_material["emissiveFactor"] = [float(emissive.value[0]), float(emissive.value[1]), float(emissive.value[2])]
        if alpha_value < 0.999 or requested_texture is not None:
            gltf_material["alphaMode"] = "BLEND"
        material_map[index] = len(document["materials"])
        document["materials"].append(gltf_material)
    if uses_unlit:
        document["extensionsUsed"] = ["KHR_materials_unlit"]

    mesh_to_material: dict[int, Optional[int]] = {}
    mesh_to_bone: dict[int, int] = {}
    for bone in bones.values():
        if bone.mesh_index is not None:
            mesh_to_material[bone.mesh_index] = bone.material_index
            mesh_to_bone[bone.mesh_index] = bone.index

    mesh_map: dict[int, int] = {}
    for mesh_index, mesh in sorted(meshes.items()):
        referenced = [arrays[idx] for idx in mesh.array_refs if idx in arrays]
        position = _array_by_semantic(referenced, "IN.position")
        normal = _array_by_semantic(referenced, "IN.normal")
        texcoord = _array_by_semantic(referenced, "IN.texuv")
        color = _array_by_semantic(referenced, "IN.color")
        indices = _index_array(referenced)
        if position is None or indices is None:
            raise FormatError(f"MESH {mesh_index}: missing position or index array")
        attributes: dict = {}
        pos_values = [tuple(float(x) for x in value[:3]) for value in position.values]
        minimum, maximum = _minmax_tuples(pos_values, 3)
        attributes["POSITION"] = builder.add_accessor(
            _pack_float_tuples(pos_values), 5126, "VEC3", len(pos_values), target=34962, minimum=minimum, maximum=maximum
        )
        if normal is not None:
            normal_values = [tuple(float(x) for x in value[:3]) for value in normal.values]
            attributes["NORMAL"] = builder.add_accessor(
                _pack_float_tuples(normal_values), 5126, "VEC3", len(normal_values), target=34962
            )
        if texcoord is not None:
            uv_values = [
                (float(value[0]), 1.0 - float(value[1]) if flip_v else float(value[1]))
                for value in texcoord.values
            ]
            attributes["TEXCOORD_0"] = builder.add_accessor(
                _pack_float_tuples(uv_values), 5126, "VEC2", len(uv_values), target=34962
            )
        if color is not None:
            color_values = [tuple(float(x) for x in value[:4]) for value in color.values]
            attributes["COLOR_0"] = builder.add_accessor(
                _pack_float_tuples(color_values), 5126, "VEC4", len(color_values), target=34962
            )
        index_values = [int(value[0]) for value in indices.values]
        index_accessor = builder.add_accessor(
            struct.pack(f"<{len(index_values)}H", *index_values),
            5123,
            "SCALAR",
            len(index_values),
            target=34963,
            minimum=[min(index_values) if index_values else 0],
            maximum=[max(index_values) if index_values else 0],
        )
        primitive: dict = {
            "attributes": attributes,
            "indices": index_accessor,
            "mode": int(mesh.primitive_mode),
        }
        material_index = mesh_to_material.get(mesh_index)
        if material_index is not None and material_index in material_map:
            primitive["material"] = material_map[material_index]
        mesh_map[mesh_index] = len(document["meshes"])
        attached_bone = bones.get(mesh_to_bone.get(mesh_index, -1))
        mesh_name = attached_bone.name if attached_bone is not None and attached_bone.name else f"mesh_{mesh_index}"
        document["meshes"].append(
            {
                "name": mesh_name,
                "primitives": [primitive],
                "extras": {"gmxMeshIndex": mesh_index, "skinIndex": mesh.skin_index},
            }
        )

    node_map: dict[int, int] = {}
    decomposition_errors: list[float] = []
    for bone_index, bone in sorted(bones.items()):
        # BONE matrices use row-vector storage; transpose to conventional row-major matrix.
        standard_matrix = _transpose_4x4(bone.matrix)
        translation, rotation, scale, error = decompose_standard_matrix(standard_matrix)
        decomposition_errors.append(error)
        node: dict = {
            "name": bone.name or f"bone_{bone_index}",
            "translation": list(translation),
            "rotation": list(rotation),
            "scale": list(scale),
            "extras": {
                "gmxBoneIndex": bone_index,
                "gmxFlags": bone.flags,
                "gmxMaterialIndex": bone.material_index,
                "gmxMeshIndex": bone.mesh_index,
            },
        }
        if bone.mesh_index is not None and bone.mesh_index in mesh_map:
            node["mesh"] = mesh_map[bone.mesh_index]
        node_map[bone_index] = len(document["nodes"])
        document["nodes"].append(node)

    child_bones: set[int] = set()
    for group in parent_groups:
        valid_children = [child for child in group.children if child in node_map]
        if group.parent >= 0 and group.parent in node_map:
            parent_node = document["nodes"][node_map[group.parent]]
            parent_node.setdefault("children", []).extend(node_map[child] for child in valid_children)
            child_bones.update(valid_children)
    roots = [node_map[index] for index in sorted(node_map) if index not in child_bones]

    # Keep malformed/unreferenced meshes visible instead of silently dropping them.
    for mesh_index, gltf_mesh_index in sorted(mesh_map.items()):
        if mesh_index not in mesh_to_bone:
            node_index = len(document["nodes"])
            document["nodes"].append({"name": f"unattached_mesh_{mesh_index}", "mesh": gltf_mesh_index})
            roots.append(node_index)
    document["scenes"][0]["nodes"] = roots

    if animations:
        document["animations"] = []
        for track in animations:
            if track.target_bone not in node_map:
                continue
            translations: list[tuple[float, float, float]] = []
            rotations: list[tuple[float, float, float, float]] = []
            scales: list[tuple[float, float, float]] = []
            previous_rotation: Optional[tuple[float, float, float, float]] = None
            track_errors: list[float] = []
            for matrix in track.matrices:
                translation, rotation, scale, error = decompose_standard_matrix(matrix)
                if previous_rotation is not None and sum(a * b for a, b in zip(previous_rotation, rotation)) < 0.0:
                    rotation = tuple(-value for value in rotation)
                previous_rotation = rotation
                translations.append(translation)
                rotations.append(rotation)
                scales.append(scale)
                track_errors.append(error)
            runtime_track_times = gmx_matrix_runtime_times(track)
            time_values = [(float(value),) for value in runtime_track_times]
            time_accessor = builder.add_accessor(
                _pack_float_tuples(time_values),
                5126,
                "SCALAR",
                len(time_values),
                minimum=[min(runtime_track_times) if runtime_track_times else 0.0],
                maximum=[max(runtime_track_times) if runtime_track_times else 0.0],
            )
            output_accessors = {
                "translation": builder.add_accessor(_pack_float_tuples(translations), 5126, "VEC3", len(translations)),
                "rotation": builder.add_accessor(_pack_float_tuples(rotations), 5126, "VEC4", len(rotations)),
                "scale": builder.add_accessor(_pack_float_tuples(scales), 5126, "VEC3", len(scales)),
            }
            samplers: list[dict] = []
            channels: list[dict] = []
            for path_name in ("translation", "rotation", "scale"):
                sampler_index = len(samplers)
                samplers.append({"input": time_accessor, "output": output_accessors[path_name], "interpolation": "LINEAR"})
                channels.append(
                    {
                        "sampler": sampler_index,
                        "target": {"node": node_map[track.target_bone], "path": path_name},
                    }
                )
            bone_name = bones[track.target_bone].name or f"bone_{track.target_bone}"
            raw_duration = motions.get(track.index).duration if track.index in motions else (track.times[-1] if track.times else 0.0)
            runtime_duration = (len(track.matrices) / GMX_MATRIX_RUNTIME_HZ) if track.matrices else 0.0
            document["animations"].append(
                {
                    "name": f"motion_{track.index:03d}_{bone_name}",
                    "samplers": samplers,
                    "channels": channels,
                    "extras": {
                        "gmxMotionIndex": track.index,
                        "runtimeDurationSeconds": runtime_duration,
                        "runtimeClockHz": GMX_MATRIX_RUNTIME_HZ,
                        "rawMotionDuration": raw_duration,
                        "rawAuthoringTimeStart": float(track.times[0]) if track.times else 0.0,
                        "rawAuthoringTimeEnd": float(track.times[-1]) if track.times else 0.0,
                        "targetBone": track.target_bone,
                        "maxDecompositionError": max(track_errors, default=0.0),
                    },
                }
            )

    binary_name = f"{gltf_path.name}.bin"
    document["buffers"] = [{"uri": binary_name, "byteLength": len(builder.data)}]
    document["extras"].update(
        {
            "meshCount": len(meshes),
            "boneCount": len(bones),
            "materialCount": len(materials),
            "animationCount": len(animations),
            "convertedTextures": converted_textures,
            "missingTextures": sorted(set(missing_textures)),
            "maxStaticDecompositionError": max(decomposition_errors, default=0.0),
        }
    )
    (gltf_path.parent / binary_name).write_bytes(builder.data)
    gltf_path.write_text(json.dumps(document, indent=2), encoding="utf-8")
    metadata = {
        "source_size": len(data),
        "gltf": gltf_path.name,
        "mesh_count": len(meshes),
        "bone_count": len(bones),
        "material_count": len(materials),
        "animation_count": len(animations),
        "texture_count": len(texture_refs),
        "converted_textures": converted_textures,
        "missing_textures": sorted(set(missing_textures)),
        "max_static_decomposition_error": max(decomposition_errors, default=0.0),
    }
    write_json_private(gltf_path.with_suffix(".gltf.json"), metadata)
    return metadata


def export_gmx_gltf_file(
    path: Path,
    output_root: Path,
    *,
    flip_v: bool = False,
    texture_roots: Sequence[Path] = (),
    relative_path: Optional[Path] = None,
) -> dict:
    relative = relative_path if relative_path is not None else Path(path.stem + ".gltf")
    if relative.suffix.lower() != ".gltf":
        relative = relative.with_suffix(".gltf")
    destination = output_root / relative
    return export_gmx_gltf_bytes(
        path.read_bytes(),
        destination,
        source_path=path,
        texture_roots=texture_roots,
        flip_v=flip_v,
    )

def iter_candidate_files(path: Path) -> Iterator[Path]:
    if path.is_file():
        yield path
    elif path.is_dir():
        yield from (p for p in sorted(path.rglob("*")) if p.is_file())
    else:
        raise FileNotFoundError(path)



LOCALIZATION_LANGUAGES = (
    "japanese",
    "english",
    "french",
    "italian",
    "german",
    "spanish",
)

# message.bin uses an old single-byte, language-specific glyph convention for
# accented uppercase letters. These replacements were recovered from the text
# itself and checked against the corresponding UTF-8 translations in text.bin.
MESSAGE_ACCENT_MAPS: dict[str, dict[str, str]] = {
    "japanese": {"p": "É", "t": "Í", "k": "Ü"},
    "english": {"p": "É", "t": "Í", "k": "Ü"},
    "french": {
        "p": "É", "q": "È", "v": "Î", "r": "Ê", "e": "À",
        "y": "Œ", "k": "Ü", "t": "Í",
    },
    "italian": {
        "q": "È", "e": "À", "m": "Ù", "u": "Ì",
        "p": "É", "k": "Ü", "t": "Í",
    },
    "german": {
        "c": "Ä", "k": "Ü", "g": "Ö", "p": "É", "t": "Í",
    },
    "spanish": {
        "h": "Ó", "b": "Ñ", "l": "Ú", "d": "Á", "p": "É",
        "t": "Í", "z": "¡", "k": "Ü",
    },
}


def correct_message_glyph_codes(text: str, language: str) -> str:
    mapping = MESSAGE_ACCENT_MAPS.get(language, {})
    if not mapping:
        return text
    out: list[str] = []
    for index, char in enumerate(text):
        # Preserve printf's decimal placeholder rather than changing %d to %Á.
        if char == "d" and index > 0 and text[index - 1] == "%":
            out.append(char)
        else:
            out.append(mapping.get(char, char))
    return "".join(out)


def parse_message_script(payload: bytes, language: str) -> tuple[str, dict[str, list[str]]]:
    try:
        source = payload.decode("shift_jis")
    except UnicodeDecodeError as exc:
        raise FormatError(f"message payload is not valid Shift-JIS: {exc}") from exc

    groups: dict[str, list[str]] = {}
    current: Optional[str] = None
    assignment_re = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\s*<-\s*\[$")

    for line_number, line in enumerate(source.splitlines(), 1):
        stripped = line.strip()
        match = assignment_re.match(stripped)
        if match:
            current = match.group(1)
            groups[current] = []
            continue
        if stripped in {"]", "],"}:
            current = None
            continue
        if current is not None and stripped.startswith('"'):
            literal = stripped[:-1] if stripped.endswith(",") else stripped
            try:
                value = json.loads(literal)
            except json.JSONDecodeError as exc:
                raise FormatError(
                    f"invalid message string at line {line_number}: {exc.msg}"
                ) from exc
            groups[current].append(correct_message_glyph_codes(value, language))

    if not groups:
        raise FormatError("message payload contains no Squirrel string arrays")
    return source, groups


def _expand_inline_newlines(value: str) -> str:
    # text.bin stores intended line breaks as the two source characters \\n.
    return value.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\r", "\n").replace("\\t", "\t")


def looks_like_message_archive(archive: BBXArchive) -> bool:
    if archive.count != 6:
        return False
    return all(archive.payload(entry).startswith(b"STR_") for entry in archive.entries)


def looks_like_text_archive(archive: BBXArchive) -> bool:
    if archive.count != 7:
        return False
    first = archive.payload(archive.entries[0])
    return first.startswith(b"EVOL_TEXT1") and b"RICH_PRESENCE" in first


def export_message_archive(archive: BBXArchive, output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    parsed: list[dict[str, list[str]]] = []
    language_meta: list[dict] = []

    for language, entry in zip(LOCALIZATION_LANGUAGES, archive.entries):
        payload = archive.payload(entry)
        source, groups = parse_message_script(payload, language)
        parsed.append(groups)

        raw_path = output_dir / f"message_{language}_raw.nut"
        raw_path.write_text(source, encoding="utf-8", newline="")
        readable_source = correct_message_glyph_codes(source, language)
        readable_path = output_dir / f"message_{language}_readable.nut"
        readable_path.write_text(readable_source, encoding="utf-8", newline="")

        text_path = output_dir / f"message_{language}.txt"
        with text_path.open("w", encoding="utf-8", newline="\n") as handle:
            for group, values in groups.items():
                handle.write(f"[{group}]\n")
                for item_index, value in enumerate(values):
                    rendered = value.replace("\n", "\\n")
                    handle.write(f"{item_index:04d}\t{rendered}\n")
                handle.write("\n")

        language_meta.append({
            "language": language,
            "bbx_entry": entry.index,
            "bytes": len(payload),
            "groups": len(groups),
            "strings": sum(len(values) for values in groups.values()),
            "raw_script": raw_path.name,
            "readable_script": readable_path.name,
        })

    reference_groups = parsed[0]
    for language, groups in zip(LOCALIZATION_LANGUAGES[1:], parsed[1:]):
        if list(groups) != list(reference_groups):
            raise FormatError(f"message group order differs in {language}")
        for group, values in reference_groups.items():
            if len(groups[group]) != len(values):
                raise FormatError(f"message group {group} has a different length in {language}")

    csv_path = output_dir / "message_strings.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["group", "item_index", *LOCALIZATION_LANGUAGES])
        for group, values in reference_groups.items():
            for item_index in range(len(values)):
                writer.writerow([
                    group,
                    item_index,
                    *(groups[group][item_index] for groups in parsed),
                ])

    group_csv = output_dir / "message_groups.csv"
    with group_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["group", "string_count"])
        for group, values in reference_groups.items():
            writer.writerow([group, len(values)])

    json_groups: dict[str, list[dict]] = {}
    for group, values in reference_groups.items():
        json_groups[group] = [
            {
                "index": item_index,
                **{
                    language: parsed[language_index][group][item_index]
                    for language_index, language in enumerate(LOCALIZATION_LANGUAGES)
                },
            }
            for item_index in range(len(values))
        ]

    metadata = {
        "format": "SIIG_message.bin",
        "language_order": list(LOCALIZATION_LANGUAGES),
        "note": (
            "The Japanese-region message block intentionally contains English UI text. "
            "Readable exports replace the original language-specific accent glyph codes with Unicode."
        ),
        "group_count": len(reference_groups),
        "strings_per_language": sum(len(values) for values in reference_groups.values()),
        "languages": language_meta,
    }
    (output_dir / "message_strings.json").write_text(
        json.dumps({**metadata, "groups": json_groups}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (output_dir / "message_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return metadata


def export_text_archive(archive: BBXArchive, output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    decoded: list[list[str]] = []
    for entry_index, entry in enumerate(archive.entries):
        payload = archive.payload(entry)
        try:
            text = payload.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise FormatError(f"text.bin entry {entry_index} is not valid UTF-8: {exc}") from exc
        lines = text.splitlines()
        decoded.append(lines)
        label = "keys" if entry_index == 0 else LOCALIZATION_LANGUAGES[entry_index - 1]
        (output_dir / f"text_{label}_raw.txt").write_text(text, encoding="utf-8", newline="")

    keys = decoded[0]
    if not keys or any(len(lines) != len(keys) for lines in decoded[1:]):
        counts = [len(lines) for lines in decoded]
        raise FormatError(f"text.bin line counts do not match: {counts}")

    raw_csv = output_dir / "text_strings_raw.csv"
    readable_csv = output_dir / "text_strings.csv"
    with raw_csv.open("w", encoding="utf-8-sig", newline="") as raw_handle, readable_csv.open(
        "w", encoding="utf-8-sig", newline=""
    ) as readable_handle:
        raw_writer = csv.writer(raw_handle)
        readable_writer = csv.writer(readable_handle)
        header = ["index", "key", *LOCALIZATION_LANGUAGES]
        raw_writer.writerow(header)
        readable_writer.writerow(header)
        for index, key in enumerate(keys):
            raw_values = [decoded[lang_index + 1][index] for lang_index in range(6)]
            raw_writer.writerow([index, key, *raw_values])
            readable_writer.writerow([index, key, *(_expand_inline_newlines(v) for v in raw_values)])

    records = []
    for index, key in enumerate(keys):
        records.append({
            "index": index,
            "key": key,
            **{
                language: _expand_inline_newlines(decoded[lang_index + 1][index])
                for lang_index, language in enumerate(LOCALIZATION_LANGUAGES)
            },
        })

    for lang_index, language in enumerate(LOCALIZATION_LANGUAGES):
        path = output_dir / f"text_{language}.txt"
        with path.open("w", encoding="utf-8", newline="\n") as handle:
            for index, key in enumerate(keys):
                value = _expand_inline_newlines(decoded[lang_index + 1][index])
                handle.write(f"[{index:04d}] {key}\n{value}\n\n")

    metadata = {
        "format": "SIIG_text.bin",
        "language_order": list(LOCALIZATION_LANGUAGES),
        "string_count": len(keys),
        "note": "Entry 0 contains identifiers; entries 1-6 contain line-aligned UTF-8 translations.",
    }
    (output_dir / "text_strings.json").write_text(
        json.dumps({**metadata, "strings": records}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (output_dir / "text_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return metadata


def decode_localization_file(path: Path, output_root: Path) -> dict:
    data = maybe_decompress(path.read_bytes())
    archive = BBXArchive.parse(data)
    lowered = path.name.lower()
    if looks_like_message_archive(archive):
        metadata = export_message_archive(archive, output_root / "message")
        metadata["source"] = path.name
        return metadata
    if looks_like_text_archive(archive):
        metadata = export_text_archive(archive, output_root / "text")
        metadata["source"] = path.name
        return metadata
    raise FormatError(f"{path}: BBX is not recognized as message.bin or text.bin")


def command_text2csv(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output_root = Path(args.output)
    if not input_path.exists():
        raise FormatError(f"input not found: {input_path}")
    if getattr(args, "rap", None):
        rap_path = Path(args.rap)
        if not rap_path.is_file():
            raise FormatError(f"RAP not found: {rap_path}")
        if rap_path.stat().st_size != 16:
            raise FormatError("RAP must be exactly 16 bytes")

    if input_path.is_file():
        candidates = [input_path]
    else:
        candidates = sorted(
            path for path in input_path.rglob("*")
            if path.is_file()
            and ("message.bin" in path.name.lower() or "text.bin" in path.name.lower())
        )
        if not candidates:
            raise FormatError(f"no message.bin/text.bin files found under {input_path}")

    results: list[dict] = []
    failures: list[dict] = []
    for candidate in candidates:
        try:
            result = decode_localization_file(candidate, output_root)
            results.append(result)
            kind = result["format"]
            count = result.get("string_count", result.get("strings_per_language", 0))
            print(f"decoded {candidate} -> {kind} ({count} strings)")
        except (OSError, FormatError, ContainerError, gzip.BadGzipFile) as exc:
            failures.append({"file": candidate.name, "error": scrub_private_text(exc)})
            print(f"warning: {candidate}: {exc}", file=sys.stderr)

    summary = {"decoded": results, "failures": failures}
    output_root.mkdir(parents=True, exist_ok=True)
    write_json_private(output_root / "localization_summary.json", summary, ensure_ascii=False)
    if not results:
        raise FormatError("no localization archive was decoded")
    print(f"completed: {len(results)} localization archive(s), {len(failures)} failure(s)")
    return 0 if not failures else 1

def command_extract(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        try:
            raw = path.read_bytes()[:4]
            if raw[:2] == b"\x1F\x8B":
                test = maybe_decompress(path.read_bytes())[:4]
            else:
                test = raw
            if test != BBX_MAGIC:
                if input_path.is_file():
                    raise FormatError("input is not BBX or standard gzip containing BBX")
                continue
            result = extract_bbx_file(
                path, output, args.recursive, args.convert_gmx, args.convert_gltf, args.convert_tex, args.flip_v
            )
            print(f"{path}: extracted {result['count']} resources")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} archive(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def command_repack_bbx(args: argparse.Namespace) -> int:
    input_dir = Path(args.input)
    if not input_dir.is_dir():
        raise FormatError(f"BBX repack input must be an extracted directory: {input_dir}")
    manifest_path = Path(args.manifest) if args.manifest else input_dir / "manifest.json"
    entries, manifest = load_bbx_repack_manifest(input_dir, manifest_path, include_extra=bool(args.include_extra))
    mode = _parse_int_auto(args.mode, label="BBX mode") if args.mode is not None else _parse_int_auto(manifest.get("mode", 0), label="BBX mode")
    hash_seed = _parse_int_auto(args.hash_seed, label="BBX hash seed") if args.hash_seed is not None else _parse_int_auto(manifest.get("hash_seed", 0), label="BBX hash seed")
    header_hex = manifest.get("header_reserved_hex", "00" * 16)
    try:
        header_reserved = bytes.fromhex(str(header_hex))
    except ValueError as exc:
        raise FormatError("manifest header_reserved_hex is invalid") from exc
    data = build_bbx_bytes(
        entries,
        mode=mode,
        hash_seed=hash_seed,
        header_reserved=header_reserved,
        preserve_identifiers=bool(args.preserve_identifiers),
    )
    verification = verify_bbx_build(data, entries, mode=mode, hash_seed=hash_seed)
    if not verification["ok"]:
        raise FormatError("BBX self-verification failed: " + "; ".join(verification["issues"]))
    output = Path(args.output)
    if args.gzip and output.suffix.lower() != ".gz":
        output = output.with_name(output.name + ".gz")
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = gzip.compress(data, compresslevel=9, mtime=0) if args.gzip else data
    write_bytes_atomic(output, payload)
    report = {
        "format": "SIIG_BBX_REPACK",
        "toolkit_version": TOOLKIT_VERSION,
        "output_file": output.name,
        "gzip": bool(args.gzip),
        "entry_count": len(entries),
        "mode": mode,
        "hash_seed": f"0x{hash_seed:08X}",
        "bbx_size": len(data),
        "output_size": len(payload),
        "bbx_sha256": hashlib.sha256(data).hexdigest(),
        "output_sha256": hashlib.sha256(payload).hexdigest(),
        "preserve_identifiers": bool(args.preserve_identifiers),
        "included_extra_files": bool(args.include_extra),
        "verification": verification,
        "entries": [{
            "index": index,
            "name": entry.name,
            "source_file": entry.source_file,
            "size": len(entry.payload),
            "sha256": hashlib.sha256(entry.payload).hexdigest(),
        } for index, entry in enumerate(entries)],
    }
    report_path = output.with_suffix(output.suffix + ".repack.json")
    write_json_private(report_path, report, ensure_ascii=False)
    print(f"repacked {len(entries)} resources -> {output}")
    print(f"verification: PASS; report: {report_path}")
    return 0


def command_asset_viewer(args: argparse.Namespace) -> int:
    from siig_asset_viewer import build_asset_viewer
    max_embed = max(0, int(args.max_embed_mib * 1024 * 1024))
    max_single = max(0, int(args.max_single_preview_mib * 1024 * 1024))
    report = build_asset_viewer(
        Path(args.input),
        Path(args.output),
        title=args.title,
        hash_files=not args.no_hash,
        max_embed_bytes=max_embed,
        max_single_preview_bytes=max_single,
        max_text_preview_bytes=max(0, int(args.max_text_preview_kib * 1024)),
        page_size=max(24, int(args.page_size)),
    )
    output = Path(args.output)
    html_path = output if output.suffix.lower() == ".html" else output / "SIIG_Asset_Viewer.html"
    print(
        f"asset viewer: {report['file_count']} files, {report['thumbnail_count']} thumbnails, "
        f"HTML {report['html_bytes'] / 1024:.1f} KiB -> {html_path}"
    )
    return 0


def command_serve(args: argparse.Namespace) -> int:
    from siig_asset_viewer import serve_directory
    serve_directory(Path(args.input), port=int(args.port), open_browser=not args.no_browser)
    return 0


def command_gmx2obj(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        if path.suffix.lower() != ".gmx" and not path.read_bytes()[:4] == GMX_MAGIC:
            continue
        try:
            chunks = parse_gmx_chunks(path.read_bytes())
            if not any(chunk.tag == "MESH" for chunk in chunks):
                meta_path = output / f"{path.stem}.gmx.json"
                meta_path.write_text(
                    json.dumps(
                        {
                            "source": path.name,
                            "mesh_count": 0,
                            "note": "This GMX has no MESH chunks; it may be hierarchy/animation-only.",
                            "chunks": [
                                {"offset": c.offset, "tag": c.tag, "size": c.size} for c in chunks
                            ],
                        },
                        indent=2,
                    ),
                    encoding="utf-8",
                )
                print(f"{path}: no mesh geometry; wrote metadata only")
            else:
                meta = export_gmx_file(path, output, args.flip_v)
                print(f"{path}: exported {meta['mesh_count']} mesh(es)")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} GMX file(s), {failures} failure(s)")
    return 1 if failures and not success else 0



def command_gmx2gltf(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    texture_roots = tuple(Path(value) for value in (args.texture_root or []))
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        try:
            if path.suffix.lower() != ".gmx" and path.read_bytes()[:4] != GMX_MAGIC:
                continue
            if input_path.is_dir():
                relative = path.relative_to(input_path).with_suffix(".gltf")
            else:
                relative = Path(path.stem + ".gltf")
            roots = (input_path,) + texture_roots if input_path.is_dir() else texture_roots
            meta = export_gmx_gltf_file(
                path,
                output,
                flip_v=args.flip_v,
                texture_roots=roots,
                relative_path=relative,
            )
            print(
                f"{path}: glTF with {meta['mesh_count']} mesh(es), "
                f"{meta['bone_count']} bone(s), {meta['animation_count']} animation track(s)"
            )
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} GMX file(s), {failures} failure(s)")
    return 1 if failures and not success else 0

def command_tex2png(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        try:
            data = path.read_bytes()
            if path.suffix.lower() != ".tex" and not looks_like_any_tex(data):
                continue
            if input_path.is_dir():
                relative = path.relative_to(input_path).with_suffix(".png")
                destination = output / relative
            else:
                destination = output / f"{path.stem}.png"
            meta = export_tex_png_bytes(data, destination)
            print(f"{path}: {meta['width']}x{meta['height']} {meta['format_name']} -> {destination}")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} TEX file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def _script_opcode_name(opcode: int) -> str:
    if 0 <= opcode < len(SIIG_SCRIPT_OPCODE_NAMES):
        value = SIIG_SCRIPT_OPCODE_NAMES[opcode]
        if value:
            return value
    return f"UNKNOWN_0x{opcode:04X}"


def _dat_field(name: str, value: int, *, unit: Optional[str] = None, note: Optional[str] = None) -> dict:
    item = {"name": name, "value": value, "hex": f"0x{value & 0xFFFF:04X}"}
    if unit:
        item["unit"] = unit
    if note:
        item["note"] = note
    return item


def decode_dat_semantics(opcode: int, args: Sequence[int]) -> dict:
    """Conservative, XEX-backed semantics for one DAT command.

    Unknown words remain ``param_N``. The lossless signed/unsigned/hex arrays
    are retained alongside this interpretation layer.
    """
    name = _script_opcode_name(opcode)
    category = "other"
    confidence = "low"
    fields: list[dict] = []
    summary = name

    def add_schema(names: Sequence[str], *, units: Optional[dict[str, str]] = None, notes: Optional[dict[str, str]] = None) -> None:
        units = units or {}
        notes = notes or {}
        for index, value in enumerate(args):
            field_name = names[index] if index < len(names) else f"param_{index}"
            fields.append(_dat_field(field_name, value, unit=units.get(field_name), note=notes.get(field_name)))

    if opcode < 0x60 or 0x96 <= opcode <= 0xAB:
        category = "enemy"
        confidence = "medium"
        add_schema(["spawn_condition", "entity_parameter", "speed_or_rate", "variant", "position_x", "position_y"], notes={
            "spawn_condition": "0 is unconditional; nonzero invokes the build's conditional spawn test",
            "entity_parameter": "copied into a common enemy/entity field; exact gameplay label varies by opcode",
            "speed_or_rate": "commonly shifted to the engine's 8.8 fixed-point representation",
            "position_x": "constructor X coordinate in handlers using the common object initializer",
            "position_y": "constructor Y coordinate in handlers using the common object initializer",
        })
        summary = f"Spawn/configure {name}"
        special = {
            0x05: (["spawn_condition", "entity_parameter", "speed", "variant", "start_x", "start_y", "target_x", "target_y"], "Moving enemy from start to target"),
            0x07: (["spawn_condition", "entity_parameter", "speed", "variant", "start_x", "start_y", "target_x", "target_y"], "V-pattern enemy from start to target"),
            0x08: (["spawn_condition", "entity_parameter", "speed", "variant", "start_x", "start_y", "target_x", "target_y", "child_count", "child_delay", "child_parameter"], "Straight enemy path with optional linked child group"),
            0x0A: (["spawn_condition", "entity_parameter", "speed", "variant", "start_x", "start_y", "warp_parameter"], "Warp enemy spawn"),
            0x0C: (["spawn_condition", "entity_parameter", "horizontal_speed", "spawn_y"], "Side-dependent entry enemy"),
            0x10: (["spawn_condition", "entity_parameter", "speed", "start_x", "start_y", "direction"], "Linear enemy movement"),
            0x24: (["spawn_condition", "entity_parameter", "unused_or_style", "base_x", "base_y", "count", "step_x", "step_y"], "Repeated element formation"),
            0x25: (["spawn_condition", "entity_parameter", "unused_or_style", "base_x", "base_y", "count", "step_x", "step_y"], "Repeated element formation"),
            0x26: (["spawn_condition", "entity_parameter", "unused_or_style", "position_x", "position_y"], "Element enemy with optional linked effect"),
            0x5A: (["spawn_condition", "entity_parameter", "position_or_speed", "variant", "start_x", "start_y", "target_x", "target_y", "duration", "mode", "extra"], "3D shutter object"),
            0x5B: (["spawn_condition", "entity_parameter", "position_or_speed", "variant", "start_x", "start_y", "target_x", "target_y", "duration", "mode"], "3D shutter object"),
        }
        if opcode in special:
            names, summary = special[opcode]
            fields.clear()
            add_schema(names)
    elif opcode in (0x6E, 0x6F, 0x70):
        category, confidence = "scroll", "high"
        layer_index = opcode - 0x6E
        add_schema(
            ["velocity_x_fixed_8_8", "velocity_y_fixed_8_8"],
            units={
                "velocity_x_fixed_8_8": "1/256 units per authored 30 Hz tick",
                "velocity_y_fixed_8_8": "1/256 units per authored 30 Hz tick",
            },
            notes={
                "velocity_x_fixed_8_8": f"2D MAP layer {layer_index} X velocity; divided by the runtime frame multiplier before each update",
                "velocity_y_fixed_8_8": f"2D MAP layer {layer_index} Y velocity; divided by the runtime frame multiplier before each update",
            },
        )
        summary = f"Set 2D MAP layer {layer_index} X/Y scroll velocity"
        if opcode == 0x6E:
            summary += "; Y also drives the 3D wall/background system"
        elif opcode == 0x6F:
            summary += "; Y also drives the 3D route/camera/field system"
        else:
            summary += "; its separate 3D dispatcher branch is diagnostic-only"
    elif 0x71 <= opcode <= 0x75:
        category, confidence = "cleanup", "high"
        add_schema([])
        summary = name.replace("_", " ").title()
    elif opcode in (0x76, 0x77):
        category, confidence = "alert", "high"
        add_schema([])
        summary = name.replace("_", " ").title()
    elif opcode == 0x78:
        category, confidence = "alert", "high"
        add_schema(["warning_value"])
        summary = f"Show warning ({args[0] if args else 0})"
    elif 0x79 <= opcode <= 0x7F or 0x84 <= opcode <= 0x8C:
        category, confidence = "background", "high"
        add_schema([])
        summary = f"Select {name.replace('_', ' ').lower()}"
    elif opcode == 0x80:
        category, confidence = "background", "high"
        color_names = ["from_r", "from_g", "from_b", "to_r", "to_g", "to_b"]
        add_schema(color_names, units={key: "0..255" for key in color_names})
        summary = "Set background color gradient"
    elif opcode == 0x81:
        category, confidence = "enemy", "low"
        add_schema([f"generator_param_{i}" for i in range(len(args))])
        summary = "Start continuous enemy generation"
    elif opcode in (0x82, 0x83):
        category, confidence = "flow", "high"
        add_schema([])
        summary = name.replace("_", " ").title()
    elif opcode == 0x8D:
        category, confidence = "background", "high"
        add_schema([])
        summary = "End background gradient"
    elif opcode == 0x8E:
        category, confidence = "flow", "medium"
        add_schema(["script_index", "delay_frames"], units={"delay_frames": "frames"})
        summary = "Loop or switch script"
    elif opcode == 0x8F:
        category, confidence = "flow", "high"
        add_schema([])
        summary = "No operation"
    elif opcode == 0xB4:
        category, confidence = "3d", "high"
        add_schema(["duration_frames"], units={"duration_frames": "frames"})
        summary = "Change 3D background scroll"
    elif opcode == 0xB5:
        category, confidence = "3d", "high"
        add_schema(["duration_frames", "scroll_mode"], units={"duration_frames": "frames"}, notes={"scroll_mode": "validated as mode 0 or 1"})
        summary = "Change 3D wall scroll"
    elif opcode == 0xB6:
        category, confidence = "3d", "high"
        rgba = ["red", "green", "blue", "alpha"]
        add_schema(rgba, units={key: "0..255" for key in rgba})
        summary = "Set 3D background color"
    elif opcode in (0xB7, 0xB8):
        category, confidence = "camera", "high"
        add_schema(["camera_index", "duration_frames"], units={"duration_frames": "frames"})
        summary = f"Change 3D camera to preset {args[0] if args else 0}"
    elif opcode == 0xB9:
        category, confidence = "3d", "high"
        add_schema(["enabled"], notes={"enabled": "0 disables; nonzero enables"})
        summary = "Toggle 3D demo mode"
    elif opcode in (0xBA, 0xBB):
        category, confidence = "cleanup", "high"
        add_schema([])
        summary = name.replace("_", " ").title()
    elif opcode == 0xBC:
        category, confidence = "3d", "high"
        add_schema(["animation_index"])
        summary = "Play/select 3D background animation"
    elif opcode == 0xBD:
        category, confidence = "3d", "high"
        add_schema(["rotation_x", "rotation_y", "rotation_z", "duration_frames", "mode"], units={"rotation_x": "degrees", "rotation_y": "degrees", "rotation_z": "degrees", "duration_frames": "frames"})
        summary = "Rotate 3D background"
    elif opcode == 0xBE:
        category, confidence = "3d", "high"
        add_schema(["control_value"])
        summary = "Set 3D field rotation control"
    elif 0xC8 <= opcode <= 0xCE:
        category, confidence = "visualizer", "high"
        schemas = {0xC8: [], 0xC9: [], 0xCA: [], 0xCB: [], 0xCC: ["sequence_set_id"], 0xCD: ["channel_or_target", "change_time", "param_2", "param_3"], 0xCE: ["volume_scale"]}
        add_schema(schemas[opcode])
        summary = name.replace("_", " ").title()
    else:
        add_schema([f"param_{i}" for i in range(len(args))])

    return {"category": category, "summary": summary, "confidence": confidence, "fields": fields}


def parse_dat_bytes(data: bytes) -> dict:
    """Decode SIIG stage/generator DAT command streams.

    Confirmed from the June 10 DebugOpt XEX ``stageScriptBlockLoad`` routine:
    byte 0 is format version 1; bytes 1..2 are a big-endian entry count.
    Every entry then stores a one-byte 16-bit-word count followed by that many
    big-endian words. Word 0 is a non-negative delta-frame value, word 1 is the
    script opcode, and remaining words are opcode-specific signed parameters.
    """
    if len(data) < 3:
        raise FormatError("DAT file is smaller than its 3-byte header")
    version = data[0]
    if version != 1:
        raise FormatError(f"unsupported DAT version {version}; expected 1")
    entry_count = be_u16(data, 1)
    offset = 3
    absolute_frame = 0
    records: list[dict] = []
    for index in range(entry_count):
        if offset >= len(data):
            raise FormatError(f"DAT entry {index} is missing its word-count byte")
        word_count = data[offset]
        entry_offset = offset
        offset += 1
        byte_count = word_count * 2
        if offset + byte_count > len(data):
            raise FormatError(
                f"DAT entry {index} declares {word_count} word(s) beyond the end of the file"
            )
        unsigned_words = list(struct.unpack_from(f">{word_count}H", data, offset)) if word_count else []
        signed_words = list(struct.unpack_from(f">{word_count}h", data, offset)) if word_count else []
        offset += byte_count
        if word_count < 2:
            raise FormatError(f"DAT entry {index} has only {word_count} word(s); expected frame and opcode")
        delta_frame = signed_words[0]
        if delta_frame < 0:
            raise FormatError(f"DAT entry {index} has a negative delta frame: {delta_frame}")
        absolute_frame += delta_frame
        opcode = unsigned_words[1]
        args_signed = signed_words[2:]
        args_unsigned = unsigned_words[2:]
        records.append(
            {
                "index": index,
                "file_offset": entry_offset,
                "word_count": word_count,
                "delta_frame": delta_frame,
                "absolute_frame": absolute_frame,
                "opcode": opcode,
                "opcode_hex": f"0x{opcode:04X}",
                "opcode_name": _script_opcode_name(opcode),
                "args_signed": args_signed,
                "args_unsigned": args_unsigned,
                "args_hex": [f"0x{value:04X}" for value in args_unsigned],
                "raw_words_hex": [f"0x{value:04X}" for value in unsigned_words],
                "semantic": decode_dat_semantics(opcode, args_signed),
            }
        )
    if offset != len(data):
        raise FormatError(f"DAT has {len(data) - offset} trailing byte(s) after {entry_count} entries")
    return {
        "format": "SIIG_DAT_COMMAND_STREAM",
        "version": version,
        "entry_count": entry_count,
        "duration_frames": absolute_frame,
        "records": records,
    }


def export_dat_csv_bytes(data: bytes, csv_path: Path) -> dict:
    parsed = parse_dat_bytes(data)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "index", "file_offset", "word_count", "delta_frame", "absolute_frame",
                "opcode", "opcode_hex", "opcode_name", "category", "summary", "semantic_fields", "args_signed", "args_hex",
            ],
        )
        writer.writeheader()
        for record in parsed["records"]:
            writer.writerow(
                {
                    "index": record["index"],
                    "file_offset": f"0x{record['file_offset']:X}",
                    "word_count": record["word_count"],
                    "delta_frame": record["delta_frame"],
                    "absolute_frame": record["absolute_frame"],
                    "opcode": record["opcode"],
                    "opcode_hex": record["opcode_hex"],
                    "opcode_name": record["opcode_name"],
                    "category": record["semantic"]["category"],
                    "summary": record["semantic"]["summary"],
                    "semantic_fields": " ".join(f"{field['name']}={field['value']}" for field in record["semantic"]["fields"]),
                    "args_signed": " ".join(str(value) for value in record["args_signed"]),
                    "args_hex": " ".join(record["args_hex"]),
                }
            )
    write_json_private(csv_path.with_suffix(csv_path.suffix + ".json"), parsed)
    return parsed


def command_dat2csv(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        if path.suffix.lower() != ".dat":
            continue
        try:
            relative = path.relative_to(input_path) if input_path.is_dir() else Path(path.name)
            destination = output / relative.parent / f"{relative.name}.csv"
            parsed = export_dat_csv_bytes(path.read_bytes(), destination)
            print(
                f"{path}: {parsed['entry_count']} command(s), "
                f"{parsed['duration_frames']} frame(s) -> {destination}"
            )
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} DAT file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def parse_map_bytes(data: bytes) -> dict:
    """Decode SIIG MAP byte-grid layers.

    Confirmed from the June 10 DebugOpt XEX ``stageGenerate2DMap`` routine:
    ``MAP\\0`` is followed by a big-endian layer count. Each layer stores a
    big-endian width and height, followed immediately by ``width*height`` raw
    one-byte cells in row-major order. Every retail/prototype sample has three
    layers, but the parser preserves the count rather than hard-coding it.
    """
    if len(data) < 8 or data[:4] != MAP_MAGIC:
        raise FormatError("not a SIIG MAP byte-grid file")
    layer_count = be_u32(data, 4)
    if layer_count > 64:
        raise FormatError(f"implausible MAP layer count: {layer_count}")
    offset = 8
    layers: list[dict] = []
    for index in range(layer_count):
        if offset + 8 > len(data):
            raise FormatError(f"MAP layer {index} is missing its dimensions")
        width = be_u32(data, offset)
        height = be_u32(data, offset + 4)
        header_offset = offset
        offset += 8
        if width > 65536 or height > 65536:
            raise FormatError(f"implausible MAP layer {index} dimensions: {width}x{height}")
        size = width * height
        if offset + size > len(data):
            raise FormatError(
                f"MAP layer {index} payload is truncated: expected {size} byte(s), "
                f"found {len(data) - offset}"
            )
        cells = data[offset : offset + size]
        data_offset = offset
        offset += size
        counts: dict[str, int] = {}
        for value in cells:
            key = f"0x{value:02X}"
            counts[key] = counts.get(key, 0) + 1
        layers.append(
            {
                "index": index,
                "header_offset": header_offset,
                "data_offset": data_offset,
                "width": width,
                "height": height,
                "cell_count": size,
                "nonzero_cells": sum(value != 0 for value in cells),
                "unique_values": len(counts),
                "value_counts": dict(sorted(counts.items())),
                "cells": cells,
            }
        )
    if offset != len(data):
        raise FormatError(f"MAP has {len(data) - offset} trailing byte(s)")
    return {
        "format": "SIIG_MAP_BYTE_GRIDS",
        "layer_count": layer_count,
        "layers": layers,
    }


def _map_cell_rgba(value: int, grayscale: bool) -> bytes:
    if value == 0:
        return b"\x00\x00\x00\xff"
    if grayscale:
        return bytes((value, value, value, 255))
    red = 48 + ((value * 73) % 208)
    green = 48 + ((value * 151) % 208)
    blue = 48 + ((value * 199) % 208)
    return bytes((red, green, blue, 255))


def _scale_rgba_nearest(rgba: bytes, width: int, height: int, scale: int) -> tuple[int, int, bytes]:
    if scale <= 1 or width == 0 or height == 0:
        return width, height, rgba
    row_size = width * 4
    output_rows: list[bytes] = []
    for y in range(height):
        source = rgba[y * row_size : (y + 1) * row_size]
        expanded = b"".join(source[x : x + 4] * scale for x in range(0, row_size, 4))
        output_rows.extend([expanded] * scale)
    return width * scale, height * scale, b"".join(output_rows)



MAP_ATLAS_COLUMNS = 7
MAP_ATLAS_ROWS = 7
MAP_ATLAS_PITCH_PX = 144
MAP_ATLAS_SOURCE_SIZE_PX = 96
MAP_LOGICAL_SPRITE_UNITS = 32
MAP_CELL_UNITS = 30


def decode_png_rgba_bytes(data: bytes) -> tuple[int, int, bytes]:
    """Decode a non-interlaced 8-bit RGB/RGBA PNG using only zlib."""
    if len(data) < 33 or data[:8] != b"\x89PNG\r\n\x1a\n":
        raise FormatError("not a PNG file")
    offset = 8
    width = height = 0
    bit_depth = color_type = interlace = -1
    idat = bytearray()
    saw_ihdr = False
    saw_iend = False
    while offset + 12 <= len(data):
        length = struct.unpack_from(">I", data, offset)[0]
        chunk_type = data[offset + 4 : offset + 8]
        chunk_start = offset + 8
        chunk_end = chunk_start + length
        crc_end = chunk_end + 4
        if crc_end > len(data):
            raise FormatError("truncated PNG chunk")
        payload = data[chunk_start:chunk_end]
        expected_crc = struct.unpack_from(">I", data, chunk_end)[0]
        actual_crc = zlib.crc32(chunk_type)
        actual_crc = zlib.crc32(payload, actual_crc) & 0xFFFFFFFF
        if actual_crc != expected_crc:
            raise FormatError(f"PNG CRC mismatch in {chunk_type.decode('ascii', errors='replace')}")
        offset = crc_end
        if chunk_type == b"IHDR":
            if saw_ihdr or length != 13:
                raise FormatError("invalid PNG IHDR")
            width, height, bit_depth, color_type, compression, filtering, interlace = struct.unpack(
                ">IIBBBBB", payload
            )
            if not width or not height or width > 32768 or height > 32768:
                raise FormatError(f"implausible PNG dimensions: {width}x{height}")
            if bit_depth != 8 or color_type not in (2, 6):
                raise FormatError("only 8-bit RGB/RGBA PNG atlases are supported")
            if compression != 0 or filtering != 0 or interlace != 0:
                raise FormatError("compressed/filter variant or interlaced PNG is unsupported")
            saw_ihdr = True
        elif chunk_type == b"IDAT":
            if not saw_ihdr:
                raise FormatError("PNG IDAT appears before IHDR")
            idat.extend(payload)
        elif chunk_type == b"IEND":
            saw_iend = True
            break
    if not saw_ihdr or not saw_iend or not idat:
        raise FormatError("incomplete PNG atlas")
    channels = 4 if color_type == 6 else 3
    stride = width * channels
    expected = height * (stride + 1)
    try:
        raw = zlib.decompress(bytes(idat))
    except zlib.error as exc:
        raise FormatError(f"PNG zlib stream is invalid: {exc}") from exc
    if len(raw) != expected:
        raise FormatError(f"PNG scanline size mismatch: expected {expected}, found {len(raw)}")

    def paeth(a: int, b: int, c: int) -> int:
        estimate = a + b - c
        pa = abs(estimate - a)
        pb = abs(estimate - b)
        pc = abs(estimate - c)
        if pa <= pb and pa <= pc:
            return a
        if pb <= pc:
            return b
        return c

    reconstructed = bytearray(height * stride)
    source_offset = 0
    for y in range(height):
        filter_type = raw[source_offset]
        source_offset += 1
        scan = raw[source_offset : source_offset + stride]
        source_offset += stride
        row_offset = y * stride
        for x, value in enumerate(scan):
            left = reconstructed[row_offset + x - channels] if x >= channels else 0
            above = reconstructed[row_offset - stride + x] if y else 0
            upper_left = reconstructed[row_offset - stride + x - channels] if y and x >= channels else 0
            if filter_type == 0:
                decoded = value
            elif filter_type == 1:
                decoded = (value + left) & 0xFF
            elif filter_type == 2:
                decoded = (value + above) & 0xFF
            elif filter_type == 3:
                decoded = (value + ((left + above) >> 1)) & 0xFF
            elif filter_type == 4:
                decoded = (value + paeth(left, above, upper_left)) & 0xFF
            else:
                raise FormatError(f"unsupported PNG scanline filter {filter_type}")
            reconstructed[row_offset + x] = decoded
    if channels == 4:
        return width, height, bytes(reconstructed)
    rgba = bytearray(width * height * 4)
    for pixel in range(width * height):
        src = pixel * 3
        dst = pixel * 4
        rgba[dst : dst + 3] = reconstructed[src : src + 3]
        rgba[dst + 3] = 255
    return width, height, bytes(rgba)


def _scaled_atlas_sprite(
    atlas: bytes,
    atlas_width: int,
    atlas_height: int,
    tile_id: int,
    flip_flags: int,
    destination_size: int,
) -> list[tuple[int, int, int, int, int, int]]:
    if tile_id < 1 or tile_id > 49:
        return []
    index = tile_id - 1
    source_x = (index % MAP_ATLAS_COLUMNS) * MAP_ATLAS_PITCH_PX
    source_y = (index // MAP_ATLAS_COLUMNS) * MAP_ATLAS_PITCH_PX
    if (
        source_x + MAP_ATLAS_SOURCE_SIZE_PX > atlas_width
        or source_y + MAP_ATLAS_SOURCE_SIZE_PX > atlas_height
    ):
        raise FormatError(
            f"atlas is too small for tile {tile_id}: {atlas_width}x{atlas_height}"
        )
    pixels: list[tuple[int, int, int, int, int, int]] = []
    for dy in range(destination_size):
        logical_y = destination_size - 1 - dy if flip_flags & 0x02 else dy
        sy = source_y + min(
            MAP_ATLAS_SOURCE_SIZE_PX - 1,
            logical_y * MAP_ATLAS_SOURCE_SIZE_PX // destination_size,
        )
        for dx in range(destination_size):
            logical_x = destination_size - 1 - dx if flip_flags & 0x01 else dx
            sx = source_x + min(
                MAP_ATLAS_SOURCE_SIZE_PX - 1,
                logical_x * MAP_ATLAS_SOURCE_SIZE_PX // destination_size,
            )
            source = (sy * atlas_width + sx) * 4
            red, green, blue, alpha = atlas[source : source + 4]
            if alpha:
                pixels.append((dx, dy, red, green, blue, alpha))
    return pixels


def _blend_sprite(
    canvas: bytearray,
    canvas_width: int,
    canvas_height: int,
    left: int,
    top: int,
    pixels: Sequence[tuple[int, int, int, int, int, int]],
) -> None:
    for dx, dy, red, green, blue, alpha in pixels:
        x = left + dx
        y = top + dy
        if x < 0 or y < 0 or x >= canvas_width or y >= canvas_height:
            continue
        target = (y * canvas_width + x) * 4
        if alpha == 255 or canvas[target + 3] == 0:
            canvas[target : target + 4] = bytes((red, green, blue, alpha))
            continue
        dest_alpha = canvas[target + 3]
        inverse = 255 - alpha
        out_alpha = alpha + (dest_alpha * inverse + 127) // 255
        if out_alpha == 0:
            continue
        denominator = out_alpha * 255
        canvas[target] = (
            red * alpha * 255 + canvas[target] * dest_alpha * inverse + denominator // 2
        ) // denominator
        canvas[target + 1] = (
            green * alpha * 255 + canvas[target + 1] * dest_alpha * inverse + denominator // 2
        ) // denominator
        canvas[target + 2] = (
            blue * alpha * 255 + canvas[target + 2] * dest_alpha * inverse + denominator // 2
        ) // denominator
        canvas[target + 3] = out_alpha


def _render_map_atlas_layer(
    layer: dict,
    atlas: bytes,
    atlas_width: int,
    atlas_height: int,
    *,
    step: int,
    cache: dict[tuple[int, int], list[tuple[int, int, int, int, int, int]]],
    canvas_width: Optional[int] = None,
    canvas_height: Optional[int] = None,
    canvas: Optional[bytearray] = None,
) -> tuple[int, int, bytearray]:
    width = int(layer["width"])
    height = int(layer["height"])
    out_width = canvas_width if canvas_width is not None else width * step
    out_height = canvas_height if canvas_height is not None else height * step
    output = canvas if canvas is not None else bytearray(out_width * out_height * 4)
    sprite_size = max(1, round(step * MAP_LOGICAL_SPRITE_UNITS / MAP_CELL_UNITS))
    cells: bytes = layer["cells"]
    for position, value in enumerate(cells):
        tile_id = value & 0x3F
        if not tile_id:
            continue
        flags = value >> 6
        key = (tile_id, flags)
        sprite = cache.get(key)
        if sprite is None:
            sprite = _scaled_atlas_sprite(
                atlas,
                atlas_width,
                atlas_height,
                tile_id,
                flags,
                sprite_size,
            )
            cache[key] = sprite
        column = position % width
        row = position // width
        center_x = column * step + step // 2
        center_y = row * step + step // 2
        _blend_sprite(
            output,
            out_width,
            out_height,
            center_x - sprite_size // 2,
            center_y - sprite_size // 2,
            sprite,
        )
    return out_width, out_height, output


def export_map_atlas_pngs(
    parsed: dict,
    output_stem: Path,
    atlas_png: bytes,
    *,
    atlas_name: str,
    step: int = 8,
    write_composite: bool = True,
) -> dict:
    if step < 2 or step > 128:
        raise FormatError("MAP atlas step must be between 2 and 128 pixels")
    atlas_width, atlas_height, atlas = decode_png_rgba_bytes(atlas_png)
    required_width = (MAP_ATLAS_COLUMNS - 1) * MAP_ATLAS_PITCH_PX + MAP_ATLAS_SOURCE_SIZE_PX
    required_height = (MAP_ATLAS_ROWS - 1) * MAP_ATLAS_PITCH_PX + MAP_ATLAS_SOURCE_SIZE_PX
    if atlas_width < required_width or atlas_height < required_height:
        raise FormatError(
            f"MAP atlas must be at least {required_width}x{required_height}; "
            f"found {atlas_width}x{atlas_height}"
        )
    cache: dict[tuple[int, int], list[tuple[int, int, int, int, int, int]]] = {}
    layer_outputs: list[dict] = []
    for layer in parsed["layers"]:
        if not layer["width"] or not layer["height"]:
            continue
        width, height, rgba = _render_map_atlas_layer(
            layer,
            atlas,
            atlas_width,
            atlas_height,
            step=step,
            cache=cache,
        )
        path = output_stem.with_name(
            f"{output_stem.name}.atlas.layer{layer['index']}.png"
        )
        write_rgba_png(path, width, height, bytes(rgba))
        layer_outputs.append({
            "layer": layer["index"],
            "file": path.name,
            "width": width,
            "height": height,
        })

    composite = None
    live_layers = [layer for layer in parsed["layers"] if layer["width"] and layer["height"]]
    if write_composite and live_layers:
        grid_width = max(int(layer["width"]) for layer in live_layers)
        grid_height = max(int(layer["height"]) for layer in live_layers)
        width = grid_width * step
        height = grid_height * step
        canvas = bytearray(width * height * 4)
        by_index = {int(layer["index"]): layer for layer in live_layers}
        for index in (2, 1, 0):
            layer = by_index.get(index)
            if layer is None:
                continue
            _render_map_atlas_layer(
                layer,
                atlas,
                atlas_width,
                atlas_height,
                step=step,
                cache=cache,
                canvas_width=width,
                canvas_height=height,
                canvas=canvas,
            )
        path = output_stem.with_name(f"{output_stem.name}.atlas.composite.png")
        write_rgba_png(path, width, height, bytes(canvas))
        composite = {"file": path.name, "width": width, "height": height, "draw_order": [2, 1, 0]}

    return {
        "atlas_file": privacy_safe_path(atlas_name),
        "atlas_width": atlas_width,
        "atlas_height": atlas_height,
        "atlas_sha256": hashlib.sha256(atlas_png).hexdigest(),
        "step_px": step,
        "sprite_px": max(1, round(step * MAP_LOGICAL_SPRITE_UNITS / MAP_CELL_UNITS)),
        "layout": {
            "columns": MAP_ATLAS_COLUMNS,
            "rows": MAP_ATLAS_ROWS,
            "pitch_px": MAP_ATLAS_PITCH_PX,
            "source_size_px": MAP_ATLAS_SOURCE_SIZE_PX,
            "logical_sprite_units": MAP_LOGICAL_SPRITE_UNITS,
            "map_cell_units": MAP_CELL_UNITS,
        },
        "layers": layer_outputs,
        "composite": composite,
    }


def export_map_png_bytes(
    data: bytes,
    output_stem: Path,
    *,
    scale: int = 1,
    grayscale: bool = False,
    write_csv: bool = False,
    atlas_png: Optional[bytes] = None,
    atlas_name: str = "",
    atlas_step: int = 8,
    atlas_composite: bool = True,
) -> dict:
    if scale < 1 or scale > 64:
        raise FormatError("MAP scale must be between 1 and 64")
    parsed = parse_map_bytes(data)
    metadata_layers: list[dict] = []
    for layer in parsed["layers"]:
        index = layer["index"]
        width = layer["width"]
        height = layer["height"]
        cells: bytes = layer["cells"]
        layer_meta = {key: value for key, value in layer.items() if key != "cells"}
        if width and height:
            rgba = b"".join(_map_cell_rgba(value, grayscale) for value in cells)
            out_width, out_height, rgba = _scale_rgba_nearest(rgba, width, height, scale)
            png_path = output_stem.with_name(f"{output_stem.name}.layer{index}.png")
            write_rgba_png(png_path, out_width, out_height, rgba)
            layer_meta["png_file"] = png_path.name
            layer_meta["png_width"] = out_width
            layer_meta["png_height"] = out_height
            if write_csv:
                csv_path = output_stem.with_name(f"{output_stem.name}.layer{index}.csv")
                csv_path.parent.mkdir(parents=True, exist_ok=True)
                with csv_path.open("w", encoding="utf-8", newline="") as handle:
                    writer = csv.writer(handle)
                    for y in range(height):
                        row = cells[y * width : (y + 1) * width]
                        writer.writerow(row)
                layer_meta["csv_file"] = csv_path.name
        metadata_layers.append(layer_meta)
    metadata = {
        "format": parsed["format"],
        "layer_count": parsed["layer_count"],
        "scale": scale,
        "palette": "grayscale" if grayscale else "categorical",
        "layers": metadata_layers,
    }
    if atlas_png is not None:
        metadata["atlas_render"] = export_map_atlas_pngs(
            parsed,
            output_stem,
            atlas_png,
            atlas_name=atlas_name or "atlas.png",
            step=atlas_step,
            write_composite=atlas_composite,
        )
    write_json_private(output_stem.with_suffix(output_stem.suffix + ".json"), metadata)
    return metadata


def command_map2png(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    atlas_path = Path(args.atlas) if getattr(args, "atlas", None) else None
    atlas_png = None
    if atlas_path is not None:
        if not atlas_path.is_file():
            raise FormatError(f"MAP atlas not found: {atlas_path}")
        atlas_png = atlas_path.read_bytes()
        # Decode once up front so a bad atlas fails before batch conversion.
        decode_png_rgba_bytes(atlas_png)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        if path.suffix.lower() != ".map":
            continue
        try:
            relative = path.relative_to(input_path) if input_path.is_dir() else Path(path.name)
            destination = output / relative.parent / relative.name
            parsed = export_map_png_bytes(
                path.read_bytes(),
                destination,
                scale=args.scale,
                grayscale=args.grayscale,
                write_csv=args.csv,
                atlas_png=atlas_png,
                atlas_name=atlas_path.name if atlas_path else "",
                atlas_step=int(getattr(args, "atlas_step", 8)),
                atlas_composite=not bool(getattr(args, "no_atlas_composite", False)),
            )
            dims = ", ".join(
                f"{layer['width']}x{layer['height']}" for layer in parsed["layers"]
            )
            print(f"{path}: {parsed['layer_count']} layer(s) [{dims}] -> {destination.parent}")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} MAP file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def parse_col_bytes(data: bytes) -> dict:
    """Decode SIIG's standalone .col collision-mask format.

    The files are a 16-byte big-endian header followed by a tightly packed
    one-bit image. Bits are stored least-significant-bit first inside each byte.
    The third header word is preserved as ``variant`` because its gameplay
    meaning has not yet been proven (retail samples use 1 or 4).
    """
    if len(data) < 16:
        raise FormatError("COL file is smaller than its 16-byte header")
    width, height, variant, reserved = struct.unpack_from(">4I", data, 0)
    if not width or not height or width > 16384 or height > 16384:
        raise FormatError(f"implausible COL dimensions: {width}x{height}")
    expected = (width * height + 7) // 8
    if len(data) != 16 + expected:
        raise FormatError(
            f"COL payload size mismatch: expected {expected} byte(s), found {len(data) - 16}"
        )
    return {
        "width": width,
        "height": height,
        "variant": variant,
        "reserved": reserved,
        "payload": data[16:],
    }


def export_col_png_bytes(data: bytes, png_path: Path, *, invert: bool = False) -> dict:
    parsed = parse_col_bytes(data)
    width = parsed["width"]
    height = parsed["height"]
    packed = parsed["payload"]
    # Expand eight LSB-first pixels per byte through a lookup table. This is
    # dramatically faster than a Python loop over every pixel when converting
    # the complete wall archive (over 80 million collision pixels).
    on = bytes((255, 255, 255, 255))
    off = bytes((0, 0, 0, 255))
    lookup = []
    for byte_value in range(256):
        pixels = []
        for bit_index in range(8):
            bit = (byte_value >> bit_index) & 1
            if invert:
                bit ^= 1
            pixels.append(on if bit else off)
        lookup.append(b"".join(pixels))
    rgba = b"".join(lookup[byte_value] for byte_value in packed)
    rgba = rgba[: width * height * 4]
    write_rgba_png(png_path, width, height, rgba)
    metadata = {
        "format": "SIIG_COL_1BIT",
        "width": width,
        "height": height,
        "variant": parsed["variant"],
        "reserved": parsed["reserved"],
        "bit_order": "LSB-first",
        "inverted": invert,
    }
    write_json_private(png_path.with_suffix(png_path.suffix + ".json"), metadata)
    return metadata


def _decode_fixed_ascii(raw: bytes, *, context: str) -> str:
    value = raw.split(b"\0", 1)[0]
    try:
        return value.decode("ascii")
    except UnicodeDecodeError as exc:
        raise FormatError(f"{context} contains non-ASCII text") from exc


def parse_anm_bytes(data: bytes) -> list[dict]:
    """Decode SIIG standalone animation-range tables.

    Ghidra-backed layout (28 bytes per record):
      +0x00 char[16] model/group name
      +0x10 be f32 start frame
      +0x14 be f32 end frame
      +0x18 be u32 loop flag

    Consecutive records with the same name form one runtime lookup group.
    """
    if not data or len(data) % 28:
        raise FormatError(f"ANM size is not a non-zero multiple of 28: {len(data)}")
    records: list[dict] = []
    group_index = -1
    previous_name: Optional[str] = None
    clip_index = 0
    for offset in range(0, len(data), 28):
        index = offset // 28
        name = _decode_fixed_ascii(data[offset : offset + 16], context=f"ANM record {index} name")
        start_frame, end_frame = struct.unpack_from(">2f", data, offset + 16)
        loop_raw = be_u32(data, offset + 24)
        if not math.isfinite(start_frame) or not math.isfinite(end_frame):
            raise FormatError(f"ANM record {index} has a non-finite frame range")
        if end_frame < start_frame:
            raise FormatError(
                f"ANM record {index} has descending range {start_frame}..{end_frame}"
            )
        if name != previous_name:
            group_index += 1
            clip_index = 0
            previous_name = name
        records.append(
            {
                "index": index,
                "group_index": group_index,
                "clip_index": clip_index,
                "model_name": name,
                "start_frame": start_frame,
                "end_frame": end_frame,
                "duration_frames": end_frame - start_frame,
                "loop": bool(loop_raw),
                "loop_raw": loop_raw,
            }
        )
        clip_index += 1
    return records


def export_anm_csv_bytes(data: bytes, csv_path: Path) -> dict:
    records = parse_anm_bytes(data)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "index", "group_index", "clip_index", "model_name", "start_frame",
        "end_frame", "duration_frames", "loop", "loop_raw",
    ]
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    groups: list[dict] = []
    for record in records:
        if not groups or groups[-1]["model_name"] != record["model_name"]:
            groups.append({
                "group_index": record["group_index"],
                "model_name": record["model_name"],
                "clip_count": 0,
                "first_record": record["index"],
                "last_record": record["index"],
            })
        groups[-1]["clip_count"] += 1
        groups[-1]["last_record"] = record["index"]
    metadata = {
        "format": "SIIG_ANM_RANGE_TABLE",
        "record_size": 28,
        "record_count": len(records),
        "group_count": len(groups),
        "looped_records": sum(1 for record in records if record["loop"]),
        "non_looped_records": sum(1 for record in records if not record["loop"]),
        "runtime_behavior": (
            "current frame starts at the range boundary, advances forward/reverse, "
            "and either wraps or stops at the opposite boundary according to loop"
        ),
        "groups": groups,
        "records": records,
    }
    write_json_private(csv_path.with_suffix(csv_path.suffix + ".json"), metadata)
    return metadata


STAGE3D_RECORD_SIZE = 0x118
STAGE3D_CELL_SIZE = 800.0
STAGE3D_HALF_CELL = STAGE3D_CELL_SIZE / 2.0
XENOS_SHADER_MAGIC_MASK = 0xFFFFFF00
XENOS_SHADER_MAGIC = 0x102A1100


def _be_f32_tuple(data: bytes, offset: int, count: int) -> tuple[float, ...]:
    values = struct.unpack_from(">" + "f" * count, data, offset)
    if not all(math.isfinite(value) for value in values):
        raise FormatError(f"non-finite float at 0x{offset:X}")
    return tuple(float(value) for value in values)


def looks_like_stage3d_map(data: bytes) -> bool:
    if not data or len(data) % STAGE3D_RECORD_SIZE:
        return False
    try:
        sample_count = min(3, len(data) // STAGE3D_RECORD_SIZE)
        for index in range(sample_count):
            base = index * STAGE3D_RECORD_SIZE
            for slot in range(4):
                raw = data[base + slot * 0x34 : base + slot * 0x34 + 16]
                text = raw.split(b"\0", 1)[0]
                if text and any(byte < 0x20 or byte > 0x7E for byte in text):
                    return False
            _be_f32_tuple(data, base + 0xD0, 3)
        return True
    except (FormatError, struct.error):
        return False


def parse_stage3d_map_bytes(data: bytes, *, source_name: str = "") -> dict:
    """Decode Bmap/Xmap fixed-size 3D stage path records."""
    if not looks_like_stage3d_map(data):
        raise FormatError(
            f"3D stage map size/layout is invalid (expected non-zero multiple of 0x118): {len(data)}"
        )
    capacity = len(data) // STAGE3D_RECORD_SIZE
    records: list[dict] = []
    cursor = [0.0, 0.0, 0.0]
    sentinel_index: Optional[int] = None
    for index in range(capacity):
        base = index * STAGE3D_RECORD_SIZE
        step = _be_f32_tuple(data, base + 0xD0, 3)
        if all(abs(value) < 1e-8 for value in step):
            sentinel_index = index
            break
        start = tuple(cursor)
        end = tuple(cursor[axis] + step[axis] * STAGE3D_CELL_SIZE for axis in range(3))
        center = tuple((start[axis] + end[axis]) / 2.0 for axis in range(3))
        bounds_min = tuple(value - STAGE3D_HALF_CELL for value in center)
        bounds_max = tuple(value + STAGE3D_HALF_CELL for value in center)
        placements: list[dict] = []
        for slot in range(4):
            slot_base = base + slot * 0x34
            name = _decode_fixed_ascii(
                data[slot_base : slot_base + 16],
                context=f"3D stage record {index} slot {slot} name",
            )
            position = _be_f32_tuple(data, slot_base + 0x10, 3)
            stored_scale = _be_f32_tuple(data, slot_base + 0x1C, 3)
            rotation = _be_f32_tuple(data, slot_base + 0x28, 3)
            runtime_scale = tuple(value * 5.0 for value in stored_scale)
            used = bool(name) and name.lower() != "notuse"
            placements.append({
                "slot": slot,
                "used": used,
                "model_name": name,
                "model_file": f"{name}.gmx" if used else "",
                "position": list(position),
                "stored_scale": list(stored_scale),
                "runtime_scale": list(runtime_scale),
                "rotation_degrees": list(rotation),
                # Compatibility alias: scale now means the effective runtime scale.
                "scale": list(runtime_scale),
            })
        route_point_slots = [
            list(_be_f32_tuple(data, base + 0xDC + point * 12, 3))
            for point in range(5)
        ]
        primary_route_point = route_point_slots[2]
        records.append({
            "index": index,
            "file_offset": base,
            "path_start": list(start),
            "path_end": list(end),
            "cell_center": list(center),
            "cell_step": list(step),
            "bounds_min": list(bounds_min),
            "bounds_max": list(bounds_max),
            "placements": placements,
            "route_point_slots": route_point_slots,
            "primary_route_point": primary_route_point,
            # Compatibility alias for pre-EBOOT exports.
            "aux_points": route_point_slots,
        })
        cursor[:] = end
    runtime_route_source: list[dict] = []
    for record in records:
        contributed = 0
        for slot, point in enumerate(record["route_point_slots"]):
            if any(abs(float(value)) > 1e-8 for value in point):
                runtime_route_source.append({
                    "sequence_index": len(runtime_route_source),
                    "record_index": record["index"],
                    "slot": slot,
                    "fallback_origin": False,
                    "point": list(point),
                })
                contributed += 1
        if record["index"] == 0 and contributed == 0:
            runtime_route_source.append({
                "sequence_index": len(runtime_route_source),
                "record_index": 0,
                "slot": None,
                "fallback_origin": True,
                "point": [0.0, 0.0, 0.0],
            })
    source_lower = Path(source_name).name.lower()
    kind = "boss" if source_lower.startswith("bmap") else (
        "normal" if source_lower.startswith("xmap") else (
            "special_level_4_5" if re.fullmatch(r"map[45]_.*\.bin", source_lower) else "unknown"
        )
    )
    if records:
        first_primary = records[0]["primary_route_point"]
        if any(abs(float(value)) > 1e-8 for value in first_primary):
            initial_field_position = list(first_primary)
            initial_field_position_source = "record0_route_point_slot2"
        else:
            initial_field_position = list(records[0]["placements"][0]["position"])
            initial_field_position_source = "record0_placement_slot0_position_fallback"
    else:
        initial_field_position = []
        initial_field_position_source = "none"
    return {
        "format": "SIIG_STAGE3D_MAP",
        "record_size": STAGE3D_RECORD_SIZE,
        "source_name": Path(source_name).name if source_name else "",
        "stage_kind": kind,
        "capacity_records": capacity,
        "active_records": len(records),
        "sentinel_record": sentinel_index,
        "cell_size_units": STAGE3D_CELL_SIZE,
        "placements_per_record": 4,
        "route_point_slots_per_record": 5,
        "primary_route_point_slot": 2,
        "initial_field_position": initial_field_position,
        "initial_field_position_source": initial_field_position_source,
        "runtime_route_source": runtime_route_source,
        "runtime_route_source_point_count": len(runtime_route_source),
        "runtime_route_source_rule": "append every nonzero route-point slot 0..4 in record order; if record 0 contributes none, append origin",
        "runtime_route_source_is_control_points_not_resampled_spline": True,
        "aux_points_per_record": 5,
        "records": records,
    }


def export_stage3d_map_bytes(data: bytes, output_base: Path, *, source_name: str = "") -> dict:
    parsed = parse_stage3d_map_bytes(data, source_name=source_name)
    output_base.parent.mkdir(parents=True, exist_ok=True)
    json_path = output_base.with_suffix(output_base.suffix + ".stage3d.json")
    write_json_private(json_path, parsed, ensure_ascii=False)

    path_csv = output_base.with_suffix(output_base.suffix + ".path.csv")
    with path_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = [
            "index", "start_x", "start_y", "start_z", "end_x", "end_y", "end_z",
            "center_x", "center_y", "center_z", "step_x", "step_y", "step_z",
            "min_x", "min_y", "min_z", "max_x", "max_y", "max_z",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for record in parsed["records"]:
            row = {"index": record["index"]}
            for prefix, values in (
                ("start", record["path_start"]), ("end", record["path_end"]),
                ("center", record["cell_center"]), ("step", record["cell_step"]),
                ("min", record["bounds_min"]), ("max", record["bounds_max"]),
            ):
                for axis, value in zip("xyz", values):
                    row[f"{prefix}_{axis}"] = value
            writer.writerow(row)

    placement_csv = output_base.with_suffix(output_base.suffix + ".placements.csv")
    with placement_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = [
            "record_index", "slot", "used", "model_name", "model_file",
            "position_x", "position_y", "position_z",
            "rotation_x_degrees", "rotation_y_degrees", "rotation_z_degrees",
            "stored_scale_x", "stored_scale_y", "stored_scale_z",
            "runtime_scale_x", "runtime_scale_y", "runtime_scale_z",
            "scale_x", "scale_y", "scale_z",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for record in parsed["records"]:
            for placement in record["placements"]:
                row = {
                    "record_index": record["index"],
                    "slot": placement["slot"],
                    "used": placement["used"],
                    "model_name": placement["model_name"],
                    "model_file": placement["model_file"],
                }
                for prefix, values in (
                    ("position", placement["position"]),
                    ("rotation", placement["rotation_degrees"]),
                    ("stored_scale", placement["stored_scale"]),
                    ("runtime_scale", placement["runtime_scale"]),
                    ("scale", placement["scale"]),
                ):
                    suffix = "_degrees" if prefix == "rotation" else ""
                    for axis, value in zip("xyz", values):
                        row[f"{prefix}_{axis}{suffix}"] = value
                writer.writerow(row)

    obj_path = output_base.with_suffix(output_base.suffix + ".path.obj")
    with obj_path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("# SIIG Bmap/Xmap decoded path centers\n")
        for record in parsed["records"]:
            x, y, z = record["cell_center"]
            handle.write(f"v {x:.9g} {y:.9g} {z:.9g}\n")
        if len(parsed["records"]) >= 2:
            handle.write("l " + " ".join(str(index + 1) for index in range(len(parsed["records"]))) + "\n")
    route_csv = output_base.with_suffix(output_base.suffix + ".route_source.csv")
    with route_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["sequence_index", "record_index", "slot", "fallback_origin", "x", "y", "z"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for item in parsed["runtime_route_source"]:
            x, y, z = item["point"]
            writer.writerow({
                "sequence_index": item["sequence_index"], "record_index": item["record_index"],
                "slot": "" if item["slot"] is None else item["slot"],
                "fallback_origin": item["fallback_origin"], "x": x, "y": y, "z": z,
            })
    route_obj = output_base.with_suffix(output_base.suffix + ".route_source.obj")
    with route_obj.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("# SIIG runtime route source control points (not the resampled spline)\n")
        for item in parsed["runtime_route_source"]:
            x, y, z = item["point"]
            handle.write(f"v {x:.9g} {y:.9g} {z:.9g}\n")
        if len(parsed["runtime_route_source"]) >= 2:
            handle.write("l " + " ".join(str(i + 1) for i in range(len(parsed["runtime_route_source"]))) + "\n")
    parsed["outputs"] = {
        "json": json_path.name,
        "path_csv": path_csv.name,
        "placements_csv": placement_csv.name,
        "path_obj": obj_path.name,
        "route_source_csv": route_csv.name,
        "route_source_obj": route_obj.name,
    }
    return parsed


def export_route_resample_bytes(
    data: bytes,
    output_base: Path,
    *,
    source_name: str = "",
    spacing: float,
) -> dict:
    """Export the executable-backed non-loop route resampler at fixed spacing.

    The source control points and initial FieldPos are decoded from a Bmap/Xmap
    stage3d table. SIIG can change spacing dynamically through SCROLL_02; this
    analysis exporter intentionally keeps spacing constant and states that scope
    in every output.
    """
    parsed = parse_stage3d_map_bytes(data, source_name=source_name)
    controls = [item["point"] for item in parsed["runtime_route_source"]]
    initial = parsed["initial_field_position"]
    if len(controls) < 3:
        raise FormatError(
            f"route resampling requires at least three runtime source points; found {len(controls)}"
        )
    if len(initial) != 3:
        raise FormatError("stage3d map does not provide an initial FieldPos")
    try:
        route = resample_route_constant_spacing(controls, initial, float(spacing))
    except ValueError as exc:
        raise FormatError(str(exc)) from exc
    route.update({
        "format": "SIIG_ROUTE_RESAMPLE",
        "source_name": Path(source_name).name if source_name else "",
        "source_stage3d_kind": parsed["stage_kind"],
        "initial_field_position_source": parsed["initial_field_position_source"],
        "source_rule": parsed["runtime_route_source_rule"],
        "evidence": {
            "retail_ps3_linear": "0x00158790",
            "retail_ps3_hermite": "0x00158A28",
            "retail_ps3_curve_setup": "0x00158D38",
            "retail_ps3_classifier": "0x00159298",
            "retail_ps3_advance": "0x00159560",
            "retail_ps3_initialization": "0x0015A338",
        },
    })
    output_base.parent.mkdir(parents=True, exist_ok=True)
    json_path = output_base.with_suffix(output_base.suffix + ".route_resample.json")
    csv_path = output_base.with_suffix(output_base.suffix + ".route_resample.csv")
    obj_path = output_base.with_suffix(output_base.suffix + ".route_resample.obj")
    write_json_private(json_path, route, ensure_ascii=False)
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["sample_index", "x", "y", "z", "segment_index", "segment_sample_index", "interpolation"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        segment_by_sample: dict[int, tuple[int, int, str]] = {}
        for segment in route["segments"]:
            start = int(segment["sample_start"])
            for local in range(int(segment["sample_count"])):
                segment_by_sample[start + local] = (
                    int(segment["segment_index"]), local, str(segment["interpolation"])
                )
        for index, point in enumerate(route["points"]):
            segment_index, local_index, interpolation = segment_by_sample.get(index, (-1, -1, ""))
            writer.writerow({
                "sample_index": index,
                "x": point[0], "y": point[1], "z": point[2],
                "segment_index": segment_index,
                "segment_sample_index": local_index,
                "interpolation": interpolation,
            })
    with obj_path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("# SIIG retail non-loop route resample at fixed spacing\n")
        handle.write(f"# spacing {route['spacing']:.9g}\n")
        handle.write("# Runtime SCROLL_02 spacing changes and loop wrapping are not modeled.\n")
        for x, y, z in route["points"]:
            handle.write(f"v {x:.9g} {y:.9g} {z:.9g}\n")
        if len(route["points"]) >= 2:
            handle.write("l " + " ".join(str(i + 1) for i in range(len(route["points"]))) + "\n")
    route["outputs"] = {"json": json_path.name, "csv": csv_path.name, "obj": obj_path.name}
    return route


def command_route_resample(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    candidates = [input_path] if input_path.is_file() else list(iter_candidate_files(input_path))
    success = 0
    skipped = 0
    failures = 0
    for path in candidates:
        name = path.name.lower()
        if not (
            re.fullmatch(r"[bx]map[^/]*\.bin", name)
            or re.fullmatch(r"map[45]_[^/]*\.bin", name)
        ):
            continue
        try:
            raw = path.read_bytes()
            source_info = parse_stage3d_map_bytes(raw, source_name=path.name)
            if source_info["runtime_route_source_point_count"] < 3:
                if input_path.is_file():
                    raise FormatError(
                        f"route resampling requires at least three runtime source points; "
                        f"found {source_info['runtime_route_source_point_count']}"
                    )
                print(
                    f"{path}: skipped (no resampleable runtime route; "
                    f"{source_info['runtime_route_source_point_count']} source point(s))"
                )
                skipped += 1
                continue
            route = export_route_resample_bytes(
                raw, output / path.name, source_name=path.name, spacing=args.spacing
            )
            print(
                f"{path}: {route['source_point_count']} source point(s) -> "
                f"{route['resampled_point_count']} resampled point(s), {len(route['segments'])} segment(s)"
            )
            success += 1
        except (FormatError, OSError, struct.error) as exc:
            print(f"warning: route resample failed for {path}: {exc}", file=sys.stderr)
            failures += 1
    if success == 0 and failures == 0:
        raise FormatError("no Bmap/Xmap/map4/map5 stage3d files found")
    print(f"completed: {success} route file(s), {skipped} skipped, {failures} failure(s)")
    return 0 if failures == 0 else 1



def command_camera_preset(args: argparse.Namespace) -> int:
    """Inspect one executable-backed retail camera preset semantically."""
    try:
        report = camera_preset_info(args.preset)
        if (args.runtime_x is None) != (args.runtime_y is None):
            raise FormatError("--runtime-x and --runtime-y must be supplied together")
        if args.runtime_x is not None:
            report["dynamic_local_x_response"] = dynamic_horizontal_offsets(
                report, args.runtime_x, args.runtime_y
            )
    except ValueError as exc:
        raise FormatError(str(exc)) from exc
    if args.output:
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        write_json_private(output, report, ensure_ascii=False)
        print(output)
    else:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


def command_pa_route_info(args: argparse.Namespace) -> int:
    """Report executable-backed PA-route gates, resources, and optional DAT boss correlations."""
    report = pa_route_reference_snapshot()
    report["toolkit_version"] = TOOLKIT_VERSION

    gate_values = (args.stage_id, args.state_218, args.state_21c)
    if any(value is not None for value in gate_values):
        if not all(value is not None for value in gate_values):
            raise FormatError("--stage-id, --state-218, and --state-21c must be supplied together")
        try:
            report["gate_evaluation"] = evaluate_pa_route_gate(
                args.build, stage_id=args.stage_id, state_218=args.state_218, state_21c=args.state_21c
            )
        except ValueError as exc:
            raise FormatError(str(exc)) from exc

    if args.camera_index is not None:
        try:
            report["camera_selection"] = pa_route_camera_selection(args.camera_index)
        except ValueError as exc:
            raise FormatError(str(exc)) from exc

    if args.input:
        dat_path = Path(args.input)
        parsed = parse_dat_bytes(dat_path.read_bytes())
        dat_report = analyze_pa_route_dat(parsed)
        dat_report["source"] = dat_path.name
        report["dat_analysis"] = dat_report

    if args.output:
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        write_json_private(output, report, ensure_ascii=False)
        print(output)
    else:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


def _scroll02_route_events(dat: dict, frame_multiplier: int) -> list[dict]:
    events: list[dict] = []
    for record in dat["records"]:
        if record["opcode"] != 0x006F:
            continue
        args = record["args_signed"]
        if len(args) < 2:
            raise FormatError(f"SCROLL_02 record {record['index']} has fewer than two arguments")
        y = int(args[1])
        events.append({
            "record_index": int(record["index"]),
            "authored_frame": int(record["absolute_frame"]),
            "script_x": int(args[0]),
            "script_y": y,
            "spacing_per_runtime_update": scroll02_spacing_from_script_y(y, frame_multiplier),
        })
    return events


def export_route_playback_bytes(
    stage_data: bytes,
    dat_data: bytes,
    output_base: Path,
    *,
    stage_source_name: str,
    dat_source_name: str,
    frame_multiplier: int = 2,
    loop: bool = False,
    start_frame: int = 0,
    end_frame: int | None = None,
    max_updates: int = 2_000_000,
) -> dict:
    """Couple a stage3d route to a DAT SCROLL_02 spacing timeline.

    This reproduces the executable-backed route position/source-index state
    machine but deliberately does not infer when a particular route object is
    created by gameplay. ``start_frame`` is therefore explicit. The latest
    SCROLL_02 value at or before that frame becomes the route's initial spacing.
    """
    if frame_multiplier not in (1, 2):
        raise FormatError("frame multiplier must be 1 or 2")
    if start_frame < 0:
        raise FormatError("start frame must be non-negative")
    if max_updates <= 0:
        raise FormatError("max updates must be greater than zero")
    stage = parse_stage3d_map_bytes(stage_data, source_name=stage_source_name)
    controls = [item["point"] for item in stage["runtime_route_source"]]
    initial = stage["initial_field_position"]
    if len(controls) < 3:
        raise FormatError(f"route playback requires at least three runtime source points; found {len(controls)}")
    if len(initial) != 3:
        raise FormatError("stage3d map does not provide an initial FieldPos")
    dat = parse_dat_bytes(dat_data)
    if end_frame is None:
        end_frame = int(dat["duration_frames"])
    if end_frame < start_frame:
        raise FormatError("end frame must be greater than or equal to start frame")
    events = _scroll02_route_events(dat, frame_multiplier)

    initial_spacing = 0.0
    initial_event: dict | None = None
    for event in events:
        if event["authored_frame"] <= start_frame:
            initial_spacing = float(event["spacing_per_runtime_update"])
            initial_event = event
        else:
            break

    runtime_events: dict[int, list[dict]] = {}
    for event in events:
        if event["authored_frame"] <= start_frame or event["authored_frame"] > end_frame:
            continue
        local_update = (int(event["authored_frame"]) - start_frame) * frame_multiplier
        item = dict(event)
        item["local_runtime_update"] = local_update
        runtime_events.setdefault(local_update, []).append(item)

    state = RouteRuntimeState(controls, initial, initial_spacing, loop=loop)
    requested_updates = (end_frame - start_frame + 1) * frame_multiplier
    update_limit = min(requested_updates, max_updates)
    rows: list[dict] = []
    applied_events: list[dict] = []
    termination = "end_frame"
    for local_update in range(update_limit):
        new_spacing: float | None = None
        for event in runtime_events.get(local_update, []):
            new_spacing = float(event["spacing_per_runtime_update"])
            applied_events.append(event)
        position = state.step(new_spacing)
        rows.append({
            "local_runtime_update": local_update,
            "authored_frame": start_frame + (local_update / frame_multiplier),
            "x": position[0], "y": position[1], "z": position[2],
            "spacing": state.spacing,
            "interpolation": state.interpolation,
            "source_current_counter": state.current_counter,
            "source_next_counter": state.next_counter,
            "source_lookahead_counter": state.lookahead_counter,
            "generated_sample_index": state.sample_index,
            "generated_sample_count": len(state.generated_samples),
            "spacing_event": new_spacing is not None,
            "consumed_interpolation": state.last_consumed_interpolation,
            "route_pitch_radians": state.pitch,
            "route_yaw_radians": state.yaw,
            "route_roll_radians": state.roll,
            "route_orientation_updates": state.orientation_update_count,
            "route_m00": state.orientation_matrix[0][0],
            "route_m01": state.orientation_matrix[0][1],
            "route_m02": state.orientation_matrix[0][2],
            "route_m10": state.orientation_matrix[1][0],
            "route_m11": state.orientation_matrix[1][1],
            "route_m12": state.orientation_matrix[1][2],
            "route_m20": state.orientation_matrix[2][0],
            "route_m21": state.orientation_matrix[2][1],
            "route_m22": state.orientation_matrix[2][2],
        })
        if state.finished and not loop:
            termination = "route_finished"
            break
    else:
        if requested_updates > max_updates:
            termination = "max_updates"

    report = {
        "format": "SIIG_ROUTE_DAT_PLAYBACK",
        "scope": "position_source_index_and_procedural_orientation_with_dat_scroll02_spacing",
        "stage_source_name": Path(stage_source_name).name,
        "dat_source_name": Path(dat_source_name).name,
        "frame_multiplier": frame_multiplier,
        "runtime_updates_per_authored_frame": frame_multiplier,
        "logical_authoring_hz": 30,
        "runtime_updates_per_second": 30 * frame_multiplier,
        "loop": bool(loop),
        "start_authored_frame": start_frame,
        "end_authored_frame": end_frame,
        "initial_field_position": list(initial),
        "initial_field_position_source": stage["initial_field_position_source"],
        "source_point_count": len(controls),
        "scroll02_event_count": len(events),
        "initial_scroll02_event": initial_event,
        "initial_spacing": initial_spacing,
        "applied_scroll02_events": applied_events,
        "updates_emitted": len(rows),
        "termination": termination,
        "final_state": state.snapshot(),
        "segment_builds": [
            {
                **build.__dict__,
                "start": list(build.start), "end": list(build.end),
                "direction_before_name": ROUTE_DIRECTION_NAMES[build.direction_before],
                "direction_after_name": ROUTE_DIRECTION_NAMES[build.direction_after],
            }
            for build in state.builds
        ],
        "evidence": {
            "retail_ps3_scroll02": "0x0014E408",
            "retail_ps3_route_advance": "0x00159560",
            "retail_ps3_route_initialization": "0x0015A338",
            "retail_ps3_route_orientation": "procedural orientation consumer traced from 0x00157A10",
        },
        "limitations": [
            "The caller must supply the route-to-DAT pairing; this command does not infer filename pairing.",
            "start_frame is the assumed route-object initialization frame; gameplay activation timing is not inferred.",
            "Procedural route orientation is modeled; field-model animation and other scenegraph side effects are not.",
            "Animated fld014/fld015 orientation mode is not modeled by route-playback.",
        ],
    }
    output_base.parent.mkdir(parents=True, exist_ok=True)
    json_path = output_base.with_suffix(output_base.suffix + ".route_playback.json")
    csv_path = output_base.with_suffix(output_base.suffix + ".route_playback.csv")
    write_json_private(json_path, report, ensure_ascii=False)
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = list(rows[0].keys()) if rows else [
            "local_runtime_update", "authored_frame", "x", "y", "z", "spacing",
            "interpolation", "source_current_counter", "source_next_counter",
            "source_lookahead_counter", "generated_sample_index", "generated_sample_count",
            "spacing_event",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    report["outputs"] = {"json": json_path.name, "csv": csv_path.name}
    return report


def command_route_playback(args: argparse.Namespace) -> int:
    stage_path = Path(args.stage3d)
    dat_path = Path(args.dat)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    report = export_route_playback_bytes(
        stage_path.read_bytes(), dat_path.read_bytes(), output / stage_path.name,
        stage_source_name=stage_path.name, dat_source_name=dat_path.name,
        frame_multiplier=args.frame_multiplier, loop=args.loop,
        start_frame=args.start_frame, end_frame=args.end_frame,
        max_updates=args.max_updates,
    )
    print(
        f"{stage_path.name} + {dat_path.name}: {report['updates_emitted']} update(s), "
        f"{len(report['segment_builds'])} segment build(s), {report['termination']}"
    )
    print(output)
    return 0

def export_route_camera_playback_files(
    stage_path: Path,
    dat_path: Path,
    output: Path,
    *,
    preset: int,
    runtime_x: float,
    runtime_y: float,
    frame_multiplier: int = 2,
    loop: bool = False,
    start_frame: int = 0,
    end_frame: int | None = None,
    max_updates: int = 2_000_000,
    emit_every: int = 1,
) -> dict:
    """Stream procedural route + camera world state without intermediate CSV I/O."""
    if not 0 <= int(preset) < 32:
        raise FormatError(f"camera preset index out of range: {preset}")
    if frame_multiplier not in (1, 2):
        raise FormatError("frame multiplier must be 1 or 2")
    if start_frame < 0:
        raise FormatError("start frame must be non-negative")
    if max_updates <= 0:
        raise FormatError("max updates must be greater than zero")
    if emit_every <= 0:
        raise FormatError("emit_every must be greater than zero")

    stage_data = stage_path.read_bytes()
    dat_data = dat_path.read_bytes()
    stage = parse_stage3d_map_bytes(stage_data, source_name=stage_path.name)
    controls = [item["point"] for item in stage["runtime_route_source"]]
    initial = stage["initial_field_position"]
    if len(controls) < 3:
        raise FormatError(f"route playback requires at least three runtime source points; found {len(controls)}")
    if len(initial) != 3:
        raise FormatError("stage3d map does not provide an initial FieldPos")
    dat = parse_dat_bytes(dat_data)
    if end_frame is None:
        end_frame = int(dat["duration_frames"])
    if end_frame < start_frame:
        raise FormatError("end frame must be greater than or equal to start frame")
    events = _scroll02_route_events(dat, frame_multiplier)

    initial_spacing = 0.0
    initial_event: dict | None = None
    for event in events:
        if event["authored_frame"] <= start_frame:
            initial_spacing = float(event["spacing_per_runtime_update"])
            initial_event = event
        else:
            break
    runtime_events: dict[int, list[dict]] = {}
    for event in events:
        if event["authored_frame"] <= start_frame or event["authored_frame"] > end_frame:
            continue
        local_update = (int(event["authored_frame"]) - start_frame) * frame_multiplier
        item = dict(event)
        item["local_runtime_update"] = local_update
        runtime_events.setdefault(local_update, []).append(item)

    state = RouteRuntimeState(controls, initial, initial_spacing, loop=loop)
    requested_updates = (end_frame - start_frame + 1) * frame_multiplier
    update_limit = min(requested_updates, max_updates)
    output.mkdir(parents=True, exist_ok=True)
    base = output / stage_path.name
    csv_path = base.with_suffix(base.suffix + ".route_camera_playback.csv")
    fields = [
        "local_runtime_update", "authored_frame", "field_x", "field_y", "field_z",
        "spacing", "spacing_event", "consumed_interpolation",
        "route_pitch_radians", "route_yaw_radians", "route_roll_radians",
        "route_orientation_updates",
        "eye_x", "eye_y", "eye_z", "target_x", "target_y", "target_z",
        "fov_degrees", "uniform_scene_view_scale",
    ]
    applied_events: list[dict] = []
    rows_emitted = 0
    updates_simulated = 0
    termination = "end_frame"
    preset_info = camera_preset_info(preset)
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for local_update in range(update_limit):
            new_spacing: float | None = None
            for event in runtime_events.get(local_update, []):
                new_spacing = float(event["spacing_per_runtime_update"])
                applied_events.append(event)
            position = state.step(new_spacing)
            updates_simulated = local_update + 1
            should_emit = (local_update % emit_every == 0)
            if state.finished and not loop:
                should_emit = True
            if should_emit:
                camera = camera_world_state(
                    preset_info, position, state.orientation_matrix,
                    runtime_x=runtime_x, runtime_y=runtime_y,
                )
                eye, target = camera["eye"], camera["target"]
                writer.writerow({
                    "local_runtime_update": local_update,
                    "authored_frame": start_frame + (local_update / frame_multiplier),
                    "field_x": position[0], "field_y": position[1], "field_z": position[2],
                    "spacing": state.spacing, "spacing_event": new_spacing is not None,
                    "consumed_interpolation": state.last_consumed_interpolation,
                    "route_pitch_radians": state.pitch, "route_yaw_radians": state.yaw,
                    "route_roll_radians": state.roll,
                    "route_orientation_updates": state.orientation_update_count,
                    "eye_x": eye[0], "eye_y": eye[1], "eye_z": eye[2],
                    "target_x": target[0], "target_y": target[1], "target_z": target[2],
                    "fov_degrees": camera["fov_degrees"],
                    "uniform_scene_view_scale": camera["uniform_scene_view_scale"],
                })
                rows_emitted += 1
            if state.finished and not loop:
                termination = "route_finished"
                break
        else:
            if requested_updates > max_updates:
                termination = "max_updates"

    report = {
        "format": "SIIG_ROUTE_CAMERA_PLAYBACK",
        "scope": "procedural_route_orientation_plus_procedural_camera_world_state",
        "stage_source_name": stage_path.name,
        "dat_source_name": dat_path.name,
        "camera_preset_index": int(preset),
        "runtime_x": float(runtime_x),
        "runtime_y": float(runtime_y),
        "frame_multiplier": frame_multiplier,
        "loop": bool(loop),
        "start_authored_frame": start_frame,
        "end_authored_frame": end_frame,
        "source_point_count": len(controls),
        "initial_field_position": list(initial),
        "initial_spacing": initial_spacing,
        "initial_scroll02_event": initial_event,
        "applied_scroll02_events": applied_events,
        "updates_simulated": updates_simulated,
        "rows_emitted": rows_emitted,
        "emit_every": emit_every,
        "termination": termination,
        "route_final_state": state.snapshot(),
        "segment_build_count": len(state.builds),
        "camera_preset": preset_info,
        "evidence": {
            "route_orientation": "retail PS3 procedural route orientation traced from 0x00157A10",
            "camera_eye_offset": "retail PS3 0x00157A10",
            "dynamic_response": "retail PS3 0x00157540",
        },
        "limitations": [
            "The camera preset index and runtime X/Y coordinates are caller supplied; activation/control timelines are not inferred.",
            "Animated camera GMX mode (cam1/int1) and animated field-model orientation (fld014/fld015) are not modeled.",
            "Fog values are reported by preset, but runtime fog-profile selection is not modeled.",
            "emit_every only decimates written rows; every runtime update is still simulated.",
        ],
    }
    json_path = base.with_suffix(base.suffix + ".route_camera_playback.json")
    report["outputs"] = {"json": json_path.name, "csv": csv_path.name}
    write_json_private(json_path, report, ensure_ascii=False)
    return report

def command_route_camera_playback(args: argparse.Namespace) -> int:
    stage_path = Path(args.stage3d)
    dat_path = Path(args.dat)
    report = export_route_camera_playback_files(
        stage_path, dat_path, Path(args.output),
        preset=args.preset, runtime_x=args.runtime_x, runtime_y=args.runtime_y,
        frame_multiplier=args.frame_multiplier, loop=args.loop,
        start_frame=args.start_frame, end_frame=args.end_frame,
        max_updates=args.max_updates, emit_every=args.emit_every,
    )
    print(
        f"{stage_path.name} + {dat_path.name} + camera preset {args.preset}: "
        f"{report['updates_simulated']} update(s), {report['rows_emitted']} row(s), {report['termination']}"
    )
    print(args.output)
    return 0


def command_stage3dmap(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        name = path.name.lower()
        if not (
            re.fullmatch(r"[bx]map[^/]*\.bin", name)
            or re.fullmatch(r"map[45]_[^/]*\.bin", name)
            or looks_like_stage3d_map(path.read_bytes())
        ):
            continue
        try:
            relative = path.relative_to(input_path) if input_path.is_dir() else Path(path.name)
            destination = output / relative.parent / relative.name
            meta = export_stage3d_map_bytes(path.read_bytes(), destination, source_name=path.name)
            print(
                f"{path}: {meta['active_records']}/{meta['capacity_records']} active 3D path records "
                f"-> {destination}.stage3d.json"
            )
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} Bmap/Xmap file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


STAGE_WALL_RECORD_SIZE = 0x14


def parse_stage_wall_table_bytes(data: bytes, *, source_name: str = "") -> dict:
    """Decode wall/Xwall and stage_generate name/count tables.

    All use char name[16] + be u32 value. For wall tables the value is a repeat
    count (the runtime clamps it to 16 before expanding the strip). For
    stage_generate.bin, non-zero values mark candidates eligible for selection.
    """
    if not data or len(data) % STAGE_WALL_RECORD_SIZE:
        raise FormatError(f"stage wall/generator table size is not a multiple of 20: {len(data)}")
    lower = Path(source_name).name.lower()
    table_kind = "generator_candidates" if lower == "stage_generate.bin" else "wall_strip"
    records: list[dict] = []
    for offset in range(0, len(data), STAGE_WALL_RECORD_SIZE):
        index = offset // STAGE_WALL_RECORD_SIZE
        name = _decode_fixed_ascii(data[offset : offset + 16], context=f"stage table record {index} name")
        value = be_u32(data, offset + 16)
        record = {"index": index, "model_name": name, "raw_value": value}
        if table_kind == "wall_strip":
            record.update({
                "repeat_count": min(value, 16),
                "repeat_count_clamped": value > 16,
                "used": bool(name) and name.lower() != "notuse",
                "model_file": f"{name}.gmx" if name and name.lower() != "notuse" else "",
            })
        else:
            record.update({
                "enabled_candidate": value != 0,
                "model_file": f"{name}.gmx" if value != 0 and name else "",
            })
        records.append(record)
    return {
        "format": "SIIG_STAGE_WALL_TABLE",
        "source_name": Path(source_name).name if source_name else "",
        "table_kind": table_kind,
        "record_size": STAGE_WALL_RECORD_SIZE,
        "record_count": len(records),
        "active_records": sum(
            1 for record in records
            if record.get("used", record.get("enabled_candidate", False))
        ),
        "expanded_repeat_count": (
            sum(record.get("repeat_count", 0) for record in records)
            if table_kind == "wall_strip" else None
        ),
        "records": records,
    }


def export_stage_wall_table_bytes(data: bytes, output_base: Path, *, source_name: str = "") -> dict:
    parsed = parse_stage_wall_table_bytes(data, source_name=source_name)
    output_base.parent.mkdir(parents=True, exist_ok=True)
    json_path = output_base.with_suffix(output_base.suffix + ".stagewall.json")
    csv_path = output_base.with_suffix(output_base.suffix + ".stagewall.csv")
    write_json_private(json_path, parsed, ensure_ascii=False)
    fields = (
        ["index", "model_name", "raw_value", "repeat_count", "repeat_count_clamped", "used", "model_file"]
        if parsed["table_kind"] == "wall_strip"
        else ["index", "model_name", "raw_value", "enabled_candidate", "model_file"]
    )
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(parsed["records"])
    parsed["outputs"] = {"json": json_path.name, "csv": csv_path.name}
    return parsed


def command_stagewall(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        lower = path.name.lower()
        if not (
            re.fullmatch(r"x?wall.*\.bin", lower)
            or lower == "stage_generate.bin"
        ):
            continue
        try:
            relative = path.relative_to(input_path) if input_path.is_dir() else Path(path.name)
            destination = output / relative.parent / relative.name
            meta = export_stage_wall_table_bytes(path.read_bytes(), destination, source_name=path.name)
            print(
                f"{path}: {meta['table_kind']}, {meta['active_records']}/{meta['record_count']} active "
                f"-> {destination}.stagewall.json"
            )
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} wall/generator table(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def looks_like_xenos_shader(data: bytes) -> bool:
    return len(data) >= 0x20 and (be_u32(data, 0) & XENOS_SHADER_MAGIC_MASK) == XENOS_SHADER_MAGIC


def parse_xenos_shader_bytes(data: bytes) -> dict:
    if not looks_like_xenos_shader(data):
        raise FormatError("input is not an SIIG Xbox 360 compiled shader blob")
    magic = be_u32(data, 0)
    microcode_offset = be_u32(data, 4)
    microcode_size = be_u32(data, 8)
    if microcode_offset < 0x20 or microcode_offset + microcode_size > len(data):
        raise FormatError(
            f"shader microcode range 0x{microcode_offset:X}+0x{microcode_size:X} exceeds 0x{len(data):X}"
        )
    strings: list[dict] = []
    for match in re.finditer(rb"[ -~]{4,}", data):
        text = match.group().decode("ascii", errors="strict")
        strings.append({"offset": match.start(), "value": text})
    profiles = [item["value"] for item in strings if re.fullmatch(r"[vp]s_\d+_\d+", item["value"])]
    compilers = [item["value"] for item in strings if re.fullmatch(r"\d+\.\d+\.\d+\.\d+", item["value"])]
    reserved_words = [be_u32(data, offset) for offset in range(0, min(0x20, len(data)), 4)]
    stage = "vertex" if magic & 1 else "pixel"
    return {
        "format": "XENOS_COMPILED_SHADER",
        "stage": stage,
        "magic": f"0x{magic:08X}",
        "size": len(data),
        "header_words_be": [f"0x{value:08X}" for value in reserved_words],
        "microcode_offset": microcode_offset,
        "microcode_size": microcode_size,
        "microcode_sha256": hashlib.sha256(
            data[microcode_offset : microcode_offset + microcode_size]
        ).hexdigest(),
        "metadata_offset": be_u32(data, 0x10),
        "descriptor_offset": be_u32(data, 0x18),
        "profiles": profiles,
        "compiler_versions": compilers,
        "printable_strings": strings,
        "instruction_set_note": "raw Xbox 360 Xenos microcode is preserved; ISA disassembly is not implemented",
    }


def export_xenos_shader_bytes(data: bytes, output_base: Path) -> dict:
    parsed = parse_xenos_shader_bytes(data)
    output_base.parent.mkdir(parents=True, exist_ok=True)
    json_path = output_base.with_suffix(output_base.suffix + ".shader.json")
    microcode_path = output_base.with_suffix(output_base.suffix + ".microcode.bin")
    write_json_private(json_path, parsed, ensure_ascii=False)
    start = parsed["microcode_offset"]
    microcode_path.write_bytes(data[start : start + parsed["microcode_size"]])
    parsed["outputs"] = {"json": json_path.name, "microcode": microcode_path.name}
    return parsed


def command_shader_info(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        try:
            data = path.read_bytes()
            if not looks_like_xenos_shader(data):
                continue
            relative = path.relative_to(input_path) if input_path.is_dir() else Path(path.name)
            destination = output / relative.parent / relative.name
            meta = export_xenos_shader_bytes(data, destination)
            print(
                f"{path}: {meta['stage']} shader, {meta['microcode_size']} microcode bytes "
                f"-> {destination}.shader.json"
            )
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} shader blob(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def command_col2png(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        if path.suffix.lower() != ".col":
            continue
        try:
            relative = path.relative_to(input_path) if input_path.is_dir() else Path(path.name)
            destination = output / relative.parent / f"{relative.name}.png"
            meta = export_col_png_bytes(path.read_bytes(), destination, invert=args.invert)
            print(f"{path}: {meta['width']}x{meta['height']} collision mask -> {destination}")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} COL file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def command_anm2csv(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        if path.suffix.lower() != ".anm":
            continue
        try:
            relative = path.relative_to(input_path) if input_path.is_dir() else Path(path.name)
            destination = output / relative.parent / f"{relative.name}.csv"
            meta = export_anm_csv_bytes(path.read_bytes(), destination)
            print(f"{path}: {meta['record_count']} ANM record(s) -> {destination}")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} ANM file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def _systemfont_crp_from_input(path: Path) -> bytes:
    data = maybe_decompress(path.read_bytes())
    if data.startswith(BBX_MAGIC):
        archive = BBXArchive.parse(data)
        matches = [
            archive.payload(entry)
            for entry in archive.entries
            if entry.name.lower().endswith(".crp") or looks_like_systemfont_crp(archive.payload(entry))
        ]
        if len(matches) != 1:
            raise FormatError(f"expected one systemfont CRP resource, found {len(matches)}")
        return matches[0]
    if looks_like_systemfont_crp(data):
        return data
    raise FormatError("input is not systemfont.bin or an encrypted systemfont.crp")


def command_font2png(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    encrypted = _systemfont_crp_from_input(input_path)
    decrypted = xor_systemfont_crp(encrypted)
    png_path = output / "systemfont_atlas.png"
    meta = export_tex_png_bytes(decrypted, png_path)
    meta.update(
        {
            "source_format": "SIIG systemfont CRP",
            "xor_key": "0xF1",
            "cell_width": 32,
            "cell_height": 32,
            "columns": 64,
            "rows": 106,
            "glyph_record_count": 6732,
        }
    )
    write_json_private(png_path.with_suffix(png_path.suffix + ".json"), meta)
    if args.write_decrypted_tex:
        (output / "systemfont_decrypted.tex").write_bytes(decrypted)
    print(f"{input_path}: decrypted XOR 0xF1 and exported {meta['width']}x{meta['height']} atlas -> {png_path}")
    return 0


def command_sanitize_json(args: argparse.Namespace) -> int:
    target = Path(args.input)
    if not target.exists():
        raise FormatError(f"input not found: {target}")
    files = [target] if target.is_file() else sorted(target.rglob("*.json"))
    changed = 0
    failed = 0
    for path in files:
        if path.suffix.lower() != ".json":
            continue
        try:
            original = path.read_text(encoding="utf-8")
            parsed = json.loads(original)
            sanitized = json.dumps(
                sanitize_json_value(parsed),
                ensure_ascii=False,
                indent=2,
            ) + "\n"
            if sanitized != original:
                if args.backup:
                    backup = path.with_suffix(path.suffix + ".bak")
                    if not backup.exists():
                        backup.write_text(original, encoding="utf-8")
                path.write_text(sanitized, encoding="utf-8")
                changed += 1
        except (OSError, json.JSONDecodeError) as exc:
            failed += 1
            print(f"warning: {path.name}: {scrub_private_text(exc)}", file=sys.stderr)
    print(f"sanitized: {changed} JSON file(s), {failed} failure(s)")
    return 1 if failed else 0


def command_scan(args: argparse.Namespace) -> int:
    path = Path(args.input)
    data = maybe_decompress(path.read_bytes())
    if data.startswith(BBX_MAGIC):
        archive = BBXArchive.parse(data)
        print(
            json.dumps(
                {
                    "format": "BBX",
                    "count": archive.count,
                    "mode": archive.mode,
                    "hash_seed": f"0x{archive.hash_seed:08X}",
                    "has_sorted_hash_index": bool(archive.sorted_index),
                    "entries": [asdict(e) for e in archive.entries],
                },
                indent=2,
            )
        )
        return 0
    if data.startswith(GMX_MAGIC):
        chunks = parse_gmx_chunks(data)
        arrays = [parse_gmx_array(c) for c in chunks if c.tag == "ARRY"]
        meshes = [parse_gmx_mesh(c) for c in chunks if c.tag == "MESH"]
        textures = [parse_gmx_texture_ref(c) for c in chunks if c.tag == "TXIF"]
        shaders = [parse_gmx_shader(c) for c in chunks if c.tag == "SHAD"]
        materials = [parse_gmx_material(c) for c in chunks if c.tag == "MTRL"]
        parents = [parse_gmx_parent_group(c) for c in chunks if c.tag == "PARE"]
        bones = [parse_gmx_bone(c) for c in chunks if c.tag == "BONE"]
        motions = [parse_gmx_motion(c) for c in chunks if c.tag == "MOTN"]
        animations = [parse_gmx_animation(c) for c in chunks if c.tag == "ANIM"]
        print(
            json.dumps(
                {
                    "format": "GMX",
                    "size": len(data),
                    "chunks": [{"offset": c.offset, "tag": c.tag, "size": c.size} for c in chunks],
                    "arrays": [
                        {
                            "index": a.array_index,
                            "semantic": a.semantic,
                            "slot": a.slot,
                            "components": a.components,
                            "gl_type": f"0x{a.gl_type:X}",
                            "count": a.count,
                        }
                        for a in arrays
                    ],
                    "meshes": [
                        {
                            "index": m.mesh_index,
                            "primitive_mode": f"0x{m.primitive_mode:X}",
                            "index_count": m.index_count,
                            "skin_index": m.skin_index,
                            "array_refs": m.array_refs,
                        }
                        for m in meshes
                    ],
                    "textures": [asdict(item) for item in textures],
                    "shaders": [asdict(item) for item in shaders],
                    "materials": [
                        {
                            "index": item.index,
                            "name": item.name,
                            "shader_index": item.shader_index,
                            "parameters": [asdict(parameter) for parameter in item.parameters],
                        }
                        for item in materials
                    ],
                    "hierarchy": [asdict(item) for item in parents],
                    "bones": [
                        {
                            "index": item.index,
                            "name": item.name,
                            "material_index": item.material_index,
                            "mesh_index": item.mesh_index,
                            "matrix": list(item.matrix),
                        }
                        for item in bones
                    ],
                    "motions": [asdict(item) for item in motions],
                    "animations": [
                        {
                            "index": item.index,
                            "target_bone": item.target_bone,
                            "channel_type": item.channel_type,
                            "frame_count": len(item.times),
                            "duration": item.times[-1] if item.times else 0.0,
                        }
                        for item in animations
                    ],
                },
                indent=2,
            )
        )
        return 0
    if (re.fullmatch(r"x?wall.*\.bin", path.name, flags=re.IGNORECASE) or path.name.lower() == "stage_generate.bin"):
        print(json.dumps(parse_stage_wall_table_bytes(data, source_name=path.name), indent=2))
        return 0
    if looks_like_xenos_shader(data):
        print(json.dumps(parse_xenos_shader_bytes(data), indent=2))
        return 0
    if path.suffix.lower() == ".anm":
        records = parse_anm_bytes(data)
        print(json.dumps({
            "format": "SIIG_ANM_RANGE_TABLE",
            "record_count": len(records),
            "group_count": 1 + sum(
                records[index]["model_name"] != records[index - 1]["model_name"]
                for index in range(1, len(records))
            ),
            "records": records,
        }, indent=2))
        return 0
    if re.fullmatch(r"[BX]map.*\.bin", path.name, flags=re.IGNORECASE) and looks_like_stage3d_map(data):
        print(json.dumps(parse_stage3d_map_bytes(data, source_name=path.name), indent=2))
        return 0
    if looks_like_xwb(data):
        xsb_path = path.with_suffix(".xsb")
        preliminary = parse_xwb(data)
        cue_names = parse_xsb_cue_names(
            xsb_path.read_bytes() if xsb_path.exists() else b"",
            len(preliminary.entries),
            preliminary.bank_name,
        )
        info = parse_xwb(data, cue_names)
        print(
            json.dumps(
                {
                    "format": "XACT_XWB",
                    "version": info.version,
                    "endian": info.endian,
                    "bank_name": info.bank_name,
                    "bank_flags": f"0x{info.bank_flags:08X}",
                    "alignment": info.alignment,
                    "stream_count": len(info.entries),
                    "entries": [asdict(entry) for entry in info.entries],
                },
                indent=2,
            )
        )
        return 0
    if data.startswith(MAP_MAGIC):
        parsed = parse_map_bytes(data)
        printable = {
            "format": parsed["format"],
            "layer_count": parsed["layer_count"],
            "layers": [
                {key: value for key, value in layer.items() if key != "cells"}
                for layer in parsed["layers"]
            ],
        }
        print(json.dumps(printable, indent=2))
        return 0
    if path.suffix.lower() == ".dat" or (len(data) >= 3 and data[0] == 1):
        try:
            parsed = parse_dat_bytes(data)
        except FormatError:
            parsed = None
        if parsed is not None:
            print(json.dumps(parsed, indent=2))
            return 0
    if looks_like_systemfont_crp(data):
        decrypted = xor_systemfont_crp(data)
        info = asdict(parse_tex(decrypted))
        info["texture_format"] = f"0x{info.pop('format'):X}"
        info["fetch_dwords"] = [f"0x{value:08X}" for value in info["fetch_dwords"]]
        info["swizzle"] = list(info["swizzle"])
        print(json.dumps({"format": "SIIG_SYSTEMFONT_CRP", "xor_key": "0xF1", **info}, indent=2))
        return 0
    if looks_like_tex(data):
        info = asdict(parse_tex(data))
        info["texture_format"] = f"0x{info.pop('format'):X}"
        info["fetch_dwords"] = [f"0x{value:08X}" for value in info["fetch_dwords"]]
        info["swizzle"] = list(info["swizzle"])
        print(json.dumps({"format": "TEX", "platform": "xbox360", **info}, indent=2))
        return 0
    if looks_like_ps3_tex(data):
        print(json.dumps({"format": "TEX", **asdict(parse_ps3_tex(data))}, indent=2))
        return 0
    raise FormatError("unrecognized input (not BBX, gzip->BBX, GMX, TEX, DAT, MAP, ANM, Bmap/Xmap, Xenos shader, XWB, or systemfont CRP)")



TOOLKIT_VERSION = "2.8.0-dev14"
NPD_MAGIC = b"NPD\x00"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_prefix(path: Path, size: int = 4) -> bytes:
    with Path(path).open("rb") as handle:
        return handle.read(size)


def _limits_from_args(args: argparse.Namespace) -> ExtractionLimits:
    return ExtractionLimits(
        max_files=int(getattr(args, "max_files", DEFAULT_EXTRACTION_LIMITS.max_files)),
        max_total_bytes=int(
            getattr(args, "max_total_bytes", DEFAULT_EXTRACTION_LIMITS.max_total_bytes)
        ),
        max_file_bytes=int(
            getattr(args, "max_file_bytes", DEFAULT_EXTRACTION_LIMITS.max_file_bytes)
        ),
    ).validate()


def _safe_extract_zip(
    zip_path: Path,
    destination: Path,
    *,
    limits: ExtractionLimits = DEFAULT_EXTRACTION_LIMITS,
    max_compression_ratio: int = 1000,
) -> dict:
    """Extract a ZIP without traversal, symlinks, duplicates, or zip bombs."""
    if max_compression_ratio < 1:
        raise FormatError("maximum ZIP compression ratio must be at least 1")
    limits = limits.validate()
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    extracted: list[dict] = []
    seen: dict[str, str] = {}
    with zipfile.ZipFile(zip_path) as archive:
        infos = archive.infolist()
        file_count = 0
        total_bytes = 0
        planned: list[tuple[zipfile.ZipInfo, Path, Path]] = []
        for info in infos:
            normalized = info.filename.replace("\\", "/")
            member = Path(normalized)
            if member.is_absolute() or not member.parts or ".." in member.parts:
                raise FormatError(f"unsafe ZIP member: {info.filename}")
            if info.flag_bits & 0x1:
                raise FormatError(f"encrypted ZIP member is unsupported: {info.filename}")
            unix_mode = (info.external_attr >> 16) & 0xFFFF
            if unix_mode and stat.S_ISLNK(unix_mode):
                raise FormatError(f"ZIP symbolic link is not allowed: {info.filename}")
            target = (destination / member).resolve()
            if root != target and root not in target.parents:
                raise FormatError(f"ZIP member escapes destination: {info.filename}")
            key = member.as_posix().rstrip("/").casefold()
            kind = "directory" if info.is_dir() else "file"
            previous = seen.get(key)
            if previous is not None:
                raise FormatError(
                    f"duplicate or colliding ZIP path {member.as_posix()} "
                    f"({previous} versus {kind})"
                )
            seen[key] = kind
            if info.is_dir():
                planned.append((info, member, target))
                continue
            file_count += 1
            if file_count > limits.max_files:
                raise FormatError(
                    f"ZIP exceeds file-count limit ({file_count} > {limits.max_files})"
                )
            if info.file_size > limits.max_file_bytes:
                raise FormatError(
                    f"ZIP member {info.filename} exceeds per-file limit "
                    f"({info.file_size} > {limits.max_file_bytes} bytes)"
                )
            total_bytes += info.file_size
            if total_bytes > limits.max_total_bytes:
                raise FormatError(
                    f"ZIP exceeds total extraction limit "
                    f"({total_bytes} > {limits.max_total_bytes} bytes)"
                )
            if info.file_size and info.compress_size == 0:
                raise FormatError(f"ZIP member has impossible zero compressed size: {info.filename}")
            if info.compress_size and info.file_size > info.compress_size * max_compression_ratio:
                raise FormatError(
                    f"ZIP member compression ratio exceeds limit: {info.filename} "
                    f"({info.file_size / info.compress_size:.1f}:1)"
                )
            planned.append((info, member, target))

        for info, member, target in planned:
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            temp = target.with_name(target.name + ".siig-part")
            temp.unlink(missing_ok=True)
            written = 0
            try:
                with archive.open(info, "r") as source, temp.open("wb") as output:
                    while True:
                        chunk = source.read(1024 * 1024)
                        if not chunk:
                            break
                        written += len(chunk)
                        if written > info.file_size or written > limits.max_file_bytes:
                            raise FormatError(f"ZIP member expanded beyond its declared size: {info.filename}")
                        output.write(chunk)
                if written != info.file_size:
                    raise FormatError(
                        f"ZIP member size mismatch for {info.filename}: "
                        f"declared {info.file_size}, extracted {written}"
                    )
                os.replace(temp, target)
            except Exception:
                temp.unlink(missing_ok=True)
                raise
            extracted.append({
                "path": member.as_posix(),
                "size": written,
                "compressed_size": info.compress_size,
                "crc32": f"{info.CRC:08X}",
            })

    return {
        "format": "ZIP",
        "files": len(extracted),
        "bytes_extracted": sum(item["size"] for item in extracted),
        "members": extracted,
        "limits": {
            "max_files": limits.max_files,
            "max_total_bytes": limits.max_total_bytes,
            "max_file_bytes": limits.max_file_bytes,
            "max_compression_ratio": max_compression_ratio,
        },
    }


def detect_game_platform(root: Path) -> tuple[str, Path]:
    executable_candidates = [path for path in root.rglob("*") if path.is_file()]
    xex_files = sorted(path for path in executable_candidates if path.name.lower() == "default.xex")
    eboot_files = sorted(path for path in executable_candidates if path.name.lower() == "eboot.bin")
    if xex_files and eboot_files:
        raise FormatError(
            "ambiguous input: both Xbox 360 default.xex and PS3 EBOOT.BIN were found"
        )
    if len(xex_files) > 1:
        names = ", ".join(path.parent.name or "." for path in xex_files[:5])
        raise FormatError(f"ambiguous input: multiple default.xex files were found ({names})")
    if len(eboot_files) > 1:
        names = ", ".join(path.parent.name or "." for path in eboot_files[:5])
        raise FormatError(f"ambiguous input: multiple EBOOT.BIN files were found ({names})")
    if xex_files:
        return "xbox360", xex_files[0].parent
    if eboot_files:
        eboot = eboot_files[0]
        # The main PS3 content is under NPUB.../USRDIR. Use the title directory
        # so metadata files such as PARAM.SFO are included in the inventory.
        return "ps3", eboot.parent.parent if eboot.parent.name.upper() == "USRDIR" else eboot.parent
    raise FormatError("could not detect Xbox 360 default.xex or PS3 EBOOT.BIN")


def _decrypted_sdat_lookup(search_roots: Sequence[Path]) -> dict[str, Path]:
    found: dict[str, Path] = {}
    for root in search_roots:
        if not root.exists():
            continue
        candidates = [root] if root.is_file() else root.rglob("*")
        for path in candidates:
            if not path.is_file():
                continue
            name = path.name.lower()
            if name.endswith(".bin.gz.dat"):
                found.setdefault(name, path)
    return found


def _archive_basename(name: str) -> str:
    lowered = name.lower()
    result = name
    for suffix in (".sdat", ".dat", ".gz", ".bin"):
        if result.lower().endswith(suffix):
            result = result[: -len(suffix)]
    return result or "archive"


def _copy_ready_file(path: Path, game_root: Path, output_root: Path) -> Path:
    try:
        relative = path.relative_to(game_root)
    except ValueError:
        relative = Path(path.name)
    target = output_root / "ready_files" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    return target


def _privacy_audit_json(root: Path) -> dict:
    suspicious: list[dict] = []
    drive_re = re.compile(r"(?i)(?<![A-Za-z0-9_:/])[A-Z]:[\\/]")
    for path in sorted(root.rglob("*.json")):
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        hits: list[str] = []
        if drive_re.search(text):
            hits.append("windows_absolute_path")
        # Avoid flagging game-internal /foo.bin strings; require two path components.
        if re.search(r'(?<![A-Za-z0-9_])/(?:[^/\s\"]+/){2,}[^/\s\"]*', text):
            hits.append("posix_absolute_path")
        if hits:
            suspicious.append({"file": path.relative_to(root).as_posix(), "issues": hits})
    return {"files_checked": len(list(root.rglob("*.json"))), "suspicious": suspicious}


def _write_rip_report(output_root: Path, report: dict) -> None:
    validation = output_root / "validation"
    validation.mkdir(parents=True, exist_ok=True)
    write_json_private(validation / "RIP_REPORT.json", report, ensure_ascii=False)
    lines = [
        "Space Invaders Infinity Gene full-game rip report",
        f"Toolkit: {report['toolkit_version']}",
        f"Platform: {report['platform']}",
        f"Input type: {report['source_kind']}",
        f"Outer-container files: {report.get('outer_container', {}).get('files', 0)}",
        f"Archives processed: {report['archives']['processed']}",
        f"Archives skipped: {report['archives']['skipped']}",
        f"Archives failed: {report['archives']['failed']}",
        f"Resources extracted: {report['archives']['resources']}",
        f"BBX hash mismatches: {report['archives']['hash_mismatches']}",
        f"PNG textures: {report['outputs']['png']}",
        f"glTF models: {report['outputs']['gltf']}",
        f"OBJ models: {report['outputs']['obj']}",
        f"WAV audio: {report['outputs']['wav']}",
        f"Ready files copied: {report['outputs']['ready_files']}",
        f"Internally decrypted PS3 SDAT files: {len(report['ps3_sdat'].get('internally_decrypted', []))}",
        f"Authenticated PS3 SDAT blocks: {report['ps3_sdat'].get('authenticated_blocks', 0)}",
        f"Fallback PS3 SDAT decryptions used: {len(report['ps3_sdat'].get('fallback_decrypted', []))}",
        f"Failed PS3 SDAT decryptions: {len(report['ps3_sdat'].get('failed_internal', []))}",
        f"Missing PS3 SDAT decryptions: {len(report['ps3_sdat']['missing'])}",
        f"Unsupported/retained resources: {len(report['unsupported'])}",
        f"Errors: {len(report['errors'])}",
        f"Privacy audit issues: {len(report['privacy_audit']['suspicious'])}",
        f"Elapsed seconds: {report.get('elapsed_seconds', 0)}",
        f"Stage explorer generated: {bool(report.get('stage_explorer', {}).get('generated'))}",
        f"Output manifest enabled: {bool(report.get('output_manifest', {}).get('enabled'))}",
    ]
    if report["ps3_sdat"]["missing"]:
        lines += ["", "PS3 SDAT files still requiring TrueAncestor decryption:"]
        lines += [f"- {item}" for item in report["ps3_sdat"]["missing"]]
    if report["errors"]:
        lines += ["", "Errors:"]
        lines += [f"- {item['file']}: {item['error']}" for item in report["errors"]]
    write_text_atomic(validation / "RIP_REPORT.txt", "\n".join(lines) + "\n", encoding="utf-8")


def build_output_manifest(root: Path) -> dict:
    """Hash a generated output tree using stable relative paths."""
    root = Path(root)
    if not root.is_dir():
        raise FormatError(f"output directory not found: {root}")
    excluded = {
        "validation/OUTPUT_MANIFEST.json",
        "validation/OUTPUT_MANIFEST.sha256",
    }
    files: list[dict] = []
    total = 0
    for path in sorted((item for item in root.rglob("*") if item.is_file()), key=lambda item: item.relative_to(root).as_posix().casefold()):
        relative = path.relative_to(root).as_posix()
        if relative in excluded or path.name.endswith(".siig-part"):
            continue
        size = path.stat().st_size
        total += size
        files.append({
            "path": relative,
            "size": size,
            "sha256": sha256_file(path),
        })
    return {
        "format": "SIIG_OUTPUT_MANIFEST",
        "schema_version": 1,
        "toolkit_version": TOOLKIT_VERSION,
        "file_count": len(files),
        "total_bytes": total,
        "files": files,
    }


def write_output_manifest(root: Path) -> dict:
    validation = Path(root) / "validation"
    validation.mkdir(parents=True, exist_ok=True)
    manifest = build_output_manifest(root)
    json_path = validation / "OUTPUT_MANIFEST.json"
    write_json_private(json_path, manifest, ensure_ascii=False)
    lines = [f"{row['sha256']}  {row['path']}" for row in manifest["files"]]
    text_path = validation / "OUTPUT_MANIFEST.sha256"
    write_text_atomic(text_path, "\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    return manifest


def verify_output_tree(root: Path, *, verify_hashes: bool = True) -> dict:
    root = Path(root)
    issues: list[dict] = []
    warnings: list[dict] = []
    report_path = root / "validation" / "RIP_REPORT.json"
    report = None
    if not report_path.is_file():
        issues.append({"kind": "missing_report", "path": "validation/RIP_REPORT.json"})
    else:
        try:
            report = json.loads(report_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            issues.append({"kind": "invalid_report", "path": "validation/RIP_REPORT.json", "error": str(exc)})
    privacy = _privacy_audit_json(root)
    for item in privacy["suspicious"]:
        issues.append({"kind": "privacy", **item})
    part_files = sorted(path.relative_to(root).as_posix() for path in root.rglob("*.siig-part"))
    for relative in part_files:
        issues.append({"kind": "partial_file", "path": relative})

    manifest_path = root / "validation" / "OUTPUT_MANIFEST.json"
    checked = 0
    if manifest_path.is_file():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            for row in manifest.get("files", []):
                relative = str(row.get("path", ""))
                path = root / Path(relative)
                if not path.is_file():
                    issues.append({"kind": "missing_file", "path": relative})
                    continue
                size = path.stat().st_size
                if size != int(row.get("size", -1)):
                    issues.append({
                        "kind": "size_mismatch",
                        "path": relative,
                        "expected": row.get("size"),
                        "actual": size,
                    })
                    continue
                if verify_hashes:
                    checked += 1
                    digest = sha256_file(path)
                    if digest.lower() != str(row.get("sha256", "")).lower():
                        issues.append({
                            "kind": "hash_mismatch",
                            "path": relative,
                            "expected": row.get("sha256"),
                            "actual": digest,
                        })
        except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
            issues.append({"kind": "invalid_manifest", "path": "validation/OUTPUT_MANIFEST.json", "error": str(exc)})
    else:
        warnings.append({"kind": "missing_manifest", "path": "validation/OUTPUT_MANIFEST.json"})

    if report:
        if report.get("archives", {}).get("failed"):
            warnings.append({"kind": "archive_failures", "count": report["archives"]["failed"]})
        if report.get("errors"):
            warnings.append({"kind": "reported_errors", "count": len(report["errors"])})
        if report.get("ps3_sdat", {}).get("missing"):
            warnings.append({"kind": "missing_ps3_sdat", "count": len(report["ps3_sdat"]["missing"])})

    return {
        "format": "SIIG_OUTPUT_VERIFICATION",
        "schema_version": 1,
        "toolkit_version": TOOLKIT_VERSION,
        "root": root.name,
        "hashes_checked": checked,
        "privacy_files_checked": privacy["files_checked"],
        "issues": issues,
        "warnings": warnings,
        "ok": not issues,
    }



def _outer_container_cache_path(input_path: Path, output_root: Path, input_kind: str) -> tuple[Path, dict]:
    """Return a content-addressed persistent staging path and its identity record."""
    stat_info = input_path.stat()
    digest = sha256_file(input_path)
    identity = {
        "schema_version": 1,
        "input_kind": input_kind,
        "input_sha256": digest,
        "input_size": stat_info.st_size,
    }
    cache_parent = output_root.parent / f".{output_root.name}.siig_outer_cache"
    cache_root = cache_parent / f"{input_kind}-{digest[:24]}"
    return cache_root, identity


def _load_outer_container_cache(cache_root: Path, identity: dict) -> Optional[tuple[Path, dict]]:
    meta_path = cache_root / "cache.json"
    content_root = cache_root / "content"
    if not meta_path.is_file() or not content_root.is_dir():
        return None
    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if any(meta.get(key) != value for key, value in identity.items()):
        return None
    outer = meta.get("outer_container")
    if not isinstance(outer, dict):
        return None
    expected_files = int(outer.get("files", 0))
    actual_files = sum(1 for item in content_root.rglob("*") if item.is_file())
    if expected_files and actual_files != expected_files:
        return None
    return content_root, outer


def _populate_outer_container_cache(
    input_path: Path,
    output_root: Path,
    input_kind: str,
    *,
    limits: ExtractionLimits,
    max_zip_ratio: int,
) -> tuple[Path, dict, bool]:
    cache_root, identity = _outer_container_cache_path(input_path, output_root, input_kind)
    cached = _load_outer_container_cache(cache_root, identity)
    if cached is not None:
        content_root, outer = cached
        return content_root, outer, True

    cache_root.parent.mkdir(parents=True, exist_ok=True)
    build_root = cache_root.parent / f".{cache_root.name}.building-{os.getpid()}-{time.time_ns()}"
    if build_root.exists():
        shutil.rmtree(build_root)
    content_root = build_root / "content"
    content_root.mkdir(parents=True, exist_ok=True)
    try:
        if input_kind == "zip":
            outer = _safe_extract_zip(
                input_path,
                content_root,
                limits=limits,
                max_compression_ratio=max_zip_ratio,
            )
        else:
            try:
                outer = unpack_outer_container(input_path, content_root, limits=limits)
            except ContainerError as exc:
                raise FormatError(str(exc)) from exc
        meta = dict(identity)
        meta["outer_container"] = outer
        write_json_private(build_root / "cache.json", meta, ensure_ascii=False)
        if cache_root.exists():
            shutil.rmtree(cache_root)
        os.replace(build_root, cache_root)
    except Exception:
        shutil.rmtree(build_root, ignore_errors=True)
        raise
    return cache_root / "content", outer, False


def command_rip_game(args: argparse.Namespace) -> int:
    started_at = time.perf_counter()
    input_path = Path(args.input)
    output_root = Path(args.output)
    if not input_path.exists():
        raise FormatError(f"input not found: {input_path}")
    if output_root.exists() and args.clean:
        shutil.rmtree(output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    limits = _limits_from_args(args)
    max_zip_ratio = int(getattr(args, "max_zip_ratio", 1000))

    temp_context: Optional[tempfile.TemporaryDirectory] = None
    outer_container: dict = {}
    try:
        input_kind = detect_container_kind(input_path)
        outer_cache_used = False
        if input_kind in ("zip", "stfs", "ps3_pkg") and args.resume and not getattr(args, "no_outer_cache", False):
            label = {
                "zip": "input ZIP",
                "stfs": "Xbox 360 STFS",
                "ps3_pkg": "PlayStation 3 PKG",
            }[input_kind]
            print(f"preparing cached {label}: {input_path.name}")
            staged_root, outer_container, outer_cache_used = _populate_outer_container_cache(
                input_path,
                output_root,
                input_kind,
                limits=limits,
                max_zip_ratio=max_zip_ratio,
            )
            source_kind = input_kind
            print(
                f"outer cache: {'reused' if outer_cache_used else 'created'}; "
                f"{outer_container.get('files', 0)} files, {outer_container.get('bytes_extracted', 0)} bytes"
            )
        elif input_kind == "zip":
            temp_context = tempfile.TemporaryDirectory(prefix="siig_rip_")
            staged_root = Path(temp_context.name)
            print(f"extracting input ZIP: {input_path.name}")
            outer_container = _safe_extract_zip(
                input_path,
                staged_root,
                limits=limits,
                max_compression_ratio=max_zip_ratio,
            )
            source_kind = "zip"
            print(
                f"outer ZIP: {outer_container.get('files', 0)} files, "
                f"{outer_container.get('bytes_extracted', 0)} bytes"
            )
        elif input_kind in ("stfs", "ps3_pkg"):
            temp_context = tempfile.TemporaryDirectory(prefix="siig_container_")
            staged_root = Path(temp_context.name)
            label = "Xbox 360 STFS" if input_kind == "stfs" else "PlayStation 3 PKG"
            print(f"unpacking {label}: {input_path.name}")
            try:
                outer_container = unpack_outer_container(input_path, staged_root, limits=limits)
            except ContainerError as exc:
                raise FormatError(str(exc)) from exc
            source_kind = input_kind
            print(
                f"outer container: {outer_container.get('files', 0)} files, "
                f"{outer_container.get('bytes_extracted', 0)} bytes"
            )
        elif input_kind == "directory":
            staged_root = input_path
            source_kind = "directory"
        else:
            raise FormatError(
                "rip-game input must be a game directory, ZIP, Xbox 360 STFS (CON/LIVE/PIRS), or PS3 PKG"
            )

        platform, game_root = detect_game_platform(staged_root)
        content_root = game_root / "USRDIR" if platform == "ps3" and (game_root / "USRDIR").is_dir() else game_root
        display_root = input_path.name if source_kind in ("stfs", "ps3_pkg") else game_root.name
        print(f"detected platform: {platform}; content root: {display_root}")

        decrypted_roots = [Path(value) for value in (args.ps3_sdat_dir or [])]
        # TrueAncestor outputs may also be placed inside or next to the selected input.
        decrypted_roots.extend([staged_root, input_path.parent])
        decrypted_lookup = _decrypted_sdat_lookup(decrypted_roots)

        report: dict = {
            "toolkit_version": TOOLKIT_VERSION,
            "platform": platform,
            "source_kind": source_kind,
            "outer_container": outer_container,
            "outer_cache": {"used": bool(outer_cache_used), "enabled": bool(args.resume and not getattr(args, "no_outer_cache", False))},
            "extraction_limits": {
                "max_files": limits.max_files,
                "max_total_bytes": limits.max_total_bytes,
                "max_file_bytes": limits.max_file_bytes,
                "max_zip_ratio": max_zip_ratio,
            },
            "game_root": display_root,
            "files_scanned": sum(1 for p in game_root.rglob("*") if p.is_file()),
            "archives": {"processed": 0, "skipped": 0, "failed": 0, "resources": 0, "hash_mismatches": 0},
            "ps3_sdat": {
                "internally_decrypted": [],
                "fallback_decrypted": [],
                "failed_internal": [],
                "decrypted_used": [],
                "missing": [],
                "authenticated_blocks": 0,
            },
            "outputs": {},
            "unsupported": [],
            "errors": [],
        }

        bbx_source_root = output_root / "decompressed_bbx"
        assets_root = output_root / "assets"
        localization_inputs: list[Path] = []
        systemfont_inputs: list[Path] = []
        x360_sound_inputs: list[Path] = []

        candidates = sorted(path for path in content_root.rglob("*") if path.is_file())
        for source in candidates:
            relative = source.relative_to(game_root)
            raw_head = _read_prefix(source, 4)
            lowered = source.name.lower()
            data: Optional[bytes] = None
            actual_source = source

            if raw_head == NPD_MAGIC:
                expected = source.name[:-5] + ".dat" if lowered.endswith(".sdat") else source.name + ".dat"
                internal_error = None
                try:
                    decrypted_bytes, sdat_report = decrypt_sdat_bytes(source)
                    decrypted_root = output_root / "decrypted_sdat" / relative.parent
                    decrypted_root.mkdir(parents=True, exist_ok=True)
                    decrypted_path = decrypted_root / expected
                    write_bytes_atomic(decrypted_path, decrypted_bytes)
                    actual_source = decrypted_path
                    report["ps3_sdat"]["internally_decrypted"].append({
                        "original": relative.as_posix(),
                        "decrypted": decrypted_path.relative_to(output_root).as_posix(),
                        "blocks": sdat_report.get("authenticated_blocks", 0),
                    })
                    report["ps3_sdat"]["decrypted_used"].append({
                        "original": relative.as_posix(),
                        "decrypted": decrypted_path.name,
                        "method": "internal_sdat",
                    })
                    report["ps3_sdat"]["authenticated_blocks"] += int(sdat_report.get("authenticated_blocks", 0))
                    data = maybe_decompress(decrypted_bytes)
                except Exception as exc:
                    internal_error = exc
                    replacement = decrypted_lookup.get(expected.lower())
                    if replacement is None:
                        report["ps3_sdat"]["failed_internal"].append({
                            "file": relative.as_posix(),
                            "error": scrub_private_text(exc),
                        })
                        report["ps3_sdat"]["missing"].append(relative.as_posix())
                        report["archives"]["skipped"] += 1
                        continue
                    actual_source = replacement
                    report["ps3_sdat"]["fallback_decrypted"].append({
                        "original": relative.as_posix(),
                        "decrypted": replacement.name,
                        "internal_error": scrub_private_text(internal_error),
                    })
                    report["ps3_sdat"]["decrypted_used"].append({
                        "original": relative.as_posix(),
                        "decrypted": replacement.name,
                        "method": "external_fallback",
                    })
                    try:
                        data = maybe_decompress(replacement.read_bytes())
                    except Exception as fallback_exc:
                        report["errors"].append({"file": relative.as_posix(), "error": scrub_private_text(fallback_exc)})
                        report["archives"]["failed"] += 1
                        continue
            elif raw_head[:2] == b"\x1F\x8B":
                try:
                    data = maybe_decompress(source.read_bytes())
                except Exception as exc:
                    report["errors"].append({"file": relative.as_posix(), "error": scrub_private_text(exc)})
                    report["archives"]["failed"] += 1
                    continue
            elif raw_head == BBX_MAGIC:
                data = source.read_bytes()
            else:
                continue

            if not data.startswith(BBX_MAGIC):
                continue

            archive_base = _archive_basename(source.name)
            relative_parent = relative.parent
            archive_out = assets_root / relative_parent / archive_base
            bbx_out = bbx_source_root / relative_parent / f"{archive_base}.bin"
            fingerprint = hashlib.sha256(data).hexdigest()
            conversion_profile = (
                f"toolkit={TOOLKIT_VERSION};sha256={fingerprint};gltf={int(not args.no_gltf)};"
                f"obj={int(bool(args.convert_obj))};tex={int(not args.no_textures)};flipv={int(bool(args.flip_v))}"
            )
            cache_path = archive_out / ".siig_source_state"
            if (
                args.resume
                and cache_path.exists()
                and cache_path.read_text(encoding="ascii", errors="ignore").strip() == conversion_profile
                and (archive_out / "manifest.json").exists()
            ):
                print(f"resume: unchanged archive skipped: {relative.as_posix()}")
                report["archives"]["skipped"] += 1
                try:
                    cached_manifest = json.loads((archive_out / "manifest.json").read_text(encoding="utf-8"))
                    report["archives"]["resources"] += int(cached_manifest.get("count", 0))
                    report["archives"]["hash_mismatches"] += sum(
                        1 for row in cached_manifest.get("entries", [])
                        if row.get("name") and row.get("hash_matches") is False
                    )
                except (OSError, json.JSONDecodeError, TypeError, ValueError):
                    pass
                if "message.bin" in lowered or "text.bin" in lowered:
                    localization_inputs.append(bbx_out if bbx_out.exists() else actual_source)
                if "systemfont.bin" in lowered:
                    systemfont_inputs.append(bbx_out if bbx_out.exists() else actual_source)
                if source.name.lower() == "sound.bin" and platform == "xbox360":
                    x360_sound_inputs.append(bbx_out if bbx_out.exists() else source)
                continue

            if archive_out.exists():
                shutil.rmtree(archive_out)
            archive_out.mkdir(parents=True, exist_ok=True)
            bbx_out.parent.mkdir(parents=True, exist_ok=True)
            bbx_out.write_bytes(data)
            try:
                result = extract_bbx_bytes(
                    data,
                    archive_out,
                    relative.as_posix(),
                    recursive=True,
                    convert_gmx=bool(args.convert_obj),
                    convert_gltf=not args.no_gltf,
                    convert_tex=not args.no_textures,
                    flip_v=bool(args.flip_v),
                )
                cache_path.write_text(conversion_profile + "\n", encoding="ascii")
                report["archives"]["processed"] += 1
                report["archives"]["resources"] += int(result.get("count", 0))
                report["archives"]["hash_mismatches"] += sum(
                    1 for row in result.get("entries", []) if row.get("name") and row.get("hash_matches") is False
                )
                print(f"{relative.as_posix()}: extracted {result['count']} resources")
            except Exception as exc:
                report["archives"]["failed"] += 1
                report["errors"].append({"file": relative.as_posix(), "error": scrub_private_text(exc)})
                print(f"ERROR {relative.as_posix()}: {exc}", file=sys.stderr)
                continue

            if "message.bin" in lowered or "text.bin" in lowered:
                localization_inputs.append(bbx_out)
            if "systemfont.bin" in lowered:
                systemfont_inputs.append(bbx_out)
            if source.name.lower() == "sound.bin" and platform == "xbox360":
                x360_sound_inputs.append(bbx_out)

        # Ready-to-use files are copied without conversion.
        ready_suffixes = {".wma", ".at3", ".png", ".sfo", ".xml"}
        copied_ready: list[str] = []
        for source in candidates:
            if source.suffix.lower() in ready_suffixes:
                target = _copy_ready_file(source, game_root, output_root)
                copied_ready.append(target.relative_to(output_root).as_posix())

        # Dedicated localization exports combine both language databases.
        localization_root = output_root / "localization"
        localization_results = 0
        for path in localization_inputs:
            try:
                decode_localization_file(path, localization_root)
                localization_results += 1
            except Exception as exc:
                report["errors"].append({"file": path.name, "error": scrub_private_text(exc)})

        # Dedicated system-font package, including the atlas and supplied glyph map.
        font_root = output_root / "systemfont"
        for path in systemfont_inputs[:1]:
            try:
                command_font2png(argparse.Namespace(input=str(path), output=str(font_root), write_decrypted_tex=False))
                toolkit_dir = Path(__file__).resolve().parent
                font_support = (
                    (toolkit_dir / "reference" / "systemfont" / "systemfont.fnt", "systemfont.fnt"),
                    (toolkit_dir / "reference" / "systemfont" / "systemfont_glyphs.csv", "systemfont_glyphs.csv"),
                    (toolkit_dir / "reference" / "systemfont" / "systemfont_metadata.json", "systemfont_metadata.json"),
                    (toolkit_dir / "docs" / "formats" / "SYSTEMFONT_NOTES.md", "SYSTEMFONT_NOTES.md"),
                )
                for source_meta, output_name in font_support:
                    if not source_meta.exists():
                        # Compatibility with v2.5.0-and-earlier development trees.
                        source_meta = toolkit_dir / output_name
                    if source_meta.exists():
                        shutil.copy2(source_meta, font_root / output_name)
            except Exception as exc:
                report["errors"].append({"file": path.name, "error": scrub_private_text(exc)})

        # Platform-native audio conversion. Xbox 360 uses XACT/XMA; PS3 uses
        # Sony 989SND/SCREAM SBlk v3 with PS-ADPCM streams. Both paths retain
        # the original extracted bank and write decoded PCM WAVs separately.
        if x360_sound_inputs and not args.no_audio:
            try:
                command_xact2wav(argparse.Namespace(
                    input=str(x360_sound_inputs[0]),
                    output=str(output_root / "audio" / "xact"),
                    ffmpeg=args.ffmpeg,
                    keep_xma=False,
                ))
            except Exception as exc:
                report["errors"].append({"file": x360_sound_inputs[0].name, "error": scrub_private_text(exc)})

        if platform == "ps3":
            banks = sorted(assets_root.rglob("*.bnk"))
            for bank_index, bank in enumerate(banks):
                if args.no_audio:
                    report["unsupported"].append({
                        "file": bank.relative_to(output_root).as_posix(),
                        "format": "Sony 989SND/SCREAM SBlk bank",
                        "note": "Audio conversion disabled with --no-audio; lossless bank retained.",
                    })
                    continue
                try:
                    bank_stem = _safe_audio_name(bank.stem)
                    audio_out = output_root / "audio" / "sony"
                    if len(banks) > 1:
                        audio_out = audio_out / f"{bank_index + 1:02d}_{bank_stem}"
                    manifest = export_sony_sblk_wav_file(bank, audio_out)
                    if int(manifest.get("decode_failures", 0)):
                        report["errors"].append({
                            "file": bank.relative_to(output_root).as_posix(),
                            "error": f"Sony SBlk decoded with {manifest['decode_failures']} failed stream(s)",
                        })
                except Exception as exc:
                    report["unsupported"].append({
                        "file": bank.relative_to(output_root).as_posix(),
                        "format": "Sony 989SND/SCREAM SBlk bank",
                        "note": "Built-in decode failed; lossless bank retained for vgmstream.",
                    })
                    report["errors"].append({
                        "file": bank.relative_to(output_root).as_posix(),
                        "error": scrub_private_text(exc),
                    })

        collision_converted = 0
        for col_path in sorted(assets_root.rglob("*.col")):
            try:
                export_col_png_bytes(
                    col_path.read_bytes(),
                    col_path.with_suffix(col_path.suffix + ".png"),
                )
                collision_converted += 1
            except Exception as exc:
                report["errors"].append({
                    "file": col_path.relative_to(output_root).as_posix(),
                    "error": scrub_private_text(exc),
                })

        anm_converted = 0
        for anm_path in sorted(assets_root.rglob("*.anm")):
            try:
                export_anm_csv_bytes(
                    anm_path.read_bytes(),
                    anm_path.with_suffix(anm_path.suffix + ".csv"),
                )
                anm_converted += 1
            except Exception as exc:
                report["errors"].append({
                    "file": anm_path.relative_to(output_root).as_posix(),
                    "error": scrub_private_text(exc),
                })

        stagewall_converted = 0
        stagewall_root = output_root / "structured" / "stagewall"
        structured_enabled = not getattr(args, "no_structured", False)
        for wall_path in (sorted(assets_root.rglob("*.bin")) if structured_enabled else []):
            lower = wall_path.name.lower()
            if not (re.fullmatch(r"x?wall.*\.bin", lower) or lower == "stage_generate.bin"):
                continue
            try:
                relative = wall_path.relative_to(assets_root)
                export_stage_wall_table_bytes(
                    wall_path.read_bytes(),
                    stagewall_root / relative.parent / relative.name,
                    source_name=wall_path.name,
                )
                stagewall_converted += 1
            except Exception as exc:
                report["errors"].append({
                    "file": wall_path.relative_to(output_root).as_posix(),
                    "error": scrub_private_text(exc),
                })

        stage3d_converted = 0
        stage3d_root = output_root / "structured" / "stage3d"
        for stage3d_path in (sorted(assets_root.rglob("*.bin")) if structured_enabled else []):
            if not (
                re.fullmatch(r"[BX]map.*\.bin", stage3d_path.name, flags=re.IGNORECASE)
                or re.fullmatch(r"map[45]_.*\.bin", stage3d_path.name, flags=re.IGNORECASE)
            ):
                continue
            try:
                relative = stage3d_path.relative_to(assets_root)
                export_stage3d_map_bytes(
                    stage3d_path.read_bytes(),
                    stage3d_root / relative.parent / relative.name,
                    source_name=stage3d_path.name,
                )
                stage3d_converted += 1
            except Exception as exc:
                report["errors"].append({
                    "file": stage3d_path.relative_to(output_root).as_posix(),
                    "error": scrub_private_text(exc),
                })

        shader_converted = 0
        shader_root = output_root / "structured" / "shaders"
        for shader_path in (sorted(path for path in assets_root.rglob("*") if path.is_file()) if structured_enabled else []):
            try:
                data = shader_path.read_bytes()
                if not looks_like_xenos_shader(data):
                    continue
                relative = shader_path.relative_to(assets_root)
                export_xenos_shader_bytes(data, shader_root / relative)
                shader_converted += 1
            except Exception as exc:
                report["errors"].append({
                    "file": shader_path.relative_to(output_root).as_posix(),
                    "error": scrub_private_text(exc),
                })

        dat_converted = 0
        dat_root = output_root / "structured" / "dat"
        for dat_path in (sorted(assets_root.rglob("*.dat")) if structured_enabled else []):
            try:
                relative = dat_path.relative_to(assets_root)
                export_dat_csv_bytes(
                    dat_path.read_bytes(),
                    dat_root / relative.parent / f"{relative.name}.csv",
                )
                dat_converted += 1
            except Exception as exc:
                report["errors"].append({
                    "file": dat_path.relative_to(output_root).as_posix(),
                    "error": scrub_private_text(exc),
                })

        map_converted = 0
        map_root = output_root / "structured" / "map"
        for map_path in (sorted(assets_root.rglob("*.map")) if structured_enabled else []):
            try:
                relative = map_path.relative_to(assets_root)
                export_map_png_bytes(
                    map_path.read_bytes(),
                    map_root / relative.parent / relative.name,
                )
                map_converted += 1
            except Exception as exc:
                report["errors"].append({
                    "file": map_path.relative_to(output_root).as_posix(),
                    "error": scrub_private_text(exc),
                })

        stageviz_result: dict = {}
        if not getattr(args, "no_stageviz", False):
            try:
                from siig_stageviz import build_stage_explorer

                stageviz_root = output_root / "stage_explorer"
                stage_manifest = build_stage_explorer(output_root, stageviz_root)
                stageviz_result = {
                    "generated": True,
                    "path": "stage_explorer/SIIG_Stage_Explorer.html",
                    "stages": stage_manifest.get("stage_count", 0),
                    "commands": sum(item.get("commands", 0) for item in stage_manifest.get("stages", [])),
                    "map_cells": sum(item.get("map_cells", 0) for item in stage_manifest.get("stages", [])),
                    "embedded_atlases": len(stage_manifest.get("embedded_atlases", [])),
                }
                print(
                    f"stage explorer: {stageviz_result['stages']} entries, "
                    f"{stageviz_result['commands']} commands"
                )
            except FormatError as exc:
                stageviz_result = {"generated": False, "reason": scrub_private_text(exc)}
                report["errors"].append({"file": "stage_explorer", "error": scrub_private_text(exc)})
            except Exception as exc:
                stageviz_result = {"generated": False, "reason": scrub_private_text(exc)}
                report["errors"].append({"file": "stage_explorer", "error": scrub_private_text(exc)})
        else:
            stageviz_result = {"generated": False, "reason": "disabled by --no-stageviz"}
        report["stage_explorer"] = stageviz_result

        asset_viewer_result: dict = {}
        if not getattr(args, "no_asset_viewer", False):
            try:
                from siig_asset_viewer import build_asset_viewer
                viewer_root = output_root / "asset_viewer"
                viewer_report = build_asset_viewer(
                    output_root,
                    viewer_root,
                    title=f"SIIG Asset Viewer — {display_root}",
                    hash_files=not getattr(args, "viewer_no_hash", False),
                    max_embed_bytes=max(0, int(getattr(args, "viewer_max_embed_mib", 0) * 1024 * 1024)),
                    max_text_preview_bytes=max(0, int(getattr(args, "viewer_max_text_preview_kib", 48) * 1024)),
                    page_size=max(24, int(getattr(args, "viewer_page_size", 96))),
                )
                asset_viewer_result = {
                    "generated": True,
                    "path": "asset_viewer/SIIG_Asset_Viewer.html",
                    "files": viewer_report.get("file_count", 0),
                    "thumbnails": viewer_report.get("thumbnail_count", 0),
                    "missing_previewable_thumbnails": viewer_report.get("missing_previewable_thumbnails", 0),
                    "html_bytes": viewer_report.get("html_bytes", 0),
                    "data_bytes": viewer_report.get("data_bytes", 0),
                    "linked_data_mode": viewer_report.get("linked_data_mode", False),
                }
                print(f"asset viewer: {asset_viewer_result['files']} indexed files")
            except Exception as exc:
                asset_viewer_result = {"generated": False, "reason": scrub_private_text(exc)}
                report["errors"].append({"file": "asset_viewer", "error": scrub_private_text(exc)})
        else:
            asset_viewer_result = {"generated": False, "reason": "disabled by --no-asset-viewer"}
        report["asset_viewer"] = asset_viewer_result

        report["outputs"] = {
            "png": len(list(output_root.rglob("*.png"))),
            "gltf": len(list(output_root.rglob("*.gltf"))),
            "obj": len(list(output_root.rglob("*.obj"))),
            "wav": len(list(output_root.rglob("*.wav"))),
            "wma": len(list(output_root.rglob("*.wma"))),
            "bnk": len(list(output_root.rglob("*.bnk"))),
            "collision_png": collision_converted,
            "anm_csv": anm_converted,
            "stage_wall_tables": stagewall_converted,
            "stage3d_maps": stage3d_converted,
            "shader_inventories": shader_converted,
            "dat_csv": dat_converted,
            "map_files": map_converted,
            "localization_archives": localization_results,
            "ready_files": len(copied_ready),
            "stage_explorer": int(bool(stageviz_result.get("generated"))),
            "asset_viewer": int(bool(asset_viewer_result.get("generated"))),
        }
        report["elapsed_seconds"] = round(time.perf_counter() - started_at, 3)
        report["privacy_audit"] = _privacy_audit_json(output_root)
        report["output_manifest"] = {
            "enabled": not getattr(args, "no_output_manifest", False),
            "file": "validation/OUTPUT_MANIFEST.json",
        }
        _write_rip_report(output_root, report)
        if not getattr(args, "no_output_manifest", False):
            write_output_manifest(output_root)

        print("\nFull-game rip complete")
        print(f"  platform: {platform}")
        print(f"  archives: {report['archives']['processed']} processed, {report['archives']['failed']} failed")
        print(f"  resources: {report['archives']['resources']}")
        print(f"  textures: {report['outputs']['png']} PNG")
        print(f"  models: {report['outputs']['gltf']} glTF")
        print(f"  audio: {report['outputs']['wav']} WAV, {report['outputs']['wma']} WMA retained")
        if stageviz_result.get("generated"):
            print(f"  stage explorer: {output_root / 'stage_explorer' / 'SIIG_Stage_Explorer.html'}")
        if asset_viewer_result.get("generated"):
            print(f"  asset viewer: {output_root / 'asset_viewer' / 'SIIG_Asset_Viewer.html'}")
        if report["output_manifest"].get("enabled"):
            print(f"  manifest: {output_root / 'validation' / 'OUTPUT_MANIFEST.json'}")
        print(f"  report: {output_root / 'validation' / 'RIP_REPORT.txt'}")
        return 1 if report["archives"]["failed"] or report["errors"] else 0
    finally:
        if temp_context is not None:
            temp_context.cleanup()


def command_sdat_decrypt(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output_path = Path(args.output) if args.output else input_path.with_suffix("").with_suffix(input_path.with_suffix("").suffix + ".dat")
    if not input_path.is_file():
        raise FormatError(f"SDAT not found: {input_path}")
    rap = getattr(args, "rap", None)
    if rap:
        rap_path = Path(rap)
        if not rap_path.is_file():
            raise FormatError(f"RAP not found: {rap_path}")
        if rap_path.stat().st_size != 16:
            raise FormatError("RAP must be exactly 16 bytes")
    try:
        report = decrypt_sdat_file(input_path, output_path)
    except SdatError as exc:
        raise FormatError(str(exc)) from exc
    print(f"SDAT: {input_path.name}")
    print(f"authenticated blocks: {report['authenticated_blocks']}")
    print(f"plaintext bytes: {report['plaintext_bytes']}")
    print(f"output: {output_path}")
    return 0


def command_unpack_container(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output_root = Path(args.output)
    if not input_path.exists() or not input_path.is_file():
        raise FormatError(f"container not found: {input_path}")
    kind = detect_container_kind(input_path)
    if kind not in ("stfs", "ps3_pkg"):
        raise FormatError("input is not an Xbox 360 STFS package or PlayStation 3 PKG")
    if output_root.exists() and args.clean:
        shutil.rmtree(output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    limits = _limits_from_args(args)
    try:
        manifest = unpack_outer_container(input_path, output_root, limits=limits)
    except ContainerError as exc:
        raise FormatError(str(exc)) from exc
    write_json_private(output_root / "SIIG_CONTAINER_MANIFEST.json", manifest, ensure_ascii=False)
    print(f"container: {manifest['format']}")
    print(f"files: {manifest['files']}")
    print(f"bytes: {manifest['bytes_extracted']}")
    print(f"output: {output_root}")
    return 0


def command_container_selftest(args: argparse.Namespace) -> int:
    if not aes_self_test():
        raise FormatError("AES-128 FIPS-197 self-test failed")
    print("AES-128 FIPS-197 self-test: PASS")
    print("Container parser import and magic detection: PASS")
    return 0


def _synthetic_bbx(name: str, payload: bytes, *, seed: int = 0) -> bytes:
    encoded = name.encode("utf-8") + b"\x00"
    name_offset = 0x30
    data_offset = (name_offset + len(encoded) + 0x0F) & ~0x0F
    output = bytearray(data_offset + len(payload))
    output[:4] = BBX_MAGIC
    struct.pack_into(">III", output, 4, 1, 2, seed & 0xFFFFFFFF)
    struct.pack_into(">4I", output, 0x20, data_offset, len(payload), name_offset, bbx_name_hash(name, seed))
    output[name_offset : name_offset + len(encoded)] = encoded
    output[data_offset:] = payload
    return bytes(output)


def run_selftest() -> dict:
    results: list[dict] = []

    def check(name: str, func) -> None:
        started = time.perf_counter()
        try:
            detail = func()
            results.append({
                "name": name,
                "status": "PASS",
                "seconds": round(time.perf_counter() - started, 6),
                "detail": detail or "",
            })
        except Exception as exc:
            results.append({
                "name": name,
                "status": "FAIL",
                "seconds": round(time.perf_counter() - started, 6),
                "detail": scrub_private_text(exc),
            })

    check("AES-128 FIPS-197", lambda: "known-answer vector" if aes_self_test() else (_ for _ in ()).throw(FormatError("AES vector mismatch")))

    def test_aes_decrypt() -> str:
        from siig_containers import _AES128
        aes = _AES128(bytes.fromhex("000102030405060708090A0B0C0D0E0F"))
        cipher = bytes.fromhex("69C4E0D86A7B0430D8CDB78070B4C55A")
        plain = bytes.fromhex("00112233445566778899AABBCCDDEEFF")
        if aes.decrypt_block(cipher) != plain or aes.encrypt_block(plain) != cipher:
            raise FormatError("AES encrypt/decrypt known-answer mismatch")
        return "encrypt and inverse-cipher vectors"

    check("AES-128 decrypt", test_aes_decrypt)

    def test_pkg_ctr_chunks() -> str:
        from siig_containers import _PkgDecryptor
        digest = bytes(range(16))
        riv = bytes(range(16, 32))
        crypt = _PkgDecryptor(True, digest, riv)
        source = bytes((index * 29 + 7) & 0xFF for index in range(257))
        whole = crypt.crypt(0, source)
        pieces = crypt.crypt(0, source[:31]) + crypt.crypt(31, source[31:173]) + crypt.crypt(173, source[173:])
        if pieces != whole or crypt.crypt(0, whole) != source:
            raise FormatError("PKG AES-CTR chunk/round-trip mismatch")
        return "unaligned chunking equals one-shot CTR and round-trips"

    check("PKG AES-CTR backend", test_pkg_ctr_chunks)

    def test_stfs_con_init() -> str:
        from siig_containers import _StfsReader
        with tempfile.TemporaryDirectory(prefix="siig_selftest_con_") as temp_dir:
            path = Path(temp_dir) / "synthetic.con"
            data = bytearray(0xC000)
            data[:4] = b"CON "
            struct.pack_into(">I", data, 0x340, 0xB000)
            volume = bytearray(0x24)
            volume[0] = 0x24
            volume[2] = 0
            struct.pack_into("<H", volume, 3, 1)
            volume[5:8] = b"\x00\x00\x00"
            struct.pack_into(">I", volume, 0x1C, 1)
            struct.pack_into(">I", volume, 0x20, 0)
            data[0x379:0x379 + 0x24] = volume
            struct.pack_into(">I", data, 0x3A9, 0)
            path.write_bytes(data)
            with _StfsReader(path) as reader:
                if reader.first_hash_table_address != 0xB000 or reader.package_sex != 1:
                    raise FormatError("CON first hash-table/package-sex initialization mismatch")
        return "CON transactional layout initializes after first hash-table address"

    check("STFS CON initialization", test_stfs_con_init)

    def test_sdat_auth() -> str:
        from siig_containers import _AES128
        from siig_npdrm import (
            SDAT_KEY, EDAT_KEY_0, FLAG_KEY_ENCRYPTED,
            decrypt_sdat_bytes,
        )
        def xor16(a: bytes, b: bytes) -> bytes:
            return bytes(x ^ y for x, y in zip(a, b))
        plain = gzip.compress(b"synthetic authenticated SIIG SDAT")
        dev_hash = bytes.fromhex("00112233445566778899AABBCCDDEEFF")
        digest = bytes.fromhex("102132435465768798A9BACBDCEDFE0F")
        root = xor16(dev_hash, SDAT_KEY)
        root_aes = _AES128(root)
        seed = dev_hash[:12] + struct.pack(">I", 0)
        generated_crypt = root_aes.encrypt_block(seed)
        generated_hash = root_aes.encrypt_block(generated_crypt)
        wrapper = _AES128(EDAT_KEY_0)
        crypt_key = wrapper.decrypt_block(generated_crypt)
        hash_key = wrapper.decrypt_block(generated_hash)
        padded = plain + b"\x00" * ((-len(plain)) & 15)
        enc = bytearray()
        prev = digest
        enc_aes = _AES128(crypt_key)
        for pos in range(0, len(padded), 16):
            block = xor16(padded[pos:pos + 16], prev)
            cipher = enc_aes.encrypt_block(block)
            enc.extend(cipher)
            prev = cipher
        digest20 = hmac.new(hash_key, bytes(enc), hashlib.sha1).digest()
        metadata = bytearray(0x20)
        metadata[0x10:0x14] = digest20[0x10:0x14]
        for i in range(16):
            metadata[i] = digest20[i] ^ metadata[16 + i]
        flags = 0x0100003C
        header = bytearray(0x100)
        header[:4] = NPD_MAGIC
        struct.pack_into(">III", header, 4, 3, 0, 0)
        header[0x40:0x50] = digest
        header[0x60:0x70] = dev_hash
        struct.pack_into(">IIQ", header, 0x80, flags, 0x4000, len(plain))
        with tempfile.TemporaryDirectory(prefix="siig_selftest_sdat_") as temp_dir:
            path = Path(temp_dir) / "test.sdat"
            path.write_bytes(bytes(header) + bytes(metadata) + bytes(enc))
            decoded, report = decrypt_sdat_bytes(path)
            if decoded != plain or report.get("authenticated_blocks") != 1:
                raise FormatError("synthetic SDAT decrypt/auth mismatch")
            damaged = bytearray(path.read_bytes())
            damaged[-1] ^= 1
            path.write_bytes(damaged)
            try:
                decrypt_sdat_bytes(path)
            except SdatError:
                pass
            else:
                raise FormatError("tampered SDAT was not rejected")
        return "encrypted-key HMAC-SHA1 block decrypts; tamper rejected"

    check("NPDRM SDAT authentication", test_sdat_auth)

    def test_psx_adpcm() -> str:
        silent = bytes((0x00, 0x00)) + (b"\x00" * 14)
        pcm = decode_psx_adpcm_mono(silent)
        if len(pcm) != 56 or pcm != b"\x00" * 56:
            raise FormatError("PSX ADPCM zero frame did not decode to 28 silent PCM16 samples")
        terminal = bytes((0x00, 0x07)) + (b"\xFF" * 14)
        if decode_psx_adpcm_mono(terminal) != b"\x00" * 56:
            raise FormatError("PSX ADPCM terminal frame was not rendered silent")
        return "16-byte frame -> 28 PCM16 samples; terminal frame silent"

    check("PSX ADPCM decoder", test_psx_adpcm)

    def test_dat() -> str:
        data = b"\x01\x00\x01" + b"\x02\x00\x05\x00\x8F"
        parsed = parse_dat_bytes(data)
        if parsed["entry_count"] != 1 or parsed["duration_frames"] != 5:
            raise FormatError("DAT parser returned unexpected timing")
        return "one command, absolute frame 5"

    check("DAT parser", test_dat)

    def test_route_runtime_state() -> str:
        # Signed divw semantics: -513 / 2 truncates toward zero to -256, not -257.
        if scroll02_spacing_from_script_y(512, 2) != 1.0:
            raise FormatError("SCROLL_02 positive spacing conversion mismatch")
        if scroll02_spacing_from_script_y(-513, 2) != -1.0:
            raise FormatError("SCROLL_02 signed truncation mismatch")

        linear = [(0, 0, 0), (10, 0, 0), (20, 0, 0), (30, 0, 0)]
        nonloop = RouteRuntimeState(linear, linear[0], 5.0, loop=False)
        for _ in range(12):
            nonloop.step()
            if nonloop.finished:
                break
        if not nonloop.finished or tuple(nonloop.current_position) != (20.0, 0.0, 0.0):
            raise FormatError("non-loop route did not stop before look-ahead tail point")
        if [b.endpoint_index for b in nonloop.builds[:2]] != [1, 2]:
            raise FormatError("non-loop endpoint sequence mismatch")

        looping = RouteRuntimeState(linear[:3], linear[0], 10.0, loop=True)
        for _ in range(5):
            looping.step()
        endpoints = [b.endpoint_index for b in looping.builds[:4]]
        if endpoints != [1, 2, 0, 1]:
            raise FormatError(f"loop route modulo endpoint sequence mismatch: {endpoints}")
        if looping.finished:
            raise FormatError("loop route unexpectedly terminated")

        rebuild = RouteRuntimeState(linear, linear[0], 2.0, loop=False)
        rebuild.step()
        rebuild.step(5.0)
        if rebuild.linear_spacing_rebuilds != 1:
            raise FormatError("linear spacing change did not rebuild remaining segment")
        if rebuild.builds[-1].reason != "linear_spacing_change" or rebuild.builds[-1].start != rebuild.current_position:
            raise FormatError("linear rebuild did not restart at current FieldPos")

        curved_points = [(0, 0, 0), (10, 10, 0), (20, 10, 0), (30, 10, 0)]
        curve = RouteRuntimeState(curved_points, curved_points[0], 2.0, loop=False)
        if curve.interpolation != "cubic_hermite":
            raise FormatError("synthetic diagonal segment did not select Hermite")
        before_builds = len(curve.builds)
        curve.step(5.0)
        if len(curve.builds) != before_builds or curve.linear_spacing_rebuilds != 0:
            raise FormatError("Hermite segment incorrectly rebuilt on spacing change")
        if curve.previous_spacing != 2.0:
            raise FormatError("Hermite path incorrectly updated previous-spacing state")
        return "signed spacing, non-loop tail, loop wrap, linear rebuild, and Hermite non-rebuild"

    check("Route runtime state machine", test_route_runtime_state)

    def test_route_dat_playback() -> str:
        records = []
        for z in (-10.0, -20.0, -30.0, -40.0):
            record = bytearray(STAGE3D_RECORD_SIZE)
            struct.pack_into(">3f", record, 0xD0, 0.0, 0.0, -1.0)
            struct.pack_into(">3f", record, 0xDC + 24, 0.0, 0.0, z)
            records.append(bytes(record))
        stage_data = b"".join(records) + bytes(STAGE3D_RECORD_SIZE)
        dat_data = (
            b"\x01\x00\x02" +
            bytes((4,)) + struct.pack(">4h", 0, 0x006F, 0, 512) +
            bytes((4,)) + struct.pack(">4h", 2, 0x006F, 0, 1024)
        )
        with tempfile.TemporaryDirectory(prefix="siig_selftest_route_dat_") as temp_dir:
            report = export_route_playback_bytes(
                stage_data, dat_data, Path(temp_dir) / "synthetic.bin",
                stage_source_name="Xmap1_1.bin", dat_source_name="stage.dat",
                frame_multiplier=2, start_frame=0, end_frame=10, max_updates=1000,
            )
            if report["initial_spacing"] != 1.0 or len(report["applied_scroll02_events"]) != 1:
                raise FormatError("DAT-coupled initial/subsequent SCROLL_02 schedule mismatch")
            event = report["applied_scroll02_events"][0]
            if event["local_runtime_update"] != 4 or event["spacing_per_runtime_update"] != 2.0:
                raise FormatError("DAT authored-frame to runtime-update conversion mismatch")
            if report["final_state"]["linear_spacing_rebuilds"] != 1:
                raise FormatError("DAT spacing event did not trigger the linear route rebuild")
            if not (Path(temp_dir) / "synthetic.bin.route_playback.csv").is_file():
                raise FormatError("route-playback CSV was not written")
        return "authored DAT frames -> runtime updates, initial spacing, and mid-segment SCROLL_02 rebuild"

    check("DAT-coupled route playback", test_route_dat_playback)

    def test_route_camera_playback() -> str:
        records = []
        for point in ((0.0,0.0,-10.0),(10.0,10.0,-20.0),(20.0,10.0,-30.0),(30.0,10.0,-40.0)):
            record = bytearray(STAGE3D_RECORD_SIZE)
            struct.pack_into(">3f", record, 0xD0, 0.0, 0.0, -1.0)
            struct.pack_into(">3f", record, 0xDC + 24, *point)
            records.append(bytes(record))
        stage_data = b"".join(records) + bytes(STAGE3D_RECORD_SIZE)
        dat_data = b"\x01\x00\x01" + bytes((4,)) + struct.pack(">4h", 0, 0x006F, 0, 512)
        with tempfile.TemporaryDirectory(prefix="siig_selftest_route_camera_") as temp_dir:
            stage_path = Path(temp_dir) / "Xmap1_1.bin"
            dat_path = Path(temp_dir) / "stage.dat"
            stage_path.write_bytes(stage_data)
            dat_path.write_bytes(dat_data)
            report = export_route_camera_playback_files(
                stage_path, dat_path, Path(temp_dir) / "out",
                preset=0, runtime_x=213.0, runtime_y=233.0,
                frame_multiplier=2, end_frame=8, max_updates=100,
            )
            if report["updates_simulated"] <= 0 or report["rows_emitted"] <= 0:
                raise FormatError("combined route-camera playback emitted no updates")
            csv_path = Path(temp_dir) / "out" / "Xmap1_1.bin.route_camera_playback.csv"
            if not csv_path.is_file():
                raise FormatError("combined route-camera CSV was not written")
        return "DAT route spacing + procedural orientation + explicit camera preset world-state export"

    check("Combined route-camera playback", test_route_camera_playback)

    def test_map() -> str:
        data = MAP_MAGIC + struct.pack(">III", 1, 2, 2) + bytes((0, 1, 0x41, 0x82))
        parsed = parse_map_bytes(data)
        layer = parsed["layers"][0]
        if layer["nonzero_cells"] != 3 or layer["width"] != 2 or layer["height"] != 2:
            raise FormatError("MAP parser returned unexpected dimensions/counts")
        return "tile IDs and X/Y bits preserved"

    check("MAP parser", test_map)

    def test_bbx() -> str:
        payload = MAP_MAGIC + struct.pack(">III", 1, 1, 1) + b"\x01"
        data = _synthetic_bbx("test.map", payload)
        archive = BBXArchive.parse(data)
        if archive.count != 1 or archive.entries[0].hash_matches is not True:
            raise FormatError("BBX hash or entry parse failed")
        if archive.payload(archive.entries[0]) != payload:
            raise FormatError("BBX payload mismatch")
        return "named entry and filename hash"

    check("BBX parser/hash", test_bbx)

    def test_bbx_repack() -> str:
        entries = [
            BBXBuildEntry("alpha.map", b"MAP\x00payload"),
            BBXBuildEntry("", b"unnamed", identifier=0x12345678),
            BBXBuildEntry("nested/path.tex", b"texture"),
        ]
        data = build_bbx_bytes(entries, mode=0, hash_seed=0x10203040)
        result = verify_bbx_build(data, entries, mode=0, hash_seed=0x10203040)
        if not result["ok"]:
            raise FormatError("BBX repacker round trip failed")
        archive = BBXArchive.parse(data)
        if archive.sorted_index != sorted((entry.identifier, entry.index) for entry in archive.entries):
            raise FormatError("BBX sorted hash index is not canonical")
        return "named/unnamed payloads, hashes, alignment, and sorted index"

    check("BBX repacker", test_bbx_repack)

    def test_anm_ranges() -> str:
        data = (
            b"model_a\0".ljust(16, b"\0") + struct.pack(">2fI", 0.0, 40.0, 1) +
            b"model_a\0".ljust(16, b"\0") + struct.pack(">2fI", 40.0, 80.0, 0)
        )
        records = parse_anm_bytes(data)
        if len(records) != 2 or records[1]["clip_index"] != 1 or not records[0]["loop"]:
            raise FormatError("ANM range/group parser mismatch")
        return "16-byte names, start/end frames, grouping, and loop flags"

    check("ANM range parser", test_anm_ranges)

    def test_stage_wall_table() -> str:
        data = (
            b"wall_a\0".ljust(16, b"\0") + struct.pack(">I", 3) +
            b"notuse\0".ljust(16, b"\0") + struct.pack(">I", 99)
        )
        parsed = parse_stage_wall_table_bytes(data, source_name="wall4_1.bin")
        if parsed["expanded_repeat_count"] != 19 or parsed["records"][1]["repeat_count"] != 16:
            raise FormatError("stage wall repeat/count parser mismatch")
        candidates = parse_stage_wall_table_bytes(
            b"bg_000\0".ljust(16, b"\0") + struct.pack(">I", 1),
            source_name="stage_generate.bin",
        )
        if not candidates["records"][0]["enabled_candidate"]:
            raise FormatError("stage generator enabled flag mismatch")
        return "20-byte names, wall repeat counts, clamp, and generator enable flags"

    check("Stage wall/generator table", test_stage_wall_table)

    def test_stage3d_map() -> str:
        record = bytearray(STAGE3D_RECORD_SIZE)
        record[:16] = b"wall_test\0".ljust(16, b"\0")
        struct.pack_into(">3f", record, 0x10, 1.0, 2.0, 3.0)
        struct.pack_into(">3f", record, 0x1C, 1.0, 2.0, 3.0)
        struct.pack_into(">3f", record, 0x28, 0.0, 90.0, 0.0)
        for slot in range(1, 4):
            base = slot * 0x34
            record[base : base + 16] = b"notuse\0".ljust(16, b"\0")
        struct.pack_into(">3f", record, 0xD0, 0.0, 0.0, -1.0)
        struct.pack_into(">3f", record, 0xDC + 0, 10.0, 0.0, 0.0)
        struct.pack_into(">3f", record, 0xDC + 24, 0.0, 0.0, -400.0)
        sentinel = bytes(STAGE3D_RECORD_SIZE)
        parsed = parse_stage3d_map_bytes(bytes(record) + sentinel, source_name="Xmap1_1.bin")
        first = parsed["records"][0]
        if parsed["active_records"] != 1 or first["cell_center"] != [0.0, 0.0, -400.0]:
            raise FormatError("Bmap/Xmap path reconstruction mismatch")
        if first["placements"][0]["model_file"] != "wall_test.gmx":
            raise FormatError("Bmap/Xmap placement decode mismatch")
        if first["placements"][0]["stored_scale"] != [1.0, 2.0, 3.0] or first["placements"][0]["runtime_scale"] != [5.0, 10.0, 15.0]:
            raise FormatError("Bmap/Xmap stored/runtime scale mismatch")
        if first["placements"][0]["rotation_degrees"] != [0.0, 90.0, 0.0]:
            raise FormatError("Bmap/Xmap rotation offset mismatch")
        if [item["slot"] for item in parsed["runtime_route_source"]] != [0, 2]:
            raise FormatError("Bmap/Xmap runtime route-source slot ordering mismatch")
        blank = bytearray(record)
        blank[0xDC:0x118] = bytes(0x3C)
        fallback = parse_stage3d_map_bytes(bytes(blank) + sentinel, source_name="Xmap1_1.bin")
        if fallback["runtime_route_source"][0]["point"] != [0.0, 0.0, 0.0] or not fallback["runtime_route_source"][0]["fallback_origin"]:
            raise FormatError("Bmap/Xmap runtime route-source origin fallback mismatch")
        return "0x118 record, corrected placement transforms, route-source slots, origin fallback, and sentinel"

    check("Bmap/Xmap parser", test_stage3d_map)

    def test_route_resampler() -> str:
        linear = resample_linear_segment((0.0, 0.0, 0.0), (0.0, 0.0, -30.0), 10.0)
        if linear != [(0.0, 0.0, -10.0), (0.0, 0.0, -20.0), (0.0, 0.0, -30.0)]:
            raise FormatError(f"route linear sampling mismatch: {linear}")
        if classify_route_curve((0.0, 0.0, -30.0)) or not classify_route_curve((10.0, 10.0, 0.0)):
            raise FormatError("route straight/curve classifier mismatch")
        if update_route_direction_state(0, (10.0, 0.0, 0.0)) != 2:
            raise FormatError("route direction-state transition mismatch")
        curve, state, m0, m1 = resample_curve_segment(
            (0.0, 0.0, 0.0), (12.0, 12.0, 0.0), (24.0, 12.0, 0.0), 3.0, 0
        )
        if state != 2 or not curve or curve[0] != (0.0, 0.0, 0.0) or curve[-1] != (12.0, 12.0, 0.0):
            raise FormatError("route Hermite endpoints/state mismatch")
        if m0 != (0.0, 0.0, 0.0) or m1 != (18.0, 0.0, 0.0):
            raise FormatError(f"route Hermite tangent mismatch: {m0}, {m1}")
        controls = [(0.0, 0.0, 0.0), (0.0, 0.0, -20.0), (20.0, 0.0, -20.0), (20.0, 0.0, -40.0)]
        route = resample_route_constant_spacing(controls, controls[0], 10.0)
        endpoints = [segment["source_endpoint_index"] for segment in route["segments"]]
        if endpoints != [1, 2]:
            raise FormatError(f"route non-loop source-index progression mismatch: {endpoints}")
        if route["untraversed_tail_source_points"] != [[20.0, 0.0, -40.0]]:
            raise FormatError("route final look-ahead point was incorrectly traversed")
        route2 = resample_route_constant_spacing(controls, (-10.0, 0.0, 0.0), 10.0)
        endpoints2 = [segment["source_endpoint_index"] for segment in route2["segments"]]
        if endpoints2[:2] != [0, 1]:
            raise FormatError(f"route non-equal FieldPos initialization mismatch: {endpoints2}")
        return "linear write-after-step, classifier, six-state tangents, Hermite endpoints, and non-loop source-index tail"

    check("Retail route resampler", test_route_resampler)

    def test_gmx_track_export() -> str:
        # Build only the two chunk types needed by the track exporter. Chunk size includes the 8-byte tag/size prefix.
        bone = bytearray(0x80)
        bone[0:4] = b"BONE"; struct.pack_into(">I", bone, 4, 0x80); struct.pack_into(">H", bone, 8, 0); bone[0x10:0x14] = b"cam1"
        struct.pack_into(">16f", bone, 0x30, 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
        anim_size = 0x20 + 2 * 4 + 2 * 16 * 4
        anim = bytearray(anim_size)
        anim[0:4] = b"ANIM"; struct.pack_into(">I", anim, 4, anim_size); struct.pack_into(">I", anim, 8, 0);
        struct.pack_into(">IIII", anim, 0x10, 0, 12, 2, 16)
        struct.pack_into(">2f", anim, 0x20, 0.0, 1.0/24.0)
        struct.pack_into(">16f", anim, 0x28, 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
        struct.pack_into(">16f", anim, 0x68, 1,0,0,2, 0,1,0,3, 0,0,1,4, 0,0,0,1)
        root = bytearray(0x30)
        root[0:4] = GMX_MAGIC
        struct.pack_into(">I", root, 4, 0x30)
        struct.pack_into(">I", root, 0x0C, len(root) + len(bone) + len(anim))
        with tempfile.TemporaryDirectory(prefix="siig_selftest_gmxtrack_") as temp_dir:
            manifest = export_gmx_tracks_bytes(bytes(root + bone + anim), Path(temp_dir), source_name="camera_test.gmx")
            if manifest["track_count"] != 1 or manifest["tracks"][0]["sample_count"] != 2:
                raise FormatError("GMX track manifest mismatch")
            track_manifest = manifest["tracks"][0]
            if track_manifest["runtime_clock_hz"] != 30.0:
                raise FormatError("GMX runtime matrix clock mismatch")
            if abs(track_manifest["runtime_last_sample_seconds"] - (1.0 / 30.0)) > 1e-8:
                raise FormatError("GMX runtime key time mismatch")
            if abs(track_manifest["raw_observed_sample_rate_hz"] - 24.0) > 0.01:
                raise FormatError("GMX raw authoring cadence mismatch")
            csv_text = (Path(temp_dir) / manifest["tracks"][0]["csv"]).read_text(encoding="utf-8-sig")
            if ",2.0,3.0,4.0," not in csv_text.replace("2,3,4", "2.0,3.0,4.0"):
                # Parse structurally instead of relying on formatting if the simple check does not match.
                rows = list(csv.DictReader(csv_text.splitlines()))
                if float(rows[-1]["translation_x"]) != 2.0 or float(rows[-1]["translation_y"]) != 3.0 or float(rows[-1]["translation_z"]) != 4.0:
                    raise FormatError("GMX track translation decomposition mismatch")
            rows = list(csv.DictReader(csv_text.splitlines()))
            if abs(float(rows[-1]["runtime_seconds_30hz"]) - 1.0/30.0) > 1e-8:
                raise FormatError("GMX track CSV runtime time mismatch")
            if abs(float(rows[-1]["raw_authoring_time"]) - 1.0/24.0) > 1e-8:
                raise FormatError("GMX track CSV raw authoring time mismatch")
            gltf_path = Path(temp_dir) / "camera_test.gltf"
            export_gmx_gltf_bytes(bytes(root + bone + anim), gltf_path)
            gltf_doc = json.loads(gltf_path.read_text(encoding="utf-8"))
            anim_doc = gltf_doc["animations"][0]
            time_accessor = gltf_doc["accessors"][anim_doc["samplers"][0]["input"]]
            if abs(float(time_accessor["max"][0]) - 1.0/30.0) > 1e-8:
                raise FormatError("glTF animation input did not use the 30 Hz runtime key clock")
            if abs(float(anim_doc["extras"]["rawAuthoringTimeEnd"]) - 1.0/24.0) > 1e-8:
                raise FormatError("glTF raw authoring time metadata mismatch")
        return "matrix tracks/glTF use 30 Hz runtime indexing while preserving raw authoring times"

    check("GMX animation-track exporter", test_gmx_track_export)

    def _synthetic_matrix_anim_gmx(target_specs: list[tuple[str, int]]) -> bytes:
        chunks: list[bytes] = []
        for bone_index, (name, frame_count) in enumerate(target_specs):
            bone = bytearray(0x80)
            bone[0:4] = b"BONE"; struct.pack_into(">I", bone, 4, 0x80); struct.pack_into(">H", bone, 8, bone_index)
            encoded = name.encode("ascii")[:0x20]; bone[0x10:0x10+len(encoded)] = encoded
            struct.pack_into(">16f", bone, 0x30, 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
            chunks.append(bytes(bone))
            anim_size = 0x20 + frame_count * 4 + frame_count * 16 * 4
            anim = bytearray(anim_size)
            anim[0:4] = b"ANIM"; struct.pack_into(">I", anim, 4, anim_size); struct.pack_into(">I", anim, 8, bone_index << 16)
            struct.pack_into(">IIII", anim, 0x10, bone_index, 12, frame_count, 16)
            for frame in range(frame_count):
                struct.pack_into(">f", anim, 0x20 + frame*4, frame / 24.0)
            values_offset = 0x20 + frame_count*4
            for frame in range(frame_count):
                tx = float(frame); ty = float(bone_index * 10); tz = float(-frame)
                struct.pack_into(">16f", anim, values_offset + frame*0x40, 1,0,0,tx, 0,1,0,ty, 0,0,1,tz, 0,0,0,1)
            chunks.append(bytes(anim))
        root = bytearray(0x30); root[0:4] = GMX_MAGIC; struct.pack_into(">I", root, 4, 0x30)
        struct.pack_into(">I", root, 0x0C, len(root) + sum(map(len, chunks)))
        return bytes(root) + b"".join(chunks)

    def test_camera_animation_runtime() -> str:
        data = _synthetic_matrix_anim_gmx([("cam1", 300), ("int1", 300)])
        with tempfile.TemporaryDirectory(prefix="siig_selftest_camanim_") as temp_dir:
            out = Path(temp_dir) / "cam.csv"
            report = export_camera_animation_bytes(data, out, field_pos=(10.0, 20.0, 30.0), frame_multiplier=2)
            if report["runtime_updates_simulated"] != 400 or report["distinct_logical_frames"] != 200:
                raise FormatError("animated camera 200-frame controller length mismatch")
            rows = list(csv.DictReader(out.read_text(encoding="utf-8-sig").splitlines()))
            if [int(rows[i]["logical_frame"]) for i in range(4)] != [0, 0, 1, 1]:
                raise FormatError("animated camera frame-multiplier sampling mismatch")
            if int(rows[-1]["logical_frame"]) != 199:
                raise FormatError("animated camera incorrectly reached descriptor frame 200")
            if float(rows[2]["eye_x"]) != 11.0 or float(rows[2]["target_y"]) != 30.0:
                raise FormatError("animated camera FieldPos translation mismatch")
        return "cam1/int1 frames 0..199, 1/frame-multiplier clock, FieldPos offset"

    check("Animated camera runtime", test_camera_animation_runtime)

    def test_field_animation_runtime() -> str:
        data = _synthetic_matrix_anim_gmx([("fld014", 1440)])
        with tempfile.TemporaryDirectory(prefix="siig_selftest_fieldanim_") as temp_dir:
            out = Path(temp_dir) / "field.csv"
            report = export_field_animation_bytes(data, out, emit_every=1440)
            if report["descriptor"]["loop"] is not True or report["endpoint_sample_index"] != 0:
                raise FormatError("fld014 loop descriptor/sample wrap mismatch")
            rows = list(csv.DictReader(out.read_text(encoding="utf-8-sig").splitlines()))
            if [int(row["logical_frame"]) for row in rows] != [0, 1440]:
                raise FormatError("fld014 descriptor endpoint export mismatch")
            if any(int(row["sample_index"]) != 0 for row in rows):
                raise FormatError("fld014 endpoint did not modulo-wrap to matrix 0")
        return "fld014 frame 1440 wraps to sample 0 under loop descriptor"

    check("Animated field runtime", test_field_animation_runtime)

    def test_field_camera_runtime_matrix() -> str:
        serialized = (
            1.0,0.0,0.0,0.0,
            0.0,0.0,-1.0,100.0,
            0.0,1.0,0.0,30.0,
            0.0,0.0,0.0,1.0,
        )
        runtime = gmx_serialized_affine_to_runtime_row(serialized)
        if tuple(runtime[3][:3]) != (0.0, 100.0, 30.0):
            raise FormatError("GMX serialized translation did not transpose into runtime final row")
        field = field_state_from_gmx_matrix(serialized)
        world = camera_world_state(4, field["field_position"], field["orientation_matrix_row_vector"])
        delta = _vec3_sub(world["eye"], world["target"])
        if any(abs(a-b) > 1e-5 for a,b in zip(delta, (0.0, -60.0, 40.0))):
            raise FormatError(f"late-style preset-4 runtime transform mismatch: {delta}")

        data = _synthetic_matrix_anim_gmx([("fld014", 1440)])
        with tempfile.TemporaryDirectory(prefix="siig_selftest_field_camera_") as temp_dir:
            out = Path(temp_dir) / "field_camera.csv"
            report = export_field_camera_reconstruction_bytes(
                data, out, source_name="fld014.gmx", preset=0, start_frame=0, end_frame=2,
            )
            rows = list(csv.DictReader(out.read_text(encoding="utf-8-sig").splitlines()))
            if report["rows_emitted"] != 3 or len(rows) != 3:
                raise FormatError("field-camera reconstruction row count mismatch")
            if float(rows[1]["field_x"]) != 1.0:
                raise FormatError("field-camera GMX serialized translation conversion mismatch")
            if report["matrix_conversion"]["operation"] != "transpose_4x4":
                raise FormatError("field-camera matrix-conversion provenance mismatch")
        return "GMX column-vector serialization -> runtime row matrix -> procedural field-camera export"

    check("Field GMX camera reconstruction", test_field_camera_runtime_matrix)

    def test_route_animation_descriptor_reference() -> str:
        table = Path(__file__).resolve().parent / "reference" / "tables" / "ROUTE_ANIMATION_DESCRIPTORS.csv"
        rows = list(csv.DictReader(table.read_text(encoding="utf-8-sig").splitlines()))
        if len(rows) != 2:
            raise FormatError("route animation descriptor row count mismatch")
        by_name = {row["model_name"]: row for row in rows}
        a = by_name.get("fld015"); b = by_name.get("fld014")
        if not a or not b:
            raise FormatError("route animation descriptors missing fld014/fld015")
        if (int(a["start_frame"]), int(a["end_frame"]), int(a["loop_flag"]), int(a["runtime_matrix_samples"])) != (0, 6300, 0, 6301):
            raise FormatError("fld015 descriptor semantics mismatch")
        if (int(b["start_frame"]), int(b["end_frame"]), int(b["loop_flag"]), int(b["runtime_matrix_samples"])) != (0, 1440, 1, 1440):
            raise FormatError("fld014 descriptor semantics mismatch")
        return "fld015 0..6300 non-loop; fld014 0..1440 loop with 1440 matrices"

    check("Route animation descriptors", test_route_animation_descriptor_reference)

    def test_pa_route_reference() -> str:
        if pa_route_stage_category(0x1E) != 0 or pa_route_stage_category(0x1F) != 1:
            raise FormatError("PA-route stage/category boundary mismatch")
        retail = evaluate_pa_route_gate("xbox360_retail", stage_id=1, state_218=4, state_21c=1)
        if not retail["eligible"]:
            raise FormatError("retail Xbox PA-route gate should be eligible for category 0 / state 4,1")
        if evaluate_pa_route_gate("xbox360_retail", stage_id=0x1F, state_218=4, state_21c=1)["eligible"]:
            raise FormatError("retail Xbox PA-route gate ignored the category-zero restriction")
        if not evaluate_pa_route_gate("xbox360_may11", stage_id=0x1F, state_218=4, state_21c=1)["eligible"]:
            raise FormatError("May 11 PA-route gate incorrectly applied the later category filter")
        if evaluate_pa_route_gate("xbox360_may9", stage_id=1, state_218=4, state_21c=1)["eligible"]:
            raise FormatError("May 9 corresponding setup incorrectly reported PA-route activation")
        if pa_route_camera_selection(0)["resource"] != "cam01_op1.gmx" or pa_route_camera_selection(1)["resource"] != "cam02_op1.gmx":
            raise FormatError("PA-route camera resource selection mismatch")
        bosses = {int(item["opcode"]): item for item in BOSS_FIELD_CORRELATIONS}
        if bosses[0xA6]["field_model"] != "fld014.gmx" or bosses[0xA8]["field_model"] != "fld015.gmx":
            raise FormatError("PA-route boss/field correlation mismatch")
        table_root = Path(__file__).resolve().parent / "reference" / "tables"
        expected_counts = {
            "PA_ROUTE_BUILD_GATES.csv": 5,
            "PA_ROUTE_FUNCTIONS.csv": 5,
            "PA_ROUTE_CAMERA_SELECTIONS.csv": 2,
            "PA_ROUTE_BOSS_MAPPING.csv": 2,
            "SPECIAL_STAGE_RELOAD_CHAIN.csv": 2,
            "ULTIMATE_UFO_DEATH_CHAIN.csv": 6,
            "ULTIMATE_UFO_LATE_OBJECTS.csv": 4,
            "ULTIMATE_UFO_PART_STATUS_OBJECTS.csv": 4,
            "ULTIMATE_UFO_DEBUG_HUD.csv": 1,
            "ULTIMATE_UFO_STAGE_PROFILES.csv": 2,
            "ULTIMATE_UFO_MFRAME_ROUTE_CHAIN.csv": 5,
            "PA_CAMERA_LIFECYCLE.csv": 5,
            "ULTIMATE_UFO_LATE_CAMERA_GEOMETRY.csv": 6,
            "CAMERA_PRESET_DIRECT_CALLERS_PS3.csv": 5,
            "ULTIMATE_UFO_CAMERA_TRANSITION_GATE.csv": 3,
            "ULTIMATE_UFO_FINAL_VANISH_EVOLUTION.csv": 4,
            "ULTIMATE_UFO_FINAL_RESET_AUDIT.csv": 9,
            "GMX_RUNTIME_MATRIX_CONVENTION.csv": 3,
        }
        for name, expected in expected_counts.items():
            with (table_root / name).open("r", encoding="utf-8-sig", newline="") as handle:
                rows = list(csv.DictReader(handle))
            if len(rows) != expected:
                raise FormatError(f"{name} row count mismatch: {len(rows)} != {expected}")
        synthetic = {"entry_count": 2, "duration_frames": 30, "records": [
            {"index": 0, "absolute_frame": 10, "opcode": 0xA6, "opcode_hex": "0x00A6", "opcode_name": "WATER_STRIDER"},
            {"index": 1, "absolute_frame": 30, "opcode": 0xA8, "opcode_hex": "0x00A8", "opcode_name": "ULTIMATE_UFO"},
        ]}
        analysis = analyze_pa_route_dat(synthetic)
        if analysis["boss_occurrence_count"] != 2:
            raise FormatError("PA-route DAT boss scan mismatch")
        return "cross-build gates, cam01/cam02 selection, boss-field correlations, tables, and conservative DAT scan"

    check("PA-route cross-build activation reference", test_pa_route_reference)

    def test_boss_route_timelines() -> str:
        w0 = water_strider_route_frame(0)
        w1 = water_strider_route_frame(1441)
        if w0["route_frame"] != 0 or w1["route_frame"] != 0 or w0["loop_length"] != 1441:
            raise AssertionError("Water Strider route wrap mismatch")
        if water_strider_route_frame(1440)["segment"]["index"] != 16:
            raise AssertionError("Water Strider final segment mismatch")
        if ultimate_ufo_phase(6200)["active"]["phase"] != 13:
            raise AssertionError("retail Ultimate UFO phase 13 missing")
        if ultimate_ufo_phase(6200, build="may11")["active"]["phase"] != 12:
            raise AssertionError("prototype Ultimate UFO table mismatch")
        if ultimate_ufo_phase(1750)["active"]["phase"] != 2 or ultimate_ufo_phase(1750, build="may9")["active"]["phase"] != 1:
            raise AssertionError("cross-build Ultimate UFO timing mismatch")
        return "Water Strider 1441-frame wrap and retail/prototype Ultimate UFO phase tables verified"

    check("boss PA-route timeline reference", test_boss_route_timelines)

    def test_special_stage_reload_chain() -> str:
        ws = special_stage_reload_for_warning(12)
        ufo = special_stage_reload_for_warning(14)
        if ws is None or ws["bmap"] != "Bmap13.bin" or ws["field_model"] != "fld014.gmx":
            raise AssertionError("WARNING[12] special-stage mapping mismatch")
        if ufo is None or ufo["bmap"] != "Bmap15.bin" or ufo["field_model"] != "fld015.gmx":
            raise AssertionError("WARNING[14] special-stage mapping mismatch")
        if special_stage_reload_for_warning(13) is not None:
            raise AssertionError("unsupported WARNING value unexpectedly mapped")
        synthetic = {"entry_count": 2, "duration_frames": 781, "records": [
            {"index": 0, "absolute_frame": 1, "opcode": 0x78, "opcode_hex": "0x0078", "opcode_name": "WARNING", "args_signed": [14]},
            {"index": 1, "absolute_frame": 781, "opcode": 0xA8, "opcode_hex": "0x00A8", "opcode_name": "ULTIMATE_UFO", "args_signed": [0]},
        ]}
        info = analyze_pa_route_dat(synthetic)
        if info["special_stage_transition_count"] != 1 or info["special_stage_transitions"][0]["transition"]["bmap"] != "Bmap15.bin":
            raise AssertionError("DAT WARNING special-stage analysis mismatch")
        return "WARNING[12]/[14] direct reload requests resolve to Bmap13/fld014 and Bmap15/fld015"

    check("special-stage reload chain", test_special_stage_reload_chain)

    def test_ultimate_ufo_death_chain() -> str:
        chain = ultimate_ufo_death_sequence()
        if len(chain) != 6 or len(ULTIMATE_UFO_DEATH_CHAIN) != 6:
            raise AssertionError("Ultimate UFO destruction-chain row count mismatch")
        by_step = {row["step"]: row for row in chain}
        if by_step["hp_zero_dispatch"]["xbox360_retail"] != "0x820FBD30":
            raise AssertionError("Ultimate UFO HP-zero dispatch address mismatch")
        if by_step["prototype_vanish"].get("debug_name") != "UltimateUfo::Vanish":
            raise AssertionError("prototype Vanish symbol missing")
        if by_step["retail_phase12"].get("trigger_frame") != 6030 or by_step["retail_phase13"].get("trigger_frame") != 6200:
            raise AssertionError("retail post-destruction phase timing mismatch")
        return "HP-zero dispatch, prototype UltimateUfo::Vanish lineage, and retail phases 12/13 are preserved"

    check("Ultimate UFO destruction chain", test_ultimate_ufo_death_chain)

    def test_ultimate_ufo_late_model_identity() -> str:
        rows = ultimate_ufo_late_objects()
        if len(rows) != 4 or len(ULTIMATE_UFO_LATE_OBJECTS) != 4:
            raise AssertionError("Ultimate UFO late-object row count mismatch")
        by_build = {row["build"]: row for row in rows}
        if by_build["xbox360_retail"]["model"] != "bos_015k.gmx" or by_build["xbox360_june10"]["model_id"] != 0xD8:
            raise AssertionError("retail/June late model identity mismatch")
        if by_build["xbox360_may9"]["model"] != "bos_015k.gmx" or by_build["xbox360_may11"]["model_id"] != 0xD9:
            raise AssertionError("May prototype late model identity mismatch")
        if by_build["xbox360_retail"]["final_frame"] != 6200 or by_build["xbox360_may11"]["final_phase"] != 12:
            raise AssertionError("late model timeline mismatch")
        table = Path(__file__).resolve().parent / "reference" / "tables" / "ULTIMATE_UFO_LATE_OBJECTS.csv"
        with table.open("r", encoding="utf-8-sig", newline="") as handle:
            csv_rows = list(csv.DictReader(handle))
        if len(csv_rows) != 4:
            raise AssertionError("ULTIMATE_UFO_LATE_OBJECTS.csv row count mismatch")
        return "bos_015k late-route ownership verified across all Xbox builds; May uses ID 0xD9 and later builds use 0xD8"

    check("Ultimate UFO late owned-model identity", test_ultimate_ufo_late_model_identity)

    def test_ultimate_ufo_debug_hud_semantics() -> str:
        hud = ULTIMATE_UFO_DEBUG_HUD
        if hud.get("draw_function") != "0x82141EC0" or hud.get("skip_input_mask") != "0x400":
            raise AssertionError("May 9 Ultimate UFO debug HUD identity mismatch")
        if "Sframe to 0" not in hud.get("skip_effect", "") or len(ULTIMATE_UFO_PART_STATUS_OBJECTS) != 4:
            raise AssertionError("May 9 L2 skip/part HUD semantics mismatch")
        phase2 = ultimate_ufo_phase(1750)["active"]
        if phase2["part_status"] != {"umb_col":1,"umb_dis":1,"tow_col":0,"tow_dis":0,"fan_col":0,"fan_dis":0,"ring_col":0,"ring_dis":0}:
            raise AssertionError("named Ultimate UFO phase status mismatch")
        phase6 = ultimate_ufo_phase(4450)["active"]["part_status"]
        if phase6["fan_col"] != 1 or phase6["ring_dis"] != 1:
            raise AssertionError("Fan/Ring phase-6 status mismatch")
        return "May 9 Mframe/Sframe/state HUD, L2 skip, and Umb/Tow/Fan/Ring col/dis phase bytes verified"

    check("Ultimate UFO May 9 debug HUD semantics", test_ultimate_ufo_debug_hud_semantics)

    def test_ultimate_ufo_stage_variants() -> str:
        normal = ultimate_ufo_stage_profile("5-3")
        bonus = ultimate_ufo_stage_profile("5-6")
        if normal["script"] != "level5_stage3.dat" or normal["fast_destroy_branch"]:
            raise AssertionError("normal 5-3 Ultimate UFO profile mismatch")
        if bonus["script"] != "extra5_stage6.dat" or not bonus["fast_destroy_branch"]:
            raise AssertionError("Bonus 5-6 Ultimate UFO profile mismatch")
        if bonus.get("xbox360_retail_branch") != "0x8212DCB0" or bonus.get("ps3_retail_branch") != "0x001D3380":
            raise AssertionError("Bonus 5-6 fast-destroy branch address mismatch")
        if bonus["next_camera_script_frame"] - bonus["ufo_script_frame"] != 1030 or normal["camera_delta_ticks"] != 131:
            raise AssertionError("stage-profile authored camera timing mismatch")
        return "normal 5-3 and DLC Bonus 5-6 destruction policies remain explicitly separated"

    check("Ultimate UFO normal versus Bonus 5-6 profiles", test_ultimate_ufo_stage_variants)

    def test_ultimate_ufo_mframe_route_chain() -> str:
        rows = ultimate_ufo_mframe_route_chain()
        if len(rows) != 5 or len(ULTIMATE_UFO_MFRAME_ROUTE_CHAIN) != 5:
            raise AssertionError("Mframe route-chain row count mismatch")
        by_build = {r["build"]:r for r in rows}
        expected = {"xbox360_may9":"0x820FCA08","xbox360_may11":"0x820FCC30","xbox360_june10":"0x820FDD68","xbox360_retail":"0x820EAED8","ps3_retail":"0x0015A2DC"}
        for build, setter in expected.items():
            if by_build[build]["route_frame_setter"] != setter or by_build[build]["field_model"] != "fld015.gmx":
                raise AssertionError(f"Mframe route setter mismatch for {build}")
        if any(r["field_end"] != 6300 or r["loop"] for r in rows):
            raise AssertionError("fld015 finite route bounds mismatch")
        return "all five builds directly write Ultimate UFO Mframe into finite fld015 frame 0..6300"

    check("Ultimate UFO Mframe to fld015 chain", test_ultimate_ufo_mframe_route_chain)

    def test_ultimate_ufo_late_camera_geometry() -> str:
        lifecycle = pa_camera_lifecycle()
        geo = ultimate_ufo_late_camera_geometry()
        if len(lifecycle) != 5 or len(PA_CAMERA_LIFECYCLE) != 5 or len(geo) != 6:
            raise AssertionError("PA camera lifecycle/geometry row count mismatch")
        if lifecycle[0]["ps3_retail"] != "0x001580DC" or lifecycle[-1]["step"] != "procedural_fallback":
            raise AssertionError("PA animated-to-procedural lifecycle mismatch")
        f6200 = next(r for r in geo if r["mframe"] == 6200)
        if abs((f6200["target_y"] - f6200["eye_y"]) - 60.0) > 1e-5 or abs((f6200["eye_z"] - f6200["target_z"]) - 40.0) > 1e-5:
            raise AssertionError("late preset-4 rear-follow offset mismatch")
        if ULTIMATE_UFO_LATE_CAMERA_CONCLUSION.get("classification") != "rear_follow_geometry":
            raise AssertionError("late camera geometry classification mismatch")
        if len(PS3_CAMERA_PRESET_DIRECT_CALLERS) != 5 or any(r["ultimate_ufo_direct_caller"] for r in PS3_CAMERA_PRESET_DIRECT_CALLERS):
            raise AssertionError("PS3 camera-preset direct-caller scan mismatch")
        return "cam01 temporary override -> procedural fallback, five non-UFO direct preset writers, and late preset-4/fld015 rear-follow geometry verified"

    check("Ultimate UFO late PA camera geometry", test_ultimate_ufo_late_camera_geometry)

    def test_ultimate_ufo_camera_gate_and_vanish() -> str:
        gate = ultimate_ufo_camera_transition_gate()
        vanish = ultimate_ufo_final_vanish_evolution()
        if len(gate) != 3 or len(ULTIMATE_UFO_CAMERA_TRANSITION_GATE) != 3:
            raise AssertionError("Ultimate UFO camera transition-gate reference mismatch")
        if gate[0]["ps3_retail"] != "0x0015B524" or gate[0]["controller_offset"] != "+0x11C":
            raise AssertionError("camera timed-transition gate semantics mismatch")
        if gate[1]["xbox360_retail"] != "0x8212DCB0" or gate[1]["ps3_retail"] != "0x001D3380":
            raise AssertionError("UFO cross-platform camera-gate clear mismatch")
        if len(vanish) != 4 or len(ULTIMATE_UFO_FINAL_VANISH_EVOLUTION) != 4:
            raise AssertionError("Ultimate UFO final-Vanish evolution row count mismatch")
        by_build = {row["build"]: row for row in vanish}
        if by_build["xbox360_may9"].get("debug_name") != "UltimateUfo::Vanish" or by_build["xbox360_may9"].get("trigger_frame") != 6200:
            raise AssertionError("May 9 final Vanish mapping mismatch")
        if by_build["xbox360_may11"].get("vanish_function") != "0x821423B8":
            raise AssertionError("May 11 final Vanish mapping mismatch")
        if by_build["xbox360_retail"].get("direct_final_vanish_in_move_main") is not False:
            raise AssertionError("retail ending evolution incorrectly retains direct phase-table Vanish")
        return "retail +0x11C timed-transition gate and May phase-12 UltimateUfo::Vanish(0) lineage"

    check("Ultimate UFO camera gate + final Vanish evolution", test_ultimate_ufo_camera_gate_and_vanish)

    def test_ultimate_ufo_final_reset_audit() -> str:
        rows = ultimate_ufo_final_reset_audit()
        if len(rows) != 9 or len(ULTIMATE_UFO_FINAL_RESET_AUDIT) != 9:
            raise AssertionError("Ultimate UFO final-reset audit row count mismatch")
        by_step = {row["step"]: row for row in rows}
        if by_step["phase12_destruction"]["clears_camera_gate"]:
            raise AssertionError("retail phase 12 incorrectly classified as a camera-gate clear")
        if by_step["phase13_owned_object_shutdown"]["calls_part0_state0"]:
            raise AssertionError("retail phase 13 incorrectly classified as a part-0 reset")
        if by_step["generic_vanish_reset"]["address"] != "0x820FBEE8":
            raise AssertionError("generic retail Vanish/reset address mismatch")
        clear = by_step["ufo_part_state_gate_clear"]
        if "0x8212DD20" not in clear["address"] or not clear["clears_camera_gate"]:
            raise AssertionError("retail camera-gate clear instruction mismatch")
        if by_step["flagged_entity_removal"]["clears_camera_gate"]:
            raise AssertionError("destructor-only manager removal incorrectly promoted to reset")
        return "6030/6200 non-clear actions, +0x48 reset chain, clear instruction, watchdog, script exclusions, and destructor-only removal verified"

    check("Ultimate UFO final reset caller audit", test_ultimate_ufo_final_reset_audit)


    def test_camera_preset_reference() -> str:
        table_root = Path(__file__).resolve().parent / "reference" / "tables"
        semantic_path = table_root / "CAMERA_PRESETS_RUNTIME_SEMANTIC.csv"
        schema_path = table_root / "CAMERA_PRESET_SCHEMA.csv"
        with semantic_path.open("r", encoding="utf-8-sig", newline="") as handle:
            runtime_rows = list(csv.DictReader(handle))
        with schema_path.open("r", encoding="utf-8-sig", newline="") as handle:
            schema_rows = list(csv.DictReader(handle))
        if len(runtime_rows) != 32 or len(schema_rows) != 30:
            raise FormatError("camera preset runtime/schema row count mismatch")
        first = runtime_rows[0]
        if float(first["fov_degrees"]) != 29.0 or abs(float(first["uniform_scene_view_scale"]) - 0.43) > 1e-5:
            raise FormatError("camera preset FOV/scale semantic mapping mismatch")
        if [float(first[f"fog1_color_{c}"]) for c in "rgba"] != [1.0, 1.0, 1.0, 0.0]:
            raise FormatError("camera preset fog semantic mapping mismatch")
        expected = {
            0: "fov_degrees", 1: "uniform_scene_view_scale",
            2: "camera_eye_offset_x", 5: "scene_view_translation_x",
            8: "dynamic_horizontal_response_gain", 9: "dynamic_target_local_x_scale",
            10: "dynamic_eye_local_x_scale", 11: "shared_model_material_scalar_unresolved",
            12: "fog0_start", 18: "fog1_start", 24: "fog2_start",
        }
        for index, name in expected.items():
            if schema_rows[index]["structural_field"] != name or schema_rows[index]["confidence"] != "high":
                raise FormatError(f"camera preset semantic schema mismatch at word {index}")
        info = camera_preset_info(0)
        if info["camera_eye_offset"] != [0.0, 200.0, 0.019999999552965164]:
            raise FormatError("camera preset eye-offset accessor mismatch")
        if abs(info["shared_model_material_scalar_unresolved"] - 0.2) > 1e-6:
            raise FormatError("camera preset shared material scalar mismatch")
        return "32 runtime presets with FOV/scale/eye/translation/dynamic/fog semantics; word 11 remains explicitly unresolved"

    check("Camera preset semantic table", test_camera_preset_reference)

    def test_camera_dynamic_response() -> str:
        info = camera_preset_info(1)
        response = dynamic_horizontal_offsets(info, 426.0, 233.0)
        expected_gain = float(info["dynamic_horizontal_response"]["gain"]) / float(info["uniform_scene_view_scale"])
        if abs(response["normalized_x"] - 1.0) > 1e-6 or abs(response["normalized_y"] - 1.0) > 1e-6:
            raise FormatError("camera dynamic coordinate normalization mismatch")
        if abs(response["gain_over_uniform_scale_clamped"] - expected_gain) > 1e-4:
            raise FormatError("camera dynamic gain mapping mismatch")
        if response["eye_local_x"] <= response["target_local_x"] or response["target_local_x"] <= 0.0:
            raise FormatError("camera target/eye response scaling mismatch")
        return "retail normalized X/Y response, gain/scale clamp, separate target and eye local-X factors"

    check("Camera dynamic response", test_camera_dynamic_response)

    def test_route_orientation_and_camera_world() -> str:
        curved = [(0, 0, 0), (10, 10, -10), (20, 10, -20), (30, 10, -30)]
        state = RouteRuntimeState(curved, curved[0], 2.0, loop=False)
        before = state.orientation_matrix
        state.step()  # Hermite sample t=0 repeats the current FieldPos.
        if state.orientation_update_count != 0:
            raise FormatError("Hermite t=0 sample unexpectedly changed procedural orientation")
        state.step()  # First moving Hermite sample drives the orientation update.
        if state.last_consumed_interpolation != "cubic_hermite" or state.orientation_update_count != 1:
            raise FormatError("moving Hermite sample did not drive procedural orientation")
        if state.orientation_matrix == before:
            raise FormatError("moving Hermite route orientation remained identity")
        straight = RouteRuntimeState([(0,0,0),(10,0,0),(20,0,0),(30,0,0)], (0,0,0), 2.0)
        straight.step()
        if straight.orientation_matrix != mat3_identity() or straight.orientation_update_count != 0:
            raise FormatError("linear route unexpectedly changed procedural orientation")
        info = camera_preset_info(0)
        world = camera_world_state(info, (1.0, 2.0, 3.0), mat3_identity(), runtime_x=213.0, runtime_y=233.0)
        expected_eye = [1.0 + float(info["camera_eye_offset"][0]), 2.0 + float(info["camera_eye_offset"][1]), 3.0 + float(info["camera_eye_offset"][2])]
        for got, expected in zip(world["eye"], expected_eye):
            if abs(float(got) - expected) > 1e-4:
                raise FormatError("identity camera-eye transform mismatch")
        if any(abs(float(a) - float(b)) > 1e-6 for a,b in zip(world["target"], (1.0,2.0,3.0))):
            raise FormatError("zero dynamic response did not retain FieldPos target")
        return "Hermite orientation ordering and procedural camera eye/target world transform"

    check("Route orientation + camera world state", test_route_orientation_and_camera_world)

    def test_xenos_shader() -> str:
        data = bytearray(0x60)
        struct.pack_into(">8I", data, 0, 0x102A1101, 0x40, 0x20, 0, 0x24, 0, 0x30, 0)
        data[0x24:0x24 + len(b"matWVP\0vs_3_0\02.0.11164.0\0")] = b"matWVP\0vs_3_0\02.0.11164.0\0"
        data[0x40:0x60] = bytes(range(0x20))
        parsed = parse_xenos_shader_bytes(bytes(data))
        if parsed["stage"] != "vertex" or parsed["microcode_size"] != 0x20:
            raise FormatError("Xenos shader header decode mismatch")
        return "stage bit, header offsets, strings, and bounded microcode"

    check("Xenos shader inventory", test_xenos_shader)

    def test_gzip_limit() -> str:
        compressed = gzip.compress(b"A" * 4096)
        if maybe_decompress(compressed, max_output=4096) != b"A" * 4096:
            raise FormatError("bounded gzip decompression changed payload")
        try:
            maybe_decompress(compressed, max_output=1024)
        except FormatError:
            pass
        else:
            raise FormatError("gzip expansion limit was not enforced")
        return "valid stream decoded; expansion over limit rejected"

    check("Gzip safety", test_gzip_limit)

    def test_png_and_atlas() -> str:
        width = height = 960
        rgba = bytearray(width * height * 4)
        for y in range(12, 84):
            for x in range(12, 84):
                off = (y * width + x) * 4
                rgba[off : off + 4] = b"\x40\xC0\xFF\xFF"
        with tempfile.TemporaryDirectory(prefix="siig_selftest_") as temp_dir:
            root = Path(temp_dir)
            atlas_path = root / "atlas.png"
            write_rgba_png(atlas_path, width, height, bytes(rgba))
            decoded_width, decoded_height, decoded = decode_png_rgba_bytes(atlas_path.read_bytes())
            if (decoded_width, decoded_height) != (width, height) or decoded != bytes(rgba):
                raise FormatError("PNG encoder/decoder round trip failed")
            map_data = MAP_MAGIC + struct.pack(">III", 1, 2, 1) + bytes((1, 0x41))
            metadata = export_map_png_bytes(
                map_data,
                root / "map",
                atlas_png=atlas_path.read_bytes(),
                atlas_name=atlas_path.name,
                atlas_step=8,
            )
            if not (root / "map.atlas.layer0.png").is_file():
                raise FormatError("atlas-backed MAP layer was not written")
            if not metadata.get("atlas_render", {}).get("composite"):
                raise FormatError("atlas-backed MAP composite was not written")
        return "RGBA PNG round trip and flipped atlas MAP render"

    check("PNG/atlas renderer", test_png_and_atlas)

    def test_zip_safety() -> str:
        with tempfile.TemporaryDirectory(prefix="siig_selftest_zip_") as temp_dir:
            root = Path(temp_dir)
            good = root / "good.zip"
            with zipfile.ZipFile(good, "w", zipfile.ZIP_DEFLATED) as archive:
                archive.writestr("Media/test.txt", "ok")
            manifest = _safe_extract_zip(good, root / "good_out")
            if manifest["files"] != 1 or (root / "good_out" / "Media" / "test.txt").read_text() != "ok":
                raise FormatError("safe ZIP extraction failed")
            bad = root / "bad.zip"
            with zipfile.ZipFile(bad, "w") as archive:
                archive.writestr("../escape.txt", "bad")
            try:
                _safe_extract_zip(bad, root / "bad_out")
            except FormatError:
                pass
            else:
                raise FormatError("ZIP traversal was not rejected")
        return "valid member extracted; traversal rejected"

    check("ZIP safety", test_zip_safety)

    def test_outer_cache() -> str:
        with tempfile.TemporaryDirectory(prefix="siig_selftest_outer_cache_") as temp_dir:
            root = Path(temp_dir)
            package = root / "game.zip"
            with zipfile.ZipFile(package, "w", zipfile.ZIP_DEFLATED) as archive:
                archive.writestr("default.xex", b"synthetic")
                archive.writestr("Media/test.bin", b"payload")
            output = root / "rip"
            first_root, first_manifest, first_reused = _populate_outer_container_cache(
                package, output, "zip", limits=DEFAULT_EXTRACTION_LIMITS, max_zip_ratio=1000
            )
            second_root, second_manifest, second_reused = _populate_outer_container_cache(
                package, output, "zip", limits=DEFAULT_EXTRACTION_LIMITS, max_zip_ratio=1000
            )
            if first_reused or not second_reused:
                raise FormatError("outer cache create/reuse state mismatch")
            if first_root != second_root or first_manifest.get("files") != 2 or second_manifest.get("files") != 2:
                raise FormatError("outer cache content/manifest mismatch")
            if (second_root / "Media" / "test.bin").read_bytes() != b"payload":
                raise FormatError("outer cache payload mismatch")
            package.write_bytes(package.read_bytes() + b"changed")
            third_root, _, third_reused = _populate_outer_container_cache(
                package, output, "zip", limits=DEFAULT_EXTRACTION_LIMITS, max_zip_ratio=1000
            )
            if third_reused or third_root == second_root:
                raise FormatError("outer cache did not invalidate after package hash change")
        return "content-addressed staging reuses exact input and invalidates changed packages"

    check("Outer-container resume cache", test_outer_cache)

    def test_privacy() -> str:
        private_fixture = ("failure at C:" + "\\" + "Users" + "\\" + "Example" + "\\secret\\file.bin" + " and /" + "home/" + "example/secret/file.bin")
        cleaned = scrub_private_text(private_fixture)
        if "Users" in cleaned or ("/home/" + "example") in cleaned:
            raise FormatError("absolute path was not redacted")
        return "Windows and POSIX routes redacted"

    check("Privacy scrubber", test_privacy)

    def test_stageviz_platform_roots() -> str:
        from siig_stageviz import _stage_media_root
        with tempfile.TemporaryDirectory(prefix="siig_selftest_stageviz_") as temp_dir:
            root = Path(temp_dir)
            xbox = root / "xbox" / "assets" / "Media" / "script"
            xbox.mkdir(parents=True)
            (xbox / "stage.dat").write_bytes(b"synthetic")
            ps3 = root / "ps3" / "assets" / "USRDIR" / "map"
            ps3.mkdir(parents=True)
            (ps3 / "stage.map").write_bytes(b"synthetic")
            if _stage_media_root(root / "xbox").name != "Media":
                raise FormatError("Xbox Media stage root was not selected")
            if _stage_media_root(root / "ps3").name != "USRDIR":
                raise FormatError("PS3 USRDIR stage root was not selected")
        return "Xbox Media and PS3 USRDIR stage roots detected without renaming"

    check("Stage Explorer platform roots", test_stageviz_platform_roots)

    def test_asset_viewer() -> str:
        from siig_asset_viewer import build_asset_viewer
        with tempfile.TemporaryDirectory(prefix="siig_selftest_viewer_") as temp_dir:
            root = Path(temp_dir)
            assets = root / "assets"
            assets.mkdir()
            (assets / "readme.txt").write_text("asset viewer test", encoding="utf-8")
            rgba = bytes((255, 0, 0, 255)) * 4
            write_rgba_png(assets / "preview.png", 2, 2, rgba)
            (assets / "retained.wma").write_bytes(b"synthetic-wma-placeholder")
            (assets / "bank.xwb").write_bytes(b"synthetic-xwb-placeholder")
            (assets / "cues.xsb").write_bytes(b"synthetic-xsb-placeholder")
            viewer_root = assets / "asset_viewer"
            report = build_asset_viewer(assets, viewer_root, hash_files=True)
            repeated = build_asset_viewer(assets, viewer_root, hash_files=True)
            html_path = viewer_root / "SIIG_Asset_Viewer.html"
            data_path = viewer_root / "viewer_assets" / "viewer_data.js"
            payloads = list((viewer_root / "viewer_assets" / "payloads").glob("*.js"))
            if report.get("file_count") != 5 or repeated.get("file_count") != 5 or not html_path.is_file() or not data_path.is_file():
                raise FormatError("asset viewer inventory, rebuild exclusion, or linked files failed")
            if report.get("base64_media_embedded") or report.get("thumbnail_count") != 4 or report.get("missing_previewable_thumbnails") != 0:
                raise FormatError("asset viewer linked-thumbnail/placeholder policy failed")
            if html_path.stat().st_size > 64 * 1024 or len(payloads) != 1:
                raise FormatError("asset viewer HTML is oversized or payload sharding failed")
            html_text = html_path.read_text(encoding="utf-8")
            data_text = data_path.read_text(encoding="utf-8")
            payload_text = payloads[0].read_text(encoding="utf-8")
            if "data:image/" in html_text or "preview.png" not in data_text or "asset viewer test" not in payload_text:
                raise FormatError("asset viewer linked data or deferred preview is incomplete")
        return "small linked HTML, lazy image thumbnail, and deferred text payload"

    check("HTML asset viewer", test_asset_viewer)

    def test_release_layout() -> str:
        toolkit_dir = Path(__file__).resolve().parent
        required = (
            toolkit_dir / "docs" / "README.md",
            toolkit_dir / "reference" / "tables" / "STAGE_PAIRING.csv",
            toolkit_dir / "reference" / "systemfont" / "systemfont.fnt",
            toolkit_dir / "validation" / "README.md",
            toolkit_dir / "tools" / "ghidra" / "ApplySIIGFunctionNames.java",
            toolkit_dir / "addons" / "SIIG_Blender_Addon_v0.1.0.zip",
        )
        missing = [path.relative_to(toolkit_dir).as_posix() for path in required if not path.is_file()]
        if missing:
            raise FormatError("organized release files missing: " + ", ".join(missing))
        root_files = sum(1 for path in toolkit_dir.iterdir() if path.is_file())
        # dev3 adds the route module; dev5 adds the camera helper; dev8 adds PA-route research helpers.
        if root_files > 23:
            raise FormatError(f"release root is unexpectedly cluttered: {root_files} files")
        return f"organized support folders present; {root_files} root files"

    check("Release layout", test_release_layout)

    def test_manifest() -> str:
        with tempfile.TemporaryDirectory(prefix="siig_selftest_manifest_") as temp_dir:
            root = Path(temp_dir)
            (root / "validation").mkdir()
            write_json_private(root / "validation" / "RIP_REPORT.json", {
                "toolkit_version": TOOLKIT_VERSION,
                "archives": {"failed": 0},
                "errors": [],
                "ps3_sdat": {"missing": []},
            })
            (root / "asset.bin").write_bytes(b"asset")
            write_output_manifest(root)
            verification = verify_output_tree(root)
            if not verification["ok"]:
                raise FormatError(f"fresh output manifest failed verification: {verification['issues']}")
            (root / "asset.bin").write_bytes(b"tampered")
            verification = verify_output_tree(root)
            if not any(item["kind"] in ("size_mismatch", "hash_mismatch") for item in verification["issues"]):
                raise FormatError("output tampering was not detected")
        return "fresh tree verified; tampering detected"

    check("Output manifest/verification", test_manifest)

    passed = sum(item["status"] == "PASS" for item in results)
    failed = len(results) - passed
    return {
        "format": "SIIG_SELFTEST",
        "toolkit_version": TOOLKIT_VERSION,
        "python": sys.version.split()[0],
        "passed": passed,
        "failed": failed,
        "ok": failed == 0,
        "tests": results,
    }


def command_selftest(args: argparse.Namespace) -> int:
    report = run_selftest()
    for item in report["tests"]:
        print(f"{item['status']:4s}  {item['name']}: {item['detail']}")
    print(f"self-test: {report['passed']} passed, {report['failed']} failed")
    if getattr(args, "json_output", None):
        write_json_private(Path(args.json_output), report, ensure_ascii=False)
        print(f"report: {Path(args.json_output)}")
    return 0 if report["ok"] else 1


def command_doctor(args: argparse.Namespace) -> int:
    checks: list[dict] = []

    def add(name: str, status: str, detail: str, *, required: bool = True) -> None:
        checks.append({"name": name, "status": status, "detail": detail, "required": required})

    py_ok = sys.version_info >= (3, 10)
    add("Python", "PASS" if py_ok else "FAIL", sys.version.split()[0])
    add("AES self-test", "PASS" if aes_self_test() else "FAIL", "FIPS-197 known-answer vector")
    toolkit_dir = Path(__file__).resolve().parent
    required_files = (
        Path("reference/tables/STAGE_PAIRING.csv"),
        Path("reference/tables/DAT_SEMANTIC_SCHEMAS.csv"),
        Path("reference/tables/STAGE_TILE_SETS.csv"),
        Path("reference/tables/TILE_SET_TEXTURES.csv"),
        Path("siig_asset_viewer.py"),
        Path("addons/SIIG_Blender_Addon_v0.1.0.zip"),
        Path("docs/README.md"),
    )
    missing = [path.as_posix() for path in required_files if not (toolkit_dir / path).is_file()]
    add(
        "Bundled support files",
        "PASS" if not missing else "FAIL",
        "all present" if not missing else "missing: " + ", ".join(missing),
    )
    ffmpeg = getattr(args, "ffmpeg", None) or shutil.which("ffmpeg")
    add(
        "FFmpeg",
        "PASS" if ffmpeg else "WARN",
        privacy_safe_path(ffmpeg) if ffmpeg else "not found; XMA files will still be exported",
        required=False,
    )

    input_summary = None
    if getattr(args, "input", None):
        input_path = Path(args.input)
        if not input_path.exists():
            add("Input", "FAIL", f"not found: {input_path.name}")
        else:
            kind = detect_container_kind(input_path)
            if kind is None:
                if input_path.is_file() and _read_prefix(input_path, 4) == BBX_MAGIC:
                    kind = "bbx"
                else:
                    kind = "unknown"
            input_summary = {"name": input_path.name, "kind": kind}
            add("Input type", "PASS" if kind != "unknown" else "WARN", kind, required=kind != "unknown")
            if kind == "directory":
                try:
                    game_platform, game_root = detect_game_platform(input_path)
                    add("Game platform", "PASS", f"{game_platform} ({game_root.name})")
                    input_summary["platform"] = game_platform
                    input_summary["game_root"] = game_root.name
                    if game_platform == "ps3":
                        npd_count = 0
                        for path in game_root.rglob("*"):
                            if path.is_file() and _read_prefix(path, 4) == NPD_MAGIC:
                                npd_count += 1
                        add(
                            "PS3 SDAT layer",
                            "PASS",
                            f"{npd_count} encrypted NPD/SDAT file(s) detected; SIIG SDATs are handled internally" if npd_count else "no encrypted SDAT files detected",
                            required=False,
                        )
                except FormatError as exc:
                    add("Game platform", "WARN", str(exc), required=False)

    report = {
        "format": "SIIG_DOCTOR",
        "toolkit_version": TOOLKIT_VERSION,
        "checks": checks,
        "input": input_summary,
        "ok": not any(item["status"] == "FAIL" and item["required"] for item in checks),
    }
    if getattr(args, "json", False):
        print(json.dumps(report, indent=2))
    else:
        for item in checks:
            print(f"{item['status']:4s}  {item['name']}: {item['detail']}")
    return 0 if report["ok"] else 1


def command_verify_output(args: argparse.Namespace) -> int:
    root = Path(args.input)
    if not root.is_dir():
        raise FormatError(f"rip output directory not found: {root}")
    if getattr(args, "write_manifest", False):
        manifest = write_output_manifest(root)
        print(f"manifest rebuilt: {manifest['file_count']} files, {manifest['total_bytes']} bytes")
    report = verify_output_tree(root, verify_hashes=not getattr(args, "quick", False))
    if getattr(args, "json_output", None):
        write_json_private(Path(args.json_output), report, ensure_ascii=False)
        print(f"verification report: {Path(args.json_output)}")
    for issue in report["issues"]:
        print(f"FAIL  {issue.get('kind')}: {issue.get('path', issue)}")
    for warning in report["warnings"]:
        print(f"WARN  {warning.get('kind')}: {warning.get('path', warning.get('count', ''))}")
    if report["ok"]:
        mode = "size/privacy" if getattr(args, "quick", False) else "hash/privacy"
        print(f"PASS  output verification ({mode}); {report['hashes_checked']} hashes checked")
    return 0 if report["ok"] else 1


def command_stageviz(args: argparse.Namespace) -> int:
    from siig_stageviz import build_stage_explorer
    manifest = build_stage_explorer(Path(args.input), Path(args.output))
    commands = sum(stage["commands"] for stage in manifest["stages"])
    map_cells = sum(stage["map_cells"] for stage in manifest["stages"])
    print(f"stage explorer: {manifest['stage_count']} stage(s), {commands} command(s), {map_cells} MAP cell(s)")
    print(f"open: {Path(args.output) / 'SIIG_Stage_Explorer.html'}")
    return 0


def command_sblk2wav(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output_dir = Path(args.output)
    try:
        manifest = export_sony_sblk_wav_file(input_path, output_dir)
    except SonyBnkError as exc:
        raise FormatError(str(exc)) from exc
    print(
        f"Sony SBlk: {manifest['stream_count']} stream(s), "
        f"{manifest['decoded_wav']} WAV(s), {manifest['decode_failures']} failure(s); "
        f"coverage={'complete' if manifest['coverage_complete'] else 'partial'}"
    )
    return 0 if not manifest['decode_failures'] else 1


def _add_extraction_limit_args(parser: argparse.ArgumentParser, *, include_zip_ratio: bool = False) -> None:
    parser.add_argument(
        "--max-files",
        type=int,
        default=DEFAULT_EXTRACTION_LIMITS.max_files,
        help=f"maximum files extracted from an outer container (default: {DEFAULT_EXTRACTION_LIMITS.max_files})",
    )
    parser.add_argument(
        "--max-total-bytes",
        type=int,
        default=DEFAULT_EXTRACTION_LIMITS.max_total_bytes,
        help="maximum total outer-container extraction size in bytes",
    )
    parser.add_argument(
        "--max-file-bytes",
        type=int,
        default=DEFAULT_EXTRACTION_LIMITS.max_file_bytes,
        help="maximum size of one outer-container member in bytes",
    )
    if include_zip_ratio:
        parser.add_argument(
            "--max-zip-ratio",
            type=int,
            default=1000,
            help="maximum uncompressed/compressed ratio for any ZIP member",
        )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", action="version", version=f"SIIG Asset Toolkit {TOOLKIT_VERSION}")
    sub = parser.add_subparsers(dest="command", required=True)

    p_unpack = sub.add_parser(
        "unpack-container",
        help="extract an Xbox 360 STFS package or PlayStation 3 PKG",
    )
    p_unpack.add_argument("input", help="input STFS/CON/LIVE/PIRS package or PS3 PKG")
    p_unpack.add_argument("-o", "--output", default="SIIG_Container_Extracted", help="output directory")
    p_unpack.add_argument("--clean", action="store_true", help="delete the output directory before starting")
    _add_extraction_limit_args(p_unpack)
    p_unpack.set_defaults(func=command_unpack_container)

    p_selftest = sub.add_parser("container-selftest", help="run the legacy container crypto smoke test")
    p_selftest.set_defaults(func=command_container_selftest)

    p_full_selftest = sub.add_parser("selftest", help="run built-in parser, renderer, safety, and manifest regression tests")
    p_full_selftest.add_argument("--json-output", help="optional JSON self-test report path")
    p_full_selftest.set_defaults(func=command_selftest)

    p_doctor = sub.add_parser("doctor", help="check the runtime, bundled tables, FFmpeg, and an optional input")
    p_doctor.add_argument("input", nargs="?", help="optional package, game directory, or BBX file to inspect")
    p_doctor.add_argument("--ffmpeg", help="path/name of FFmpeg executable")
    p_doctor.add_argument("--json", action="store_true", help="print machine-readable JSON")
    p_doctor.set_defaults(func=command_doctor)

    p_verify = sub.add_parser("verify-output", help="verify a full-game rip report, privacy, files, sizes, and hashes")
    p_verify.add_argument("input", help="SIIG_Ripped output directory")
    p_verify.add_argument("--quick", action="store_true", help="skip SHA-256 checks and verify structure/sizes/privacy only")
    p_verify.add_argument("--write-manifest", action="store_true", help="rebuild OUTPUT_MANIFEST before verification")
    p_verify.add_argument("--json-output", help="optional JSON verification report path")
    p_verify.set_defaults(func=command_verify_output)

    p_sdat = sub.add_parser("sdat-decrypt", help="decrypt and authenticate a PS3 SIIG NPDRM SDAT")
    p_sdat.add_argument("input", help="input .sdat file")
    p_sdat.add_argument("-o", "--output", help="output decrypted file")
    p_sdat.add_argument("--rap", help="optional 16-byte RAP path; accepted for workflow compatibility (SIIG SDATs do not require it)")
    p_sdat.set_defaults(func=command_sdat_decrypt)

    p_sblk = sub.add_parser("sblk2wav", help="decode a PS3 Sony 989SND/SCREAM SBlk v3 bank to WAV")
    p_sblk.add_argument("input", help="input .bnk bank")
    p_sblk.add_argument("-o", "--output", default="siig_sony_audio", help="output directory")
    p_sblk.set_defaults(func=command_sblk2wav)

    p_rip = sub.add_parser(
        "rip-game",
        help="one-click Xbox 360/PS3 full-game extraction, conversion, and validation",
    )
    p_rip.add_argument("input", help="game directory, ZIP, Xbox 360 STFS, or PS3 PKG")
    p_rip.add_argument("-o", "--output", default="SIIG_Ripped", help="output directory")
    p_rip.add_argument("--rap", help="optional 16-byte PS3 RAP; validated for workflow compatibility")
    p_rip.add_argument(
        "--ps3-sdat-dir",
        action="append",
        help="directory containing TrueAncestor .bin.gz.dat outputs (repeatable)",
    )
    p_rip.add_argument("--clean", action="store_true", help="delete the output directory before starting")
    p_rip.add_argument("--resume", action="store_true", help="skip unchanged archives already extracted and reuse matching outer-package staging")
    p_rip.add_argument("--no-outer-cache", action="store_true", help="with --resume, force outer ZIP/STFS/PKG extraction instead of reusing the content-addressed staging cache")
    p_rip.add_argument("--no-gltf", action="store_true", help="skip GMX to glTF conversion")
    p_rip.add_argument("--convert-obj", action="store_true", help="also write legacy OBJ models")
    p_rip.add_argument("--no-textures", action="store_true", help="skip TEX/font PNG conversion")
    p_rip.add_argument("--no-audio", action="store_true", help="skip Xbox 360 XACT and PS3 Sony SBlk WAV conversion")
    p_rip.add_argument("--ffmpeg", help="path/name of FFmpeg executable")
    p_rip.add_argument("--flip-v", action="store_true", help="flip model texture V coordinates")
    p_rip.add_argument("--no-structured", action="store_true", help="skip automatic DAT/MAP/stage3D/stagewall/shader structured exports")
    p_rip.add_argument("--no-stageviz", action="store_true", help="skip automatic offline stage-explorer generation")
    p_rip.add_argument("--no-asset-viewer", action="store_true", help="skip automatic offline asset-viewer generation")
    p_rip.add_argument("--viewer-no-hash", action="store_true", help="omit SHA-256 hashing from the generated asset viewer")
    p_rip.add_argument("--viewer-max-embed-mib", type=int, default=0, help="deprecated compatibility option; v2.5 links previews instead of embedding them")
    p_rip.add_argument("--viewer-max-text-preview-kib", type=int, default=48, help="maximum deferred text preview per file in KiB (default: 48)")
    p_rip.add_argument("--viewer-page-size", type=int, default=96, help="initial Asset Viewer results per page (default: 96)")
    p_rip.add_argument("--no-output-manifest", action="store_true", help="skip deterministic SHA-256 output manifest generation")
    _add_extraction_limit_args(p_rip, include_zip_ratio=True)
    p_rip.set_defaults(func=command_rip_game)

    p_extract = sub.add_parser("extract", help="extract one BBX archive or every BBX in a directory")
    p_extract.add_argument("input", help="input .bin/.gz file or directory")
    p_extract.add_argument("-o", "--output", default="siig_extracted", help="output directory")
    p_extract.add_argument("--recursive", action="store_true", help="recursively extract nested BBX payloads")
    p_extract.add_argument("--convert-gmx", action="store_true", help="also convert extracted GMX geometry to OBJ")
    p_extract.add_argument(
        "--convert-gltf",
        action="store_true",
        help="also export GMX hierarchy, materials and animations to glTF 2.0",
    )
    p_extract.add_argument("--convert-tex", action="store_true", help="also convert extracted TEX textures to PNG")
    p_extract.add_argument("--flip-v", action="store_true", help="flip texture V coordinates for OBJ/glTF output")
    p_extract.set_defaults(func=command_extract)

    p_repack = sub.add_parser("repack-bbx", help="rebuild a BBX archive from an extracted directory and manifest")
    p_repack.add_argument("input", help="directory produced by the extract command")
    p_repack.add_argument("-o", "--output", required=True, help="output .bin/.bbx file")
    p_repack.add_argument("--manifest", help="manifest.json path (defaults to INPUT/manifest.json)")
    p_repack.add_argument("--mode", help="override BBX mode (decimal or 0x-prefixed)")
    p_repack.add_argument("--hash-seed", help="override filename hash seed (decimal or 0x-prefixed)")
    p_repack.add_argument("--preserve-identifiers", action="store_true", help="preserve named identifiers from the manifest instead of recomputing hashes")
    p_repack.add_argument("--include-extra", action="store_true", help="append files not referenced by the manifest using relative paths as BBX names")
    p_repack.add_argument("--gzip", action="store_true", help="write a deterministic gzip-wrapped BBX")
    p_repack.set_defaults(func=command_repack_bbx)

    p_viewer = sub.add_parser("asset-viewer", help="build a searchable offline HTML browser for extracted assets")
    p_viewer.add_argument("input", help="asset or full-rip directory to index")
    p_viewer.add_argument("-o", "--output", default="siig_asset_viewer", help="output directory or .html path")
    p_viewer.add_argument("--title", default="SIIG Asset Viewer", help="viewer title")
    p_viewer.add_argument("--no-hash", action="store_true", help="skip SHA-256 hashes for faster generation")
    p_viewer.add_argument("--max-embed-mib", type=float, default=0, help="deprecated compatibility option; media is linked and lazy-loaded")
    p_viewer.add_argument("--max-single-preview-mib", type=float, default=0, help="deprecated compatibility option; media is linked and lazy-loaded")
    p_viewer.add_argument("--max-text-preview-kib", type=float, default=48, help="maximum deferred text preview per file in KiB")
    p_viewer.add_argument("--page-size", type=int, default=96, help="initial number of cards per page")
    p_viewer.set_defaults(func=command_asset_viewer)

    p_serve = sub.add_parser("serve", help="serve an output directory locally and optionally open a browser")
    p_serve.add_argument("input", nargs="?", default=".", help="directory to serve")
    p_serve.add_argument("--port", type=int, default=8765, help="localhost TCP port (default: 8765)")
    p_serve.add_argument("--no-browser", action="store_true", help="do not open the default browser")
    p_serve.set_defaults(func=command_serve)

    p_gmx = sub.add_parser("gmx2obj", help="convert one GMX or a directory of GMX files to OBJ")
    p_gmx.add_argument("input", help="input .gmx file or directory")
    p_gmx.add_argument("-o", "--output", default="siig_obj", help="output directory")
    p_gmx.add_argument("--flip-v", action="store_true", help="flip the OBJ texture V coordinate")
    p_gmx.set_defaults(func=command_gmx2obj)

    p_gmxtrack = sub.add_parser("gmxtrack", help="export GMX matrix-animation tracks to decomposed CSV and OBJ trajectories")
    p_gmxtrack.add_argument("input", help="input animated .gmx file or directory")
    p_gmxtrack.add_argument("-o", "--output", default="siig_gmx_tracks", help="output directory")
    p_gmxtrack.set_defaults(func=command_gmxtrack)

    p_camanim = sub.add_parser("camera-animation", help="evaluate the retail 200-frame cam1/int1 animated-camera controller")
    p_camanim.add_argument("input", help="input cam01_op1.gmx or cam02_op1.gmx")
    p_camanim.add_argument("-o", "--output", default="siig_camera_animation", help="output directory or CSV path")
    p_camanim.add_argument("--frame-multiplier", type=int, choices=(1, 2), default=2, help="runtime update multiplier (default: 2)")
    p_camanim.add_argument("--field-x", type=float, default=0.0, help="FieldPos X offset added to cam1/int1 translations")
    p_camanim.add_argument("--field-y", type=float, default=0.0, help="FieldPos Y offset added to cam1/int1 translations")
    p_camanim.add_argument("--field-z", type=float, default=0.0, help="FieldPos Z offset added to cam1/int1 translations")
    p_camanim.add_argument("--emit-every", type=int, default=1, help="write every Nth runtime update while still simulating all updates")
    p_camanim.set_defaults(func=command_camera_animation)

    p_field_camera = sub.add_parser(
        "field-camera",
        help="reconstruct procedural camera eye/target directly from fld014/fld015 GMX matrices",
    )
    p_field_camera.add_argument("input", help="input fld014.gmx or fld015.gmx")
    p_field_camera.add_argument("--preset", type=int, required=True, help="explicit retail camera preset index 0..31")
    p_field_camera.add_argument("--start-frame", type=int, help="first field logical frame; defaults to descriptor start")
    p_field_camera.add_argument("--end-frame", type=int, help="last field logical frame; defaults to descriptor end")
    p_field_camera.add_argument("--runtime-x", type=float, help="optional runtime X coordinate for dynamic horizontal response")
    p_field_camera.add_argument("--runtime-y", type=float, help="optional runtime Y coordinate for dynamic horizontal response")
    p_field_camera.add_argument("--emit-every", type=int, default=1, help="write every Nth logical field frame")
    p_field_camera.add_argument("-o", "--output", default="siig_field_camera", help="output directory or CSV path")
    p_field_camera.set_defaults(func=command_field_camera)

    p_fieldanim = sub.add_parser("field-animation", help="export fld014/fld015 runtime matrix samples over the executable descriptor frame domain")
    p_fieldanim.add_argument("input", help="input fld014.gmx or fld015.gmx")
    p_fieldanim.add_argument("-o", "--output", default="siig_field_animation", help="output directory or CSV path")
    p_fieldanim.add_argument("--emit-every", type=int, default=1, help="write every Nth logical descriptor frame")
    p_fieldanim.set_defaults(func=command_field_animation)

    p_gltf = sub.add_parser(
        "gmx2gltf",
        help="export GMX geometry, hierarchy, materials and animation tracks to glTF 2.0",
    )
    p_gltf.add_argument("input", help="input .gmx file or directory")
    p_gltf.add_argument("-o", "--output", default="siig_gltf", help="output directory")
    p_gltf.add_argument("--flip-v", action="store_true", help="flip the glTF texture V coordinate")
    p_gltf.add_argument(
        "--texture-root",
        action="append",
        help="additional directory to search recursively for TXIF-referenced DDS/TEX files",
    )
    p_gltf.set_defaults(func=command_gmx2gltf)

    p_tex = sub.add_parser("tex2png", help="convert one TEX or a directory of TEX files to PNG")
    p_tex.add_argument("input", help="input .tex file or directory")
    p_tex.add_argument("-o", "--output", default="siig_png", help="output directory")
    p_tex.set_defaults(func=command_tex2png)

    p_col = sub.add_parser("col2png", help="convert one-bit SIIG collision masks to PNG")
    p_col.add_argument("input", help="input .col file or directory")
    p_col.add_argument("-o", "--output", default="siig_collision", help="output directory")
    p_col.add_argument("--invert", action="store_true", help="invert black and white pixels")
    p_col.set_defaults(func=command_col2png)

    p_anm = sub.add_parser("anm2csv", help="decode standalone SIIG ANM tables to CSV and JSON")
    p_anm.add_argument("input", help="input .anm file or directory")
    p_anm.add_argument("-o", "--output", default="siig_anm", help="output directory")
    p_anm.set_defaults(func=command_anm2csv)

    p_stagewall = sub.add_parser("stagewall", help="decode wall/Xwall strips and stage_generate candidates")
    p_stagewall.add_argument("input", help="wall/Xwall/stage_generate .bin file or directory")
    p_stagewall.add_argument("-o", "--output", default="siig_stagewall", help="output directory")
    p_stagewall.set_defaults(func=command_stagewall)

    p_stage3d = sub.add_parser("stage3dmap", help="decode Bmap/Xmap/map4/map5 3D stage path and placement records")
    p_stage3d.add_argument("input", help="input Bmap/Xmap .bin file or directory")
    p_stage3d.add_argument("-o", "--output", default="siig_stage3d", help="output directory")
    p_stage3d.set_defaults(func=command_stage3dmap)

    p_route = sub.add_parser("route-resample", help="resample a stage3d route with the retail non-loop fixed-spacing algorithm")
    p_route.add_argument("input", help="input Bmap/Xmap/map4/map5 .bin file or directory")
    p_route.add_argument("-o", "--output", default="siig_route_resample", help="output directory")
    p_route.add_argument("--spacing", type=float, required=True, help="constant route spacing in game units (> 0); runtime SCROLL_02 changes are not modeled")
    p_route.set_defaults(func=command_route_resample)

    p_route_play = sub.add_parser("route-playback", help="couple one stage3d route to a DAT SCROLL_02 runtime-spacing timeline")
    p_route_play.add_argument("stage3d", help="input Bmap/Xmap/map4/map5 .bin route table")
    p_route_play.add_argument("dat", help="input paired SIIG stage DAT script")
    p_route_play.add_argument("-o", "--output", default="siig_route_playback", help="output directory")
    p_route_play.add_argument("--frame-multiplier", type=int, choices=(1, 2), default=2, help="runtime update multiplier; retail gameplay scene 0x02 uses 2 (default)")
    p_route_play.add_argument("--loop", action="store_true", help="enable retail modulo-wrapped route loop behavior")
    p_route_play.add_argument("--start-frame", type=int, default=0, help="authored DAT frame at which the route object is assumed initialized")
    p_route_play.add_argument("--end-frame", type=int, help="authored DAT frame at which to stop; defaults to DAT duration")
    p_route_play.add_argument("--max-updates", type=int, default=2000000, help="safety cap on emitted runtime updates")
    p_route_play.set_defaults(func=command_route_playback)

    p_route_camera = sub.add_parser("route-camera-playback", help="combine DAT-driven route playback with procedural camera world-state reconstruction")
    p_route_camera.add_argument("stage3d", help="input Bmap/Xmap/map4/map5 .bin route table")
    p_route_camera.add_argument("dat", help="input paired SIIG stage DAT script")
    p_route_camera.add_argument("--preset", type=int, required=True, help="explicit retail camera preset index 0..31")
    p_route_camera.add_argument("--runtime-x", type=float, required=True, help="explicit runtime X coordinate for dynamic camera response")
    p_route_camera.add_argument("--runtime-y", type=float, required=True, help="explicit runtime Y coordinate for dynamic camera response")
    p_route_camera.add_argument("-o", "--output", default="siig_route_camera_playback", help="output directory")
    p_route_camera.add_argument("--frame-multiplier", type=int, choices=(1, 2), default=2, help="runtime update multiplier; retail gameplay scene 0x02 uses 2 (default)")
    p_route_camera.add_argument("--loop", action="store_true", help="enable retail modulo-wrapped route loop behavior")
    p_route_camera.add_argument("--start-frame", type=int, default=0, help="authored DAT frame at which the route object is assumed initialized")
    p_route_camera.add_argument("--end-frame", type=int, help="authored DAT frame at which to stop; defaults to DAT duration")
    p_route_camera.add_argument("--max-updates", type=int, default=2000000, help="safety cap on emitted runtime updates")
    p_route_camera.add_argument("--emit-every", type=int, default=1, help="write every Nth runtime update while still simulating all updates")
    p_route_camera.set_defaults(func=command_route_camera_playback)

    p_camera = sub.add_parser("camera-preset", help="inspect one executable-backed retail camera preset semantically")
    p_camera.add_argument("preset", type=int, help="camera preset index 0..31")
    p_camera.add_argument("--runtime-x", type=float, help="optional runtime X coordinate for 0x00157540 dynamic-response evaluation")
    p_camera.add_argument("--runtime-y", type=float, help="optional runtime Y coordinate for 0x00157540 dynamic-response evaluation")
    p_camera.add_argument("-o", "--output", help="optional JSON output path; otherwise print to stdout")
    p_camera.set_defaults(func=command_camera_preset)

    p_pa = sub.add_parser("pa-route-info", help="inspect executable-backed special PA-route gates, resources, and boss correlations")
    p_pa.add_argument("input", nargs="?", help="optional SIIG DAT script to scan for Water Strider / Ultimate UFO occurrences")
    p_pa.add_argument("--build", default="ps3_retail", help="gate build: ps3_retail, xbox360_retail, xbox360_june10, xbox360_may11, or xbox360_may9")
    p_pa.add_argument("--stage-id", type=int, help="optional numeric stage ID for reconstructed PA-route gate evaluation")
    p_pa.add_argument("--state-218", type=int, help="optional runtime state value at +0x218; requires --stage-id and --state-21c")
    p_pa.add_argument("--state-21c", type=int, help="optional runtime state value at +0x21C; requires --stage-id and --state-218")
    p_pa.add_argument("--camera-index", type=int, choices=(0, 1), help="inspect Route::SetPaRoute camera index 0 or 1")
    p_pa.add_argument("-o", "--output", help="optional JSON output path; otherwise print to stdout")
    p_pa.set_defaults(func=command_pa_route_info)

    p_shader = sub.add_parser("shader-info", help="inventory SIIG Xbox 360 compiled shaders and extract raw microcode")
    p_shader.add_argument("input", help="compiled shader blob or extracted shader directory")
    p_shader.add_argument("-o", "--output", default="siig_shaders", help="output directory")
    p_shader.set_defaults(func=command_shader_info)

    p_dat = sub.add_parser("dat2csv", help="decode SIIG DAT command streams to timed CSV and JSON")
    p_dat.add_argument("input", help="input .dat file or directory")
    p_dat.add_argument("-o", "--output", default="siig_dat", help="output directory")
    p_dat.set_defaults(func=command_dat2csv)

    p_map = sub.add_parser("map2png", help="decode SIIG MAP byte-grid layers to PNG and JSON")
    p_map.add_argument("input", help="input .map file or directory")
    p_map.add_argument("-o", "--output", default="siig_map", help="output directory")
    p_map.add_argument("--scale", type=int, default=1, help="nearest-neighbor display scale (1-64)")
    p_map.add_argument("--grayscale", action="store_true", help="use cell values as grayscale instead of categorical colors")
    p_map.add_argument("--csv", action="store_true", help="also write every layer as a numeric CSV grid")
    p_map.add_argument("--atlas", help="verified fence-atlas PNG for actual tile rendering")
    p_map.add_argument("--atlas-step", type=int, default=8, help="atlas-rendered pixels per 30-unit MAP cell (2-128)")
    p_map.add_argument("--no-atlas-composite", action="store_true", help="skip zero-scroll layer composite in atlas mode")
    p_map.set_defaults(func=command_map2png)

    p_stage = sub.add_parser("stageviz", help="build a self-contained stage MAP and DAT timeline explorer")
    p_stage.add_argument("input", help="full rip directory, game Media directory, or directory containing script/map")
    p_stage.add_argument("-o", "--output", default="siig_stage_explorer", help="output directory")
    p_stage.set_defaults(func=command_stageviz)

    p_font = sub.add_parser("font2png", help="decrypt systemfont.bin/systemfont.crp and export the glyph atlas")
    p_font.add_argument("input", help="input systemfont.bin, systemfont.bin.gz, or extracted systemfont.crp")
    p_font.add_argument("-o", "--output", default="siig_systemfont", help="output directory")
    p_font.add_argument("--write-decrypted-tex", action="store_true", help="also save the decrypted TEX payload")
    p_font.set_defaults(func=command_font2png)

    p_audio = sub.add_parser(
        "xact2wav",
        help="extract XACT XWB/XSB audio from sound.bin or convert XWB banks to WAV",
    )
    p_audio.add_argument("input", help="sound.bin/BBX, an .xwb file, or a directory containing XWB/XSB files")
    p_audio.add_argument("-o", "--output", default="siig_audio", help="output directory")
    p_audio.add_argument(
        "--ffmpeg",
        help="path/name of FFmpeg executable (auto-detected from PATH when omitted)",
    )
    p_audio.add_argument(
        "--keep-xma",
        action="store_true",
        help="keep the intermediate RIFF-wrapped .xma files after successful WAV decoding",
    )
    p_audio.set_defaults(func=command_xact2wav)


    p_text = sub.add_parser(
        "text2csv",
        help="decode message.bin/text.bin localization data to UTF-8 CSV, JSON, and text",
    )
    p_text.add_argument("input", help="message.bin, text.bin, or a directory containing both")
    p_text.add_argument("-o", "--output", default="siig_text", help="output directory")
    p_text.set_defaults(func=command_text2csv)

    p_sanitize = sub.add_parser(
        "sanitize-json",
        help="remove absolute local filesystem routes from existing JSON metadata in place",
    )
    p_sanitize.add_argument("input", help="JSON file or directory tree containing generated JSON metadata")
    p_sanitize.add_argument(
        "--backup",
        action="store_true",
        help="save each changed original as .json.bak before sanitizing",
    )
    p_sanitize.set_defaults(func=command_sanitize_json)

    p_scan = sub.add_parser("scan", help="print a JSON description of a BBX, GMX, TEX, DAT, MAP, XWB, or systemfont CRP file")
    p_scan.add_argument("input")
    p_scan.set_defaults(func=command_scan)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (OSError, FormatError, gzip.BadGzipFile) as exc:
        parser.error(str(exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
