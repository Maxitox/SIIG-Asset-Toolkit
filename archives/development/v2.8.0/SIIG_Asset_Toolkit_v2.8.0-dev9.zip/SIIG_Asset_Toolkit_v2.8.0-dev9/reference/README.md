# Reference data

Machine-readable supporting material is grouped by purpose:

- [`tables/`](tables/) — DAT, MAP, stage-pairing, and tile-set CSV tables
- [`provenance/`](provenance/) — source and implementation provenance records
- [`systemfont/`](systemfont/) — BMFont descriptor, glyph table, and metadata
- [`samples/`](samples/) — small source-only format examples
