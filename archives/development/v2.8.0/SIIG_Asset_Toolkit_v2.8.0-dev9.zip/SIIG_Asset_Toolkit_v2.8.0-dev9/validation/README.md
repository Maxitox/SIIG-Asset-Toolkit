- `BOSS_ROUTE_VALIDATION_2.8.0-dev9.json` — dev9 five-build executable-backed Water Strider / Ultimate UFO route validation.
- `SELFTEST_2.8.0-dev9.json` — dev9 36/36 self-test report.
- `SOURCE_ONLY_AUDIT_2.8.0-dev9.json` — dev9 source/package hygiene audit.

- `SELFTEST_2.8.0-dev8.json` — 35-test dev8 regression report.
- `PA_ROUTE_VALIDATION_2.8.0-dev8.json` — five-build PA-route gate + real 76-DAT corpus validation.
- `RELEASE_VALIDATION_2.8.0-dev8.json` — dev8 inherited/targeted/source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev8.json` — dev8 source/package hygiene audit.
- `SELFTEST_2.8.0-dev7.json` — 34-test dev7 regression report.
- `ANIMATED_RUNTIME_VALIDATION_2.8.0-dev7.json` — real four-GMX runtime timing/camera/field/glTF gate.
- `RELEASE_VALIDATION_2.8.0-dev7.json` — dev7 inherited/targeted/source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev7.json` — dev7 source/package hygiene audit.
- `SELFTEST_2.8.0-dev6.json` — 31-test dev6 regression report.
- `RUNTIME_CAMERA_ROUTE_VALIDATION_2.8.0-dev6.json` — real-corpus procedural orientation and explicit route-camera playback gate.
- `RELEASE_VALIDATION_2.8.0-dev6.json` — dev6 inherited/targeted/source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev6.json` — dev6 source/package hygiene audit.
# Validation reports

Machine-readable reports from release and corpus testing. Historical version numbers are retained in filenames so results are not confused with current runs.

- `SELFTEST_2.8.0-dev5.json` — 29-test dev5 regression report.
- `CAMERA_SEMANTIC_VALIDATION_2.8.0-dev5.json` — 32-preset semantic-table and dynamic-response gate.
- `RELEASE_VALIDATION_2.8.0-dev5.json` — dev5 inherited/targeted/source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev5.json` — dev5 source/package hygiene audit.
- `SELFTEST_2.8.0-dev4.json` — 28-test dev4 regression report.
- `RELEASE_VALIDATION_2.8.0-dev4.json` — dev4 dynamic-route/DAT targeted real-corpus and source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev4.json` — dev4 source/package hygiene audit.
- `SELFTEST_2.8.0-dev3.json` — 26-test dev3 regression report.
- `RELEASE_VALIDATION_2.8.0-dev3.json` — dev3 targeted real-corpus and source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev3.json` — dev3 source/package hygiene audit.
