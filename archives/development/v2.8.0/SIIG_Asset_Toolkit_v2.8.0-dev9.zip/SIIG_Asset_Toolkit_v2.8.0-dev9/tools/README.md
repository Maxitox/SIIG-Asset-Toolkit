# Optional tools

- `ghidra/ApplySIIGFunctionNames.java` applies confirmed labels during Ghidra research.

Normal extraction and conversion do not require this folder.
