# Research

Prototype and cross-build research notes.

- [`PROTOTYPE_NOTES.md`](PROTOTYPE_NOTES.md)
- [`RUNTIME_ENTITY_CAMERA_ROUTE_RESEARCH.md`](RUNTIME_ENTITY_CAMERA_ROUTE_RESEARCH.md) — five-build entity registry, Bmap/Xmap route-source behavior, route/camera GMX tracks, and raw camera presets.

- [`PA_ROUTE_ACTIVATION_RESEARCH.md`](PA_ROUTE_ACTIVATION_RESEARCH.md) — cross-build `Route::SetPaRoute` gates, boss/field correlations, and activation limits.
- [`BOSS_PA_ROUTE_TIMELINES_DEV9.md`](BOSS_PA_ROUTE_TIMELINES_DEV9.md) — Water Strider looping course and Ultimate UFO finite phase/hold timeline.
