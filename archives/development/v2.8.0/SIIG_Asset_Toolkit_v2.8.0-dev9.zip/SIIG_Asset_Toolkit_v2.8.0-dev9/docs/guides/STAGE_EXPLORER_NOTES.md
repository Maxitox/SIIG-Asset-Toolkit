# Offline stage explorer v5

Run after extraction:

```text
python siig_toolkit.py stageviz <SIIG_Ripped> -o stage_explorer
```

The generated HTML is self-contained and makes no network requests. The locator accepts the Xbox `Media/script` + `Media/map` layout and the PS3 `USRDIR/script` + `USRDIR/map` layout directly; platform-native folders do not need to be renamed.

## MAP rendering

Verified resource mapping: 6 → `fence1_512.png`, 7 → `fence2_512.png`, 8 → `fence6_512a.png`, 9 → `fence3_512.png`. Tiles use the confirmed 7×7 atlas, 144-pixel pitch, 96×96 source rectangles, one-based IDs 1–49, and 0x40/0x80 X/Y reflections.

## Runtime scroll playback

Explorer v5 carries decoded SCROLL events into the dataset:

- `SCROLL_01` → MAP layer 0 X/Y velocity
- `SCROLL_02` → MAP layer 1 X/Y velocity
- `SCROLL_03` → MAP layer 2 X/Y velocity

The runtime viewport integrates the signed 8.8 velocities and plays at the logical 30 Hz authoring timebase established by executable analysis. Across the retained retail explorer corpus there are 92 entries, 78 runtime pairings, and 468 scroll events. Playback controls support play/pause, single-frame stepping, seeking, and speed multipliers.

## Limits

The zero-scroll composite remains useful for layer inspection, while the runtime viewport adds confirmed 2D scrolling. This is not yet a complete gameplay renderer: camera/route transforms, all 3D stage behavior, entity simulation, and player-facing layer names remain outside the demonstrated scope.
