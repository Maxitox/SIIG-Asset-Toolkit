# Blender add-on

The bundled `addons/SIIG_Blender_Addon_v0.1.0.zip` adds SIIG GMX import to Blender 3.6 or newer.

The add-on deliberately does **not** implement a second GMX parser. It loads the selected toolkit installation, runs the verified GMX → glTF exporter in Blender's Python process, and hands the temporary glTF to Blender's built-in importer. This keeps Blender results aligned with command-line conversion fixes.

## Installation

1. Open **Edit → Preferences → Add-ons** in Blender.
2. Choose **Install from Disk** and select `addons/SIIG_Blender_Addon_v0.1.0.zip`.
3. Enable **SIIG Asset Toolkit**.
4. In the add-on preferences, choose the folder containing `siig_toolkit.py`.

An alternative is to set the `SIIG_TOOLKIT_HOME` environment variable to the toolkit folder.

## Features

- File → Import → **Space Invaders Infinity Gene (.gmx)**.
- Multi-file selection.
- Recursive folder import from the **SIIG** 3D View sidebar tab.
- Optional V-coordinate flip.
- Configurable texture-search root.
- Optional collection per GMX.
- Source filename and toolkit version stored as Blender custom properties.
- Missing textures reported without discarding geometry.

## Boundaries

- The add-on imports but does not export or repack GMX.
- It inherits the toolkit's currently verified GMX hierarchy/material/animation coverage.
- Blender was not available in the release-build environment, so syntax, packaging, module loading, and exporter integration were validated, while final UI/operator behavior requires an in-Blender test.
