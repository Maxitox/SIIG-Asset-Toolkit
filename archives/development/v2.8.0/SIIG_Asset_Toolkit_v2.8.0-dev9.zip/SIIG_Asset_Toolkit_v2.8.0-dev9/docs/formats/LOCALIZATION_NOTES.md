# SIIG localization formats

## `text.bin`

`text.bin` is a mode-3 BBX archive with seven anonymous payloads. Every payload has exactly 542 CRLF-delimited lines:

```text
entry 0  identifiers / lookup keys
entry 1  Japanese UTF-8
entry 2  English UTF-8
entry 3  French UTF-8
entry 4  Italian UTF-8
entry 5  German UTF-8
entry 6  Spanish UTF-8
```

The executable loads entry 0 and the selected-language entry, splits both at CRLF boundaries, and pairs their lines in order. Thus line `N` of entry 0 is the key for line `N` of each translation payload. Some values contain the literal source sequence `\n`; the readable exports expand that sequence into a real line break, while `text_strings_raw.csv` preserves the source spelling.

The first and last recovered records are:

```text
EVOL_TEXT1      Bonus Stage 1-1 is now available.
RICH_PRESENCE9  Title Screen
```

## `message.bin`

`message.bin` is a mode-3 BBX archive with six anonymous Shift-JIS payloads. The payloads are Squirrel-style source files consisting of assignments such as:

```text
STR_WARNING <- [
"WARNING",
"A FORMIDABLE ENEMY",
"HAS ENTERED THE BATTLE.",
]
```

Language order:

```text
entry 0  Japanese locale / region-default block (the UI strings are intentionally English)
entry 1  English
entry 2  French
entry 3  Italian
entry 4  German
entry 5  Spanish
```

Each payload contains the same 284 array names and 1,295 string values. The source uses language-specific ASCII glyph codes for accented capital letters. For example, French `ESPqCES`, Italian `PIm`, German `ZURkCK`, and Spanish `ATENCIhN` render as `ESPÈCES`, `PIÙ`, `ZURÜCK`, and `ATENCIÓN`. The toolkit preserves the original scripts as `*_raw.nut` and writes Unicode-corrected scripts as `*_readable.nut`.

Confirmed substitutions include:

```text
universal names  p=É, t=Í, k=Ü
French           q=È, v=Î, r=Ê, e=À, y=Œ
Italian          q=È, e=À, m=Ù, u=Ì
German           c=Ä, k=Ü, g=Ö
Spanish          h=Ó, b=Ñ, l=Ú, d=Á, p=É, t=Í, z=¡
```

The `%d` printf sequence is explicitly preserved rather than changing its `d` to `Á` in Spanish.

## Toolkit command

Decode one archive:

```bat
python siig_toolkit.py text2csv "C:\path\to\text.bin" -o localization
python siig_toolkit.py text2csv "C:\path\to\message.bin" -o localization
```

Decode both by pointing at their directory:

```bat
python siig_toolkit.py text2csv "C:\path\to\media" -o localization
```

Important outputs:

```text
localization\text\text_strings.csv
localization\text\text_strings_raw.csv
localization\text\text_strings.json
localization\message\message_strings.csv
localization\message\message_strings.json
localization\message\message_*_readable.nut
```
