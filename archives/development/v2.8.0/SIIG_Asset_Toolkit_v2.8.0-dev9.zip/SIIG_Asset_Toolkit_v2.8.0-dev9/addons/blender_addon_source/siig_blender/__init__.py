from __future__ import annotations

bl_info = {
    "name": "SIIG Asset Toolkit",
    "author": "SIIG Asset Toolkit project",
    "version": (0, 1, 0),
    "blender": (3, 6, 0),
    "location": "File > Import and 3D View > Sidebar > SIIG",
    "description": "Import Space Invaders Infinity Gene GMX models through the verified SIIG glTF exporter",
    "category": "Import-Export",
}

import importlib.util
import os
import sys
import tempfile
from pathlib import Path
from typing import Iterable

import bpy
from bpy.props import BoolProperty, CollectionProperty, IntProperty, StringProperty
from bpy.types import AddonPreferences, Operator, OperatorFileListElement, Panel
from bpy_extras.io_utils import ImportHelper

_MODULE_NAME = "_siig_toolkit_blender_runtime"


def _preferences(context):
    addon = context.preferences.addons.get(__package__)
    return addon.preferences if addon else None


def _candidate_toolkits(context) -> Iterable[Path]:
    prefs = _preferences(context)
    if prefs and prefs.toolkit_path:
        selected = Path(bpy.path.abspath(prefs.toolkit_path))
        yield selected / "siig_toolkit.py" if selected.is_dir() else selected
    env = os.environ.get("SIIG_TOOLKIT_HOME")
    if env:
        selected = Path(env)
        yield selected / "siig_toolkit.py" if selected.is_dir() else selected
    here = Path(__file__).resolve()
    if len(here.parents) >= 3:
        yield here.parents[2] / "siig_toolkit.py"
    yield Path.cwd() / "siig_toolkit.py"


def _find_toolkit(context) -> Path:
    checked = []
    for candidate in _candidate_toolkits(context):
        checked.append(str(candidate))
        if candidate.is_file():
            return candidate.resolve()
    raise RuntimeError(
        "siig_toolkit.py was not found. Set the toolkit folder in Edit > Preferences > Add-ons > SIIG Asset Toolkit. "
        + "Checked: " + "; ".join(checked)
    )


def _load_toolkit(context):
    script = _find_toolkit(context)
    existing = sys.modules.get(_MODULE_NAME)
    if existing is not None and Path(getattr(existing, "__file__", "")).resolve() == script:
        return existing
    root = str(script.parent)
    if root not in sys.path:
        sys.path.insert(0, root)
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, script)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load SIIG toolkit from {script}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


def _new_objects(before: set[bpy.types.Object]) -> list[bpy.types.Object]:
    return [obj for obj in bpy.data.objects if obj not in before]


def _move_to_collection(objects: list[bpy.types.Object], collection: bpy.types.Collection) -> None:
    for obj in objects:
        if collection not in obj.users_collection:
            collection.objects.link(obj)
        for old in list(obj.users_collection):
            if old != collection:
                old.objects.unlink(obj)


def _import_one(context, source: Path, flip_v: bool, texture_root: str, group_collection: bool) -> tuple[int, dict]:
    toolkit = _load_toolkit(context)
    roots = [source.parent]
    if texture_root:
        roots.append(Path(bpy.path.abspath(texture_root)))
    before = set(bpy.data.objects)
    with tempfile.TemporaryDirectory(prefix="siig_blender_") as temp_dir:
        output = Path(temp_dir)
        metadata = toolkit.export_gmx_gltf_file(
            source,
            output,
            flip_v=flip_v,
            texture_roots=tuple(roots),
        )
        gltf = output / f"{source.stem}.gltf"
        if not gltf.is_file():
            raise RuntimeError(f"SIIG exporter did not create {gltf.name}")
        result = bpy.ops.import_scene.gltf(filepath=str(gltf))
        if "FINISHED" not in result:
            raise RuntimeError(f"Blender glTF importer returned {result}")
    created = _new_objects(before)
    if group_collection and created:
        collection = bpy.data.collections.new(f"SIIG_{source.stem}")
        context.scene.collection.children.link(collection)
        _move_to_collection(created, collection)
    for obj in created:
        obj["siig_source_gmx"] = str(source)
        obj["siig_toolkit_version"] = str(getattr(toolkit, "TOOLKIT_VERSION", "unknown"))
    return len(created), metadata


class SIIGAddonPreferences(AddonPreferences):
    bl_idname = __package__

    toolkit_path: StringProperty(
        name="Toolkit folder",
        description="Folder containing siig_toolkit.py, or the script itself",
        subtype="DIR_PATH",
    )
    default_texture_root: StringProperty(
        name="Default texture root",
        description="Optional folder searched recursively for textures referenced by GMX files",
        subtype="DIR_PATH",
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "toolkit_path")
        layout.prop(self, "default_texture_root")
        layout.label(text="The add-on calls the toolkit's verified GMX to glTF exporter locally.")


class SIIG_OT_import_gmx(Operator, ImportHelper):
    bl_idname = "import_scene.siig_gmx"
    bl_label = "Import SIIG GMX"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".gmx"
    filter_glob: StringProperty(default="*.gmx;*.GMX", options={"HIDDEN"})
    files: CollectionProperty(type=OperatorFileListElement)
    directory: StringProperty(subtype="DIR_PATH")
    flip_v: BoolProperty(name="Flip texture V", default=False)
    group_collection: BoolProperty(name="Collection per GMX", default=True)
    texture_root: StringProperty(name="Texture root", subtype="DIR_PATH")

    def invoke(self, context, event):
        prefs = _preferences(context)
        if prefs and prefs.default_texture_root and not self.texture_root:
            self.texture_root = prefs.default_texture_root
        return ImportHelper.invoke(self, context, event)

    def execute(self, context):
        paths = [Path(self.directory) / item.name for item in self.files] if self.files else [Path(self.filepath)]
        imported_objects = 0
        failures = []
        for path in paths:
            try:
                count, metadata = _import_one(context, path.resolve(), self.flip_v, self.texture_root, self.group_collection)
                imported_objects += count
                missing = metadata.get("missing_textures", []) if isinstance(metadata, dict) else []
                if missing:
                    self.report({"WARNING"}, f"{path.name}: {len(missing)} referenced texture(s) not found")
            except Exception as exc:
                failures.append(f"{path.name}: {exc}")
        if failures:
            self.report({"ERROR"}, " | ".join(failures[:4]))
            return {"CANCELLED"} if imported_objects == 0 else {"FINISHED"}
        self.report({"INFO"}, f"Imported {len(paths)} GMX file(s), {imported_objects} Blender object(s)")
        return {"FINISHED"}


class SIIG_OT_import_gmx_folder(Operator):
    bl_idname = "import_scene.siig_gmx_folder"
    bl_label = "Import GMX Folder"
    bl_options = {"REGISTER", "UNDO"}

    directory: StringProperty(name="Folder", subtype="DIR_PATH")
    recursive: BoolProperty(name="Recursive", default=True)
    flip_v: BoolProperty(name="Flip texture V", default=False)
    group_collection: BoolProperty(name="Collection per GMX", default=True)
    texture_root: StringProperty(name="Texture root", subtype="DIR_PATH")
    max_files: IntProperty(name="Maximum files", default=256, min=1, max=10000)

    def invoke(self, context, event):
        prefs = _preferences(context)
        if prefs and prefs.default_texture_root and not self.texture_root:
            self.texture_root = prefs.default_texture_root
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        root = Path(bpy.path.abspath(self.directory))
        iterator = root.rglob("*.gmx") if self.recursive else root.glob("*.gmx")
        paths = sorted(iterator, key=lambda p: p.as_posix().lower())
        if not paths:
            self.report({"ERROR"}, "No .gmx files were found")
            return {"CANCELLED"}
        if len(paths) > self.max_files:
            self.report({"ERROR"}, f"Found {len(paths)} GMX files; raise Maximum files to continue")
            return {"CANCELLED"}
        imported = 0
        failures = []
        for path in paths:
            try:
                count, _metadata = _import_one(context, path, self.flip_v, self.texture_root, self.group_collection)
                imported += count
            except Exception as exc:
                failures.append(f"{path.name}: {exc}")
        if failures:
            self.report({"WARNING"}, f"Imported {len(paths)-len(failures)}/{len(paths)} files; first error: {failures[0]}")
        else:
            self.report({"INFO"}, f"Imported {len(paths)} files, {imported} objects")
        return {"FINISHED"} if imported else {"CANCELLED"}


class SIIG_PT_tools(Panel):
    bl_label = "SIIG Asset Toolkit"
    bl_idname = "SIIG_PT_tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "SIIG"

    def draw(self, context):
        layout = self.layout
        layout.operator(SIIG_OT_import_gmx.bl_idname, icon="IMPORT")
        layout.operator(SIIG_OT_import_gmx_folder.bl_idname, icon="FILE_FOLDER")
        try:
            path = _find_toolkit(context)
            layout.label(text=f"Toolkit: {path.parent.name}", icon="CHECKMARK")
        except Exception:
            layout.label(text="Set toolkit path in Add-on Preferences", icon="ERROR")


def _menu_import(self, context):
    self.layout.operator(SIIG_OT_import_gmx.bl_idname, text="Space Invaders Infinity Gene (.gmx)")


_CLASSES = (
    SIIGAddonPreferences,
    SIIG_OT_import_gmx,
    SIIG_OT_import_gmx_folder,
    SIIG_PT_tools,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(_menu_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(_menu_import)
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
