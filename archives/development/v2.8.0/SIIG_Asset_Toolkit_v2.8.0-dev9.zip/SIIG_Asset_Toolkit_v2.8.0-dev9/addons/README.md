# Optional add-ons

- `SIIG_Blender_Addon_v0.1.0.zip` — installable Blender add-on
- `blender_addon_source/` — readable source copy of the same add-on

See `docs/guides/BLENDER_ADDON_NOTES.md`.
