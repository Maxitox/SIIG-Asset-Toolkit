#!/usr/bin/env python3
"""Executable-backed PA-route / special-route research helpers for SIIG.

This module intentionally distinguishes direct executable evidence from strong
cross-system correlations. It does not automatically activate PA-route playback.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Iterable, Mapping, Sequence


@dataclass(frozen=True)
class PaRouteBuildGate:
    build: str
    platform: str
    gate_function: str
    category_function: str | None
    requires_category_zero: bool
    requires_state_218: int | None
    requires_state_21c: int | None
    setup_calls_pa_route: bool
    evidence: str


BUILD_GATES: tuple[PaRouteBuildGate, ...] = (
    PaRouteBuildGate(
        "ps3_retail", "ps3", "0x000EA2E0", None, True, 4, 1, True,
        "direct retail decompilation: inlined stage/category classifier + state checks; stage setup vtable +0x08 requests index 0",
    ),
    PaRouteBuildGate(
        "xbox360_retail", "xbox360", "0x8221CBE0", "0x8212C000", True, 4, 1, True,
        "direct retail decompilation: category helper + state checks; stage setup invokes route vtable +0x08 with index 0",
    ),
    PaRouteBuildGate(
        "xbox360_june10", "xbox360", "0x82243F78", "0x821013E0", True, 4, 1, True,
        "direct June 10 decompilation; Route::SetPaRoute debug string identifies the vtable target",
    ),
    PaRouteBuildGate(
        "xbox360_may11", "xbox360", "0x82238A18", "0x820FF990", False, 4, 1, True,
        "direct May 11 decompilation: state checks only; category filter is absent",
    ),
    PaRouteBuildGate(
        "xbox360_may9", "xbox360", "not observed in corresponding setup", "0x820FF2D8", False, None, None, False,
        "Route::SetPaRoute exists, but the corresponding stage-setup routine does not invoke the PA-route activation branch",
    ),
)


PA_ROUTE_FUNCTIONS: tuple[dict, ...] = (
    {"build":"ps3_retail","set_pa_route":"0x0015AEBC","activation_wrapper":"0x001580DC","stage_setup":"0x00161134","debug_name":"Route::SetPaRoute (name recovered from Xbox prototypes)","camera_format":"cam%02d_op1.gmx"},
    {"build":"xbox360_retail","set_pa_route":"0x820EAFC8","activation_wrapper":"0x820EABE8","stage_setup":"0x820EFA98","debug_name":"Route::SetPaRoute (name recovered from Xbox prototypes)","camera_format":"cam%02d_op1.gmx"},
    {"build":"xbox360_june10","set_pa_route":"0x820FDE88","activation_wrapper":"0x820FDAE0","stage_setup":"0x82104860","debug_name":"Route::SetPaRoute","camera_format":"cam%02d_op1.gmx"},
    {"build":"xbox360_may11","set_pa_route":"0x820FCD50","activation_wrapper":"0x820FC9A8","stage_setup":"0x82101C90","debug_name":"Route::SetPaRoute","camera_format":"cam%02d_op1.gmx"},
    {"build":"xbox360_may9","set_pa_route":"0x820FCB28","activation_wrapper":"0x820FC718","stage_setup":"corresponding setup does not activate PA-route","debug_name":"Route::SetPaRoute","camera_format":"cam%02d_op1.gmx"},
)


# Confidence deliberately says "strong_correlation" rather than "direct" for the
# boss -> special parameter / Bmap link. Boss identity and field-frame driver are
# directly supported by prototype debug names/vtable shape; descriptor/time-domain
# matching closes the field-model identity. The exact boss->reload-parameter call
# has not yet been recovered as a single literal direct callsite.
BOSS_FIELD_CORRELATIONS: tuple[dict, ...] = (
    {
        "opcode": 0xA6,
        "opcode_name": "WATER_STRIDER",
        "boss_class": "WaterStrider",
        "field_descriptor_index": 1,
        "field_model": "fld014.gmx",
        "descriptor_start": 0,
        "descriptor_end": 1440,
        "loop": True,
        "special_parameter": 0x0C,
        "special_bmap": "Bmap13.bin",
        "confidence": "strong_correlation",
        "evidence": "WaterStrider MoveMain-class path wraps its external field frame at 1440; descriptor 1 is fld014 0..1440 loop; special parameter 0x0C selects descriptor 1 and Bmap13",
    },
    {
        "opcode": 0xA8,
        "opcode_name": "ULTIMATE_UFO",
        "boss_class": "UltimateUfo",
        "field_descriptor_index": 0,
        "field_model": "fld015.gmx",
        "descriptor_start": 0,
        "descriptor_end": 6300,
        "loop": False,
        "special_parameter": 0x0E,
        "special_bmap": "Bmap15.bin",
        "confidence": "strong_correlation",
        "evidence": "UltimateUfo::MoveMain drives the long external field timeline into the 6000s; descriptor 0 is fld015 0..6300 non-loop; special parameter 0x0E selects descriptor 0 and Bmap15",
    },
)


CAMERA_SELECTIONS: tuple[dict, ...] = (
    {
        "index": 0,
        "resource": "cam01_op1.gmx",
        "retail_stage_setup_observed": True,
        "controller_start": 0,
        "controller_end_exclusive": 200,
        "loop": False,
        "evidence": "retail PS3/Xbox stage setup invokes Route vtable +0x08 with argument 0",
    },
    {
        "index": 1,
        "resource": "cam02_op1.gmx",
        "retail_stage_setup_observed": False,
        "controller_start": 0,
        "controller_end_exclusive": 200,
        "loop": False,
        "evidence": "Route::SetPaRoute accepts index 1 and formats cam02_op1.gmx; no proven retail activation callsite selecting index 1 has been found yet",
    },
)



# Dev9 executable-backed boss-route timelines.  These values come from the
# literal tables consumed by the named boss update functions.  Retail Xbox,
# retail PS3 and June 10 are byte-identical for both tables.
BOSS_ROUTE_FUNCTIONS: tuple[dict, ...] = (
    {"build":"xbox360_retail","ultimate_move_main":"0x8212EC50","water_update_act":"0x82135670","water_loop_driver":"0x82136810"},
    {"build":"xbox360_june10","ultimate_move_main":"0x82149DF8","water_update_act":"0x82150BA8","water_loop_driver":"0x82151D98"},
    {"build":"xbox360_may11","ultimate_move_main":"0x821431D0","water_update_act":"0x82149490","water_loop_driver":"not recovered as retail-equivalent"},
    {"build":"xbox360_may9","ultimate_move_main":"0x82142008","water_update_act":"0x82148078","water_loop_driver":"not recovered as retail-equivalent"},
    {"build":"ps3_retail","ultimate_move_main":"0x001D2988","water_update_act":"0x001DEB68","water_loop_driver":"0x001E04D0"},
)

# start/end are inclusive.  The three trailing bytes are copied from the
# compact retail/June table and deliberately kept opaque until their consumers
# are semantically named.  The first flag byte is also executable data.
WATER_STRIDER_SEGMENTS: tuple[dict, ...] = tuple(
    {"index":i,"start":a,"end":b,"flags":flags} for i,(a,b,flags) in enumerate((
        (0,109,(0,1,0)), (110,180,(1,1,0)), (181,244,(0,1,0)),
        (245,340,(1,1,0)), (341,379,(0,1,0)), (380,435,(0,0,0)),
        (436,454,(0,1,1)), (455,520,(1,1,0)), (521,669,(0,1,0)),
        (670,770,(1,0,0)), (771,784,(0,0,0)), (785,860,(0,1,1)),
        (861,899,(0,1,0)), (900,1185,(1,0,0)), (1186,1260,(1,0,0)),
        (1261,1380,(0,0,0)), (1381,1440,(0,0,1)),
    ))
)

ULTIMATE_UFO_RETAIL_PHASES: tuple[dict, ...] = tuple(
    {"phase":phase,"trigger_frame":frame,"delay_frames":delay,"part_flags":flags} for phase,frame,delay,flags in (
        (1,0,0,(0,0,0,0,0,0,0,0)),
        (2,1750,0,(1,1,0,0,0,0,0,0)),
        (3,2250,0,(0,0,1,1,0,0,0,0)),
        (4,3123,0,(0,0,0,0,0,0,0,0)),
        (5,4231,200,(0,0,0,0,0,0,0,0)),
        (6,4450,0,(0,0,0,0,1,1,1,1)),
        (7,5100,0,(0,0,0,0,1,1,1,1)),
        (8,5300,0,(0,0,0,0,0,0,1,1)),
        (9,5897,0,(0,0,0,0,0,0,0,0)),
        (10,5898,0,(0,0,0,0,0,0,0,0)),
        (11,5902,0,(0,0,0,0,0,0,0,0)),
        (12,6030,0,(0,0,0,0,0,0,0,0)),
        (13,6200,0,(0,0,0,0,0,0,0,0)),
    )
)

ULTIMATE_UFO_PROTOTYPE_PHASES: tuple[dict, ...] = tuple(
    {"phase":phase,"trigger_frame":frame,"delay_frames":delay,"part_flags":flags} for phase,frame,delay,flags in (
        (1,0,0,(0,0,0,0,0,0,0,0)),
        (2,1800,0,(1,1,0,0,0,0,0,0)),
        (3,2300,0,(0,0,1,1,0,0,0,0)),
        (4,3123,0,(0,0,0,0,0,0,0,0)),
        (5,4231,200,(0,0,0,0,0,0,0,0)),
        (6,4600,0,(0,0,0,0,1,1,1,1)),
        (7,5100,0,(0,0,0,0,1,1,1,1)),
        (8,5300,0,(0,0,0,0,0,0,1,1)),
        (9,5897,2000,(0,0,0,0,0,0,0,0)),
        (10,5898,0,(0,0,0,0,0,0,0,0)),
        (11,5902,0,(0,0,0,0,0,0,0,0)),
        (12,6200,0,(0,0,0,0,0,0,0,0)),
    )
)

def water_strider_route_frame(frame: int) -> dict:
    """Evaluate the retail Water Strider course clock (0..1440, then wrap)."""
    raw = int(frame)
    wrapped = raw % 1441
    seg = next(item for item in WATER_STRIDER_SEGMENTS if item["start"] <= wrapped <= item["end"])
    return {"input_frame":raw,"route_frame":wrapped,"loop_length":1441,"segment":dict(seg)}

def ultimate_ufo_phase(frame: int, *, build: str = "retail") -> dict:
    """Return the latest executable phase record at or before *frame*."""
    key = build.strip().lower()
    proto = key in {"may9","may11","xbox360_may9","xbox360_may11","prototype"}
    table = ULTIMATE_UFO_PROTOTYPE_PHASES if proto else ULTIMATE_UFO_RETAIL_PHASES
    f = max(0, int(frame))
    active = table[0]
    for item in table:
        if item["trigger_frame"] <= f:
            active = item
        else:
            break
    return {"input_frame":int(frame),"route_frame":f,"finite":True,"table":"prototype_may9_may11" if proto else "retail_june10_ps3","active":dict(active)}

def stage_category(stage_id: int) -> int:
    """Return the retail stage/category bucket reconstructed from the executable."""
    value = int(stage_id)
    if value < 0x1F:
        return 0
    if value < 0x28:
        return 1
    if value < 0x31:
        return 2
    if value < 0x3A:
        return 3
    if value < 0x43:
        return 4
    if value < 0x4C:
        return 5
    if value < 0xAF:
        return 6
    if value == 9999:
        return 7
    return 0


def build_gate(build: str) -> PaRouteBuildGate:
    key = build.strip().lower()
    aliases = {
        "ps3":"ps3_retail", "retail_ps3":"ps3_retail",
        "xbox":"xbox360_retail", "xbox360":"xbox360_retail", "retail_xbox":"xbox360_retail",
        "june10":"xbox360_june10", "may11":"xbox360_may11", "may9":"xbox360_may9",
    }
    key = aliases.get(key, key)
    for item in BUILD_GATES:
        if item.build == key:
            return item
    raise ValueError(f"unknown PA-route build: {build}")


def evaluate_gate(build: str, *, stage_id: int, state_218: int, state_21c: int) -> dict:
    item = build_gate(build)
    category = stage_category(stage_id)
    if not item.setup_calls_pa_route:
        eligible = False
        reason = "corresponding stage setup does not invoke the PA-route activation branch"
    else:
        eligible = True
        reasons: list[str] = []
        if item.requires_category_zero and category != 0:
            eligible = False
            reasons.append(f"stage category is {category}, expected 0")
        if item.requires_state_218 is not None and state_218 != item.requires_state_218:
            eligible = False
            reasons.append(f"state +0x218 is {state_218}, expected {item.requires_state_218}")
        if item.requires_state_21c is not None and state_21c != item.requires_state_21c:
            eligible = False
            reasons.append(f"state +0x21C is {state_21c}, expected {item.requires_state_21c}")
        reason = "eligible under reconstructed gate" if eligible else "; ".join(reasons)
    return {
        "build": item.build,
        "stage_id": int(stage_id),
        "stage_category": category,
        "state_218": int(state_218),
        "state_21c": int(state_21c),
        "eligible": bool(eligible),
        "reason": reason,
        "gate": asdict(item),
    }


def camera_selection(index: int) -> dict:
    for item in CAMERA_SELECTIONS:
        if item["index"] == int(index):
            return dict(item)
    raise ValueError("PA-route camera index must be 0 or 1")


def boss_correlation_for_opcode(opcode: int) -> dict | None:
    for item in BOSS_FIELD_CORRELATIONS:
        if item["opcode"] == int(opcode):
            return dict(item)
    return None


def analyze_parsed_dat(parsed: Mapping) -> dict:
    occurrences: list[dict] = []
    for record in parsed.get("records", []):
        mapping = boss_correlation_for_opcode(int(record.get("opcode", -1)))
        if mapping is None:
            continue
        occurrences.append({
            "record_index": record.get("index"),
            "absolute_frame": record.get("absolute_frame"),
            "opcode": record.get("opcode"),
            "opcode_hex": record.get("opcode_hex"),
            "opcode_name": record.get("opcode_name"),
            "correlation": mapping,
        })
    return {
        "format": "SIIG_PA_ROUTE_INFO",
        "dat_entry_count": parsed.get("entry_count"),
        "dat_duration_frames": parsed.get("duration_frames"),
        "boss_occurrences": occurrences,
        "boss_occurrence_count": len(occurrences),
        "warning": "Boss opcode presence alone does not prove that PA-route activation occurs at that DAT frame. Special-stage transition timing remains a separate executable-controlled state transition.",
    }


def reference_snapshot() -> dict:
    return {
        "format": "SIIG_PA_ROUTE_REFERENCE",
        "build_gates": [asdict(item) for item in BUILD_GATES],
        "functions": [dict(item) for item in PA_ROUTE_FUNCTIONS],
        "camera_selections": [dict(item) for item in CAMERA_SELECTIONS],
        "boss_field_correlations": [dict(item) for item in BOSS_FIELD_CORRELATIONS],
        "boss_route_functions": [dict(item) for item in BOSS_ROUTE_FUNCTIONS],
        "water_strider_segments": [dict(item) for item in WATER_STRIDER_SEGMENTS],
        "ultimate_ufo_retail_phases": [dict(item) for item in ULTIMATE_UFO_RETAIL_PHASES],
        "ultimate_ufo_prototype_phases": [dict(item) for item in ULTIMATE_UFO_PROTOTYPE_PHASES],
        "limits": [
            "PA is retained as the executable/debug name; its expansion is unknown.",
            "Retail stage setup is directly observed selecting camera index 0; cam02 activation is not yet proven.",
            "Water Strider retail/June/PS3 course clock wraps after frame 1440; May prototypes contain the same 0..1440 segment boundaries but their surrounding driver evolved.",
            "Ultimate UFO retail/June/PS3 uses the 13-phase table; May 9/May 11 use an earlier 12-phase table. Human camera-angle labels are not assigned without a proven camera consumer.",
            "Boss-to-field-model mapping is strong cross-system correlation, not a recovered single direct boss->reload callsite.",
            "DAT boss spawn presence is not by itself an automatic PA-route activation trigger.",
        ],
    }
