#!/usr/bin/env python3
"""Executable-backed iOS -> console SIIG code-lineage reference data.

This module contains only derived metadata and equations. It does not contain
proprietary executable bytes or decompiled game code.
"""
from __future__ import annotations

from typing import Any


IOS_CONSOLE_FUNCTION_LINEAGE = (
    {
        "subsystem": "MAP loader",
        "ios_symbol": "Invinf_LoadMap",
        "ios_address_armv7": "0x000900CC",
        "console_xbox_address": "0x82239190",
        "console_role": "load/allocate MAP layers",
        "confidence": "high",
        "preserved": "layer count; width/height descriptors; one cell buffer per layer; row-major u8 cells",
        "changed": "mobile MAP integer headers are little-endian; console headers are big-endian; resource packaging/path changed",
    },
    {
        "subsystem": "MAP runtime update",
        "ios_symbol": "calcMap",
        "ios_address_armv7": "0x0008D020",
        "console_xbox_address": "0x82239608",
        "console_role": "update MAP scrolling and visible ranges",
        "confidence": "high",
        "preserved": "three per-layer X/Y velocities; fixed-point position accumulation; clamped visible row/column ranges",
        "changed": "console implementation is reorganized around the console runtime and renderer",
    },
    {
        "subsystem": "MAP cell renderer",
        "ios_symbol": "drawMap2",
        "ios_address_armv7": "0x0008E5EC",
        "console_xbox_address": "0x8223AC28 + 0x8223A1B0",
        "console_role": "decode cells and submit 49-tile reflected variants",
        "confidence": "high",
        "preserved": "cell&0x3F tile code; 0 empty; tile indices 0..48 after subtract-one; 0x40 X reflection; 0x80 Y reflection",
        "changed": "platform-specific draw/geometry submission path",
    },
    {
        "subsystem": "MAP scroll command",
        "ios_symbol": "analyzeScript2 + setMapLayerSpeed",
        "ios_address_armv7": "0x00093CFC + 0x0008CFC4",
        "console_xbox_address": "0x820FB578 dispatcher; 2D scroll handlers in same script subsystem",
        "console_role": "SCROLL_01/02/03 set MAP layer 0/1/2 X/Y velocities",
        "confidence": "high",
        "preserved": "opcodes 0x6E/0x6F/0x70; three layer channels; speed normalization against 30-Hz authored timebase",
        "changed": "console SCROLL_01 Y also drives 3D wall/background; SCROLL_02 Y also drives 3D route/camera/field",
    },
    {
        "subsystem": "authored DAT loader",
        "ios_symbol": "Invinf_LoadScript",
        "ios_address_armv7": "0x0008FEFC",
        "console_xbox_address": "0x82239790 (June 10)",
        "console_build_addresses": {
            "xbox_may9": "0x8222C3B8",
            "xbox_may11": "0x8222DE78",
            "xbox_june10": "0x82239790",
            "xbox_retail": "0x82212888",
            "ps3_retail_opd": "0x000DF5C0",
        },
        "console_role": "shared DAT loader/index representation",
        "confidence": "high",
        "preserved": "version-1 command stream; big-endian 16-bit words; flattened word-data buffer plus per-command starting-word index; delta-frame timing",
        "changed": "addresses move across prototype/retail builds while the compact loader/index architecture remains recognizable",
    },
    {
        "subsystem": "script execution",
        "ios_symbol": "analyzeScript + analyzeScript_FPS60 + analyzeScript2",
        "ios_address_armv7": "0x00011C68 + 0x001308B4 + 0x00093CFC",
        "console_xbox_address": "0x820FB578",
        "console_role": "SgScript::AnalyzeScript candidate / June dispatcher",
        "confidence": "high-architectural",
        "preserved": "same low-range DAT command language and 30-Hz authored timing model",
        "changed": "mobile duplicates the primary enemy dispatcher for 30/60 Hz; console consolidates timing through a runtime frame multiplier and extends the command vocabulary through 0xCE",
    },
    {
        "subsystem": "generator DAT block loader",
        "ios_symbol": "stageScriptBlockLoad(NSString*,int)",
        "ios_address_armv7": "0x000DF89C",
        "console_xbox_address": "0x8226BC48",
        "console_role": "generator DAT block loading/assembly",
        "confidence": "high-structural",
        "preserved": "same DAT block serialization; append into generator script/index buffers; cumulative timeline across blocks",
        "changed": "console implementation/address naming reconstructed from debug executable rather than retained source symbols",
    },
    {
        "subsystem": "generator MAP initialization",
        "ios_symbol": "stageGenerateMapInit",
        "ios_address_armv7": "0x000E0128",
        "console_xbox_address": None,
        "console_role": "generator output-map buffer initialization (exact console routine not yet isolated)",
        "confidence": "high-mobile / unresolved-console-address",
        "preserved": "three generated output layers and fixed reusable-block assembly model",
        "changed": "console generator resources have exactly twice the total stored cell capacity; exact buffer-growth transformation remains unresolved",
    },
    {
        "subsystem": "generator MAP assembly",
        "ios_symbol": "stageGenerateMap",
        "ios_address_armv7": "0x000E06D8",
        "console_xbox_address": "0x8226CB28 + 0x8226CD30",
        "console_role": "append generator MAP blocks + choose/load 24 named blocks",
        "confidence": "high",
        "preserved": "24-block generated stage; a_%03d.map..j_%03d.map naming family; three-layer map assembly; same 330-map generator family",
        "changed": "console split selection and append responsibilities into distinct recovered routines; stored MAP corpus capacity doubled",
    },
)


# dev19 direct gameplay-code ancestry. Pool rows are source-only structural
# metadata reconstructed from named iOS functions and console constructors; no
# executable bytes or decompiled code are embedded.
STAGE3_BOSS_POOL_LINEAGE = (
    {"boss": "THE_MOON", "ios_opcode": "0x0046", "ios_pools": ((70, 5), (36, 20)), "console_pools": ((70, 5), (36, 20)), "preserved_slots": 2, "total_slots": 2},
    {"boss": "THE_SUN", "ios_opcode": "0x0047", "ios_pools": ((71, 9), (37, 8), (38, 36), (39, 20), (46, 4)), "console_pools": ((71, 9), (37, 8), (38, 60), (39, 20), (46, 4)), "preserved_slots": 4, "total_slots": 5, "changed_slot": {"type_id": 38, "ios_capacity": 36, "console_capacity": 60, "ios_handler": "dischargeTheSunWaveShot"}},
    {"boss": "GIGANTIC_UFO", "ios_opcode": "0x0048", "ios_pools": ((72, 59), (40, 20), (41, 20), (42, 4), (43, 2), (44, 2), (23, 10), (28, 10), (60, 30), (29, 30), (80, 4)), "console_pools": ((72, 59), (40, 20), (41, 20), (42, 4), (43, 2), (44, 2), (23, 10), (28, 10), (60, 30), (29, 30), (80, 4)), "preserved_slots": 11, "total_slots": 11},
    {"boss": "LADYBUG", "ios_opcode": "0x0049", "ios_pools": ((73, 5), (45, 40), (46, 20), (47, 4)), "console_pools": ((73, 5), (45, 40), (46, 20), (47, 4)), "preserved_slots": 4, "total_slots": 4},
    {"boss": "MANDALA", "ios_opcode": "0x004A", "ios_pools": ((74, 72), (48, 100), (49, 10), (50, 40)), "console_pools": ((74, 72), (48, 100), (49, 10), (50, 40)), "preserved_slots": 4, "total_slots": 4},
    {"boss": "UNKNOWN", "ios_opcode": "0x004B", "ios_pools": ((75, 11), (51, 30), (52, 30), (53, 80)), "console_pools": ((75, 11), (51, 30), (52, 30), (53, 80)), "preserved_slots": 4, "total_slots": 4},
)

BOSS_CONSTRUCTOR_EVOLUTION = tuple(
    {
        "boss": boss,
        "may9_to_may11_mnemonic_similarity": 1.0,
        "may11_to_june10_similarity_band": "~0.86-0.93 across the six bosses",
        "may11_to_june10_exact_score_retained": False,
        "june10_to_retail_mnemonic_similarity": 1.0,
        "interpretation": (
            "engine/layout refactor around preserved gameplay logic; THE_MOON specifically grows 0x10C->0x120 and replaces repeated runtime-rate calls with centralized frame-multiplier timing"
            if boss == "THE_MOON" else
            "engine/layout refactor around preserved gameplay logic; exact per-boss middle similarity was not retained in the continuity checkpoint"
        ),
    }
    for boss in ("THE_MOON", "THE_SUN", "GIGANTIC_UFO", "LADYBUG", "MANDALA", "UNKNOWN")
)

CONSOLE_ENEMY_HANDLER_LINEAGE = (
    {"opcode": 0x96, "script_name": "CIRCLE_INVADER"},
    {"opcode": 0x97, "script_name": None},
    {"opcode": 0x98, "script_name": None},
    {"opcode": 0x99, "script_name": "GREED"},
    {"opcode": 0x9A, "script_name": "LINE_INVADER"},
    {"opcode": 0x9B, "script_name": "WRATH"},
    {"opcode": 0x9C, "script_name": "GLUTTONY", "retune": "56-object helper type 55->72", "retune_window": "May 9 -> May 11"},
    {"opcode": 0x9D, "script_name": None},
    {"opcode": 0x9E, "script_name": "SG_GIGANTIC_UFO"},
    {"opcode": 0x9F, "script_name": None, "dispatcher_status": "NULL in May 9, May 11, June 10, and retail; absent from available DAT corpus"},
    {"opcode": 0xA0, "script_name": "CENTIPEDE"},
    {"opcode": 0xA1, "script_name": "HONET"},
    {"opcode": 0xA2, "script_name": "PROGRESSIVE_UFO"},
    {"opcode": 0xA3, "script_name": "OCTOPUS"},
    {"opcode": 0xA4, "script_name": "BUTTERFLY"},
    {"opcode": 0xA5, "script_name": None},
    {"opcode": 0xA6, "script_name": "WATER_STRIDER"},
    {"opcode": 0xA7, "script_name": None, "name_status": "machine-readable opcode name unresolved; gameplay identification is CRAB and Crab.cpp exists, but the explicit code linkage remains a research target"},
    {"opcode": 0xA8, "script_name": "ULTIMATE_UFO", "retune": "type-55 helper pool capacity 20->40", "retune_window": "May 11 -> June 10"},
    {"opcode": 0xA9, "script_name": "SQUID"},
    {"opcode": 0xAA, "script_name": "VERTEBRATE", "retune": "one pool 4->20; one 80-object helper type 72->62", "retune_window": "May 11 -> June 10"},
    {"opcode": 0xAB, "script_name": "NO_NAME"},
)

WORLD5_DEVELOPMENT_CHRONOLOGY = (
    {"opcode": 0xA6, "script_name": "WATER_STRIDER", "normal_stage": "5-1", "may9": "trial 5-1 only; not normal 5-1", "may11": "normal 5-1 integrated", "june10": "normal 5-1 integrated", "retail": "normal 5-1 integrated"},
    {"opcode": 0xA7, "script_name": None, "normal_stage": "5-2", "may9": "boss slot present in normal 5-2", "may11": "boss slot present", "june10": "boss slot present", "retail": "boss slot present", "note": "gameplay identification CRAB; keep machine-readable opcode name unresolved until explicit code connection"},
    {"opcode": 0xA8, "script_name": "ULTIMATE_UFO", "normal_stage": "5-3", "may9": "normal 5-3 integrated", "may11": "normal 5-3 integrated", "june10": "normal 5-3 integrated", "retail": "normal 5-3 integrated"},
    {"opcode": 0xA9, "script_name": "SQUID", "normal_stage": "5-4", "may9": "not normal-stage content", "may11": "not normal-stage content", "june10": "first preserved normal-stage integration", "retail": "normal 5-4 integrated"},
    {"opcode": 0xAA, "script_name": "VERTEBRATE", "normal_stage": "5-5", "may9": "not normal-stage content", "may11": "not normal-stage content", "june10": "first preserved normal-stage integration", "retail": "normal 5-5 integrated"},
    {"opcode": 0xAB, "script_name": "NO_NAME", "normal_stage": "5-6", "may9": "hidden 3Db_026.dat generator test only", "may11": "hidden 3Db_026.dat generator test only", "june10": "first preserved normal-stage integration", "retail": "normal 5-6 integrated"},
)


CONSOLE_OPCODE_EXPANSION = (
    {"range": "0x96-0xAB", "family": "new/expanded console enemies and 3D bosses", "examples": "CIRCLE_INVADER, GREED, WRATH, WATER_STRIDER, ULTIMATE_UFO, SQUID, VERTEBRATE, NO_NAME"},
    {"range": "0xB4-0xBE", "family": "3D stage controls", "examples": "3D Back Scroll, 3D Wall Scroll, 3D Back Color, 3D Camera Change 01, 3D Demo, 3D Back Animation, 3D Field Rotate Control"},
    {"range": "0xC8-0xCE", "family": "Visualizer controls", "examples": "VL_START, VL_END, VL_DISP_ON/OFF, VL_SEQUENCESET, VL_CHANGETIME, VL_VOLUME_SCALE"},
)


def ios_console_lineage_reference() -> dict[str, Any]:
    """Return source-only executable-lineage facts through dev19 research."""
    return {
        "format": "SIIG_IOS_CONSOLE_CODE_LINEAGE",
        "schema_version": 2,
        "mobile_command_dispatch": {
            "primary_analyzer": {"symbol": "analyzeScript", "serialized_opcode_min": 0x02, "serialized_opcode_max": 0x83},
            "fps60_primary_analyzer": {"symbol": "analyzeScript_FPS60", "serialized_opcode_min": 0x02, "serialized_opcode_max": 0x83},
            "secondary_analyzer": {"symbol": "analyzeScript2", "serialized_opcode_min": 0x6E, "serialized_opcode_max": 0x8D},
            "effective_mobile_frontier": 0x8D,
            "console_table_frontier": 0xCE,
            "note": "0x83 is only the primary iOS analyzer frontier; 0x84..0x8D are handled by analyzeScript2.",
        },
        "timing_model": {
            "authored_hz": 30,
            "ios_delta_runtime_formula": "runtime_delta = authored_delta * runtime_fps / 30",
            "ios_scroll_runtime_formula": "runtime_speed = authored_speed * 30 / runtime_fps",
            "console_duration_formula": "runtime_updates = authored_ticks * frame_multiplier",
            "console_velocity_formula": "runtime_velocity = authored_velocity / frame_multiplier",
            "console_update_hz_formula": "runtime_updates_per_second = 30 * frame_multiplier",
            "interpretation": "same 30-Hz authored-time invariant; console centralizes the 30/60 timing policy that mobile partly handled with duplicated primary analyzers",
        },
        "generator_model": {
            "ios_output_layers": 3,
            "ios_bytes_per_output_layer": 6144,
            "ios_block_iterations": 24,
            "ordinary_block_width": 8,
            "ordinary_block_height": 32,
            "capacity_identity": "6144 = 24 * 8 * 32",
            "ios_generator_map_files": 330,
            "ios_nonempty_generator_layers": 645,
            "ios_generator_cells": 121472,
            "console_generator_map_files": 330,
            "console_nonempty_generator_layers": 645,
            "console_generator_cells": 242944,
            "console_to_ios_cell_ratio": 2.0,
            "warning": "nonzero cells are not doubled, so the console corpus is not a simple byte duplication of the mobile maps",
        },
        "function_lineage": [dict(x) for x in IOS_CONSOLE_FUNCTION_LINEAGE],
        "stage3_boss_pool_lineage": [dict(x) for x in STAGE3_BOSS_POOL_LINEAGE],
        "boss_constructor_evolution": [dict(x) for x in BOSS_CONSTRUCTOR_EVOLUTION],
        "console_enemy_handler_lineage": [dict(x) for x in CONSOLE_ENEMY_HANDLER_LINEAGE],
        "world5_development_chronology": [dict(x) for x in WORLD5_DEVELOPMENT_CHRONOLOGY],
        "console_opcode_expansion": [dict(x) for x in CONSOLE_OPCODE_EXPANSION],
        "evidence_policy": {
            "high": "both sides have instruction-level or executable-backed structural evidence",
            "high-structural": "behavior/data structure matches strongly but exact console symbol/address attribution is incomplete",
            "continuity_reconstruction": "dev19 exact findings are retained; exact per-boss May11->June10 similarity values and raw dispatcher pointer values were not retained, so this source-only reconstruction does not invent them",
            "no_binary_distribution": True,
        },
    }
