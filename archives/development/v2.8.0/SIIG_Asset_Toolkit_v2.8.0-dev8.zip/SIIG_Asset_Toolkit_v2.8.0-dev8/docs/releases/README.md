# Releases

Historical release notes. Current version information is also summarized in the root README and changelog.

- [`RELEASE_NOTES_2.2.md`](RELEASE_NOTES_2.2.md)
- [`RELEASE_NOTES_2.3.md`](RELEASE_NOTES_2.3.md)
- [`RELEASE_NOTES_2.4.md`](RELEASE_NOTES_2.4.md)
- [`RELEASE_NOTES_2.5.1.md`](RELEASE_NOTES_2.5.1.md)
- [`RELEASE_NOTES_2.5.md`](RELEASE_NOTES_2.5.md)

- [`RELEASE_NOTES_2.8.0-dev1.md`](RELEASE_NOTES_2.8.0-dev1.md) — retail-package/internal-SDAT/audio consolidation checkpoint
- [`RELEASE_NOTES_2.8.0-dev2.md`](RELEASE_NOTES_2.8.0-dev2.md) — current runtime registry, route-source, and GMX-track research checkpoint

- [`RELEASE_NOTES_2.8.0-dev3.md`](RELEASE_NOTES_2.8.0-dev3.md) — fixed-spacing route resampling and runtime camera-preset checkpoint
- [`RELEASE_NOTES_2.8.0-dev4.md`](RELEASE_NOTES_2.8.0-dev4.md) — dynamic route-runtime and DAT-coupled playback checkpoint

- [`RELEASE_NOTES_2.8.0-dev6.md`](RELEASE_NOTES_2.8.0-dev6.md) — procedural route orientation + camera world-state checkpoint
- [`RELEASE_NOTES_2.8.0-dev5.md`](RELEASE_NOTES_2.8.0-dev5.md) — semantic retail camera-preset checkpoint

- [`RELEASE_NOTES_2.8.0-dev7.md`](RELEASE_NOTES_2.8.0-dev7.md) — runtime-correct GMX animation and explicit animated camera/field checkpoint

- [`RELEASE_NOTES_2.8.0-dev8.md`](RELEASE_NOTES_2.8.0-dev8.md) — cross-build PA-route activation research checkpoint
