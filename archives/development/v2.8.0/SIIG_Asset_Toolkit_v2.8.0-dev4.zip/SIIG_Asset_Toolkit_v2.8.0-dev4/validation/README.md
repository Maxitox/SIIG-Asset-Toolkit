# Validation reports

Machine-readable reports from release and corpus testing. Historical version numbers are retained in filenames so results are not confused with current runs.

- `SELFTEST_2.8.0-dev4.json` — 28-test dev4 regression report.
- `RELEASE_VALIDATION_2.8.0-dev4.json` — dev4 dynamic-route/DAT targeted real-corpus and source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev4.json` — dev4 source/package hygiene audit.
- `SELFTEST_2.8.0-dev3.json` — 26-test dev3 regression report.
- `RELEASE_VALIDATION_2.8.0-dev3.json` — dev3 targeted real-corpus and source-only release gates.
- `SOURCE_ONLY_AUDIT_2.8.0-dev3.json` — dev3 source/package hygiene audit.
