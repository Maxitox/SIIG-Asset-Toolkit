# SIIG Blender Add-on 0.1.0

This add-on imports extracted SIIG `.gmx` models into Blender by running the same verified GMX → glTF exporter shipped in `siig_toolkit.py`, then calling Blender's built-in glTF importer. It does not contain game assets and does not contact the network.

## Install

1. In Blender, open **Edit → Preferences → Add-ons**.
2. Choose **Install from Disk** and select `SIIG_Blender_Addon_v0.1.0.zip`.
3. Enable **SIIG Asset Toolkit**.
4. Open the add-on preferences and select the folder containing `siig_toolkit.py`.

## Use

- **File → Import → Space Invaders Infinity Gene (.gmx)** imports one or several GMX files.
- The **SIIG** tab in the 3D View sidebar provides single-file and folder import actions.
- Set a texture root when related TEX/DDS/PNG files are outside the GMX directory.

Imported objects receive `siig_source_gmx` and `siig_toolkit_version` custom properties. The add-on can place each imported GMX in its own collection.

## Current boundaries

- The add-on imports through generated glTF; it does not edit or export GMX.
- Hierarchy, materials, rigid attachments, and supported transform animations are limited to what the toolkit's GMX exporter has verified.
- Missing textures are reported but do not stop geometry import.
- Blender 3.6 or newer is the supported baseline. Syntax is validated automatically, but final UI behavior must be tested inside Blender.
