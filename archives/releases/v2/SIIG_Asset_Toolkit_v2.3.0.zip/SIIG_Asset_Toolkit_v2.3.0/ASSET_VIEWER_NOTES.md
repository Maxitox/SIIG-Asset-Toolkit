# Offline HTML asset viewer

`asset-viewer` creates a searchable browser for a full rip or any extracted asset directory.

```bat
python siig_toolkit.py asset-viewer SIIG_Ripped -o SIIG_Ripped\asset_viewer
```

The generated `SIIG_Asset_Viewer.html`:

- makes no network requests;
- filters and sorts by asset type, name, path, extension, size, and hash;
- embeds bounded image/audio previews when practical;
- shows text/CSV/JSON previews;
- summarizes glTF meshes, nodes, materials, and animations;
- provides an interactive local-space wireframe preview for supported glTF geometry;
- links to original files with relative URLs;
- records an `ASSET_VIEWER_REPORT.json` summary.

`rip-game` builds the viewer automatically unless `--no-asset-viewer` is supplied. Use `--viewer-no-hash` to reduce generation time or `--viewer-max-embed-mib` to change the preview budget.

For browser file-access restrictions, use the local-only server:

```bat
python siig_toolkit.py serve SIIG_Ripped
```

It binds to `127.0.0.1` and opens the default browser. It does not expose the directory on other network interfaces.

## Preview boundaries

- The wireframe view is a lightweight inspection aid, not a replacement for Blender. It displays sampled local mesh-space geometry and does not reproduce every node transform, shader, or animation.
- Large media files remain linked rather than embedded once configured limits are reached.
- XMA, AT3, WMA, XWB, and SBlk/VAG data are inventoried but may not be playable in a browser.
- A generated viewer can contain game-derived previews and should be kept private unless redistribution rights are clear.
