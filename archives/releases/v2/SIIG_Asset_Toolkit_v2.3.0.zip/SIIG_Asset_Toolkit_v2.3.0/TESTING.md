# Testing and validation

This release includes a dependency-free regression suite and reproducible end-to-end checks. Validation is intended to catch parser regressions, unsafe extraction behavior, stale resume output, and accidental privacy leaks; it is not a substitute for testing every possible third-party package variant.

## Built-in self-test

```bat
python siig_toolkit.py selftest
```

The suite covers:

1. FIPS-197 AES-128 known-answer vector.
2. DAT framing, signed delta accumulation, and argument preservation.
3. MAP layer parsing and cell encoding.
4. BBX extraction and filename-hash behavior.
5. BBX repacking, unnamed entries, seeded hashes, sorted indexes, and round-trip verification.
6. Bounded gzip expansion.
7. PNG decoding and atlas-backed MAP rendering, including flips.
8. ZIP extraction safety and traversal rejection.
9. Privacy scrubbing.
10. Offline HTML asset-viewer inventory and embedded previews.
11. Output-manifest generation and tamper detection.

A successful run exits with code 0 and reports all tests as passed.

## Environment/input diagnostics

```bat
python siig_toolkit.py doctor
python siig_toolkit.py doctor "C:\path\to\input"
```

`doctor` checks:

- supported Python version;
- required standard-library cryptographic primitives and bundled modules;
- bundled CSV/JSON lookup files;
- optional FFmpeg availability;
- recognizable package/game input indicators when a path is supplied.

Warnings may describe optional functionality, such as missing FFmpeg. Errors indicate that the requested workflow is not ready.

## Verify a full rip

```bat
python siig_toolkit.py verify-output "C:\path\to\SIIG_Ripped"
```

Full mode checks every manifest SHA-256. Quick mode checks structure, sizes, privacy, and partial files without hashing:

```bat
python siig_toolkit.py verify-output "C:\path\to\SIIG_Ripped" --quick
```

A machine-readable report may be written with:

```bat
python siig_toolkit.py verify-output "C:\path\to\SIIG_Ripped" ^
  --json-output verification_result.json
```

## 2.3.0 release validation

The release candidate is tested with:

- Python bytecode compilation for all bundled Python modules and Blender add-on source;
- the complete 11-case built-in self-test;
- byte-identical extraction/repacking of the supplied retail `map.bin`;
- deterministic gzip repack verification;
- canonical repack verification of larger supplied BBX archives;
- offline asset-viewer generation on real extracted output;
- JavaScript syntax validation of generated Stage Explorer and Asset Viewer files;
- an end-to-end SIIG subset containing the original `default.xex`, `map.bin`, `script.bin`, and `texture_map.bin` resources;
- automatic BBX extraction, DAT/MAP conversion, both HTML viewers, manifest generation, and output verification;
- deterministic release ZIP reconstruction and source-only content scanning.

Blender itself was unavailable in the build environment. Add-on syntax, packaging, toolkit discovery logic, and exporter calls are validated outside Blender; final operator/UI behavior remains an explicit in-Blender test item.

The end-to-end subset produced:

```text
3 BBX archives processed
146 resources extracted
76 DAT files decoded
64 MAP files decoded
92 Stage Explorer entries
17,335 stage DAT commands
573,984 stage MAP cells
4 MAP atlases embedded
423 output files hashed and verified
0 verification errors
```

These counts are test evidence, not promised output for every platform/input combination.

## Container-reader coverage

The STFS/PKG implementations have synthetic tests for consecutive/chained STFS files, level-0/1/2 boundaries, finalized/debug PKG streams, AES, malformed metadata, extraction limits, and unsafe paths. Supplied extracted retail releases were also processed end to end.

The exact original retail SIIG STFS and PKG outer packages were not available. Validation against those exact package files remains an explicit open item.

## Adding a regression case

A new parser or security fix should include a minimal deterministic synthetic case in `selftest` when feasible. Tests must not include copyrighted game assets, machine-specific absolute paths, secrets, or nondeterministic timestamps.

For corpus-only findings that cannot be reduced to a synthetic fixture, record:

- input class and build;
- relevant counts/hashes without redistributing content;
- expected behavior;
- observed failure before the fix;
- observed success after the fix;
- any unresolved ambiguity.
