# Third-party notices

This source-only package does not bundle FFmpeg, vgmstream, Ghidra, XEXLoaderWV, TrueAncestor, Xenia, DirectXTK, or any other external binary/library. It contains no game assets.

## Adapted source logic

### Xenia

The function `xg_address_2d_tiled_offset` in `siig_toolkit.py` is an independent Python translation/adaptation of Xenos tiled-texture addressing logic published by the Xenia project. It was reduced to SIIG's texture cases, renamed, and validated against the supplied texture corpus.

Upstream: https://github.com/xenia-project/xenia  
License: BSD 3-Clause  
Notice: `LICENSES/XENIA-BSD-3-CLAUSE.txt`

The exact historical upstream commit/file consulted was not preserved. This limitation is recorded in `SOURCE_AUDIT.md` and `PROVENANCE.json`.

## Normative documentation and algorithm references

### NIST FIPS 197

The locally written AES-128 implementation is validated with the published FIPS-197 known-answer vector. No NIST implementation code is included.

Reference: https://csrc.nist.gov/pubs/fips/197/final

### Microsoft DirectXTK Wave Formats

The XMA2 RIFF wrapper field layout follows the public `XMA2WAVEFORMATEX` documentation. No DirectXTK source code is included.

Reference: https://github.com/microsoft/DirectXTK/wiki/Wave-Formats  
License of the referenced project: MIT

### Khronos glTF 2.0

Generated `.gltf` files target the Khronos glTF 2.0 specification. No Khronos implementation library is bundled.

Reference: https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html

### Portable Network Graphics

The limited PNG reader/writer used for texture and MAP rendering is locally written against the PNG format specification. No third-party PNG library is bundled.

Reference: https://www.w3.org/TR/png/

### Python standard library

The toolkit uses Python standard-library modules, including `zipfile`, `hashlib`, `zlib`, `json`, `csv`, and `struct`. The interpreter is not bundled.

Reference: https://www.python.org/  
License: PSF License

## External tools

### Ghidra

Used for reverse engineering and by the optional Java label script. Not distributed with this toolkit.

Upstream: https://github.com/NationalSecurityAgency/ghidra  
License: Apache-2.0

### XEXLoaderWV

Used by the project owner to load Xbox 360 XEX files into Ghidra. No code is bundled or copied.

Upstream: https://github.com/zeroKilo/XEXLoaderWV  
Original author credit in the repository: Warranty Voider

### FFmpeg

Invoked as a separate process when installed by the user. It is not linked, modified, or redistributed by this package.

Upstream: https://ffmpeg.org/  
License: LGPL-2.1-or-later by default; GPL terms may apply to particular builds.

### vgmstream

Recommended as a separate decoder/fallback. It is not bundled.

Upstream: https://github.com/vgmstream/vgmstream  
License: consult upstream `COPYING`.

### TrueAncestor EDAT Rebuilder

Used externally to obtain decrypted PS3 SDAT payloads. No TrueAncestor code or files are included. Because an explicit redistribution/source license was not identified in this audit, it remains strictly a user-supplied external tool.

Reference: https://www.psx-place.com/resources/trueancestor-edat-rebuilder-by-jjkkyu.34/  
Author: JjKkYu

## Locally authored container support

The STFS and PS3 PKG readers are clean-room project implementations. They do not incorporate code from a third-party container reader. See `SOURCE_AUDIT.md` and `CONTAINER_INPUT_NOTES.md` for evidence and test boundaries.


## Blender

Blender is an optional external host for `SIIG_Blender_Addon_v0.1.0.zip`. Blender is not bundled. The add-on is locally authored, imports `bpy` at runtime, and invokes Blender's built-in glTF importer after the toolkit creates a temporary glTF file. No Blender source code is copied into the toolkit.
