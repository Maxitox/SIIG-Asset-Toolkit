#!/usr/bin/env python3
"""Offline, single-file asset browser for SIIG toolkit outputs.

The viewer is generated locally and never makes network requests. Preview payloads are
bounded; original files remain beside the HTML and can be opened through relative links.
"""
from __future__ import annotations

import base64
import csv
import hashlib
import html
import json
import math
import mimetypes
import os
import struct
import wave
import webbrowser
import zlib
from dataclasses import dataclass
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Iterable, Optional
from urllib.parse import quote

VIEWER_VERSION = "1.0.0"
TEXT_EXTENSIONS = {
    ".txt", ".md", ".csv", ".json", ".xml", ".ini", ".cfg", ".log",
    ".obj", ".mtl", ".fnt", ".glsl", ".hlsl", ".bat", ".ps1",
}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
MODEL_EXTENSIONS = {".gltf", ".glb", ".obj", ".gmx"}
AUDIO_EXTENSIONS = {".wav", ".mp3", ".ogg", ".flac", ".m4a", ".wma", ".xma", ".at3"}
ARCHIVE_EXTENSIONS = {".zip", ".gz", ".pkg", ".bin", ".bbx", ".sdat"}
DATA_EXTENSIONS = {".map", ".dat", ".col", ".anm", ".tex", ".crp", ".xwb", ".xsb", ".bnk"}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _kind(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in IMAGE_EXTENSIONS:
        return "image"
    if ext in MODEL_EXTENSIONS:
        return "model"
    if ext in AUDIO_EXTENSIONS:
        return "audio"
    if ext in TEXT_EXTENSIONS:
        return "text"
    if ext in DATA_EXTENSIONS:
        return "data"
    if ext in ARCHIVE_EXTENSIONS:
        return "archive"
    return "other"


def _png_size(data: bytes) -> Optional[tuple[int, int]]:
    if len(data) >= 24 and data[:8] == b"\x89PNG\r\n\x1a\n" and data[12:16] == b"IHDR":
        return struct.unpack_from(">II", data, 16)
    return None


def _jpeg_size(data: bytes) -> Optional[tuple[int, int]]:
    if not data.startswith(b"\xFF\xD8"):
        return None
    offset = 2
    while offset + 9 <= len(data):
        if data[offset] != 0xFF:
            offset += 1
            continue
        marker = data[offset + 1]
        offset += 2
        if marker in (0xD8, 0xD9):
            continue
        if offset + 2 > len(data):
            break
        length = int.from_bytes(data[offset:offset + 2], "big")
        if length < 2 or offset + length > len(data):
            break
        if marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
            if length >= 7:
                return int.from_bytes(data[offset + 3:offset + 5], "big"), int.from_bytes(data[offset + 5:offset + 7], "big")
            break
        offset += length
    return None


def _image_meta(path: Path) -> dict[str, Any]:
    try:
        data = path.read_bytes()[:512 * 1024]
    except OSError:
        return {}
    size = _png_size(data) or _jpeg_size(data)
    return {"width": size[0], "height": size[1]} if size else {}


def _text_preview(path: Path, limit: int = 48 * 1024) -> str:
    try:
        raw = path.read_bytes()[:limit]
    except OSError:
        return ""
    if b"\x00" in raw[:2048]:
        return ""
    return raw.decode("utf-8", errors="replace")


def _wav_meta(path: Path) -> dict[str, Any]:
    try:
        with wave.open(str(path), "rb") as handle:
            frames = handle.getnframes()
            rate = handle.getframerate()
            return {
                "channels": handle.getnchannels(),
                "sample_rate": rate,
                "sample_width_bits": handle.getsampwidth() * 8,
                "frames": frames,
                "duration_seconds": round(frames / rate, 4) if rate else 0,
            }
    except (OSError, wave.Error):
        return {}


def _safe_child(root: Path, candidate: Path) -> Optional[Path]:
    try:
        resolved_root = root.resolve()
        resolved = candidate.resolve()
        resolved.relative_to(resolved_root)
        return resolved
    except (OSError, ValueError):
        return None


def _gltf_summary(path: Path) -> dict[str, Any]:
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return {}
    meshes = document.get("meshes", []) if isinstance(document, dict) else []
    nodes = document.get("nodes", []) if isinstance(document, dict) else []
    materials = document.get("materials", []) if isinstance(document, dict) else []
    animations = document.get("animations", []) if isinstance(document, dict) else []
    primitives = sum(len(mesh.get("primitives", [])) for mesh in meshes if isinstance(mesh, dict))
    return {
        "meshes": len(meshes),
        "primitives": primitives,
        "nodes": len(nodes),
        "materials": len(materials),
        "animations": len(animations),
        "wireframe": _gltf_wireframe(path, document),
    }


def _component_format(component_type: int) -> Optional[tuple[str, int]]:
    return {
        5120: ("b", 1), 5121: ("B", 1), 5122: ("h", 2), 5123: ("H", 2),
        5125: ("I", 4), 5126: ("f", 4),
    }.get(component_type)


def _type_components(value: str) -> int:
    return {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT2": 4, "MAT3": 9, "MAT4": 16}.get(value, 0)


def _load_gltf_buffer(path: Path, document: dict[str, Any], index: int) -> Optional[bytes]:
    buffers = document.get("buffers", [])
    if not isinstance(buffers, list) or index < 0 or index >= len(buffers) or not isinstance(buffers[index], dict):
        return None
    uri = buffers[index].get("uri")
    if not isinstance(uri, str):
        return None
    if uri.startswith("data:"):
        try:
            return base64.b64decode(uri.split(",", 1)[1], validate=True)
        except Exception:
            return None
    target = _safe_child(path.parent, path.parent / uri)
    if target is None or not target.is_file() or target.stat().st_size > 128 * 1024 * 1024:
        return None
    try:
        return target.read_bytes()
    except OSError:
        return None


def _read_accessor(path: Path, document: dict[str, Any], accessor_index: int, max_items: int) -> list[tuple[float, ...]]:
    accessors = document.get("accessors", [])
    views = document.get("bufferViews", [])
    if not isinstance(accessors, list) or accessor_index < 0 or accessor_index >= len(accessors):
        return []
    accessor = accessors[accessor_index]
    if not isinstance(accessor, dict) or "sparse" in accessor:
        return []
    view_index = accessor.get("bufferView")
    if not isinstance(view_index, int) or not isinstance(views, list) or view_index < 0 or view_index >= len(views):
        return []
    view = views[view_index]
    if not isinstance(view, dict):
        return []
    component = _component_format(int(accessor.get("componentType", 0)))
    components = _type_components(str(accessor.get("type", "")))
    count = min(int(accessor.get("count", 0)), max_items)
    if component is None or components < 1 or count < 1:
        return []
    fmt, component_size = component
    buffer_index = int(view.get("buffer", -1))
    payload = _load_gltf_buffer(path, document, buffer_index)
    if payload is None:
        return []
    element_size = component_size * components
    stride = int(view.get("byteStride", element_size))
    if stride < element_size:
        return []
    offset = int(view.get("byteOffset", 0)) + int(accessor.get("byteOffset", 0))
    output: list[tuple[float, ...]] = []
    unpack = struct.Struct("<" + fmt * components)
    for index in range(count):
        position = offset + index * stride
        if position < 0 or position + element_size > len(payload):
            break
        values = unpack.unpack_from(payload, position)
        output.append(tuple(float(value) for value in values))
    return output


def _gltf_wireframe(path: Path, document: dict[str, Any]) -> dict[str, Any]:
    meshes = document.get("meshes", [])
    if not isinstance(meshes, list):
        return {}
    points: list[list[float]] = []
    edges: list[list[int]] = []
    max_points = 5000
    max_edges = 10000
    for mesh in meshes:
        if not isinstance(mesh, dict):
            continue
        for primitive in mesh.get("primitives", []):
            if not isinstance(primitive, dict):
                continue
            attributes = primitive.get("attributes", {})
            position_accessor = attributes.get("POSITION") if isinstance(attributes, dict) else None
            if not isinstance(position_accessor, int):
                continue
            local = _read_accessor(path, document, position_accessor, max_points - len(points))
            if not local:
                continue
            base = len(points)
            for value in local:
                if len(value) >= 3:
                    points.append([round(value[0], 6), round(value[1], 6), round(value[2], 6)])
            indices_accessor = primitive.get("indices")
            indices: list[int] = []
            if isinstance(indices_accessor, int):
                raw_indices = _read_accessor(path, document, indices_accessor, max_edges * 3)
                indices = [int(item[0]) for item in raw_indices if item]
            else:
                indices = list(range(len(local)))
            mode = int(primitive.get("mode", 4))
            if mode == 4:
                for i in range(0, len(indices) - 2, 3):
                    tri = indices[i:i + 3]
                    if max(tri, default=-1) >= len(local) or min(tri, default=0) < 0:
                        continue
                    edges.extend([[base + tri[0], base + tri[1]], [base + tri[1], base + tri[2]], [base + tri[2], base + tri[0]]])
                    if len(edges) >= max_edges:
                        break
            elif mode == 1:
                for i in range(0, len(indices) - 1, 2):
                    a, b = indices[i], indices[i + 1]
                    if 0 <= a < len(local) and 0 <= b < len(local):
                        edges.append([base + a, base + b])
                    if len(edges) >= max_edges:
                        break
            if len(points) >= max_points or len(edges) >= max_edges:
                break
        if len(points) >= max_points or len(edges) >= max_edges:
            break
    if not points:
        return {}
    mins = [min(point[i] for point in points) for i in range(3)]
    maxs = [max(point[i] for point in points) for i in range(3)]
    return {"points": points, "edges": edges[:max_edges], "min": mins, "max": maxs}


def _data_uri(path: Path, max_bytes: int) -> Optional[str]:
    try:
        size = path.stat().st_size
        if size > max_bytes:
            return None
        payload = path.read_bytes()
    except OSError:
        return None
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    return f"data:{mime};base64,{base64.b64encode(payload).decode('ascii')}"


def _human_bytes(value: int) -> str:
    number = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if number < 1024 or unit == "TiB":
            return f"{number:.0f} {unit}" if unit == "B" else f"{number:.1f} {unit}"
        number /= 1024
    return str(value)


def _walk_files(root: Path, excluded: set[Path]) -> Iterable[Path]:
    for path in sorted(root.rglob("*"), key=lambda item: item.as_posix().lower()):
        if not path.is_file():
            continue
        try:
            resolved = path.resolve()
        except OSError:
            continue
        if resolved in excluded:
            continue
        if any(part in {".git", "__pycache__"} for part in path.parts):
            continue
        if path.name.endswith(".siig-part"):
            continue
        yield path


def build_asset_viewer(
    input_path: Path,
    output: Path,
    *,
    title: str = "SIIG Asset Viewer",
    hash_files: bool = True,
    max_embed_bytes: int = 32 * 1024 * 1024,
    max_single_preview_bytes: int = 4 * 1024 * 1024,
) -> dict[str, Any]:
    root = input_path.resolve()
    if not root.is_dir():
        raise ValueError(f"asset-viewer input must be a directory: {input_path}")
    if output.suffix.lower() == ".html":
        html_path = output.resolve()
        output_dir = html_path.parent
    else:
        output_dir = output.resolve()
        html_path = output_dir / "SIIG_Asset_Viewer.html"
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "ASSET_VIEWER_REPORT.json"
    excluded = {html_path.resolve(), report_path.resolve()}

    entries: list[dict[str, Any]] = []
    embedded_total = 0
    kind_counts: dict[str, int] = {}
    total_bytes = 0
    for path in _walk_files(root, excluded):
        relative = path.relative_to(root).as_posix()
        stat_result = path.stat()
        kind = _kind(path)
        kind_counts[kind] = kind_counts.get(kind, 0) + 1
        total_bytes += stat_result.st_size
        entry: dict[str, Any] = {
            "path": relative,
            "name": path.name,
            "extension": path.suffix.lower(),
            "kind": kind,
            "size": stat_result.st_size,
            "size_human": _human_bytes(stat_result.st_size),
            "modified_ns": stat_result.st_mtime_ns,
            "url": quote(os.path.relpath(path, html_path.parent).replace(os.sep, "/"), safe="/._-"),
        }
        if hash_files:
            entry["sha256"] = _sha256(path)
        if kind == "image":
            entry["metadata"] = _image_meta(path)
            remaining = max_embed_bytes - embedded_total
            if remaining > 0:
                preview = _data_uri(path, min(max_single_preview_bytes, remaining))
                if preview:
                    entry["preview"] = preview
                    embedded_total += stat_result.st_size
        elif kind == "audio":
            entry["metadata"] = _wav_meta(path) if path.suffix.lower() == ".wav" else {}
            if path.suffix.lower() in {".wav", ".mp3", ".ogg", ".flac", ".m4a"}:
                remaining = max_embed_bytes - embedded_total
                if remaining > 0:
                    preview = _data_uri(path, min(max_single_preview_bytes, remaining))
                    if preview:
                        entry["preview"] = preview
                        embedded_total += stat_result.st_size
        elif path.suffix.lower() == ".gltf":
            entry["metadata"] = _gltf_summary(path)
        elif kind == "text":
            entry["text_preview"] = _text_preview(path)
            if path.suffix.lower() == ".json":
                try:
                    value = json.loads(path.read_text(encoding="utf-8"))
                    if isinstance(value, dict):
                        entry["metadata"] = {"top_level_keys": list(value)[:40]}
                    elif isinstance(value, list):
                        entry["metadata"] = {"items": len(value)}
                except (OSError, UnicodeDecodeError, json.JSONDecodeError):
                    pass
        entries.append(entry)

    database = {
        "viewer_version": VIEWER_VERSION,
        "title": title,
        "root_name": root.name,
        "file_count": len(entries),
        "total_bytes": total_bytes,
        "total_bytes_human": _human_bytes(total_bytes),
        "embedded_preview_bytes": embedded_total,
        "kind_counts": kind_counts,
        "files": entries,
    }
    payload = json.dumps(database, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    html_path.write_text(_viewer_html(title, payload), encoding="utf-8", newline="\n")
    report = {
        key: value for key, value in database.items() if key != "files"
    }
    report.update({
        "html_file": html_path.name,
        "report_file": report_path.name,
        "hashes_included": hash_files,
        "max_embed_bytes": max_embed_bytes,
        "max_single_preview_bytes": max_single_preview_bytes,
    })
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return report


def _viewer_html(title: str, payload: str) -> str:
    safe_title = html.escape(title)
    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{safe_title}</title>
<style>
:root{{color-scheme:dark;--bg:#0b0e14;--panel:#121722;--panel2:#171e2b;--line:#2a3446;--text:#edf2ff;--muted:#9ba8bd;--accent:#76b9ff;font:14px system-ui,sans-serif}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text)}}header{{position:sticky;top:0;z-index:4;background:#0e131dcc;border-bottom:1px solid var(--line);backdrop-filter:blur(8px);padding:12px 16px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}}h1{{font-size:18px;margin:0 16px 0 0}}input,select,button{{background:var(--panel2);color:var(--text);border:1px solid #39475f;border-radius:7px;padding:7px 9px}}input{{min-width:270px}}button{{cursor:pointer}}main{{padding:14px}}.stats{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}}.stat{{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:8px 11px}}.stat b{{font-size:17px}}.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(245px,1fr));gap:10px}}.card{{background:var(--panel);border:1px solid var(--line);border-radius:10px;overflow:hidden;display:flex;flex-direction:column;min-height:180px}}.thumb{{height:150px;background:#080a0f;display:flex;align-items:center;justify-content:center;overflow:hidden;border-bottom:1px solid var(--line)}}.thumb img{{max-width:100%;max-height:100%;object-fit:contain;image-rendering:auto}}.thumb canvas{{width:100%;height:100%}}.icon{{font-size:44px;color:#596780}}.body{{padding:10px;min-width:0}}.name{{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}.path{{font-size:12px;color:var(--muted);overflow-wrap:anywhere;margin-top:4px}}.meta{{font-size:12px;color:#bdc8da;margin-top:7px}}.actions{{margin-top:auto;padding:0 10px 10px;display:flex;gap:6px}}a{{color:var(--accent)}}.pill{{display:inline-block;background:#273348;border-radius:999px;padding:2px 7px;font-size:11px;margin-right:4px}}dialog{{width:min(1100px,94vw);height:min(820px,90vh);background:var(--panel);color:var(--text);border:1px solid #48566e;border-radius:12px;padding:0}}dialog::backdrop{{background:#000b}}.modal-head{{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;border-bottom:1px solid var(--line)}}.modal-content{{height:calc(100% - 52px);overflow:auto;padding:14px}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#090c12;border:1px solid var(--line);padding:12px;border-radius:8px}}.large-preview{{max-width:100%;max-height:62vh;display:block;margin:auto}}.model{{height:62vh;width:100%;background:#070a0f;border-radius:8px}}.empty{{padding:40px;text-align:center;color:var(--muted)}}
</style></head><body>
<header><h1>{safe_title}</h1><input id="search" placeholder="Search name, path, extension, or hash"><select id="kind"><option value="">All types</option></select><select id="sort"><option value="path">Path</option><option value="name">Name</option><option value="size-desc">Largest</option><option value="size-asc">Smallest</option></select><span id="shown"></span></header>
<main><div class="stats" id="stats"></div><div class="grid" id="grid"></div></main>
<dialog id="modal"><div class="modal-head"><b id="modalTitle"></b><button onclick="modal.close()">Close</button></div><div class="modal-content" id="modalContent"></div></dialog>
<script>const DB={payload};
const grid=document.getElementById('grid'),search=document.getElementById('search'),kind=document.getElementById('kind'),sort=document.getElementById('sort'),shown=document.getElementById('shown'),modal=document.getElementById('modal'),modalTitle=document.getElementById('modalTitle'),modalContent=document.getElementById('modalContent');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}}[c]));
for(const key of Object.keys(DB.kind_counts).sort()){{const o=document.createElement('option');o.value=key;o.textContent=`${{key}} (${{DB.kind_counts[key]}})`;kind.appendChild(o)}}
stats.innerHTML=`<div class=stat><b>${{DB.file_count}}</b><br>files</div><div class=stat><b>${{DB.total_bytes_human}}</b><br>total</div><div class=stat><b>${{Math.round(DB.embedded_preview_bytes/1048576*10)/10}} MiB</b><br>embedded previews</div>`+Object.entries(DB.kind_counts).sort().map(([k,v])=>`<div class=stat><b>${{v}}</b><br>${{esc(k)}}</div>`).join('');
function icon(k){{return {{image:'▧',model:'◇',audio:'♫',text:'≡',data:'⌗',archive:'▣',other:'·'}}[k]||'·'}}
function meta(f){{const m=f.metadata||{{}},parts=[f.size_human];if(m.width)parts.push(`${{m.width}}×${{m.height}}`);if(m.meshes!==undefined)parts.push(`${{m.meshes}} meshes`,`${{m.animations}} animations`);if(m.duration_seconds!==undefined)parts.push(`${{m.duration_seconds}} s`,`${{m.sample_rate}} Hz`);return parts.join(' · ')}}
function modelCanvas(f){{const w=f.metadata?.wireframe;if(!w?.points?.length)return `<div class=icon>${{icon(f.kind)}}</div>`;return `<canvas data-model="${{esc(f.path)}}"></canvas>`}}
function thumb(f){{if(f.kind==='image'&&f.preview)return `<img loading=lazy src="${{f.preview}}">`;if(f.kind==='model')return modelCanvas(f);return `<div class=icon>${{icon(f.kind)}}</div>`}}
function render(){{const q=search.value.trim().toLowerCase(),k=kind.value;let files=DB.files.filter(f=>(!k||f.kind===k)&&(!q||`${{f.path}} ${{f.sha256||''}} ${{f.extension}}`.toLowerCase().includes(q)));files.sort((a,b)=>sort.value==='name'?a.name.localeCompare(b.name):sort.value==='size-desc'?b.size-a.size:sort.value==='size-asc'?a.size-b.size:a.path.localeCompare(b.path));shown.textContent=`${{files.length}}/${{DB.file_count}}`;grid.innerHTML=files.map((f,i)=>`<article class=card><div class=thumb>${{thumb(f)}}</div><div class=body><div><span class=pill>${{esc(f.kind)}}</span><span class=pill>${{esc(f.extension||'no ext')}}</span></div><div class=name title="${{esc(f.name)}}">${{esc(f.name)}}</div><div class=path>${{esc(f.path)}}</div><div class=meta>${{esc(meta(f))}}</div></div><div class=actions><button data-open="${{esc(f.path)}}">Inspect</button><a href="${{f.url}}" target=_blank>Open file</a></div></article>`).join('')||'<div class=empty>No matching assets.</div>';for(const b of grid.querySelectorAll('[data-open]'))b.onclick=()=>openFile(DB.files.find(f=>f.path===b.dataset.open));for(const c of grid.querySelectorAll('canvas[data-model]'))startModel(c,DB.files.find(f=>f.path===c.dataset.model),false)}}
function openFile(f){{modalTitle.textContent=f.path;let body=`<p><b>Type:</b> ${{esc(f.kind)}} · <b>Size:</b> ${{esc(f.size_human)}}${{f.sha256?`<br><b>SHA-256:</b> <code>${{esc(f.sha256)}}</code>`:''}}</p>`;if(f.kind==='image')body+=(f.preview?`<img class=large-preview src="${{f.preview}}">`:`<p>Preview was not embedded because of the configured size budget. <a href="${{f.url}}" target=_blank>Open original</a>.</p>`);else if(f.kind==='audio'&&f.preview)body+=`<audio controls style="width:100%" src="${{f.preview}}"></audio>`;else if(f.kind==='model'&&f.metadata?.wireframe?.points?.length)body+=`<canvas class=model id=modalModel></canvas><p class=path>Local mesh-space wireframe preview; node transforms and materials are summarized but not reproduced here.</p>`;else if(f.text_preview!==undefined)body+=`<pre>${{esc(f.text_preview)}}</pre>`;else body+=`<pre>${{esc(JSON.stringify(f.metadata||{{}},null,2))}}</pre>`;modalContent.innerHTML=body;modal.showModal();if(document.getElementById('modalModel'))startModel(document.getElementById('modalModel'),f,true)}}
function startModel(canvas,f,interactive){{const w=f?.metadata?.wireframe;if(!w?.points?.length)return;const ctx=canvas.getContext('2d'),pts=w.points,edges=w.edges||[];let ax=-.35,ay=.55,zoom=1,drag=false,lx=0,ly=0;function draw(){{const rect=canvas.getBoundingClientRect(),dpr=devicePixelRatio||1,ww=Math.max(10,Math.floor(rect.width*dpr)),hh=Math.max(10,Math.floor(rect.height*dpr));if(canvas.width!==ww||canvas.height!==hh){{canvas.width=ww;canvas.height=hh}}ctx.fillStyle='#070a0f';ctx.fillRect(0,0,ww,hh);const sx=Math.sin(ax),cx=Math.cos(ax),sy=Math.sin(ay),cy=Math.cos(ay),center=[(w.min[0]+w.max[0])/2,(w.min[1]+w.max[1])/2,(w.min[2]+w.max[2])/2],extent=Math.max(w.max[0]-w.min[0],w.max[1]-w.min[1],w.max[2]-w.min[2],1e-5),scale=Math.min(ww,hh)*.72/extent*zoom;const pp=pts.map(p=>{{let x=p[0]-center[0],y=p[1]-center[1],z=p[2]-center[2];const x1=x*cy+z*sy,z1=-x*sy+z*cy,y1=y*cx-z1*sx;return [ww/2+x1*scale,hh/2-y1*scale,z1]}});ctx.strokeStyle='#78baff';ctx.globalAlpha=.72;ctx.lineWidth=Math.max(1,dpr*.6);ctx.beginPath();for(const e of edges){{const a=pp[e[0]],b=pp[e[1]];if(!a||!b)continue;ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1])}}ctx.stroke();if(!edges.length){{ctx.fillStyle='#78baff';for(const p of pp)ctx.fillRect(p[0],p[1],2*dpr,2*dpr)}}ctx.globalAlpha=1}}draw();if(interactive){{canvas.onpointerdown=e=>{{drag=true;lx=e.clientX;ly=e.clientY;canvas.setPointerCapture(e.pointerId)}};canvas.onpointermove=e=>{{if(!drag)return;ay+=(e.clientX-lx)*.008;ax+=(e.clientY-ly)*.008;lx=e.clientX;ly=e.clientY;draw()}};canvas.onpointerup=()=>drag=false;canvas.onwheel=e=>{{e.preventDefault();zoom=Math.max(.2,Math.min(8,zoom*Math.exp(-e.deltaY*.001)));draw()}}}}else{{let t=0;const tick=()=>{{if(!canvas.isConnected)return;ay=.55+Math.sin(t)*.22;t+=.008;draw();requestAnimationFrame(tick)}};requestAnimationFrame(tick)}}}}
search.oninput=render;kind.onchange=render;sort.onchange=render;render();
</script></body></html>'''


def serve_directory(root: Path, *, port: int = 8765, open_browser: bool = True) -> None:
    directory = root.resolve()
    if not directory.is_dir():
        raise ValueError(f"serve root is not a directory: {root}")

    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, directory=str(directory), **kwargs)

        def log_message(self, fmt: str, *args: Any) -> None:
            print("viewer:", fmt % args)

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    url = f"http://127.0.0.1:{server.server_port}/"
    print(f"serving {directory} at {url}")
    print("press Ctrl+C to stop")
    if open_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nstopping server")
    finally:
        server.server_close()
