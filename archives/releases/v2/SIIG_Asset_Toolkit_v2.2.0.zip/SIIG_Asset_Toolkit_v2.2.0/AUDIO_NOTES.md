# SIIG XACT Audio Notes

The game audio is stored in Microsoft XACT3 banks. `sound.bin` is a BBX archive containing nested BBX archives, which in turn contain matching `.xsb` sound banks and `.xwb` wave banks.

## Confirmed banks

| Bank | Streams | Codec | Channels | Notes |
|---|---:|---|---|---|
| `SE.xwb` | 83 | XMA2 | mono | Cue names `SE01` through the XSB list (`SE83` is absent; the final cue is `SE84`) |
| `BGM_007.xwb` | 1 | XMA2 | stereo | Cue `BGM007` |
| `BGM_008.xwb` | 1 | XMA2 | stereo | Cue `BGM008_MIX_C` |
| `BGM_XACT_SE33.xwb` | 1 | XMA2 | mono | Cue `BGM_XACT_SE33` |

All banks use big-endian `DNBW` XACT3 version 46 and 0x800-byte wave-data alignment.

## Toolkit conversion

```bat
python siig_toolkit.py xact2wav sound.bin -o audio
```

The tool creates one directory per bank, one WAV per stream, and `xwb_manifest.csv` / `xwb_manifest.json`. FFmpeg is used only for the XMA2-to-PCM decode. Without FFmpeg, the generated RIFF-wrapped `.xma` files may be opened by vgmstream.

## General-purpose alternative

For unrelated XACT banks, vgmstream is preferable because it supports many XWB versions/codecs, loop handling, companion files and subsongs. With extracted XWB/XSB pairs kept together, `vgmstream-cli -S 0 bank.xwb` converts all subsongs.
