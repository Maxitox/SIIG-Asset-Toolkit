# One-click full-game rip

`rip-game` accepts the original outer package directly, an extracted game directory, or a ZIP containing an extracted game. Input type is detected from the header and contents rather than the filename extension.

```text
Xbox 360 STFS package: CON / LIVE / PIRS
PlayStation 3 type-1 PKG
Extracted game directory
ZIP containing an extracted game
```

## Before the first rip

```bat
python siig_toolkit.py selftest
python siig_toolkit.py doctor "C:\path\to\game-package"
```

`doctor` reports Python/runtime status, bundled-table integrity, optional FFmpeg availability, and any recognizable input issues without extracting the game.

## Fastest Windows method

Drag the package, extracted ZIP, or extracted folder onto `SIIG_Rip_Game.bat`.

The output is created beside the input as `SIIG_Ripped`. The launcher uses `--resume`; unchanged archives are skipped only when their source hash, conversion profile, and toolkit version match.

## Command-line examples

### Xbox 360

```bat
python siig_toolkit.py rip-game "C:\Games\SIIG_X360" -o "C:\Rips\SIIG_X360" --resume
```

### PlayStation 3

```bat
python siig_toolkit.py rip-game "C:\Games\SIIG_PS3.pkg" -o "C:\Rips\SIIG_PS3" ^
  --ps3-sdat-dir "C:\Games\SIIG_PS3_decrypted" --resume
```

The outer PKG is handled internally. SIIG's six inner NPDRM SDAT resources remain a separate cryptographic layer and require matching decrypted files:

```text
generator.bin.gz.dat
message.bin.gz.dat
script.bin.gz.dat
shader.bin.gz.dat
text.bin.gz.dat
visualizerSet.bin.gz.dat
```

They may be placed beside the PKG/ZIP or supplied through one or more `--ps3-sdat-dir` arguments.

### Previously extracted input

```bat
python siig_toolkit.py rip-game "C:\Games\Space Invaders IG X360.zip" -o "C:\Rips\SIIG_X360" --resume
python siig_toolkit.py rip-game "C:\Games\Extracted SIIG PS3" -o "C:\Rips\SIIG_PS3" --resume
```

### Outer-container-only mode

```bat
python siig_toolkit.py unpack-container "C:\Games\SIIG.pkg" -o "C:\Rips\SIIG_Installed_Files" --clean
```

This stops after STFS/PKG extraction and writes `SIIG_CONTAINER_MANIFEST.json`.

## Default processing sequence

1. Detect input type by magic/content.
2. Extract ZIP, STFS, or PKG into a bounded temporary workspace when needed.
3. Detect Xbox 360 or PS3 from `default.xex` or `EBOOT.BIN`.
4. Match PS3 decrypted SDAT outputs where applicable.
5. Normalize gzip-wrapped BBX archives with bounded expansion.
6. Extract BBX resources recursively with hash validation and entry/depth budgets.
7. Convert supported textures, models, font, audio, localization, DAT, MAP, COL, and ANM resources.
8. Build the offline Stage Explorer when its required data is present.
9. Write privacy-safe reports and a deterministic SHA-256 output manifest.
10. Remove temporary outer-container files.

## Output layout

```text
SIIG_Ripped\
├── assets\
├── decompressed_bbx\
├── audio\
├── localization\
├── ready_files\
├── stage_explorer\
├── structured\
│   ├── dat\
│   └── map\
├── systemfont\
└── validation\
    ├── RIP_REPORT.json
    ├── RIP_REPORT.txt
    ├── OUTPUT_MANIFEST.json
    └── OUTPUT_MANIFEST.sha256
```

The exact folders depend on the source platform and available resources.

## Stage Explorer generation

The explorer is generated automatically unless `--no-stageviz` is supplied. It embeds available verified MAP atlases and creates:

```text
stage_explorer\SIIG_Stage_Explorer.html
stage_explorer\STAGE_MANIFEST.json
stage_explorer\README.txt
```

The explorer is offline and self-contained. Because it may embed game-derived images and stage data, treat it as a private research artifact.

## Verification

After extraction:

```bat
python siig_toolkit.py verify-output "C:\Rips\SIIG_X360"
```

Checks include:

- report presence and format;
- privacy-safe metadata;
- manifest path uniqueness;
- file existence and exact sizes;
- SHA-256 hashes unless `--quick` is used;
- unexpected `.siig-part` files left by interrupted atomic writes.

To intentionally rebuild the manifest after adding or removing files:

```bat
python siig_toolkit.py verify-output "C:\Rips\SIIG_X360" --write-manifest
```

Do not use `--write-manifest` merely to make an unexpected verification error disappear; inspect the change first.

## Useful options

```text
--clean                 delete the existing output before starting
--resume                reuse only matching archive/conversion results
--ps3-sdat-dir DIR      search DIR for decrypted PS3 SDAT outputs; repeatable
--convert-obj           also write legacy OBJ models
--no-gltf               skip glTF conversion
--no-textures           skip TEX/font PNG conversion
--no-audio              skip Xbox 360 XACT conversion
--ffmpeg PATH           select a particular FFmpeg executable
--flip-v                flip model texture V coordinates
--no-stageviz           skip automatic Stage Explorer generation
--no-output-manifest    skip final deterministic SHA-256 manifest
--max-files N           outer-container file-count limit
--max-total-bytes N     outer-container total expanded-byte limit
--max-file-bytes N      outer-container per-file expanded-byte limit
--max-zip-ratio N       ZIP per-member expansion-ratio limit
```

## Platform behavior

### Xbox 360

- STFS is unpacked internally.
- Ordinary gzip wrappers are detected by magic.
- BBX resources are extracted recursively.
- TEX files are untiled and converted to PNG.
- GMX files are exported to glTF by default.
- XACT/XMA2 banks are converted to WAV when FFmpeg is installed.
- Existing WMA media is copied unchanged.

### PlayStation 3

- Type-1 outer PKG is unpacked internally.
- Ordinary gzip files are decompressed directly.
- Inner `NPD\0` SDAT payloads require matching decrypted `.bin.gz.dat` inputs.
- PS3 TEX uses its RSX wrapper and linear pixel layout.
- Shared GMX resources use the same glTF exporter.
- Sony SBlk/VAG audio is preserved losslessly for external decoding.
- AT3 and other ready-to-use media is copied unchanged.

## Failure and recovery behavior

Writes use temporary `.siig-part` files and are renamed only after success. An interrupted rip can normally be restarted with `--resume`. Verification reports leftover partial files so they are not mistaken for valid output.

Use `--clean` when changing source packages, PS3 decryption sets, or output policy substantially. Keep the original game package unchanged and use a separate output directory.

See `CONTAINER_INPUT_NOTES.md`, `SECURITY_NOTES.md`, and `TESTING.md`.
