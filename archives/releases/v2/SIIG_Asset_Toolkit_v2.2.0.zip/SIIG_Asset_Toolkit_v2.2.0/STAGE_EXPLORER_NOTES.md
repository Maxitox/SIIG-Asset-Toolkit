# Offline stage explorer v4

Run after extracting/converting the game:

```text
python siig_toolkit.py stageviz <SIIG_Ripped> -o stage_explorer
```

Open `SIIG_Stage_Explorer.html`. It is self-contained and makes no network
requests.

## New MAP rendering

When the converted `Media/texture_map` PNGs are present, **Game atlas tiles**
renders MAP IDs with the verified resource mapping:

- 6 → `fence1_512.png`
- 7 → `fence2_512.png`
- 8 → `fence6_512a.png`
- 9 → `fence3_512.png`

Tiles use the row-major 7×7 atlas, 144-pixel pitch, 96×96 source rectangles,
and the confirmed X/Y reflection flags. The explorer embeds the required PNGs
as data URLs, so the resulting HTML remains portable.

## Views and inspection

The explorer retains raw-byte, base-ID, flip, and categorical tile views. Click
a cell to inspect its row, column, raw byte, base tile ID, reflection flags, and
zero-scroll center. The optional composite draws layers in runtime submission
order 2, 1, 0 at zero scroll.

## Important limits

The composite is not a runtime screenshot. Each layer scrolls independently,
and the exact gameplay label and scroll trajectory of each layer are not yet
resolved. DAT commands are listed in the timeline, but they are not placed over
the MAP until coordinate semantics are proven for the relevant handlers.

Runtime stage/script/MAP pairing still follows the June 10 XEX tables. Missing
MAPs tolerated by the game and package MAPs absent from the runtime table remain
explicitly identified rather than guessed.
