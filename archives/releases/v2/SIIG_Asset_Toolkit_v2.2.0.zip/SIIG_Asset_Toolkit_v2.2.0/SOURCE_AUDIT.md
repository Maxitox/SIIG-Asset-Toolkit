# Source-provenance audit report

Audit date: 2026-08-27  
Release reviewed: SIIG Asset Toolkit 2.2.0

## Scope

The audit covered bundled Python/Java source, launchers, format notes, lookup tables, validation metadata, and release documentation. It searched imports, comments, algorithm descriptions, external-process calls, and format implementations for copied/adapted code, vendored dependencies, bundled binaries, and unresolved attribution claims.

## Findings

- The toolkit imports only the Python standard library and vendors no third-party Python package.
- It bundles no third-party executable, shared library, emulator, decompiler, or decryption utility.
- One direct algorithmic adaptation remains identified: Xenos tiled-texture addressing translated from Xenia's published implementation. The BSD 3-Clause notice is included.
- The exact historical Xenia commit/file consulted was not preserved. This limitation is stated rather than replaced with an invented revision.
- XMA2 RIFF fields follow Microsoft/DirectXTK documentation; implementation code is locally written.
- glTF output follows the Khronos specification; no glTF library is bundled.
- STFS and PS3 PKG readers, AES-128 implementation, debug stream handling, and bounded extraction wrappers are locally authored clean-room code. No third-party container-reader source was copied or adapted.
- AES correctness is checked with a published FIPS-197 known-answer vector.
- BBX, GMX, game-specific TEX wrappers, font, localization, COL, ANM, DAT, MAP, stage tables, MAP atlas mapping, and container behavior were reconstructed from user-supplied binaries, Ghidra exports, synthetic fixtures, and cross-build/cross-platform validation.
- Ghidra, XEXLoaderWV, FFmpeg, vgmstream, and TrueAncestor are external tools/references and are not redistributed.
- No game binaries or extracted game assets are present in the source-only release package.

## Container-support provenance decision

Earlier documentation marked STFS/PKG support as blocked pending selection of a third-party source. The completed implementation did not use such a source: it was written locally using observed package behavior, synthetic fixtures, public algorithm specifications, and user-supplied evidence. The obsolete block is therefore replaced by a clean-room provenance record.

This does not assert that every package variant is supported. It records authorship and evidence, while testing limitations remain documented separately.

## AI limitation

The audit can enumerate explicit sources consulted and intentional adaptations. It cannot enumerate the complete training corpus or latent influences of the AI model. OpenAI ChatGPT's role is disclosed in `AI_DISCLOSURE.md`.

## Release recommendation

The 2.2.0 source-only package is suitable for private testing and source review with these retained conditions:

- select a license before public redistribution of original project code;
- preserve the Xenia notice and all provenance files;
- keep game-derived assets and self-contained explorers out of public source releases;
- do not claim exact retail outer-package validation until those files are tested;
- repeat a source/license audit after any new copied or adapted code is introduced;
- record exact repository revision and local scope for every future adaptation.
