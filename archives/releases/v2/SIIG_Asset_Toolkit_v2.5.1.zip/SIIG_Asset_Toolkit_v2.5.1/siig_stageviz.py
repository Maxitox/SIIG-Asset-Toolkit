#!/usr/bin/env python3
"""Self-contained SIIG stage MAP/DAT explorer generator."""
from __future__ import annotations

import base64
import csv
import json
import struct
from collections import Counter
from pathlib import Path

import siig_toolkit as toolkit


# June 10 DebugOpt runtime table at 0x8204BD50.
STAGE_TILE_SET_IDS = (
    6, 7, 6, 7, 6, 8, 6, 7, 6, 7, 6, 8, 6, 7, 6, 7, 6, 8,
    6, 7, 6, 7, 6, 8, 6, 7, 6, 7, 6, 8, 6, 7, 6, 7, 6, 8,
    6, 7, 6, 6, 7, 7, 7, 6, 8, 6, 7, 6, 6, 7, 6, 7, 6, 8,
    6, 7, 6, 6, 7, 6, 7, 7, 8, 6, 7, 6, 6, 7, 6, 7, 6, 8,
    6, 7, 6,
)

# Function_822407D8 calls Function_821CEBA8(base=6, count=4,
# descriptor=0x820481C8). The descriptor entries are ordered as follows.
TILE_SET_TEXTURES = {
    6: "fence1_512.png",
    7: "fence2_512.png",
    8: "fence6_512a.png",
    9: "fence3_512.png",
}

# Every fence atlas is 1152x1152. The 49 shapes are row-major in a 7x7 table,
# on a 144-pixel pitch. Each logical sprite occupies a 96x96 source rectangle.
# The XEX renders at 3x coordinates, so 96 source pixels correspond to 32
# logical units, centered on a 30-unit MAP cell step.
ATLAS_LAYOUT = {
    "columns": 7,
    "rows": 7,
    "pitch_px": 144,
    "source_size_px": 96,
    "logical_sprite_units": 32,
    "map_cell_units": 30,
}
MAX_EMBEDDED_ATLAS_BYTES = 32 * 1024 * 1024


def _rle_bytes(data: bytes) -> list[list[int]]:
    if not data:
        return []
    result: list[list[int]] = []
    current = data[0]
    count = 1
    for value in data[1:]:
        if value == current:
            count += 1
        else:
            result.append([current, count])
            current = value
            count = 1
    result.append([current, count])
    return result


def _stage_media_root(input_path: Path) -> Path:
    candidates = (input_path / "assets" / "Media", input_path / "Media", input_path)
    for candidate in candidates:
        if (candidate / "script").is_dir() or (candidate / "map").is_dir():
            return candidate
    raise toolkit.FormatError("could not find Media/script or Media/map below the supplied path")


def _png_dimensions(data: bytes) -> tuple[int, int]:
    if len(data) < 24 or data[:8] != b"\x89PNG\r\n\x1a\n" or data[12:16] != b"IHDR":
        raise toolkit.FormatError("invalid PNG atlas")
    return struct.unpack(">II", data[16:24])


def _find_atlas_files(input_path: Path, media: Path) -> dict[int, Path]:
    names = {name.lower(): resource_id for resource_id, name in TILE_SET_TEXTURES.items()}
    found: dict[int, Path] = {}
    candidates = [
        media / "texture_map",
        input_path / "assets" / "Media" / "texture_map",
        input_path / "Media" / "texture_map",
        input_path / "texture_map",
    ]
    seen: set[Path] = set()
    for directory in candidates:
        try:
            resolved = directory.resolve()
        except OSError:
            continue
        if resolved in seen or not directory.is_dir():
            continue
        seen.add(resolved)
        for path in directory.iterdir():
            if path.is_file() and path.name.lower() in names:
                found.setdefault(names[path.name.lower()], path)
    # A shallowly different rip layout should still work. Restrict the fallback
    # to exact expected names so no unrelated image is embedded.
    if len(found) < 3 and input_path.is_dir():
        for path in input_path.rglob("*.png"):
            resource_id = names.get(path.name.lower())
            if resource_id is not None:
                found.setdefault(resource_id, path)
    return found


def _atlas_payload(input_path: Path, media: Path) -> dict[str, dict]:
    payload: dict[str, dict] = {}
    for resource_id, path in sorted(_find_atlas_files(input_path, media).items()):
        size = path.stat().st_size
        if size > MAX_EMBEDDED_ATLAS_BYTES:
            raise toolkit.FormatError(
                f"atlas {path.name} exceeds embedded-image limit "
                f"({size} > {MAX_EMBEDDED_ATLAS_BYTES} bytes)"
            )
        data = path.read_bytes()
        width, height = _png_dimensions(data)
        required = (ATLAS_LAYOUT["columns"] - 1) * ATLAS_LAYOUT["pitch_px"] + ATLAS_LAYOUT["source_size_px"]
        if width < required or height < required or width > 8192 or height > 8192:
            raise toolkit.FormatError(
                f"atlas {path.name} has unsupported dimensions {width}x{height}; "
                f"expected at least {required}x{required}"
            )
        payload[str(resource_id)] = {
            "resource_id": resource_id,
            "filename": path.name,
            "width": width,
            "height": height,
            "data_url": "data:image/png;base64," + base64.b64encode(data).decode("ascii"),
            **ATLAS_LAYOUT,
        }
    return payload


def _html(dataset: dict) -> str:
    payload = json.dumps(dataset, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    prefix = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SIIG Stage Explorer</title>
<style>
:root{color-scheme:dark;background:#0d1017;color:#e7ebf3;font:14px system-ui,sans-serif}*{box-sizing:border-box}body{margin:0}
header{position:sticky;top:0;z-index:5;background:#121722;border-bottom:1px solid #2a3242;padding:12px 18px;display:flex;gap:14px;align-items:center;flex-wrap:wrap}
h1{font-size:18px;margin:0 18px 0 0}.control{display:flex;gap:6px;align-items:center}select,input,button{background:#1a2130;color:#eef;border:1px solid #39445b;border-radius:6px;padding:6px 8px}button{cursor:pointer}
main{display:grid;grid-template-columns:minmax(360px,48%) 1fr;min-height:calc(100vh - 58px)}section{padding:16px;min-width:0}.maps{border-right:1px solid #2a3242;background:#0f131c}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(90px,1fr));gap:8px;margin-bottom:12px}.card{background:#171d29;border:1px solid #283146;border-radius:8px;padding:9px}.card b{display:block;font-size:19px}.muted{color:#9ba7bd}
.layer-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.layer{background:#171d29;border:1px solid #283146;border-radius:8px;overflow:hidden}.layer h3{font-size:13px;margin:0;padding:8px 10px;border-bottom:1px solid #283146}.canvas-wrap{height:56vh;overflow:auto;text-align:center;padding:8px;background:#07090d}.canvas-wrap canvas{image-rendering:pixelated;image-rendering:crisp-edges;transform-origin:top left;display:block;margin:0 auto}.legend{padding:8px;font-size:12px;white-space:pre-wrap;overflow-wrap:anywhere}
.timeline-tools{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}.table-wrap{overflow:auto;max-height:76vh;border:1px solid #283146;border-radius:8px}table{border-collapse:collapse;width:100%}th,td{padding:7px 8px;border-bottom:1px solid #222b3b;text-align:left;vertical-align:top}th{position:sticky;top:0;background:#171d29;z-index:1}.frame{font-variant-numeric:tabular-nums}.tag{display:inline-block;border-radius:999px;padding:2px 7px;background:#29344a;font-size:11px}.high{color:#8ee6a8}.medium{color:#f4d37c}.low{color:#e79898}.fields{font-family:ui-monospace,monospace;font-size:12px;color:#b9c5d9;white-space:normal}.files{margin:0 0 10px;line-height:1.5}.notice{background:#17271d;border:1px solid #315d40;padding:9px;border-radius:8px;margin-bottom:12px;color:#bfe8c9}.warning{background:#261f14;border-color:#5e4b25;color:#efd99e}.inspector{margin:10px 0;background:#111826;border:1px solid #2a3954;border-radius:8px;padding:9px;font-family:ui-monospace,monospace;min-height:38px}.check{display:flex;gap:5px;align-items:center}.check input{padding:0}
@media(max-width:1100px){main{display:block}.maps{border-right:0}.layer-grid{grid-template-columns:1fr}.canvas-wrap{height:48vh}}
</style></head><body>
<header><h1>SIIG Stage Explorer</h1><div class="control"><label>Stage</label><select id="stage"></select></div><div class="control"><label>Zoom</label><input id="zoom" type="range" min="50" max="500" value="150"><span id="zoomValue">1.5×</span></div><div class="control"><label>Map view</label><select id="mapMode"><option value="game">Game atlas tiles</option><option value="tile">Tile ID + flip shading</option><option value="raw">Raw byte</option><option value="base">Tile ID (1–49)</option><option value="flip">X/Y flip flags</option></select></div><label class="check"><input id="composite" type="checkbox" checked> zero-scroll composite</label></header>
<main><section class="maps"><div class="notice" id="notice"></div><div class="files muted" id="files"></div><div class="cards" id="cards"></div><div class="inspector" id="inspector">Click a rendered cell to inspect its raw value, tile ID, flips, and zero-scroll game-space center.</div><div class="layer-grid" id="layers"></div></section>
<section><div class="timeline-tools"><input id="search" placeholder="Search opcode, summary, or argument" size="34"><select id="category"><option value="">All categories</option></select><span class="muted" id="shown"></span></div><div class="table-wrap"><table><thead><tr><th>Frame</th><th>Command</th><th>Interpretation</th><th>Fields</th></tr></thead><tbody id="timeline"></tbody></table></div></section></main>
<script id="data" type="application/json">'''
    suffix = r'''</script><script>
const DB=JSON.parse(document.getElementById('data').textContent);
const stageSel=document.getElementById('stage'),layersEl=document.getElementById('layers'),timeline=document.getElementById('timeline');
const search=document.getElementById('search'),category=document.getElementById('category'),zoom=document.getElementById('zoom'),mapMode=document.getElementById('mapMode'),composite=document.getElementById('composite');
const inspector=document.getElementById('inspector'),notice=document.getElementById('notice'),zoomValue=document.getElementById('zoomValue');
const atlasImages={},atlasPromises={};
for(const [id,a] of Object.entries(DB.atlases||{})){const im=new Image();atlasImages[id]=im;atlasPromises[id]=new Promise((resolve,reject)=>{im.onload=()=>resolve(im);im.onerror=reject});im.src=a.data_url}
for(const s of DB.stages){const o=document.createElement('option');o.value=s.name;o.textContent=s.display_name||s.name;stageSel.appendChild(o)}
if(DB.default_stage)stageSel.value=DB.default_stage;
const cats=[...new Set(DB.stages.flatMap(s=>(s.script?.records||[]).map(r=>r.semantic.category)))].sort();for(const c of cats){const o=document.createElement('option');o.value=c;o.textContent=c;category.appendChild(o)}
function esc(v){return String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]))}
function unrle(rle,total){const a=new Uint8Array(total);let p=0;for(const [v,n] of rle){a.fill(v,p,p+n);p+=n}return a}
function color(v,mode){if(v===0)return[4,6,10,255];const base=v&63,flags=v>>6;if(mode==='flip'){const cs=[[170,170,170],[80,180,255],[255,170,70],[220,90,220]];return[...cs[flags],255]}const id=mode==='raw'?v:base;const h=(id*47)%360,s=mode==='tile'?(flags===0?68:82):68,l=mode==='tile'?(42+flags*10):46,c=(1-Math.abs(2*l/100-1))*s/100,x=c*(1-Math.abs((h/60)%2-1)),m=l/100-c/2;let q=h<60?[c,x,0]:h<120?[x,c,0]:h<180?[0,c,x]:h<240?[0,x,c]:h<300?[x,0,c]:[c,0,x];return q.map(z=>Math.round((z+m)*255)).concat(255)}
function renderStep(l){return Math.max(2,Math.min(15,Math.floor(16000/Math.max(1,l.height))))}
function atlasFor(s){return DB.atlases?.[String(s.tile_set_id)]||null}
function drawGameCells(ctx,l,cells,atlas,im,step,clear=true){if(clear){ctx.fillStyle='#05070a';ctx.fillRect(0,0,l.width*step,l.height*step)}ctx.imageSmoothingEnabled=false;const dst=Math.max(2,Math.round(step*atlas.logical_sprite_units/atlas.map_cell_units));for(let p=0;p<cells.length;p++){const v=cells[p],id=v&63;if(!id)continue;const c=p%l.width,r=Math.floor(p/l.width),idx=id-1,sx=(idx%atlas.columns)*atlas.pitch_px,sy=Math.floor(idx/atlas.columns)*atlas.pitch_px;ctx.save();ctx.translate(c*step+step/2,r*step+step/2);ctx.scale((v&0x40)?-1:1,(v&0x80)?-1:1);ctx.drawImage(im,sx,sy,atlas.source_size_px,atlas.source_size_px,-dst/2,-dst/2,dst,dst);ctx.restore()}}
function drawColorCells(ctx,l,cells,mode){const img=ctx.createImageData(l.width,l.height);for(let p=0;p<cells.length;p++)img.data.set(color(cells[p],mode),p*4);ctx.putImageData(img,0,0)}
function drawColorComposite(ctx,w,h,ls,mode){const img=ctx.createImageData(w,h);for(let p=0;p<w*h;p++)img.data.set([5,7,10,255],p*4);for(const i of [2,1,0]){const l=ls[i];if(!l||!l.width||!l.height)continue;const cells=unrle(l.rle,l.width*l.height);for(let p=0;p<cells.length;p++){const v=cells[p];if(!v)continue;const c=p%l.width,r=Math.floor(p/l.width);img.data.set(color(v,mode),(r*w+c)*4)}}ctx.putImageData(img,0,0)}
function attachInspector(can,l,cells,layerLabel,step){can.onclick=e=>{const rect=can.getBoundingClientRect(),x=(e.clientX-rect.left)*can.width/rect.width,y=(e.clientY-rect.top)*can.height/rect.height,col=Math.floor(x/step),row=Math.floor(y/step);if(col<0||row<0||col>=l.width||row>=l.height)return;const v=cells[row*l.width+col],id=v&63,flags=v>>6,flips=['none','X','Y','X+Y'][flags];inspector.textContent=`${layerLabel} · row ${row}, column ${col} · raw 0x${v.toString(16).padStart(2,'0').toUpperCase()} · tile ${id||'empty'} · flips ${flips} · center (${col*30+15}, ${row*30+15}) before layer scroll`}}
async function createLayerPanel(title,l,s,kind){const box=document.createElement('div');box.className='layer';box.innerHTML=`<h3>${title} · ${l.width}×${l.height}</h3><div class="canvas-wrap"><canvas></canvas></div><div class="legend"></div>`;layersEl.appendChild(box);const can=box.querySelector('canvas'),leg=box.querySelector('.legend');if(!l.width||!l.height){leg.textContent='Empty';return}const cells=unrle(l.rle,l.width*l.height),atlas=atlasFor(s);let step=1;if(mapMode.value==='game'&&atlas&&atlasImages[String(s.tile_set_id)]){step=renderStep(l);can.width=l.width*step;can.height=l.height*step;const im=await atlasPromises[String(s.tile_set_id)];drawGameCells(can.getContext('2d'),l,cells,atlas,im,step)}else{can.width=l.width;can.height=l.height;drawColorCells(can.getContext('2d'),l,cells,mapMode.value==='game'?'tile':mapMode.value)}const z=Number(zoom.value)/100;can.style.width=`${can.width*z}px`;can.style.height=`${can.height*z}px`;attachInspector(can,l,cells,title,step);const vals=Object.entries(l.value_counts).sort((a,b)=>Number(a[0])-Number(b[0])),ids=Object.entries(l.base_id_counts||{}).sort((a,b)=>Number(a[0])-Number(b[0])),fl=l.flip_counts||{};leg.textContent=`nonzero ${l.nonzero_cells}/${l.cell_count} · flips none:${fl['0']||0} X:${fl['1']||0} Y:${fl['2']||0} XY:${fl['3']||0}\ntile IDs: `+ids.map(([v,n])=>`${v}:${n}`).join(' ')+`\nraw: `+vals.map(([v,n])=>`${Number(v).toString(16).padStart(2,'0').toUpperCase()}:${n}`).join(' ')}
async function createComposite(s,ls){if(!composite.checked)return;const live=ls.filter(l=>l&&l.width&&l.height);if(!live.length)return;const w=Math.max(...live.map(l=>l.width)),h=Math.max(...live.map(l=>l.height)),synthetic={width:w,height:h};const box=document.createElement('div');box.className='layer';box.innerHTML=`<h3>Zero-scroll composite · ${w}×${h}</h3><div class="canvas-wrap"><canvas></canvas></div><div class="legend">Draw order 2 → 1 → 0. Runtime per-layer scroll offsets are not applied.</div>`;layersEl.appendChild(box);const can=box.querySelector('canvas'),atlas=atlasFor(s);let step=1;if(mapMode.value==='game'&&atlas&&atlasImages[String(s.tile_set_id)]){step=renderStep(synthetic);can.width=w*step;can.height=h*step;const ctx=can.getContext('2d'),im=await atlasPromises[String(s.tile_set_id)];ctx.fillStyle='#05070a';ctx.fillRect(0,0,can.width,can.height);for(const i of [2,1,0]){const l=ls[i];if(!l||!l.width||!l.height)continue;drawGameCells(ctx,l,unrle(l.rle,l.width*l.height),atlas,im,step,false)}}else{can.width=w;can.height=h;drawColorComposite(can.getContext('2d'),w,h,ls,mapMode.value==='game'?'tile':mapMode.value)}{const z=Number(zoom.value)/100;can.style.width=`${can.width*z}px`;can.style.height=`${can.height*z}px`}}
async function drawMaps(s){layersEl.innerHTML='';const ls=s.map?.layers||[];await createComposite(s,ls);for(let i=0;i<3;i++)await createLayerPanel(`Layer ${i}`,ls[i]||{width:0,height:0,rle:[],value_counts:{}},s,'layer')}
function renderTimeline(s){const q=search.value.toLowerCase(),cat=category.value,all=s.script?.records||[],rs=all.filter(r=>(!cat||r.semantic.category===cat)&&(!q||JSON.stringify(r).toLowerCase().includes(q)));timeline.innerHTML='';for(const r of rs){const tr=document.createElement('tr'),fs=r.semantic.fields.map(f=>`${f.name}=${f.value}${f.unit?' '+f.unit:''}`).join(' · ');tr.innerHTML=`<td class="frame">${r.absolute_frame}</td><td><b>${esc(r.opcode_name)}</b><br><span class="tag">${esc(r.semantic.category)}</span> <span class="${esc(r.semantic.confidence)}">${esc(r.semantic.confidence)}</span></td><td>${esc(r.semantic.summary)}</td><td class="fields">${esc(fs||'—')}<br><span class="muted">raw ${esc(r.args_signed.join(' '))}</span></td>`;timeline.appendChild(tr)}document.getElementById('shown').textContent=`${rs.length}/${all.length} commands`}
async function render(){const s=DB.stages.find(x=>x.name===stageSel.value)||DB.stages[0],rec=s.script?.records||[],map=s.map,atlas=atlasFor(s);notice.className='notice'+(atlas?'':' warning');notice.textContent=atlas?`Verified atlas rendering: resource ${s.tile_set_id} → ${atlas.filename}; tile IDs 1–49 use the 7×7 atlas and 0x40/0x80 are applied as X/Y reflections.`:`No verified PNG atlas is embedded for this entry. The explorer is using the categorical tile fallback; MAP bytes remain exact.`;document.getElementById('files').innerHTML=`<b>${esc(s.display_name||s.name)}</b><br>kind: ${esc(s.entry_kind||'asset')} · script: ${esc(s.script_file||'—')}${s.script_missing?' (missing)':''} · map: ${esc(s.map_file||'—')}${s.map_missing?' (missing)':''} · tile set: ${s.tile_set_id??'—'}${s.tile_set_texture?' → '+esc(s.tile_set_texture):''}`;document.getElementById('cards').innerHTML=`<div class="card"><span class="muted">Commands</span><b>${rec.length}</b></div><div class="card"><span class="muted">Duration</span><b>${s.script?.duration_frames||0}</b><small> frames</small></div><div class="card"><span class="muted">MAP cells</span><b>${(map?.layers||[]).reduce((a,l)=>a+l.cell_count,0)}</b></div><div class="card"><span class="muted">Nonzero</span><b>${(map?.layers||[]).reduce((a,l)=>a+l.nonzero_cells,0)}</b></div><div class="card"><span class="muted">Tile set</span><b>${s.tile_set_id??'—'}</b><small>${s.tile_set_texture||' resource ID'}</small></div>`;await drawMaps(s);renderTimeline(s)}
function updateZoom(){zoomValue.textContent=(Number(zoom.value)/100).toFixed(2).replace(/0+$/,'').replace(/\.$/,'')+'×';document.querySelectorAll('canvas').forEach(c=>{const z=Number(zoom.value)/100;c.style.width=`${c.width*z}px`;c.style.height=`${c.height*z}px`})}
stageSel.onchange=render;search.oninput=render;category.onchange=render;mapMode.onchange=render;composite.onchange=render;zoom.oninput=updateZoom;updateZoom();render();
</script></body></html>'''
    return prefix + payload + suffix


def _load_pairing() -> list[dict[str, str]]:
    toolkit_dir = Path(__file__).resolve().parent
    candidates = (
        toolkit_dir / "reference" / "tables" / "STAGE_PAIRING.csv",
        toolkit_dir / "STAGE_PAIRING.csv",  # legacy v2.5.0-and-earlier layout
    )
    path = next((candidate for candidate in candidates if candidate.is_file()), None)
    if path is None:
        return []
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))

def _script_payload(path: Path) -> dict:
    parsed = toolkit.parse_dat_bytes(path.read_bytes())
    return {
        "entry_count": parsed["entry_count"],
        "duration_frames": parsed["duration_frames"],
        "records": [{
            "index": record["index"],
            "absolute_frame": record["absolute_frame"],
            "opcode": record["opcode"],
            "opcode_name": record["opcode_name"],
            "args_signed": record["args_signed"],
            "semantic": record["semantic"],
        } for record in parsed["records"]],
    }


def _map_payload(path: Path) -> dict:
    parsed = toolkit.parse_map_bytes(path.read_bytes())
    return {
        "layer_count": parsed["layer_count"],
        "layers": [{
            "index": layer["index"],
            "width": layer["width"],
            "height": layer["height"],
            "cell_count": layer["cell_count"],
            "nonzero_cells": layer["nonzero_cells"],
            "unique_values": layer["unique_values"],
            "value_counts": {str(int(key, 16)): value for key, value in layer["value_counts"].items()},
            "base_id_counts": {str(key): value for key, value in sorted(Counter(cell & 0x3F for cell in layer["cells"] if cell).items())},
            "flip_counts": {str(key): value for key, value in sorted(Counter(cell >> 6 for cell in layer["cells"] if cell).items())},
            "rle": _rle_bytes(layer["cells"]),
        } for layer in parsed["layers"]],
    }


def build_stage_explorer(input_path: Path, output: Path) -> dict:
    media = _stage_media_root(input_path)
    script_dir, map_dir = media / "script", media / "map"
    script_paths = {path.name.lower(): path for path in script_dir.glob("*.dat")} if script_dir.is_dir() else {}
    map_paths = {path.name.lower(): path for path in map_dir.glob("*.map")} if map_dir.is_dir() else {}
    if not script_paths and not map_paths:
        raise toolkit.FormatError("no stage DAT or MAP files were found")

    atlases = _atlas_payload(input_path, media)
    pairing = _load_pairing()
    stages: list[dict] = []
    referenced_scripts: set[str] = set()
    referenced_maps: set[str] = set()

    if pairing:
        for row_index, row in enumerate(pairing):
            stage_no = int(row["stage_no"])
            variant = row["variant"]
            script_file = row["script_file"]
            map_file = row["map_file"]
            script_path = script_paths.get(script_file.lower()) if script_file else None
            map_path = map_paths.get(map_file.lower()) if map_file else None
            if script_file:
                referenced_scripts.add(script_file.lower())
            if map_file:
                referenced_maps.add(map_file.lower())
            stem = Path(script_file or map_file).stem
            if row["entry_kind"] == "runtime_stage":
                display = f"Stage {stage_no:03d} · {stem}"
                name = f"stage_{stage_no:03d}_{stem}"
            elif row["entry_kind"] == "trial_variant":
                display = f"Trial variant · {stem} (stage {stage_no:03d})"
                name = f"trial_stage_{stage_no:03d}_{stem}"
            else:
                display = f"Map-only slot {stage_no:03d} · {stem}"
                name = f"map_slot_{stage_no:03d}_{stem}"
            tile_set_id = STAGE_TILE_SET_IDS[stage_no - 1] if 1 <= stage_no <= len(STAGE_TILE_SET_IDS) else None
            item: dict = {
                "name": name,
                "display_name": display,
                "entry_kind": row["entry_kind"],
                "stage_no": stage_no,
                "variant": variant,
                "script_file": script_file,
                "map_file": map_file,
                "evidence": row["evidence"],
                "script_missing": bool(script_file and not script_path),
                "map_missing": bool(map_file and not map_path),
                "pairing_index": row_index,
                "tile_set_id": tile_set_id,
                "tile_set_texture": TILE_SET_TEXTURES.get(tile_set_id, "") if tile_set_id is not None else "",
            }
            if script_path:
                item["script"] = _script_payload(script_path)
            if map_path:
                item["map"] = _map_payload(map_path)
            stages.append(item)
    else:
        names = sorted(set(Path(key).stem for key in script_paths) | set(Path(key).stem for key in map_paths), key=str.lower)
        for name in names:
            script_path = script_paths.get((name + ".dat").lower())
            map_path = map_paths.get((name + ".map").lower())
            item: dict = {
                "name": name,
                "display_name": name,
                "entry_kind": "fallback_stem_pair",
                "script_file": script_path.name if script_path else "",
                "map_file": map_path.name if map_path else "",
                "tile_set_id": None,
                "tile_set_texture": "",
            }
            if script_path:
                item["script"] = _script_payload(script_path)
            if map_path:
                item["map"] = _map_payload(map_path)
            stages.append(item)

    for map_key in sorted(set(map_paths) - referenced_maps):
        map_path = map_paths[map_key]
        stem = map_path.stem
        stages.append({
            "name": f"unreferenced_map_{stem}",
            "display_name": f"Unreferenced package MAP · {stem}",
            "entry_kind": "unreferenced_package_map",
            "stage_no": None,
            "variant": "unreferenced",
            "script_file": "",
            "map_file": map_path.name,
            "evidence": "present in map BBX but absent from the June 10 runtime map-slot table",
            "tile_set_id": None,
            "tile_set_texture": "",
            "map": _map_payload(map_path),
        })

    for script_key in sorted(set(script_paths) - referenced_scripts):
        script_path = script_paths[script_key]
        stem = script_path.stem
        stages.append({
            "name": f"unreferenced_script_{stem}",
            "display_name": f"Unreferenced package DAT · {stem}",
            "entry_kind": "unreferenced_package_script",
            "stage_no": None,
            "variant": "unreferenced",
            "script_file": script_path.name,
            "map_file": "",
            "evidence": "present in script BBX but absent from the June 10 runtime script table",
            "tile_set_id": None,
            "tile_set_texture": "",
            "script": _script_payload(script_path),
        })

    dataset = {
        "format": "SIIG_STAGE_EXPLORER",
        "version": 4,
        "source": media.name,
        "stage_count": len(stages),
        "runtime_pair_count": len(pairing),
        "default_stage": next((stage["name"] for stage in stages if sum(layer["cell_count"] for layer in stage.get("map", {}).get("layers", [])) > 0 and stage.get("script")), stages[0]["name"]),
        "atlases": atlases,
        "atlas_layout": ATLAS_LAYOUT,
        "tile_set_textures": {str(key): value for key, value in TILE_SET_TEXTURES.items()},
        "stages": stages,
        "notes": {
            "pairing": "June 10 runtime map slots and script slots are paired by executable table index",
            "missing_maps": "some expected normal level 4/5 MAP files are absent from the package; the loader tolerates this",
            "unreferenced_maps": "package MAP files absent from the runtime table are shown separately",
            "map_layers": "confirmed independently scrolling 2D tile/sprite layers; exact gameplay roles remain unresolved",
            "map_cell": "0 is empty; lower six bits are one-based tile IDs 1..49",
            "map_flips": "0x40 is X reflection; 0x80 is Y reflection",
            "map_cell_size": "30 units; renderer places tile centers at cell*30+15 plus scroll offset",
            "tile_set_mapping": "resource IDs 6, 7, 8, 9 map to fence1, fence2, fence6, fence3 through the 0x820481C8 registration descriptor",
            "atlas_layout": "49 row-major shapes in a 7x7 table; 144-pixel pitch and 96-pixel source rectangles",
            "composite": "the composite uses draw order 2,1,0 at zero scroll; it is not a reconstructed runtime frame",
            "not_wall_geometry": "Media/map and Media/generator MAP files do not place 3D wall GMX models",
            "semantic_policy": "XEX-backed fields are named; unresolved words remain generic",
        },
    }
    output.mkdir(parents=True, exist_ok=True)
    toolkit.write_text_atomic(output / "SIIG_Stage_Explorer.html", _html(dataset), encoding="utf-8")
    manifest = {
        "format": dataset["format"],
        "version": dataset["version"],
        "stage_count": dataset["stage_count"],
        "entry_count": dataset["stage_count"],
        "runtime_pair_count": dataset["runtime_pair_count"],
        "embedded_atlases": [{
            "resource_id": int(resource_id),
            "filename": atlas["filename"],
            "width": atlas["width"],
            "height": atlas["height"],
        } for resource_id, atlas in sorted(atlases.items(), key=lambda item: int(item[0]))],
        "stages": [{
            "name": stage["name"],
            "display_name": stage["display_name"],
            "entry_kind": stage["entry_kind"],
            "stage_no": stage.get("stage_no"),
            "script_file": stage.get("script_file", ""),
            "map_file": stage.get("map_file", ""),
            "script_missing": stage.get("script_missing", False),
            "map_missing": stage.get("map_missing", False),
            "commands": stage.get("script", {}).get("entry_count", 0),
            "duration_frames": stage.get("script", {}).get("duration_frames", 0),
            "map_layers": stage.get("map", {}).get("layer_count", 0),
            "map_cells": sum(layer["cell_count"] for layer in stage.get("map", {}).get("layers", [])),
            "map_nonzero": sum(layer["nonzero_cells"] for layer in stage.get("map", {}).get("layers", [])),
            "tile_set_id": stage.get("tile_set_id"),
            "tile_set_texture": stage.get("tile_set_texture", ""),
            "evidence": stage.get("evidence", ""),
        } for stage in stages],
        "notes": dataset["notes"],
    }
    toolkit.write_json_private(output / "STAGE_MANIFEST.json", manifest)
    toolkit.write_text_atomic(
        output / "README.txt",
        "Open SIIG_Stage_Explorer.html in a modern browser.\n"
        "The file is self-contained and makes no network requests.\n"
        "Runtime DAT/MAP pairing follows the June 10 XEX tables by stage index.\n"
        "Game-atlas mode embeds verified fence atlases when their converted PNG files are present.\n"
        "MAP cells are 2D tile/sprite data: 0 empty, IDs 1-49, 0x40 X flip, 0x80 Y flip.\n"
        "The composite is zero-scroll only; layer roles and runtime scroll trajectories remain unresolved.\n",
        encoding="utf-8",
    )
    return manifest
