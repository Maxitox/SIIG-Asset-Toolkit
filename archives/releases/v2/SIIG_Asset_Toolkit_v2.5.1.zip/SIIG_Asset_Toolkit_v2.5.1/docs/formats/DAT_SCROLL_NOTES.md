# DAT 2D scroll opcode correction

The June 10 dispatcher routes opcodes `0x6E`, `0x6F`, and `0x70` to the three named SCROLL analyzers.

- `SCROLL_01` and `SCROLL_02` ignore the first argument, normalize the second signed word by the runtime timebase, and write it as an 8.8 fixed-point value (`value / 256`) to separate 2D scroll channels.
- `SCROLL_03` only emits `AnalyzeScroll03` and returns without changing state in this executable. Its raw words remain preserved.

This replaces the earlier speculative `delay/start` and `duration` field labels. It does not by itself establish the exact visual layer name for channels 1 and 2 or reconstruct their complete frame-by-frame trajectory.

Relevant June 10 functions: dispatcher `0x820FB578`, channel handlers `0x820F98A0` and `0x820F9960`.
