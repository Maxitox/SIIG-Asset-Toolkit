# Credits

## Project work

- **Project owner and data curator:** supplied the retail Xbox 360 and PS3 extracted files, prototype builds, Ghidra exports, decrypted PS3 SDAT payloads, and hardware/emulator observations. Public credit remains intentionally unspecified until the project owner chooses a name.
- **OpenAI ChatGPT:** assisted with reverse-engineering hypotheses, clean-room parser/converter implementation, MAP atlas reconstruction, package-input support, BBX repacking, Blender/HTML tooling, automated validation, security hardening, documentation, and release packaging.

## Clean-room game-format research

Unless an explicit source is listed below, BBX, GMX, game-specific TEX wrappers, PS3 TEX wrappers, system-font metadata, localization, COL, ANM, DAT, MAP, stage tables, MAP atlas mapping, STFS, and PS3 PKG work was reconstructed from user-supplied files, Ghidra evidence, synthetic fixtures, and cross-build/cross-platform validation. Original game source code was not available and is not included.

## Explicit third-party sources and tools

- **Xenia — Xbox 360 Emulator Research Project:** algorithmic reference for Xenos 2D tiled-texture addressing. The local Python routine is a project-specific adaptation. BSD 3-Clause notice included.
- **NIST FIPS 197:** AES-128 algorithm/known-answer reference used to validate locally written package cryptography.
- **Microsoft DirectXTK documentation:** structural reference for `XMA2WAVEFORMATEX`; no DirectXTK source bundled.
- **Khronos glTF 2.0 Specification:** normative reference for generated glTF files.
- **PNG specification:** normative reference for the locally written limited PNG codec.
- **Ghidra:** PowerPC/XEX analysis and optional Java label API; not bundled.
- **XEXLoaderWV by Warranty Voider / maintained fork:** external Ghidra XEX loader used by the project owner; not bundled.
- **FFmpeg:** optional external XMA2-to-PCM decoder; not bundled.
- **vgmstream:** recommended external decoder/fallback; not bundled.
- **TrueAncestor EDAT Rebuilder by JjKkYu:** external user-run SDAT decryption utility; not bundled.
- **Python standard library:** runtime/API platform; interpreter not bundled.
- **Blender:** optional external host for the bundled GMX import add-on; Blender and its Python modules are not bundled. The add-on source is locally authored and uses Blender's built-in glTF importer.

TCRF/The Cutting Room Floor was not used and is explicitly excluded; see `docs/project/SOURCE_EXCLUSIONS.md`.

See `reference/provenance/SOURCES.csv`, `reference/provenance/PROVENANCE.json`, `docs/project/SOURCE_AUDIT.md`, and `docs/project/THIRD_PARTY_NOTICES.md` for detailed records.
