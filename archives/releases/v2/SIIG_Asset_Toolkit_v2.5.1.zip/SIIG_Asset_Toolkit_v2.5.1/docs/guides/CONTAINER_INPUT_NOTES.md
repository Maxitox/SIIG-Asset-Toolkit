# Direct STFS and PS3 PKG input

The toolkit places an outer-container stage before the SIIG asset pipeline. The same `rip-game` command accepts:

- an extracted game directory;
- a ZIP of an extracted game;
- an Xbox 360 STFS package beginning with `CON `, `LIVE`, or `PIRS`;
- a PlayStation 3 package beginning with `7F 50 4B 47` (`\x7fPKG`).

Detection uses file headers, not filename extensions.

## One-click use

```bat
python siig_toolkit.py rip-game "C:\Games\SIIG_X360_STFS" -o "C:\Rips\SIIG_X360" --resume
python siig_toolkit.py rip-game "C:\Games\SIIG_PS3.pkg" -o "C:\Rips\SIIG_PS3" ^
  --ps3-sdat-dir "C:\Games\SIIG_PS3_decrypted" --resume
```

The package is extracted into a temporary directory, processed, and removed. Normal output is written only to the selected output directory.

## Xbox 360 STFS support

The built-in clean-room reader supports `CON `, `LIVE`, and `PIRS` STFS containers. It reads the volume descriptor, file table, directory hierarchy, consecutive and chained files, active hash-table copies, and level-0/1/2 hash layouts.

It is an extractor, not a package authenticator or signer. Package signatures and content hashes are not treated as proof of authenticity. SVOD packages are rejected as unsupported rather than guessed as STFS.

## PlayStation 3 PKG support

The built-in clean-room reader supports PS3 type-1 packages in finalized and non-finalized/debug forms. It includes locally written, dependency-free AES-128-CTR and debug SHA-1 stream handling.

This does not decrypt inner NPDRM SELF, EDAT, or SDAT resources. For SIIG, provide matching decrypted outputs for:

```text
generator.bin.gz.sdat
message.bin.gz.sdat
script.bin.gz.sdat
shader.bin.gz.sdat
text.bin.gz.sdat
visualizerSet.bin.gz.sdat
```

The toolkit consumes the corresponding `*.bin.gz.dat` outputs and does not bundle or automate the external decryption utility.

## Extraction safety model

Outer-container members are treated as untrusted. The implementation:

- rejects absolute paths and `..` traversal;
- rejects ZIP symlinks and encrypted members;
- detects duplicate and case-insensitive-colliding output paths;
- validates STFS/PKG declared sizes before writing;
- limits file count, total expanded bytes, and per-file bytes;
- limits ZIP expansion ratio per member;
- writes each member to a `.siig-part` temporary file and atomically renames it;
- records planned and extracted totals in a privacy-safe manifest.

Default limits are:

```text
files:       200,000
total bytes: 16 GiB
one file:     4 GiB
```

ZIP also uses a default expansion-ratio ceiling. Use command-line limit options to lower these values for an unfamiliar package. Raising limits weakens denial-of-service protection and should be deliberate.

## Outer-container-only extraction

```bat
python siig_toolkit.py unpack-container "C:\Games\SIIG.pkg" -o "C:\Rips\SIIG_PKG_Files" --clean
```

This writes `SIIG_CONTAINER_MANIFEST.json` with archive-relative metadata.

## Validation status

The readers have passed:

- the FIPS-197 AES-128 known-answer vector;
- synthetic STFS packages using consecutive and nonconsecutive chains;
- STFS chains crossing level-0, level-1, and level-2 hash boundaries;
- synthetic finalized and debug PS3 PKGs;
- malformed/path-collision/limit regression tests;
- end-to-end processing of supplied extracted Xbox 360 and PS3 releases;
- end-to-end 2.2.0 pipeline testing on a real SIIG subset containing `default.xex`, `map.bin`, `script.bin`, and `texture_map.bin`.

The exact original retail SIIG STFS and PKG outer containers were not supplied. The readers are format-validated and regression-tested, but that exact-package validation remains outstanding.

## Provenance

The STFS and PKG readers, AES implementation, and extraction wrappers are locally authored clean-room code. No third-party container-reader source is copied or bundled. Normative algorithm tests and user-supplied format evidence are recorded in `reference/provenance/SOURCES.csv`, `reference/provenance/PROVENANCE.json`, and `docs/project/SOURCE_AUDIT.md`.
