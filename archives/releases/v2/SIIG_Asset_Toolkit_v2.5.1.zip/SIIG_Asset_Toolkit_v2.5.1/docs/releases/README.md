# Releases

Historical release notes. Current version information is also summarized in the root README and changelog.

- [`RELEASE_NOTES_2.2.md`](RELEASE_NOTES_2.2.md)
- [`RELEASE_NOTES_2.3.md`](RELEASE_NOTES_2.3.md)
- [`RELEASE_NOTES_2.4.md`](RELEASE_NOTES_2.4.md)
- [`RELEASE_NOTES_2.5.1.md`](RELEASE_NOTES_2.5.1.md)
- [`RELEASE_NOTES_2.5.md`](RELEASE_NOTES_2.5.md)
