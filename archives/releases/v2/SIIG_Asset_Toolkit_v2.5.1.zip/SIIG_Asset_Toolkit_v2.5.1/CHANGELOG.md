# Changelog

## 2.5.1

- Reorganized the release root into `docs/`, `reference/`, `validation/`, `tools/`, and `addons/`.
- Added a central documentation index and folder-level README files.
- Updated runtime resource lookups and all documentation references to the new paths.
- Retained fallbacks for legacy root-level data-table locations.
- Reduced root-level files from 75 to 18 with no content removed.

## 2.5.0

- Replaced the monolithic Asset Viewer with a linked-data layout: compact HTML, external inventory, thumbnails, and deferred preview shards.
- Removed base64 media embedding and added pagination plus intersection-based lazy loading.
- Added direct GMX/OBJ wireframes, TEX previews, MAP/DAT/ANM thumbnails, WAV waveforms, and explicit empty/animation-only placeholders.
- Added matching converted-asset previews for source TEX, GMX, OBJ, and audio files.
- Fixed related glTF payload keys and excluded viewer output during in-tree rebuilds.
- Added detailed viewer size/coverage reporting and validation of all generated relative references.
- Validated 1,016/1,016 previewable thumbnails and reduced the tested HTML document by 99.934%.

## 2.4.0

- Corrected standalone ANM parsing to 16-byte names, start/end frames, and loop flags; added group/clip indexes.
- Added `stage3dmap` for Bmap/Xmap/map4/map5 0x118-byte 3D path and placement records.
- Added `stagewall` for wall/Xwall repeat strips and `stage_generate.bin` enabled candidates.
- Added `shader-info` for Xenos shader stages, bounded microcode, metadata strings, and hashes.
- Added automatic full-rip structured exports and `scan` recognition for these formats.
- Corrected SCROLL_01/02 to 8.8 fixed-point values and documented SCROLL_03 as a June 10 no-op.
- Expanded the built-in regression suite from 11 to 15 tests.
- Added Ghidra-backed stage/ANM/shader notes and a real-corpus validation report.

## 2.3.0

- Added `repack-bbx` with canonical archive layout, named/unnamed resources, seeded hashes, sorted indexes, preserved reserved bytes, deterministic gzip, atomic output, and mandatory post-build verification.
- Extended extraction manifests with payload SHA-256, original archive SHA-256/size, reserved header bytes, alignment, and sorted-index metadata.
- Verified the unchanged supplied retail `map.bin` as a byte-for-byte extract/repack round trip.
- Added the SIIG Blender Add-on 0.1.0 for single, multi-file, and recursive-folder GMX import through the toolkit's existing glTF exporter.
- Added `asset-viewer`, a searchable offline HTML inventory with bounded media previews, text inspection, glTF summaries, and interactive wireframe views.
- Added `serve`, bound to localhost, for viewing generated HTML without `file://` restrictions.
- `rip-game` now generates an asset viewer automatically unless disabled.
- Added drag-and-drop launchers for BBX extraction/repacking, viewer generation, and local serving.
- Expanded `selftest` from 9 to 11 checks with BBX repacker and HTML viewer tests.
- Added dedicated repacker, asset viewer, Blender add-on, and excluded-source documentation.

## 2.2.0

- Integrated the verified MAP atlas renderer into the main toolkit. Resource IDs 6, 7, 8, and 9 resolve to `fence1_512`, `fence2_512`, `fence6_512a`, and `fence3_512`; tile IDs 1–49 use the confirmed 7×7 atlas layout and X/Y reflections.
- Upgraded `stageviz` to explorer format v4 with embedded game atlases, zero-scroll layer composites, cell inspection, safe HTML escaping, and categorical fallback when an atlas is absent.
- Added optional atlas-backed output to `map2png` through `--atlas`, `--atlas-step`, and `--no-atlas-composite`.
- `rip-game` now generates the offline stage explorer automatically unless `--no-stageviz` is used.
- Added deterministic `OUTPUT_MANIFEST.json` and `.sha256` files plus `verify-output` for privacy, size, hash, partial-file, and report validation.
- Added `doctor`, global `--version`, and a built-in `selftest` covering AES, BBX, DAT, MAP, bounded gzip, PNG/atlas rendering, ZIP safety, privacy redaction, and output tamper detection.
- Hardened ZIP, STFS, and PKG extraction with configurable file-count/size limits, duplicate-path checks, traversal and symlink rejection, and atomic `.siig-part` writes.
- Added bounded gzip expansion, nested-BBX depth/resource budgets, Windows-reserved-name handling, case-insensitive output collision avoidance, and stricter platform ambiguity detection.
- Resume profiles now include the toolkit version so changed converter behavior cannot silently reuse stale output.
- Restored and updated the credits, AI disclosure, provenance, source audit, third-party notices, project-license status, and attribution policy in the package.
- Added security and testing documentation and expanded full-rip reports with elapsed time, explorer status, extraction limits, and manifest status.

## 2.1

- Added direct Xbox 360 STFS input to `rip-game` for `CON `, `LIVE`, and `PIRS` packages.
- Added direct PlayStation 3 PKG input for finalized and non-finalized/debug type-1 packages.
- Added dependency-free STFS block-chain/hash-table extraction and PS3 PKG AES/debug-stream decryption.
- Added `unpack-container` for outer-package-only extraction and `container-selftest` for the AES known-answer test.
- Added magic-based input detection; package filenames no longer need a particular extension.
- Added outer-container totals and input type to full-game validation reports.
- Preserved the separate PS3 NPDRM SDAT step: TrueAncestor `.bin.gz.dat` files are still discovered beside the PKG or through `--ps3-sdat-dir`.
- Validated synthetic STFS level-0/1/2 boundaries, chained files, finalized/debug PKGs, and both supplied extracted retail releases.
- Added `docs/guides/CONTAINER_INPUT_NOTES.md` and updated the drag-and-drop launcher.


## 2.0

- Corrected the MAP interpretation using the June 10 XEX renderer path.
- Confirmed `0` as empty, tile IDs `1..49`, `0x40` as X flip, and `0x80` as Y flip.
- Confirmed a 30-unit tile grid and three independently scrolling layers.
- Added runtime tile-set resource IDs for all 75 stage-table entries.
- Updated the offline explorer with verified tile and flip views.
- Documented generator MAPs as reusable 2D tile-pattern blocks.
- Removed the unsupported assumption that these MAP cells place 3D wall models.
- Kept exact tile-set filenames and layer gameplay roles explicitly unresolved.

## 1.9

- Added conservative XEX-backed DAT semantic decoding with categories, summaries, confidence levels and proven field names.
- Added `stageviz`, a self-contained offline MAP/DAT explorer with searchable frame timelines and three MAP bit views.
- Reconstructed the 75 stage/script pairings, two MAP-only slots and trial variant from the June 10 executable tables.
- Added explicit reporting for 12 expected-but-absent level-4/5 MAP names and 14 package MAPs unreferenced by the runtime table.
- Added `reference/tables/STAGE_PAIRING.csv`, `reference/tables/DAT_SEMANTIC_SCHEMAS.csv` and `docs/guides/STAGE_EXPLORER_NOTES.md`.
- Validated semantic export on all 1,334 June 10 DAT files with zero failures; the explorer contains 17,335 commands from all 76 stage scripts and no absolute source paths.


## 1.8

- Confirmed the shared DAT format from the June 10 DebugOpt `stageScriptBlockLoad` routine.
- Added `dat2csv`, delta-to-absolute frame conversion, full signed/hex argument preservation, and the executable-derived 207-slot opcode-name table.
- Confirmed the MAP layer format from `stageGenerate2DMap`.
- Added `map2png` with categorical/grayscale palettes, optional nearest-neighbor scaling, numeric CSV grids, and JSON metadata.
- Added DAT/MAP recognition to `scan`.
- `rip-game` now converts all extracted DAT and MAP resources automatically.
- Validated 5,244 DAT files containing 96,750 commands and 1,576 MAP files containing 4,728 layers across May 9, May 11, June 10 and retail Xbox 360 builds with zero parse failures.

## 1.7

- Added `.col` collision-mask decoding to PNG.
- Added standalone `.anm` table decoding to CSV and JSON.
- `rip-game` now converts COL and ANM resources automatically.
- Added prototype-analysis notes based on the May 9, May 11 and June 10 Xbox 360 builds.

## 1.6.0

- Added `rip-game` for original Xbox 360/PS3 directories and ZIP archives.
- Added automatic platform detection from `default.xex` and `EBOOT.BIN`.
- Added PS3 RSX TEX to PNG support and PS3 system-font atlas decoding.
- Added TrueAncestor `.bin.gz.dat` discovery for NPDRM/SDAT payloads.
- Added deterministic archive ancestry, decompressed BBX preservation, resume-state hashes, ready-file copying, and privacy-safe validation reports.
- Added drag-and-drop `SIIG_Rip_Game.bat`.
- Xbox 360 WMA files are preserved unchanged; PS3 Sony SBlk audio banks are extracted losslessly as `.bnk` for vgmstream.

## 1.5.1

- Removed absolute input, output, FFmpeg, and glTF filesystem routes from generated JSON metadata.
- JSON manifests now retain only privacy-safe filenames and archive-relative paths.
- Added `sanitize-json` to clean metadata generated by v1.5 or earlier in place.
- Sanitized the bundled glTF samples.

## 1.5

- Added `gmx2gltf` and `extract --convert-gltf`.
- Decoded GMX `TXIF`, `SHAD`, `MTRL`, `PARE`, `BONE`, `MOTN`, and `ANIM` chunk relationships.
- Added glTF 2.0 hierarchy, rigid mesh attachment, materials, vertex colors, texture assignment, and transform-animation export.
- Added automatic conversion of the shared uncompressed `ptn_001.dds` texture to PNG.
- Added `docs/formats/GMX_GLTF_NOTES.md` and detailed GMX output in `scan`.
- Validated 486 GMX files, 1,938 meshes, 3,298 nodes, 776 materials, and 913 animation tracks with zero conversion failures.

## 1.4

- Added `text2csv` for direct decoding of `text.bin`, `message.bin`, or a directory containing both.
- Recovered the 542-row `text.bin` key/translation table across Japanese, English, French, Italian, German and Spanish.
- Parsed all 284 Squirrel-style `message.bin` arrays and 1,295 strings per language.
- Added Unicode correction for the legacy language-specific accented-glyph codes while retaining untouched raw scripts.
- Added combined CSV/JSON, per-language text files, metadata, and `docs/formats/LOCALIZATION_NOTES.md`.

## 1.3

- Added `xact2wav` for direct conversion from `sound.bin`, extracted XWB files, or XWB/XSB directories.
- Added standard big-endian XACT3 wave-bank parsing and XSB cue-name recovery.
- Added RIFF XMA2 wrapper generation and optional FFmpeg PCM WAV decoding.
- Validated all 86 SIIG streams: 83 SE cues plus BGM007, BGM008_MIX_C and BGM_XACT_SE33.
- Added per-bank CSV/JSON manifests with channels, sample rates, sample counts and loop metadata.

## 1.2

- Added `font2png` for `systemfont.bin`, `.gz`, or extracted `systemfont.crp`.
- Confirmed from `default.xex` that `systemfont.crp` is XOR-obfuscated bytewise with key `0xF1`.
- Added automatic CRP conversion when `extract --convert-tex` is used.
- Added `reference/systemfont/systemfont_glyphs.csv` with all 6,732 executable-resident glyph records, atlas coordinates, widths, left insets and known aliases.
- Added `reference/systemfont/systemfont.fnt` AngelCode BMFont descriptor for the 6,730 native Unicode mappings.
- Added CRP detection to `scan`.

## 1.1

- Fixed TEX untile addressing.
- Added the missing Y[3] XOR in the Xenos pipe selector.
- Eliminated repeating 8-row jitter/scrambling in converted PNG files.
- Revalidated all 54 supplied TEX files with zero conversion failures.

## 1.0

- Initial BBX extraction, GMX-to-OBJ and TEX-to-PNG release.
