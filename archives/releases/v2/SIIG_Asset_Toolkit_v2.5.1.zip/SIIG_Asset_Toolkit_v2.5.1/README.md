# Space Invaders Infinity Gene Asset Toolkit

**Version 2.5.1 — organized release layout and documentation index**

SIIG Asset Toolkit is a dependency-light Python toolkit for researching and extracting assets from the Xbox 360 and PlayStation 3 releases of **Space Invaders Infinity Gene**. It accepts original outer packages, extracted game folders, or ZIP archives; extracts nested BBX resources; converts supported assets; builds a self-contained stage explorer; and records enough metadata to audit the result.

The toolkit is based on user-supplied retail/prototype files, cross-platform comparisons, and Ghidra exports from `default.xex`. It does not include game binaries or extracted copyrighted assets.

## Highlights in 2.5.1

- Reorganized 57 documentation, reference, validation, add-on, and tool files into purpose-specific folders.
- Reduced the release root from 75 files to 18 without deleting any research material.
- Added `docs/README.md` as the central documentation and data index.
- Added compatibility lookups for the legacy root-level table locations.
- Kept commands and drag-and-drop launchers at the root for straightforward use.

Inherited v2.5.0 viewer improvements:

- Replaced the monolithic Asset Viewer with a small linked-data HTML shell.
- Removed base64 media embedding; images/audio are loaded through local relative links.
- Added pagination, intersection-based lazy loading, and 32 deferred preview shards.
- Added direct thumbnails for GMX, OBJ, TEX, MAP, DAT, ANM, and WAV assets.
- Added explicit placeholders for animation-only models, empty path files, and empty MAPs.
- Fixed related glTF payload keys and prevented viewer rebuilds from indexing their own output.
- Validated 1,016/1,016 previewable assets with thumbnails on the 1,759-file research rip.
- Reduced the tested main HTML from 18,207,366 bytes to 12,022 bytes.

The v2.5 Asset Viewer work and v2.4 stage, animation, wall, and shader research remain included. See `docs/releases/RELEASE_NOTES_2.5.1.md`, `docs/guides/ASSET_VIEWER_NOTES.md`, and `validation/ASSET_VIEWER_VALIDATION_2.5.json`.

## Release folder layout

```text
SIIG_Asset_Toolkit_v2.5.1/
├── siig_toolkit.py and companion modules
├── SIIG_*.bat launchers
├── docs/          guides, format research, project records, release history
├── reference/     tables, provenance, samples, system-font support data
├── validation/    machine-readable validation reports
├── tools/         optional Ghidra helper
├── addons/        Blender add-on package and source
└── LICENSES/      required third-party notices
```

Use [`docs/README.md`](docs/README.md) as the central index.

## Requirements

- Python **3.10 or newer**.
- No third-party Python packages are required.
- FFmpeg is optional and only needed to decode Xbox 360 XMA2 streams to PCM WAV. Without FFmpeg, the toolkit still writes RIFF-wrapped `.xma` files and manifests.
- PS3 SIIG's six inner NPDRM SDAT resources still require matching decrypted `*.bin.gz.dat` files produced by a user-run external tool. The outer PKG layer is handled internally.

## Recommended first run

From Command Prompt or PowerShell in the toolkit folder:

```bat
python siig_toolkit.py --version
python siig_toolkit.py selftest
python siig_toolkit.py doctor "C:\path\to\game-package"
```

On Windows, `py -3` may be used instead of `python`.

## One-click full-game extraction

Drag an Xbox 360 STFS package, PS3 PKG, extracted game ZIP, or extracted game folder onto `SIIG_Rip_Game.bat`.

Command-line equivalent:

```bat
python siig_toolkit.py rip-game "C:\path\to\game-package" -o "C:\path\to\SIIG_Ripped" --resume
```

For PS3, supply the decrypted inner SDAT outputs when they are not beside the input:

```bat
python siig_toolkit.py rip-game "C:\Games\SIIG.pkg" -o "C:\Rips\SIIG_PS3" ^
  --ps3-sdat-dir "C:\Games\SIIG_decrypted" --resume
```

The expected files are:

```text
generator.bin.gz.dat
message.bin.gz.dat
script.bin.gz.dat
shader.bin.gz.dat
text.bin.gz.dat
visualizerSet.bin.gz.dat
```

See `docs/guides/FULL_GAME_RIP.md` and `docs/guides/CONTAINER_INPUT_NOTES.md`.

## Verify a completed rip

```bat
python siig_toolkit.py verify-output "C:\path\to\SIIG_Ripped"
```

Or drag the output folder onto `SIIG_Verify_Rip.bat`. Full verification checks report consistency, privacy, file sizes, SHA-256 hashes, and leftover partial files. Use `--quick` to omit hashing.

## Main capabilities

### Package and archive extraction

- Header-based Xbox 360 STFS detection: `CON `, `LIVE`, and `PIRS`.
- PlayStation 3 type-1 PKG extraction for finalized and non-finalized/debug packages.
- ZIP and extracted-directory inputs.
- BBX extraction for `01 42 42 58` containers, including unnamed resources, nested BBX archives, gzip wrappers, filename hierarchy, exact filename-hash verification, and CSV/JSON manifests.
- Configurable extraction limits and atomic writes.

### Repacking and modding research

- Rebuild extracted BBX directories from their manifests with canonical mode/hash/index/name/payload layout.
- Preserve unnamed resource identifiers and reserved header bytes.
- Recompute named hashes by default or preserve deliberate mismatches.
- Verify every output immediately and write a detailed repack report.
- Produce deterministic gzip-wrapped archives when requested.

### Asset browsing and Blender

- Generate a searchable offline asset browser with a small HTML shell and local linked payloads.
- Inspect images, browser-playable audio, text/CSV/JSON, hashes, GMX/glTF/OBJ structure, and interactive wireframes.
- Browse paginated cards with lazy thumbnails for converted and raw SIIG asset formats.
- Import GMX files into Blender 3.6+ with the bundled add-on, using the same exporter as the CLI.
- Serve an output directory on localhost when browsers restrict direct file access.

### Models and textures

- GMX → glTF 2.0 with indexed triangles/lines, positions, normals, UVs, vertex colors, hierarchy, rigid attachment, materials, textures, and transform animation.
- GMX → OBJ as a lightweight static-geometry option.
- Xbox 360 tiled TEX → PNG with Xenos bank/pipe addressing and endian/channel conversion.
- PS3 RSX-wrapped linear A8R8G8B8 TEX → PNG.
- System-font XOR deobfuscation, 2048×3392 atlas export, 6,732-record glyph table, and AngelCode BMFont descriptor.

### Audio and localization

- Xbox 360 XACT3 XWB/XSB extraction, cue naming, XMA2 RIFF wrapping, and optional FFmpeg WAV decoding.
- Lossless preservation of ready-to-use WMA/AT3 media.
- PS3 Sony SBlk/VAG bank preservation for external vgmstream processing.
- `text.bin` and `message.bin` localization export to UTF-8 CSV, JSON, corrected scripts, raw scripts, and per-language text.

### Structured gameplay data

- DAT command streams to timed semantic CSV/JSON with absolute frames, executable-derived opcode names, confidence labels, and lossless raw words.
- MAP parsing for all three independently sized tile/sprite layers.
- Categorical, grayscale, and verified atlas-backed MAP PNG output.
- Offline Stage Explorer v4 with runtime stage pairing, embedded atlases, MAP layer/composite views, cell inspection, and DAT timeline filtering.
- COL one-bit collision masks to PNG.
- ANM model/group clip ranges to CSV/JSON, including start/end frames and loop behavior.
- Bmap/Xmap/map4/map5 3D path and GMX-placement tables to JSON/CSV/OBJ.
- Wall/Xwall repeat strips and `stage_generate.bin` candidate tables to JSON/CSV.
- Xenos compiled-shader headers, metadata strings, hashes, and raw microcode extraction.

### Research support

- `scan` for JSON descriptions of known formats.
- `tools/ghidra/ApplySIIGFunctionNames.java` for optional confirmed Ghidra labels.
- Machine-readable validation tables and format notes.
- Privacy sanitizer for older JSON metadata.
- Source, license, attribution, and AI-assistance records.

## Common commands

### Inspect the environment and input

```bat
python siig_toolkit.py doctor "C:\path\to\input"
```

### Extract only the outer STFS/PKG container

```bat
python siig_toolkit.py unpack-container "C:\path\to\package" -o outer_files --clean
```

### Extract a BBX archive

```bat
python siig_toolkit.py extract player.bin -o extracted --convert-gltf --convert-tex
```

### Recursively extract a directory of BBX archives

```bat
python siig_toolkit.py extract game_bins -o extracted --recursive --convert-gltf --convert-tex
```

### Build or rebuild the stage explorer

```bat
python siig_toolkit.py stageviz "C:\path\to\SIIG_Ripped" -o stage_explorer
```

Open `stage_explorer\SIIG_Stage_Explorer.html`. The file is self-contained and makes no network requests.

### Render a MAP with a verified atlas

```bat
python siig_toolkit.py map2png level1_stage1.map -o map_preview ^
  --atlas fence1_512.png --atlas-step 30 --csv
```

Without `--atlas`, the command writes exact categorical or grayscale cell visualizations.

### Repack an extracted BBX

```bat
python siig_toolkit.py extract map.bin -o work
python siig_toolkit.py repack-bbx work\map -o map_repacked.bin
```

The second command reads `work\map\manifest.json`, writes atomically, verifies the new archive, and creates a `.repack.json` report. See `docs/guides/BBX_REPACK_NOTES.md` before modifying game data.

### Build and open the asset viewer

```bat
python siig_toolkit.py asset-viewer "C:\path\to\SIIG_Ripped" -o viewer
python siig_toolkit.py serve viewer
```

The server binds only to `127.0.0.1`. Keep `SIIG_Asset_Viewer.html` beside its generated `viewer_assets` directory; the viewer is intentionally no longer one giant self-contained file.

### Install the Blender add-on

Install `addons/SIIG_Blender_Addon_v0.1.0.zip` through Blender's Add-ons preferences, then point its preferences at this toolkit folder. See `docs/guides/BLENDER_ADDON_NOTES.md`.

### Decode 3D stage paths and placements

```bat
python siig_toolkit.py stage3dmap extracted\stage -o stage3d
```

### Decode wall strips and generator candidates

```bat
python siig_toolkit.py stagewall extracted\stage -o stagewall
```

### Inventory Xbox 360 compiled shaders

```bat
python siig_toolkit.py shader-info extracted\shader -o shader_metadata
```

### Decode localization

```bat
python siig_toolkit.py text2csv "C:\path\to\Media" -o localization
```

### Decode audio

```bat
python siig_toolkit.py xact2wav sound.bin -o audio
```

### Decode the system font

```bat
python siig_toolkit.py font2png systemfont.bin -o systemfont_decoded
```

### Convert extracted models

```bat
python siig_toolkit.py gmx2gltf extracted -o gltf
python siig_toolkit.py gmx2obj extracted -o obj
```

### Run the built-in regression suite

```bat
python siig_toolkit.py selftest
```

## Typical full-rip output

```text
SIIG_Ripped\
├── assets\                  extracted resources and direct conversions
├── decompressed_bbx\        normalized BBX archives
├── audio\                   audio manifests and converted streams
├── localization\            combined UTF-8 exports
├── ready_files\             directly usable media copied unchanged
├── stage_explorer\
│   ├── SIIG_Stage_Explorer.html
│   ├── STAGE_MANIFEST.json
│   └── README.txt
├── asset_viewer\
│   ├── SIIG_Asset_Viewer.html
│   └── ASSET_VIEWER_REPORT.json
├── structured\
│   ├── dat\                  timed DAT CSV/JSON
│   └── map\                  MAP layers, metadata, and optional atlas renders
├── systemfont\              decoded atlas and glyph data
└── validation\
    ├── RIP_REPORT.json
    ├── RIP_REPORT.txt
    ├── OUTPUT_MANIFEST.json
    └── OUTPUT_MANIFEST.sha256
```

Output varies by platform and available source assets.

## Safety and reproducibility

The toolkit treats input packages as untrusted. Outer-container extraction is bounded by file-count, per-file, total-byte, and ZIP-ratio limits. Paths are normalized, traversal and symlink entries are rejected, collisions are detected case-insensitively, writes are atomic, gzip output is bounded, and nested BBX extraction has depth and entry budgets.

Defaults are intentionally generous for SIIG but can be lowered:

```bat
python siig_toolkit.py rip-game game.zip -o SIIG_Ripped ^
  --max-files 10000 --max-total-bytes 8589934592 ^
  --max-file-bytes 2147483648 --max-zip-ratio 200
```

See `docs/guides/SECURITY_NOTES.md`. Keep original packages read-only and verify output before archiving or sharing research results. Repacking never changes the extraction directory, but modified archives must be tested only on copies; it does not update outer-package metadata or executable references.

## Accuracy boundaries

Confirmed facts are separated from unresolved semantics. In particular:

- MAP cells are confirmed 2D tile/sprite data, not 3D wall placements.
- MAP atlas mapping and flip behavior are confirmed; exact gameplay labels for the three independent layers and their complete runtime scroll trajectories remain unresolved.
- The Stage Explorer composite is a zero-scroll reconstruction, not a frame-accurate gameplay recording.
- The 3D stage path, placement, and wall-strip tables are decoded, but complete runtime reconstruction still requires camera/route behavior, auxiliary-vector semantics, collision, and DAT 3D-control playback.
- Direct STFS/PKG readers have synthetic boundary tests and extracted-release regression coverage, but the exact original retail SIIG outer packages were not available for validation in this release.

## Ethics, licenses, and redistribution

- Do not redistribute game packages, binaries, extracted textures/audio/models, or self-contained explorers containing embedded game atlases without permission.
- The source-only toolkit release contains no game assets.
- External tools such as FFmpeg, Ghidra, XEXLoaderWV, vgmstream, and TrueAncestor are not bundled.
- OpenAI ChatGPT assistance is disclosed in `docs/project/AI_DISCLOSURE.md`.
- Explicit sources and adaptations are recorded in `reference/provenance/SOURCES.csv`, `reference/provenance/PROVENANCE.json`, `docs/project/SOURCE_AUDIT.md`, and `docs/project/THIRD_PARTY_NOTICES.md`.
- TCRF/the Cutting Room Floor was not used and is an explicitly excluded research source; see `docs/project/SOURCE_EXCLUSIONS.md`.
- No license has yet been selected for the toolkit's original project code. See `docs/project/PROJECT_LICENSE_STATUS.md` before redistribution.
