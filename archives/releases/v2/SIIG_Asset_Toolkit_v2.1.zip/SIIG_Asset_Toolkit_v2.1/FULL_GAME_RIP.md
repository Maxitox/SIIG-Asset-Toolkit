# One-click full-game rip

The platform-aware `rip-game` command accepts the original outer package directly, as well as previously supported extracted inputs:

```text
Xbox 360 STFS package (CON/LIVE/PIRS)
PlayStation 3 PKG
Extracted game directory
ZIP containing an extracted game
```

Input type is detected by the file header, not by its extension.

## Fastest Windows method

Drag the STFS package, PS3 PKG, extracted ZIP, or extracted game folder onto `SIIG_Rip_Game.bat`.

The output is created beside the input as `SIIG_Ripped`. Repeating the operation uses `--resume` and skips archives whose source hash and conversion profile have not changed.

## Xbox 360 direct package input

```bat
python siig_toolkit.py rip-game "C:\Games\SIIG_X360_STFS" -o "C:\Rips\SIIG_X360" --resume
```

The built-in reader unpacks `CON `, `LIVE`, and `PIRS` STFS containers, then continues through gzip, BBX, TEX, GMX, XACT, localization, font, DAT, MAP, COL, and ANM processing.

## PlayStation 3 direct package input

```bat
python siig_toolkit.py rip-game "C:\Games\SIIG_PS3.pkg" -o "C:\Rips\SIIG_PS3" --ps3-sdat-dir "C:\Games\SIIG_PS3_decrypted" --resume
```

The outer PKG is removed automatically. SIIG's six inner NPDRM `*.bin.gz.sdat` files still need the matching TrueAncestor outputs, because PKG decryption and SDAT decryption are separate layers. Put these beside the PKG or provide their directory with `--ps3-sdat-dir`:

```text
generator.bin.gz.dat
message.bin.gz.dat
script.bin.gz.dat
shader.bin.gz.dat
text.bin.gz.dat
visualizerSet.bin.gz.dat
```

## Previously extracted inputs

```bat
python siig_toolkit.py rip-game "C:\Games\Space Invaders IG X360.zip" -o "C:\Rips\SIIG_X360" --resume
python siig_toolkit.py rip-game "C:\Games\Extracted SIIG PS3" -o "C:\Rips\SIIG_PS3" --ps3-sdat-dir "C:\Games\SIIG_PS3_decrypted" --resume
```

## Outer-container-only mode

```bat
python siig_toolkit.py unpack-container "C:\Games\SIIG.pkg" -o "C:\Rips\SIIG_Installed_Files" --clean
```

This stops after STFS/PKG extraction and writes a privacy-safe `SIIG_CONTAINER_MANIFEST.json`.

## Output layout

```text
SIIG_Ripped\
├── assets\                 raw BBX resources plus PNG/glTF conversions
├── decompressed_bbx\       normalized `.bin` BBX archives
├── audio\xact\             Xbox 360 XACT streams converted to WAV
├── localization\           combined UTF-8 CSV/JSON/text exports
├── systemfont\             decoded atlas and glyph mapping
├── structured\dat\         timed command CSV/JSON
├── structured\map\         per-layer MAP PNG/JSON
├── ready_files\            WMA, AT3, PNG, SFO and XML files copied unchanged
└── validation\
    ├── RIP_REPORT.json
    └── RIP_REPORT.txt
```

All generated metadata uses archive-relative names. The final report records the detected input type, outer-container totals, and a privacy audit for accidental absolute paths.

## Platform behavior

### Xbox 360

- STFS packages are unpacked internally before game detection.
- Ordinary `.bin.gz` and `.bin.gz.sdat` files are recognized as gzip by their header.
- BBX resources are extracted recursively.
- TEX files are untiled and converted to PNG.
- GMX files are exported to glTF 2.0.
- `sound.bin` XACT/XMA2 banks are converted to WAV when FFmpeg is installed.
- Existing `Media/BGM/*.wma` files are copied unchanged.

### PlayStation 3

- Finalized and debug PS3 PKGs are unpacked internally.
- Ordinary `.bin.gz` files are decompressed directly.
- `NPD\0` SDAT files use matching TrueAncestor `.bin.gz.dat` outputs.
- PS3 TEX files use their native 0x80-byte RSX wrapper and linear A8R8G8B8 pixels.
- The shared GMX files use the same glTF converter.
- The Sony SBlk/VAG audio bank is extracted losslessly as `.bnk`; individual stream conversion is delegated to vgmstream.
- `SND0.AT3` and other ready-to-use media are copied unchanged.

## Useful options

```text
--clean          remove an old output tree before starting
--resume         skip unchanged archives and matching conversion profiles
--ps3-sdat-dir   directory containing TrueAncestor `.bin.gz.dat` files
--convert-obj    also write legacy OBJ models
--no-gltf        skip glTF model conversion
--no-textures    skip TEX conversion
--no-audio       skip Xbox 360 XACT conversion
--ffmpeg PATH    choose a specific FFmpeg executable
```

See `CONTAINER_INPUT_NOTES.md` for supported container variants, validation, and limitations.
