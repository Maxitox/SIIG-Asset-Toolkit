# Direct STFS and PS3 PKG input

Version 2.1 adds an outer-container stage before the existing SIIG asset pipeline. The same `rip-game` command can now accept:

- an extracted game directory;
- a ZIP of an extracted game;
- an Xbox 360 STFS package beginning with `CON `, `LIVE`, or `PIRS`;
- a PlayStation 3 PKG beginning with `7F 50 4B 47` (`\x7fPKG`).

Detection uses the file header rather than the filename extension.

## One-click use

On Windows, drag the STFS package or PS3 PKG onto `SIIG_Rip_Game.bat`.

Command-line equivalents:

```bat
python siig_toolkit.py rip-game "C:\Games\SIIG_X360_STFS" -o "C:\Rips\SIIG_X360" --resume
python siig_toolkit.py rip-game "C:\Games\SIIG_PS3.pkg" -o "C:\Rips\SIIG_PS3" --ps3-sdat-dir "C:\Games\SIIG_PS3_decrypted" --resume
```

The package is unpacked into a temporary directory, processed, and discarded automatically. The normal output remains in the selected `SIIG_Ripped` directory.

## Xbox 360 STFS support

The built-in reader supports STFS packages using the `CON `, `LIVE`, or `PIRS` signatures. It reads the volume descriptor, file table, directory hierarchy, consecutive files, chained files, active hash-table copies, and level-0/1/2 hash layouts.

It is an extractor, not a package validator or signer. Signatures and content hashes are not trusted as proof of authenticity; extraction is bounded and path-sanitized. SVOD packages are reported as unsupported rather than misparsed as STFS.

## PlayStation 3 PKG support

The built-in reader supports PS3 PKG type 1 and removes the outer package layer for both finalized and non-finalized/debug packages. It includes dependency-free AES-128-CTR and debug SHA-1 stream handling.

This does **not** decrypt inner NPDRM SELF, EDAT, or SDAT payloads. For SIIG, the six `*.bin.gz.sdat` resources still require their matching TrueAncestor outputs:

```text
generator.bin.gz.dat
message.bin.gz.dat
script.bin.gz.dat
shader.bin.gz.dat
text.bin.gz.dat
visualizerSet.bin.gz.dat
```

Place those files beside the PKG or pass their directory with `--ps3-sdat-dir`. Everything else proceeds automatically.

## Outer-container-only extraction

To inspect the installed files without running BBX or asset conversion:

```bat
python siig_toolkit.py unpack-container "C:\Games\SIIG.pkg" -o "C:\Rips\SIIG_PKG_Files" --clean
```

The command writes `SIIG_CONTAINER_MANIFEST.json` with privacy-safe relative metadata.

## Validation status

The implementation has passed:

- a FIPS-197 AES-128 known-answer test;
- synthetic STFS packages with consecutive and nonconsecutive chains;
- STFS chains crossing level-0, level-1, and level-2 hash boundaries;
- synthetic finalized and debug PS3 PKGs;
- end-to-end regression on the supplied extracted Xbox 360 and PS3 releases: 23 BBX archives, 2,593 resources, zero BBX hash mismatches, zero archive failures, and zero privacy-audit findings on each platform.

A raw retail SIIG STFS/PKG was not supplied for this release, so the package readers are format-validated and regression-tested but not yet verified against those exact two original outer containers.
