@echo off
setlocal
if "%~1"=="" (
  echo Drag an Xbox 360 STFS package, PS3 PKG, extracted game ZIP, or game folder onto this file.
  echo.
  echo PS3 note: place the six TrueAncestor .bin.gz.dat files beside the PKG,
  echo or run the command-line tool with --ps3-sdat-dir.
  echo.
  pause
  exit /b 1
)
set "INPUT=%~1"
set "OUTPUT=%~dp1SIIG_Ripped"
python "%~dp0siig_toolkit.py" rip-game "%INPUT%" -o "%OUTPUT%" --resume
set "CODE=%ERRORLEVEL%"
echo.
if exist "%OUTPUT%\validation\RIP_REPORT.txt" (
  echo Report: "%OUTPUT%\validation\RIP_REPORT.txt"
)
pause
exit /b %CODE%
