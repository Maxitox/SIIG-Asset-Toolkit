# SIIG MAP Renderer Findings

## Corrected interpretation

The `Media/map` and `Media/generator` `.map` resources are 2D tile/sprite maps used by the Infinity Gene core renderer. They are **not** tables that place 3D wall GMX models. This conclusion comes from the June 10 DebugOpt XEX's complete load, update, and draw path.

## File structure

```text
+0x00  char[4]  "MAP\0"
+0x04  be u32   layer count

Repeated layer:
        be u32   width
        be u32   height
        u8       cells[width * height]
```

`Function_82239190` (`0x82239190`) allocates and copies each layer. The loader diagnostic is `Invinf_LoadMap`, and the source path places the subsystem in `InfinityGene/Game/invinfGame.cpp`.

## Cell encoding

`Function_8223AC28` (`0x8223AC28`) reads each byte and performs:

```text
base_code = cell & 0x3F
flip_bits = cell >> 6
```

- `0` is empty.
- `1..49` are one-based tile codes. The renderer subtracts one and accepts tile indices `0..48`.
- `0x40` is X reflection.
- `0x80` is Y reflection.
- `0xC0` applies both reflections.

`Function_8223A1B0` (`0x8223A1B0`) selects one of three groups of 49 sprite/UV variants: base, X-reflected, and Y-reflected. It also adjusts the X or Y geometry path when the corresponding flag is set.

## Placement and layers

Cells use a 30-unit grid. Tile centers are placed at:

```text
x = scroll_x + column * 30 + 15
y = scroll_y + row    * 30 + 15
```

The three arrays scroll independently and are submitted in layer order 2, 1, 0. Their exact gameplay labels remain unresolved.

## Runtime tile-set selection

The June 10 stage table at `0x8204BD50` selects tile-set resource IDs `6`, `7`, or `8` for each of the 75 runtime stages. The numeric mapping is confirmed, but assigning those IDs to archive filenames is postponed until the resource-manager registration order is proven.

## Generator MAPs

`Function_8226CB28` (`0x8226CB28`) appends the layers of small generator MAP blocks into larger buffers. `Function_8226CD30` (`0x8226CD30`) selects 24 blocks by names such as `a_000.map`. These are reusable 2D tile-pattern blocks, not wall-model placement data.

## Corpus validation

### Stage MAP archive

- 64 files
- 32 nonempty layers
- 573,984 cells
- 150,480 nonzero cells
- 49 valid base tile IDs; no value decodes above 49
- X-reflected cells: 34,327
- Y-reflected cells: 3,521
- XY-reflected cells: 3,525

### Generator MAP archive

- 330 files
- 645 nonempty layers
- 242,944 cells
- 62,223 nonzero cells
- no value decodes above tile ID 49
- X-reflected cells: 25,845
- Y-reflected cells: 1,219
- XY-reflected cells: 1,219

## Consequence for 3D reconstruction

A true 3D stage reconstruction must follow a separate path through `3ddata/stage`, `3ddata/map`, `3ddata/wall`, routes, camera data, and DAT 3D-control commands. The 2D MAP renderer remains useful for reconstructing the game's scrolling sprite/tile playfield and generator patterns.
