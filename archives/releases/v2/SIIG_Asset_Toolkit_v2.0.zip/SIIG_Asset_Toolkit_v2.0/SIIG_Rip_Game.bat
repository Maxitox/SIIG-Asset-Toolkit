@echo off
setlocal
if "%~1"=="" (
  echo Drag the original Xbox 360 or PS3 game ZIP/folder onto this file.
  echo.
  pause
  exit /b 1
)
set "INPUT=%~1"
set "OUTPUT=%~dp1SIIG_Ripped"
python "%~dp0siig_toolkit.py" rip-game "%INPUT%" -o "%OUTPUT%" --resume
set "CODE=%ERRORLEVEL%"
echo.
if exist "%OUTPUT%\validation\RIP_REPORT.txt" (
  echo Report: "%OUTPUT%\validation\RIP_REPORT.txt"
)
pause
exit /b %CODE%
