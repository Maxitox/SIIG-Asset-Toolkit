#!/usr/bin/env python3
"""Self-contained SIIG stage MAP/DAT explorer generator."""
from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path

import siig_toolkit as toolkit


# June 10 DebugOpt runtime table at 0x8204BD50. The values are renderer
# texture/tile-set resource IDs. Exact archive filenames are intentionally not
# assigned until the resource-manager registration table is fully traced.
STAGE_TILE_SET_IDS = (
    6, 7, 6, 7, 6, 8, 6, 7, 6, 7, 6, 8, 6, 7, 6, 7, 6, 8,
    6, 7, 6, 7, 6, 8, 6, 7, 6, 7, 6, 8, 6, 7, 6, 7, 6, 8,
    6, 7, 6, 6, 7, 7, 7, 6, 8, 6, 7, 6, 6, 7, 6, 7, 6, 8,
    6, 7, 6, 6, 7, 6, 7, 7, 8, 6, 7, 6, 6, 7, 6, 7, 6, 8,
    6, 7, 6,
)


def _rle_bytes(data: bytes) -> list[list[int]]:
    if not data:
        return []
    result: list[list[int]] = []
    current = data[0]
    count = 1
    for value in data[1:]:
        if value == current:
            count += 1
        else:
            result.append([current, count])
            current = value
            count = 1
    result.append([current, count])
    return result


def _stage_media_root(input_path: Path) -> Path:
    candidates = (input_path / "assets" / "Media", input_path / "Media", input_path)
    for candidate in candidates:
        if (candidate / "script").is_dir() or (candidate / "map").is_dir():
            return candidate
    raise toolkit.FormatError("could not find Media/script or Media/map below the supplied path")


def _html(dataset: dict) -> str:
    payload = json.dumps(dataset, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    prefix = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SIIG Stage Explorer</title>
<style>
:root{color-scheme:dark;background:#0d1017;color:#e7ebf3;font:14px system-ui,sans-serif}*{box-sizing:border-box}body{margin:0}
header{position:sticky;top:0;z-index:5;background:#121722;border-bottom:1px solid #2a3242;padding:12px 18px;display:flex;gap:14px;align-items:center;flex-wrap:wrap}
h1{font-size:18px;margin:0 18px 0 0}.control{display:flex;gap:6px;align-items:center}select,input{background:#1a2130;color:#eef;border:1px solid #39445b;border-radius:6px;padding:6px 8px}
main{display:grid;grid-template-columns:minmax(320px,42%) 1fr;min-height:calc(100vh - 58px)}section{padding:16px;min-width:0}.maps{border-right:1px solid #2a3242;background:#0f131c}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(90px,1fr));gap:8px;margin-bottom:12px}.card{background:#171d29;border:1px solid #283146;border-radius:8px;padding:9px}.card b{display:block;font-size:19px}.muted{color:#9ba7bd}
.layer-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.layer{background:#171d29;border:1px solid #283146;border-radius:8px;overflow:hidden}.layer h3{font-size:13px;margin:0;padding:8px 10px;border-bottom:1px solid #283146}.canvas-wrap{height:68vh;overflow:auto;text-align:center;padding:8px;background:#07090d}.canvas-wrap canvas{image-rendering:pixelated;image-rendering:crisp-edges;transform-origin:top center}.legend{padding:8px;font-size:12px;white-space:pre-wrap;overflow-wrap:anywhere}
.timeline-tools{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}.table-wrap{overflow:auto;max-height:76vh;border:1px solid #283146;border-radius:8px}table{border-collapse:collapse;width:100%}th,td{padding:7px 8px;border-bottom:1px solid #222b3b;text-align:left;vertical-align:top}th{position:sticky;top:0;background:#171d29;z-index:1}.frame{font-variant-numeric:tabular-nums}.tag{display:inline-block;border-radius:999px;padding:2px 7px;background:#29344a;font-size:11px}.high{color:#8ee6a8}.medium{color:#f4d37c}.low{color:#e79898}.fields{font-family:ui-monospace,monospace;font-size:12px;color:#b9c5d9;white-space:normal}.files{margin:0 0 10px;line-height:1.5}.notice{background:#261f14;border:1px solid #5e4b25;padding:9px;border-radius:8px;margin-bottom:12px;color:#efd99e}
@media(max-width:1000px){main{display:block}.maps{border-right:0}.layer-grid{grid-template-columns:1fr}.canvas-wrap{height:45vh}}
</style></head><body>
<header><h1>SIIG Stage Explorer</h1><div class="control"><label>Stage</label><select id="stage"></select></div><div class="control"><label>Zoom</label><input id="zoom" type="range" min="2" max="20" value="4"></div><div class="control"><label>Map view</label><select id="mapMode"><option value="tile">Tile ID + flip shading</option><option value="raw">Raw byte</option><option value="base">Tile ID (1–49)</option><option value="flip">X/Y flip flags</option></select></div></header>
<main><section class="maps"><div class="notice">MAP cells are confirmed 2D tile/sprite data—not 3D wall placements. Zero is empty; the lower six bits are one-based tile IDs 1–49; 0x40 flips X and 0x80 flips Y. The three layers’ gameplay roles and exact texture-set filenames remain unresolved.</div><div class="files muted" id="files"></div><div class="cards" id="cards"></div><div class="layer-grid" id="layers"></div></section>
<section><div class="timeline-tools"><input id="search" placeholder="Search opcode, summary, or argument" size="34"><select id="category"><option value="">All categories</option></select><span class="muted" id="shown"></span></div><div class="table-wrap"><table><thead><tr><th>Frame</th><th>Command</th><th>Interpretation</th><th>Fields</th></tr></thead><tbody id="timeline"></tbody></table></div></section></main>
<script id="data" type="application/json">'''
    suffix = r'''</script><script>
const DB=JSON.parse(document.getElementById('data').textContent),stageSel=document.getElementById('stage'),layersEl=document.getElementById('layers'),timeline=document.getElementById('timeline');
const search=document.getElementById('search'),category=document.getElementById('category'),zoom=document.getElementById('zoom'),mapMode=document.getElementById('mapMode');
for(const s of DB.stages){const o=document.createElement('option');o.value=s.name;o.textContent=s.display_name||s.name;stageSel.appendChild(o)}
if(DB.default_stage)stageSel.value=DB.default_stage;
const cats=[...new Set(DB.stages.flatMap(s=>(s.script?.records||[]).map(r=>r.semantic.category)))].sort();for(const c of cats){const o=document.createElement('option');o.value=c;o.textContent=c;category.appendChild(o)}
function unrle(rle,total){const a=new Uint8Array(total);let p=0;for(const [v,n] of rle){a.fill(v,p,p+n);p+=n}return a}
function color(v,mode){if(v===0)return[4,6,10,255];const base=v&63,flags=v>>6;if(mode==='flip'){const cs=[[170,170,170],[80,180,255],[255,170,70],[220,90,220]];return[...cs[flags],255]}const id=mode==='raw'?v:base;const h=(id*47)%360,s=mode==='tile'?(flags===0?68:82):68,l=mode==='tile'?(42+flags*10):46,c=(1-Math.abs(2*l/100-1))*s/100,x=c*(1-Math.abs((h/60)%2-1)),m=l/100-c/2;let q=h<60?[c,x,0]:h<120?[x,c,0]:h<180?[0,c,x]:h<240?[0,x,c]:h<300?[x,0,c]:[c,0,x];return q.map(z=>Math.round((z+m)*255)).concat(255)}
function drawMaps(s){layersEl.innerHTML='';const ls=s.map?.layers||[];for(let i=0;i<3;i++){const l=ls[i]||{width:0,height:0,rle:[],value_counts:{}};const box=document.createElement('div');box.className='layer';box.innerHTML=`<h3>Layer ${i} · ${l.width}×${l.height}</h3><div class="canvas-wrap"><canvas></canvas></div><div class="legend"></div>`;layersEl.appendChild(box);const can=box.querySelector('canvas'),leg=box.querySelector('.legend');if(!l.width||!l.height){leg.textContent='Empty';continue}can.width=l.width;can.height=l.height;can.style.transform=`scale(${zoom.value})`;const ctx=can.getContext('2d'),img=ctx.createImageData(l.width,l.height),cells=unrle(l.rle,l.width*l.height);for(let p=0;p<cells.length;p++)img.data.set(color(cells[p],mapMode.value),p*4);ctx.putImageData(img,0,0);const vals=Object.entries(l.value_counts).sort((a,b)=>Number(a[0])-Number(b[0])),ids=Object.entries(l.base_id_counts||{}).sort((a,b)=>Number(a[0])-Number(b[0])),fl=l.flip_counts||{};leg.textContent=`nonzero ${l.nonzero_cells}/${l.cell_count} · flips none:${fl['0']||0} X:${fl['1']||0} Y:${fl['2']||0} XY:${fl['3']||0}\ntile IDs: `+ids.map(([v,n])=>`${v}:${n}`).join(' ')+`\nraw: `+vals.map(([v,n])=>`${Number(v).toString(16).padStart(2,'0').toUpperCase()}:${n}`).join(' ')}}
function renderTimeline(s){const q=search.value.toLowerCase(),cat=category.value,all=s.script?.records||[],rs=all.filter(r=>(!cat||r.semantic.category===cat)&&(!q||JSON.stringify(r).toLowerCase().includes(q)));timeline.innerHTML='';for(const r of rs){const tr=document.createElement('tr'),fs=r.semantic.fields.map(f=>`${f.name}=${f.value}${f.unit?' '+f.unit:''}`).join(' · ');tr.innerHTML=`<td class="frame">${r.absolute_frame}</td><td><b>${r.opcode_name}</b><br><span class="tag">${r.semantic.category}</span> <span class="${r.semantic.confidence}">${r.semantic.confidence}</span></td><td>${r.semantic.summary}</td><td class="fields">${fs||'—'}<br><span class="muted">raw ${r.args_signed.join(' ')}</span></td>`;timeline.appendChild(tr)}document.getElementById('shown').textContent=`${rs.length}/${all.length} commands`}
function render(){const s=DB.stages.find(x=>x.name===stageSel.value)||DB.stages[0],rec=s.script?.records||[],map=s.map;document.getElementById('files').innerHTML=`<b>${s.display_name||s.name}</b><br>kind: ${s.entry_kind||'asset'} · script: ${s.script_file||'—'}${s.script_missing?' (missing)':''} · map: ${s.map_file||'—'}${s.map_missing?' (missing)':''} · tile set ID: ${s.tile_set_id??'—'}`;document.getElementById('cards').innerHTML=`<div class="card"><span class="muted">Commands</span><b>${rec.length}</b></div><div class="card"><span class="muted">Duration</span><b>${s.script?.duration_frames||0}</b><small> frames</small></div><div class="card"><span class="muted">MAP cells</span><b>${(map?.layers||[]).reduce((a,l)=>a+l.cell_count,0)}</b></div><div class="card"><span class="muted">Nonzero</span><b>${(map?.layers||[]).reduce((a,l)=>a+l.nonzero_cells,0)}</b></div><div class="card"><span class="muted">Tile set</span><b>${s.tile_set_id??'—'}</b><small> resource ID</small></div>`;drawMaps(s);renderTimeline(s)}
stageSel.onchange=render;search.oninput=render;category.onchange=render;mapMode.onchange=render;zoom.oninput=()=>document.querySelectorAll('canvas').forEach(c=>c.style.transform=`scale(${zoom.value})`);render();
</script></body></html>'''
    return prefix + payload + suffix


def _load_pairing() -> list[dict[str, str]]:
    path = Path(__file__).with_name("STAGE_PAIRING.csv")
    if not path.is_file():
        return []
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def _script_payload(path: Path) -> dict:
    parsed = toolkit.parse_dat_bytes(path.read_bytes())
    return {
        "entry_count": parsed["entry_count"],
        "duration_frames": parsed["duration_frames"],
        "records": [{
            "index": record["index"],
            "absolute_frame": record["absolute_frame"],
            "opcode": record["opcode"],
            "opcode_name": record["opcode_name"],
            "args_signed": record["args_signed"],
            "semantic": record["semantic"],
        } for record in parsed["records"]],
    }


def _map_payload(path: Path) -> dict:
    parsed = toolkit.parse_map_bytes(path.read_bytes())
    return {
        "layer_count": parsed["layer_count"],
        "layers": [{
            "index": layer["index"],
            "width": layer["width"],
            "height": layer["height"],
            "cell_count": layer["cell_count"],
            "nonzero_cells": layer["nonzero_cells"],
            "unique_values": layer["unique_values"],
            "value_counts": {str(int(key, 16)): value for key, value in layer["value_counts"].items()},
            "base_id_counts": {str(key): value for key, value in sorted(Counter(cell & 0x3F for cell in layer["cells"] if cell).items())},
            "flip_counts": {str(key): value for key, value in sorted(Counter(cell >> 6 for cell in layer["cells"] if cell).items())},
            "rle": _rle_bytes(layer["cells"]),
        } for layer in parsed["layers"]],
    }


def build_stage_explorer(input_path: Path, output: Path) -> dict:
    media = _stage_media_root(input_path)
    script_dir, map_dir = media / "script", media / "map"
    script_paths = {path.name.lower(): path for path in script_dir.glob("*.dat")} if script_dir.is_dir() else {}
    map_paths = {path.name.lower(): path for path in map_dir.glob("*.map")} if map_dir.is_dir() else {}
    if not script_paths and not map_paths:
        raise toolkit.FormatError("no stage DAT or MAP files were found")

    pairing = _load_pairing()
    stages: list[dict] = []
    referenced_scripts: set[str] = set()
    referenced_maps: set[str] = set()

    if pairing:
        for row_index, row in enumerate(pairing):
            stage_no = int(row["stage_no"])
            variant = row["variant"]
            script_file = row["script_file"]
            map_file = row["map_file"]
            script_path = script_paths.get(script_file.lower()) if script_file else None
            map_path = map_paths.get(map_file.lower()) if map_file else None
            if script_file:
                referenced_scripts.add(script_file.lower())
            if map_file:
                referenced_maps.add(map_file.lower())
            stem = Path(script_file or map_file).stem
            if row["entry_kind"] == "runtime_stage":
                display = f"Stage {stage_no:03d} · {stem}"
                name = f"stage_{stage_no:03d}_{stem}"
            elif row["entry_kind"] == "trial_variant":
                display = f"Trial variant · {stem} (stage {stage_no:03d})"
                name = f"trial_stage_{stage_no:03d}_{stem}"
            else:
                display = f"Map-only slot {stage_no:03d} · {stem}"
                name = f"map_slot_{stage_no:03d}_{stem}"
            item: dict = {
                "name": name,
                "display_name": display,
                "entry_kind": row["entry_kind"],
                "stage_no": stage_no,
                "variant": variant,
                "script_file": script_file,
                "map_file": map_file,
                "evidence": row["evidence"],
                "script_missing": bool(script_file and not script_path),
                "map_missing": bool(map_file and not map_path),
                "pairing_index": row_index,
                "tile_set_id": STAGE_TILE_SET_IDS[stage_no - 1] if 1 <= stage_no <= len(STAGE_TILE_SET_IDS) else None,
            }
            if script_path:
                item["script"] = _script_payload(script_path)
            if map_path:
                item["map"] = _map_payload(map_path)
            stages.append(item)
    else:
        # Generic fallback for other builds: safe filename-stem pairing only.
        names = sorted(set(Path(key).stem for key in script_paths) | set(Path(key).stem for key in map_paths), key=str.lower)
        for name in names:
            script_path = script_paths.get((name + ".dat").lower())
            map_path = map_paths.get((name + ".map").lower())
            item: dict = {
                "name": name,
                "display_name": name,
                "entry_kind": "fallback_stem_pair",
                "script_file": script_path.name if script_path else "",
                "map_file": map_path.name if map_path else "",
            }
            if script_path:
                item["script"] = _script_payload(script_path)
            if map_path:
                item["map"] = _map_payload(map_path)
            stages.append(item)

    # Preserve and expose package maps not referenced by the June 10 runtime table.
    for map_key in sorted(set(map_paths) - referenced_maps):
        map_path = map_paths[map_key]
        stem = map_path.stem
        stages.append({
            "name": f"unreferenced_map_{stem}",
            "display_name": f"Unreferenced package MAP · {stem}",
            "entry_kind": "unreferenced_package_map",
            "stage_no": None,
            "variant": "unreferenced",
            "script_file": "",
            "map_file": map_path.name,
            "evidence": "present in map BBX but absent from the June 10 runtime map-slot table",
            "map": _map_payload(map_path),
        })

    # Preserve any script that is not covered by the static table (future builds/forks).
    for script_key in sorted(set(script_paths) - referenced_scripts):
        script_path = script_paths[script_key]
        stem = script_path.stem
        stages.append({
            "name": f"unreferenced_script_{stem}",
            "display_name": f"Unreferenced package DAT · {stem}",
            "entry_kind": "unreferenced_package_script",
            "stage_no": None,
            "variant": "unreferenced",
            "script_file": script_path.name,
            "map_file": "",
            "evidence": "present in script BBX but absent from the June 10 runtime script table",
            "script": _script_payload(script_path),
        })

    dataset = {
        "format": "SIIG_STAGE_EXPLORER",
        "version": 3,
        "source": media.name,
        "stage_count": len(stages),
        "runtime_pair_count": len(pairing),
        "default_stage": next((stage["name"] for stage in stages if sum(layer["cell_count"] for layer in stage.get("map", {}).get("layers", [])) > 0 and stage.get("script")), stages[0]["name"]),
        "stages": stages,
        "notes": {
            "pairing": "June 10 runtime map slots and script slots are paired by executable table index",
            "missing_maps": "some expected normal level 4/5 MAP files are absent from the package; the loader tolerates this",
            "unreferenced_maps": "package MAP files absent from the runtime table are shown separately",
            "map_layers": "confirmed independently scrolling 2D tile/sprite layers; exact gameplay roles remain unresolved",
            "map_cell": "0 is empty; lower six bits are one-based tile IDs 1..49",
            "map_flips": "0x40 is X reflection; 0x80 is Y reflection",
            "map_cell_size": "30 units; renderer places tile centers at cell*30+15 plus scroll offset",
            "tile_set_ids": "runtime stages select resource IDs 6, 7, or 8; exact texture filenames remain unresolved",
            "not_wall_geometry": "Media/map and Media/generator MAP files do not place 3D wall GMX models",
            "semantic_policy": "XEX-backed fields are named; unresolved words remain generic",
        },
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "SIIG_Stage_Explorer.html").write_text(_html(dataset), encoding="utf-8")
    manifest = {
        "format": dataset["format"],
        "version": dataset["version"],
        "stage_count": dataset["stage_count"],
        "entry_count": dataset["stage_count"],
        "runtime_pair_count": dataset["runtime_pair_count"],
        "stages": [{
            "name": stage["name"],
            "display_name": stage["display_name"],
            "entry_kind": stage["entry_kind"],
            "stage_no": stage.get("stage_no"),
            "script_file": stage.get("script_file", ""),
            "map_file": stage.get("map_file", ""),
            "script_missing": stage.get("script_missing", False),
            "map_missing": stage.get("map_missing", False),
            "commands": stage.get("script", {}).get("entry_count", 0),
            "duration_frames": stage.get("script", {}).get("duration_frames", 0),
            "map_layers": stage.get("map", {}).get("layer_count", 0),
            "map_cells": sum(layer["cell_count"] for layer in stage.get("map", {}).get("layers", [])),
            "map_nonzero": sum(layer["nonzero_cells"] for layer in stage.get("map", {}).get("layers", [])),
            "tile_set_id": stage.get("tile_set_id"),
            "evidence": stage.get("evidence", ""),
        } for stage in stages],
        "notes": dataset["notes"],
    }
    toolkit.write_json_private(output / "STAGE_MANIFEST.json", manifest)
    (output / "README.txt").write_text(
        "Open SIIG_Stage_Explorer.html in a modern browser.\n"
        "The file is self-contained and makes no network requests.\n"
        "Runtime DAT/MAP pairing follows the June 10 XEX tables by stage index.\n"
        "MAP cells are 2D tile/sprite data: 0 empty, IDs 1-49, 0x40 X flip, 0x80 Y flip.\n"
        "Layer roles and exact tile-set filenames remain unresolved.\n",
        encoding="utf-8",
    )
    return manifest
