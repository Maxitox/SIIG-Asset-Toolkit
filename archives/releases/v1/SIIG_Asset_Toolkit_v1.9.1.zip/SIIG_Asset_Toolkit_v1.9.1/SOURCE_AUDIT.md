# Source-provenance audit report

Audit date: 2026-08-27

## Scope

The audit covered the source and documentation shipped in SIIG Asset Toolkit
v1.9. The review searched imports, comments, algorithm descriptions, external
process calls, and release documentation for third-party dependencies or
adapted implementation logic.

## Findings

- The toolkit has no vendored third-party Python packages and imports only the
  Python standard library.
- It bundles no third-party executable or shared library.
- One direct algorithmic adaptation was identified: the Xenos tiled-texture
  address calculation derived from Xenia. An inline notice and the Xenia BSD
  3-Clause license are now included.
- The XMA2 RIFF structure follows Microsoft DirectXTK documentation, but the
  Python wrapper code is locally written rather than copied from DirectXTK.
- glTF output follows the Khronos specification; no glTF library is bundled.
- Ghidra, XEXLoaderWV, FFmpeg, vgmstream, and TrueAncestor are external tools or
  references and are not redistributed.
- The proprietary SIIG format parsers are based on user-supplied binaries,
  decompiler/listing exports, cross-build comparison, and corpus validation.

## Historical limitation

The earlier development notes recorded Xenia at the project level but did not
preserve the exact upstream commit and source-file location consulted when the
texture routine was translated. This release states that limitation rather than
inventing a commit. All future code adaptations—including STFS and PS3 PKG
support—are blocked by policy until the exact repository, commit/tag,
file/function scope, license, and modifications are recorded.

## AI limitation

This audit can enumerate explicit sources consulted in the project and direct
adaptations intentionally made by the assistant. It cannot enumerate the full
training corpus or latent influences of the AI model. See `AI_DISCLOSURE.md`.

## Release recommendation

Before publishing a public source repository:

- select a license for original project code;
- decide the public contributor credit name(s);
- repeat source-overlap and license review after STFS/PKG implementation;
- retain the provenance and third-party notice files in every binary/source
  release.
