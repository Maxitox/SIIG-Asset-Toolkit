# Third-party notices

This package does not bundle FFmpeg, vgmstream, Ghidra, XEXLoaderWV,
TrueAncestor, Xenia, or DirectXTK binaries/libraries.

## Adapted source logic

### Xenia

The function `xg_address_2d_tiled_offset` in `siig_toolkit.py` is an independent
Python translation/adaptation of the Xenos tiled-texture addressing logic used
by the Xenia project. The implementation was reduced to the SIIG texture case,
renamed, and validated against all supplied textures. Xenia's BSD 3-Clause
notice is reproduced in `LICENSES/XENIA-BSD-3-CLAUSE.txt`.

Upstream: https://github.com/xenia-project/xenia

## Documentation and format references

### Microsoft DirectXTK

The XMA2 RIFF wrapper field layout follows the public `XMA2WAVEFORMATEX`
documentation in the DirectXTK Wave Formats wiki. No DirectXTK implementation
code is included.

Upstream: https://github.com/microsoft/DirectXTK/wiki/Wave-Formats
License: MIT

### Khronos glTF

Generated `.gltf` files target the Khronos glTF 2.0 specification.

Specification: https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html

## External tools

### Ghidra

Used for reverse engineering and by the optional Java label script. Ghidra is
not distributed with this toolkit.

Upstream: https://github.com/NationalSecurityAgency/ghidra
License: Apache-2.0

### XEXLoaderWV

Used to load Xbox 360 XEX files into Ghidra. No code is bundled or copied.

Upstream: https://github.com/zeroKilo/XEXLoaderWV
Original author credit in the repository: Warranty Voider

### FFmpeg

Invoked as a separate process when installed by the user. It is not linked,
modified, or redistributed by this package.

Upstream: https://ffmpeg.org/
License: LGPL-2.1-or-later by default; GPL terms may apply to particular builds.

### vgmstream

Recommended as a separate audio decoder/fallback. It is not bundled.

Upstream: https://github.com/vgmstream/vgmstream
License: permissive ISC-style notice; consult upstream `COPYING`.

### TrueAncestor EDAT Rebuilder

Used externally to obtain decrypted PS3 SDAT payloads. No TrueAncestor files or
code are included. Because an explicit redistribution/source license was not
identified during this audit, the project treats it strictly as a user-supplied
external tool and does not vendor or automate redistribution of it.

Reference: https://www.psx-place.com/resources/trueancestor-edat-rebuilder-by-jjkkyu.34/
Author: JjKkYu
