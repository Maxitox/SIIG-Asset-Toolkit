# Attribution and provenance policy

Every public release should satisfy these rules:

1. **Record explicit sources.** Add every repository, specification, article,
   tool, or user-provided evidence set that materially influenced implementation
   to `SOURCES.csv` and `PROVENANCE.json`.
2. **Pin imported code.** Any future copied or adapted code must record the exact
   repository, commit/tag, source file, function/range, license, and local
   modifications.
3. **Preserve notices.** Reproduce required copyright/license notices in
   `LICENSES/` and place an inline attribution beside adapted code.
4. **No unclear-license copying.** A source with no clear compatible license may
   be cited as research or used externally, but its code must not be copied or
   redistributed.
5. **Prefer clean-room work.** Proprietary game formats should be implemented
   from observed files, behavior, and decompiler evidence, with tests that show
   how conclusions were reached.
6. **Keep external binaries external.** FFmpeg, vgmstream, Ghidra, XEXLoaderWV,
   TrueAncestor, and similar utilities are not bundled unless a later release
   performs a separate license review and fulfills all redistribution terms.
7. **Disclose AI assistance.** Keep `AI_DISCLOSURE.md` in releases and update it
   when the development workflow materially changes.
8. **Avoid unapproved personal credit.** Contributor names are published only
   with permission; anonymous/project-role credit is acceptable.
9. **Do not redistribute game content.** Releases contain tooling, format notes,
   schemas, and validation metadata—not original game binaries or extracted
   copyrighted assets.
10. **Fail closed.** STFS/PKG or other new container support cannot be released
    until its code provenance and license entries are complete.
