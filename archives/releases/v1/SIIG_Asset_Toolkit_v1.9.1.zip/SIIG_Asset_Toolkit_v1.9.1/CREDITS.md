# Credits

## Project work

- **Project owner and data curator:** supplied the retail Xbox 360 and PS3 game
  files, prototype builds, Ghidra exports, decrypted PS3 SDAT payloads, and
  hardware/emulator test results. The public credit name is intentionally left
  unspecified until the project owner chooses one.
- **OpenAI ChatGPT:** assisted with reverse-engineering hypotheses, parser and
  converter implementation, automated validation, documentation, and release
  packaging.

## Clean-room game-format research

Unless a source is specifically identified below, the BBX, GMX, game-specific
TEX wrappers, PS3 TEX wrappers, system-font metadata, localization, COL, ANM,
DAT, MAP, and stage-table work was reconstructed from user-supplied game files,
prototype comparisons, and Ghidra decompilation/listing exports. Original game
source code was not available and is not included.

## Explicit third-party sources and tools

- **Xenia — Xbox 360 Emulator Research Project**
  - Used as an algorithmic reference for Xenos 2D tiled-texture addressing.
  - The Python implementation is a project-specific translation and adaptation,
    not a verbatim copy.
  - License: BSD 3-Clause. See `LICENSES/XENIA-BSD-3-CLAUSE.txt`.
- **Microsoft DirectX Tool Kit documentation**
  - Used as a structural reference for `XMA2WAVEFORMATEX` when creating RIFF
    wrappers around extracted XMA2 streams.
  - DirectXTK is MIT-licensed; no DirectXTK source code is bundled.
- **Khronos glTF 2.0 Specification**
  - Used as the normative format reference for generated glTF files.
- **Ghidra**
  - Used for PowerPC/XEX disassembly, decompilation, cross-references, and the
    optional label script API. Ghidra is Apache-2.0 licensed and is not bundled.
- **XEXLoaderWV by Warranty Voider / zeroKilo maintained fork**
  - Used by the project owner to load Xbox 360 XEX files into Ghidra.
  - Not bundled and no loader source code is copied into the toolkit.
- **FFmpeg**
  - Optional external executable used for XMA2-to-PCM WAV decoding.
  - Not bundled. Upstream builds may be LGPL or GPL depending on configuration.
- **vgmstream**
  - Recommended external decoder/fallback for game audio formats.
  - Not bundled.
- **TrueAncestor EDAT Rebuilder by JjKkYu**
  - Used externally by the project owner to decrypt the PS3 SDAT payloads.
  - Not bundled, modified, or copied. The toolkit only consumes its output.
- **Python 3 standard library**
  - Runtime platform used by the toolkit; no Python interpreter is bundled.

See `SOURCES.csv`, `PROVENANCE.json`, `SOURCE_AUDIT.md`, and
`THIRD_PARTY_NOTICES.md` for the machine-readable, audit, and license-oriented
records.
