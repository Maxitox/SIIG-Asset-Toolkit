#!/usr/bin/env python3
"""
Space Invaders Infinity Gene cross-platform asset toolkit.

Confirmed by cross-checking the game files with the default.xex Ghidra export:
- Extracts BBX containers (magic 01 42 42 58), including unnamed and nested entries.
- Verifies the game-specific filename hash.
- Exports GMX geometry, hierarchy, materials and transform animations to glTF 2.0, with OBJ retained for static geometry.
- Decrypts the XOR-obfuscated systemfont CRP and exports its 2048x3392 glyph atlas.
- Extracts XACT3 XWB/XSB banks and wraps Xbox 360 XMA2 streams for FFmpeg/vgmstream conversion.
- Decodes text.bin and message.bin localization databases to UTF-8 CSV/JSON/text.
- Converts one-bit COL collision masks to PNG and standalone ANM tables to CSV/JSON.
- Decodes DAT command streams to timed semantic CSV/JSON, MAP byte-grid layers, and a self-contained stage explorer.

Python 3.9+; standard library only.

Attribution and AI-development records are in CREDITS.md, SOURCES.csv,
PROVENANCE.json, THIRD_PARTY_NOTICES.md, and AI_DISCLOSURE.md.
"""

from __future__ import annotations

import argparse
import csv
from array import array
from functools import lru_cache
import gzip
import hashlib
import json
import math
import os
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile
import zlib
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Iterator, Optional, Sequence

BBX_MAGIC = b"\x01BBX"
GMX_MAGIC = b"GMX\x00"
MAP_MAGIC = b"MAP\x00"
GL_FLOAT = 0x1406
GL_UNSIGNED_SHORT = 0x1403
GL_LINES = 0x0001
GL_TRIANGLES = 0x0004
TEX_HEADER_SIZE = 0x34
XENOS_TEXFMT_8_8_8_8 = 6
SYSTEMFONT_CRP_XOR = 0xF1
XWB_MAGIC_BE = b"DNBW"
XWB_MAGIC_LE = b"WBND"
XSB_MAGIC_BE = b"KBDS"
XSB_MAGIC_LE = b"SDBK"
WAVEBANK_FLAGS_COMPACT = 0x00020000
XENOS_ENDIAN_NAMES = {0: "none", 1: "8in16", 2: "8in32", 3: "16in32"}
XENOS_TEXTURE_FORMAT_NAMES = {
    0: "1_REVERSE", 1: "1", 2: "8", 3: "1_5_5_5", 4: "5_6_5", 5: "6_5_5",
    6: "8_8_8_8", 7: "2_10_10_10", 8: "8_A", 9: "8_B", 10: "8_8",
    18: "DXT1", 19: "DXT2_3", 20: "DXT4_5", 49: "DXN", 60: "CTX1",
}

SIIG_SCRIPT_OPCODE_NAMES: tuple[Optional[str], ...] = (
    'CLASSIC_INVADER',  # 0x00
    'CLASSIC_UFO',  # 0x01
    'NORMAL_INVADER',  # 0x02
    'BARRIER_INVADER',  # 0x03
    'TURN_INVADER',  # 0x04
    'SIDE_INVADER',  # 0x05
    'GAMMA_INVADER',  # 0x06
    'V_INVADER',  # 0x07
    'STRAIGHT_INVADER',  # 0x08
    'S_LASER_INVADER',  # 0x09
    'WARP_INVADER',  # 0x0A
    'TELEPORTER',  # 0x0B
    None,  # 0x0C
    'ALARM_UFO',  # 0x0D
    'SCRATCHER',  # 0x0E
    'ASSAILANT',  # 0x0F
    'LINER',  # 0x10
    'FORTRESS',  # 0x11
    'FORTRESS2',  # 0x12
    'CRAWLER',  # 0x13
    'SWINDLER',  # 0x14
    'CUTTLEFISH',  # 0x15
    'HATCH',  # 0x16
    'SCRAMBLE_INVADER',  # 0x17
    'TENTACLE',  # 0x18
    'SHADOW',  # 0x19
    'REVOLVER1',  # 0x1A
    'REVOLVER2',  # 0x1B
    'ATTACKER',  # 0x1C
    'STORMER',  # 0x1D
    'CONSPIRATOR',  # 0x1E
    'CONSPIRATOR2',  # 0x1F
    None,  # 0x20
    'EXPANDER',  # 0x21
    'SPRINKLER',  # 0x22
    None,  # 0x23
    'ELEMENT1',  # 0x24
    'ELEMENT2',  # 0x25
    'ELEMENT3',  # 0x26
    'SLUGGARD',  # 0x27
    'GUSHER',  # 0x28
    'PRIDE',  # 0x29
    'SLOTH',  # 0x2A
    'KEEPER',  # 0x2B
    'OPPRESSOR',  # 0x2C
    None,  # 0x2D
    None,  # 0x2E
    None,  # 0x2F
    None,  # 0x30
    None,  # 0x31
    'DIFFUSER',  # 0x32
    'DIFFUSER2',  # 0x33
    None,  # 0x34
    'SATORU_UFO',  # 0x35
    'SPIDER',  # 0x36
    'JOLYNE',  # 0x37
    'VANITY',  # 0x38
    None,  # 0x39
    None,  # 0x3A
    None,  # 0x3B
    None,  # 0x3C
    None,  # 0x3D
    None,  # 0x3E
    None,  # 0x3F
    None,  # 0x40
    None,  # 0x41
    None,  # 0x42
    None,  # 0x43
    None,  # 0x44
    None,  # 0x45
    'THE_MOON',  # 0x46
    'THE_SUN',  # 0x47
    'GIGANTIC_UFO',  # 0x48
    'LADYBUG',  # 0x49
    'MANDALA',  # 0x4A
    'UNKNOWN',  # 0x4B
    None,  # 0x4C
    None,  # 0x4D
    None,  # 0x4E
    None,  # 0x4F
    None,  # 0x50
    None,  # 0x51
    None,  # 0x52
    None,  # 0x53
    None,  # 0x54
    None,  # 0x55
    None,  # 0x56
    None,  # 0x57
    None,  # 0x58
    None,  # 0x59
    'SHUTTER1',  # 0x5A
    'SHUTTER2',  # 0x5B
    'SHUTTER3',  # 0x5C
    'SHUTTER_KEY',  # 0x5D
    'CONTAINER',  # 0x5E
    'PIPE_LINE',  # 0x5F
    None,  # 0x60
    None,  # 0x61
    None,  # 0x62
    None,  # 0x63
    None,  # 0x64
    None,  # 0x65
    None,  # 0x66
    None,  # 0x67
    None,  # 0x68
    None,  # 0x69
    None,  # 0x6A
    None,  # 0x6B
    None,  # 0x6C
    None,  # 0x6D
    'SCROLL_01',  # 0x6E
    'SCROLL_02',  # 0x6F
    'SCROLL_03',  # 0x70
    'DEL_ZAKO',  # 0x71
    'DEL_M_BOSS',  # 0x72
    'DEL_L_BOSS',  # 0x73
    'DEL_ALL_ENEMY',  # 0x74
    'DEL_ALL_ENEMY_SHOT',  # 0x75
    'EMERGENCY',  # 0x76
    'EMERGENCY_END',  # 0x77
    'WARNING',  # 0x78
    'BACKGROUND_01',  # 0x79
    'BACKGROUND_02',  # 0x7A
    'BACKGROUND_03',  # 0x7B
    'BACKGROUND_04',  # 0x7C
    'BACKGROUND_05',  # 0x7D
    'BACKGROUND_06',  # 0x7E
    'BACKGROUND_07',  # 0x7F
    'BACKGROUND_GRADATION',  # 0x80
    'ENEMY_APPEAR_CONTINUOUSLY',  # 0x81
    'BOSS_RUSH',  # 0x82
    'BOSS_RUSH_END',  # 0x83
    'BACKGROUND_08',  # 0x84
    'BACKGROUND_11',  # 0x85
    'BACKGROUND_12',  # 0x86
    'BACKGROUND_13',  # 0x87
    'BACKGROUND_14',  # 0x88
    'BACKGROUND_15',  # 0x89
    'BACKGROUND_16',  # 0x8A
    'BACKGROUND_17',  # 0x8B
    'BACKGROUND_18',  # 0x8C
    'BACKGROUND_GRADATION_END',  # 0x8D
    'SCRIPT LOOP',  # 0x8E
    'NONE_COMMAND',  # 0x8F
    None,  # 0x90
    None,  # 0x91
    None,  # 0x92
    None,  # 0x93
    None,  # 0x94
    None,  # 0x95
    'CIRCLE_INVADER',  # 0x96
    None,  # 0x97
    None,  # 0x98
    'GREED',  # 0x99
    'LINE_INVADER',  # 0x9A
    'WRATH',  # 0x9B
    'GLUTTONY',  # 0x9C
    None,  # 0x9D
    'SG_GIGANTIC_UFO',  # 0x9E
    None,  # 0x9F
    'CENTIPEDE',  # 0xA0
    'HONET',  # 0xA1
    'PROGRESSIVE_UFO',  # 0xA2
    'OCTOPUS',  # 0xA3
    'BUTTERFLY',  # 0xA4
    None,  # 0xA5
    'WATER_STRIDER',  # 0xA6
    None,  # 0xA7
    'ULTIMATE_UFO',  # 0xA8
    'SQUID',  # 0xA9
    'VERTEBRATE',  # 0xAA
    'NO_NAME',  # 0xAB
    None,  # 0xAC
    None,  # 0xAD
    None,  # 0xAE
    None,  # 0xAF
    None,  # 0xB0
    None,  # 0xB1
    None,  # 0xB2
    None,  # 0xB3
    '3D Back Scroll',  # 0xB4
    '3D Wall Scroll',  # 0xB5
    '3D Back Color',  # 0xB6
    '3D Camera Change 01',  # 0xB7
    '3D Camera Change 02',  # 0xB8
    '3D Demo',  # 0xB9
    'DEL_LV4_BOSS',  # 0xBA
    'DEL_LV5_BOSS',  # 0xBB
    '3D Back Animation',  # 0xBC
    '3D Back Rotate',  # 0xBD
    '3D Field Rotate Control',  # 0xBE
    None,  # 0xBF
    None,  # 0xC0
    None,  # 0xC1
    None,  # 0xC2
    None,  # 0xC3
    None,  # 0xC4
    None,  # 0xC5
    None,  # 0xC6
    None,  # 0xC7
    'VL_START',  # 0xC8
    'VL_END',  # 0xC9
    'VL_DISP_ON',  # 0xCA
    'VL_DISP_OFF',  # 0xCB
    'VL_SEQUENCESET',  # 0xCC
    'VL_CHANGETIME',  # 0xCD
    'VL_VOLUME_SCALE',  # 0xCE
)



class FormatError(ValueError):
    pass


def be_u16(data: bytes, off: int) -> int:
    if off < 0 or off + 2 > len(data):
        raise FormatError(f"u16 read outside file at 0x{off:X}")
    return struct.unpack_from(">H", data, off)[0]


def be_u32(data: bytes, off: int) -> int:
    if off < 0 or off + 4 > len(data):
        raise FormatError(f"u32 read outside file at 0x{off:X}")
    return struct.unpack_from(">I", data, off)[0]


def read_c_string(data: bytes, off: int, max_len: int = 4096) -> str:
    if off <= 0 or off >= len(data):
        return ""
    end_limit = min(len(data), off + max_len)
    end = data.find(b"\0", off, end_limit)
    if end < 0:
        raise FormatError(f"unterminated string at 0x{off:X}")
    raw = data[off:end]
    return raw.decode("utf-8", errors="replace")


def safe_relative_path(name: str, fallback: str) -> Path:
    # Preserve legitimate archive subdirectories (notably sound/se and sound/bgm)
    # while preventing absolute paths and traversal outside the output folder.
    raw_parts = name.replace("\\", "/").split("/") if name else []
    parts: list[str] = []
    for raw in raw_parts:
        part = raw.strip()
        if part in {"", ".", ".."}:
            continue
        part = re.sub(r"[\x00-\x1F<>:\"|?*]", "_", part)[:120]
        if part:
            parts.append(part)
    if not parts:
        parts = [fallback]
    return Path(*parts)


def privacy_safe_path(value: object) -> str:
    """Return a metadata-safe filename without parent directories."""
    text = str(value or "").strip()
    if not text:
        return ""
    normalized = text.replace("\\", "/")
    return normalized.rstrip("/").rsplit("/", 1)[-1]


def privacy_safe_source_label(value: object) -> str:
    """Keep archive-entry suffixes while removing the local filesystem route."""
    text = str(value or "").strip()
    if not text:
        return ""
    normalized = text.replace("\\", "/")
    # Nested archive labels use :<entry index>. Preserve those suffixes, while
    # not treating the drive colon in C:/... as an archive suffix.
    match = re.search(r"(?::\d+)+$", normalized)
    suffix = match.group(0) if match else ""
    base_text = normalized[: -len(suffix)] if suffix else normalized
    return base_text.rstrip("/").rsplit("/", 1)[-1] + suffix


def scrub_private_text(value: object) -> str:
    """Redact absolute routes embedded in diagnostic text."""
    text = str(value or "")
    # Windows absolute paths.
    text = re.sub(
        r"(?i)(?<![A-Za-z0-9_])[A-Z]:[\\/](?:[^\r\n<>:\"|?*]+[\\/])*[^\r\n<>:\"|?*]*",
        lambda m: privacy_safe_path(m.group(0)) or "<redacted>",
        text,
    )
    # POSIX absolute paths. Limit matching to path-like strings with at least
    # two components to avoid altering game-internal names such as /sound.bin.
    text = re.sub(
        r"(?<![A-Za-z0-9_])/(?:[^/\s:]+/)+[^/\s:]*",
        lambda m: privacy_safe_path(m.group(0)) or "<redacted>",
        text,
    )
    return text


def sanitize_json_value(value: object, key: str = "") -> object:
    """Recursively remove absolute filesystem routes from JSON-compatible data."""
    path_keys = {
        "source", "source_file", "source_path", "file", "path", "input",
        "output", "gltf", "ffmpeg", "xma_file", "wav_file", "destination",
    }
    if isinstance(value, dict):
        return {str(k): sanitize_json_value(v, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [sanitize_json_value(item, key) for item in value]
    if isinstance(value, tuple):
        return [sanitize_json_value(item, key) for item in value]
    if isinstance(value, str):
        normalized = value.replace("\\", "/")
        is_absolute = normalized.startswith("/") or bool(re.match(r"(?i)^[A-Z]:/", normalized))
        if key.lower() in path_keys and is_absolute:
            return privacy_safe_path(value)
        return scrub_private_text(value)
    return value


def write_json_private(path: Path, value: object, *, ensure_ascii: bool = True) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(sanitize_json_value(value), ensure_ascii=ensure_ascii, indent=2),
        encoding="utf-8",
    )


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem, suffix = path.stem, path.suffix
    for n in range(1, 100000):
        candidate = path.with_name(f"{stem}_{n}{suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"could not find unique output name for {path}")


def rotl32(value: int, count: int) -> int:
    count &= 31
    value &= 0xFFFFFFFF
    if count == 0:
        return value
    return ((value << count) | (value >> (32 - count))) & 0xFFFFFFFF


def _s8(value: int) -> int:
    return value - 256 if value & 0x80 else value


def bbx_name_hash(name: str | bytes, seed: int = 0) -> int:
    """Reimplementation of default.xex Function_824739D0.

    BBX filenames in this title are ASCII. Passing bytes preserves arbitrary byte names.
    """
    raw = name.encode("utf-8") if isinstance(name, str) else bytes(name)
    result = 0
    running_sum = 0
    seed &= 0xFFFFFFFF

    for byte in raw:
        signed_byte = _s8(byte)
        running_sum = (running_sum + signed_byte) & 0xFFFFFFFF
        shift = running_sum & 31

        left = ((signed_byte & 0xFFFFFFFF) << shift) & 0xFFFFFFFF
        right_count = 32 - shift
        if right_count >= 32:
            shifted = -1 if signed_byte < 0 else 0
        else:
            shifted = signed_byte >> right_count

        # The PPC code sign-extends the low byte after the right shift.
        low = shifted & 0xFF
        sign_extended_low = _s8(low) & 0xFFFFFFFF
        rotated_seed = rotl32(seed, byte & 31)
        result = (result + rotated_seed + (left | sign_extended_low)) & 0xFFFFFFFF

    return result


@dataclass
class BBXEntry:
    index: int
    data_offset: int
    data_size: int
    name_offset: int
    identifier: int
    name: str
    hash_matches: Optional[bool]


@dataclass
class BBXArchive:
    data: bytes
    count: int
    mode: int
    hash_seed: int
    entries: list[BBXEntry]
    sorted_index: list[tuple[int, int]]

    @classmethod
    def parse(cls, data: bytes) -> "BBXArchive":
        if len(data) < 0x20:
            raise FormatError("file is too small for a BBX header")
        if data[:4] != BBX_MAGIC:
            raise FormatError(f"bad BBX magic: {data[:4].hex(' ')}")

        count = be_u32(data, 0x04)
        mode = be_u32(data, 0x08)
        hash_seed = be_u32(data, 0x0C)
        table_end = 0x20 + count * 0x10
        if table_end > len(data):
            raise FormatError(
                f"BBX entry table exceeds file: count={count}, end=0x{table_end:X}, size=0x{len(data):X}"
            )

        entries: list[BBXEntry] = []
        for index in range(count):
            rec = 0x20 + index * 0x10
            data_offset, data_size, name_offset, identifier = struct.unpack_from(">4I", data, rec)
            if data_offset > len(data) or data_size > len(data) - data_offset:
                raise FormatError(
                    f"entry {index}: payload outside file (offset=0x{data_offset:X}, size=0x{data_size:X})"
                )
            name = read_c_string(data, name_offset) if name_offset else ""
            match = None if not name else bbx_name_hash(name, hash_seed) == identifier
            entries.append(
                BBXEntry(index, data_offset, data_size, name_offset, identifier, name, match)
            )

        # The executable uses a sorted {hash,index} table for modes 0 and 1.
        sorted_index: list[tuple[int, int]] = []
        if mode < 2:
            index_end = table_end + count * 8
            if index_end <= len(data):
                for i in range(count):
                    h, resource_index = struct.unpack_from(">2I", data, table_end + i * 8)
                    if resource_index >= count:
                        # Avoid treating payload bytes as a table in malformed/unusual files.
                        sorted_index = []
                        break
                    sorted_index.append((h, resource_index))

        return cls(data, count, mode, hash_seed, entries, sorted_index)

    def payload(self, entry: BBXEntry) -> bytes:
        return self.data[entry.data_offset : entry.data_offset + entry.data_size]


def maybe_decompress(data: bytes) -> bytes:
    if data[:2] == b"\x1F\x8B":
        return gzip.decompress(data)
    return data


def xor_systemfont_crp(data: bytes) -> bytes:
    """Decrypt the systemfont.crp payload used by SIIG.

    default.xex Function_8215B010 XORs every byte with 0xF1 before
    passing the result to the normal Xbox 360 texture loader.
    """
    return bytes(byte ^ SYSTEMFONT_CRP_XOR for byte in data)


def looks_like_tex(data: bytes) -> bool:
    if len(data) < TEX_HEADER_SIZE:
        return False
    try:
        words = struct.unpack_from(">13I", data, 0)
    except struct.error:
        return False
    # All SIIG TEX samples are a 0x1C-byte D3D resource header followed by a
    # six-dword Xenos texture fetch constant and pixel data.
    if words[:5] != (3, 1, 0, 0, 0):
        return False
    fetch0, fetch1, fetch2 = words[7], words[8], words[9]
    width = (fetch2 & 0x1FFF) + 1
    height = ((fetch2 >> 13) & 0x1FFF) + 1
    fmt = fetch1 & 0x3F
    return (fetch0 & 3) == 2 and 0 < width <= 8192 and 0 < height <= 8192 and fmt < 64


def looks_like_ps3_tex(data: bytes) -> bool:
    """Recognize SIIG's PS3 RSX texture wrapper.

    The PS3 build stores a 0x80-byte header followed by linear A8R8G8B8
    pixels. Width and height are big-endian 16-bit values at 0x20/0x22.
    """
    if len(data) < 0x80 or data[:4] != b"\x02\x00\x00\xFF":
        return False
    try:
        data_offset = be_u32(data, 0x10)
        payload_size = be_u32(data, 0x14)
        width = be_u16(data, 0x20)
        height = be_u16(data, 0x22)
    except FormatError:
        return False
    if data_offset != 0x80 or not (0 < width <= 8192 and 0 < height <= 8192):
        return False
    expected = width * height * 4
    return payload_size >= expected and data_offset + expected <= len(data)


def looks_like_any_tex(data: bytes) -> bool:
    return looks_like_tex(data) or looks_like_ps3_tex(data)


def looks_like_systemfont_crp(data: bytes) -> bool:
    if len(data) < TEX_HEADER_SIZE:
        return False
    decrypted_header = bytes(byte ^ SYSTEMFONT_CRP_XOR for byte in data[:0x80])
    return looks_like_any_tex(decrypted_header)


def sniff_extension(payload: bytes) -> str:
    if payload.startswith(GMX_MAGIC):
        return ".gmx"
    if payload.startswith(MAP_MAGIC):
        return ".map"
    if payload.startswith(BBX_MAGIC):
        return ".bbx"
    if payload.startswith(b"RIFF"):
        return ".riff"
    if payload.startswith(b"FSGX"):
        return ".fsgx"
    if payload.startswith((XWB_MAGIC_BE, XWB_MAGIC_LE)):
        return ".xwb"
    if payload.startswith((XSB_MAGIC_BE, XSB_MAGIC_LE)):
        return ".xsb"
    if looks_like_any_tex(payload):
        return ".tex"
    if b"klBS" in payload[:0x40]:
        return ".bnk"
    if looks_like_systemfont_crp(payload):
        return ".crp"
    return ".bin"


def extract_bbx_bytes(
    data: bytes,
    output_dir: Path,
    source_label: str,
    recursive: bool = False,
    convert_gmx: bool = False,
    convert_gltf: bool = False,
    convert_tex: bool = False,
    flip_v: bool = False,
) -> dict:
    archive = BBXArchive.parse(data)
    output_dir.mkdir(parents=True, exist_ok=True)

    manifest_rows: list[dict] = []
    nested_results: list[dict] = []
    gltf_candidates: list[Path] = []

    for entry in archive.entries:
        payload = archive.payload(entry)
        fallback = f"{entry.index:04d}_{entry.identifier:08X}{sniff_extension(payload)}"
        relative_output = safe_relative_path(entry.name, fallback)
        destination = unique_path(output_dir / relative_output)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(payload)

        row = asdict(entry)
        row.update(
            {
                "output_file": destination.relative_to(output_dir).as_posix(),
                "payload_magic": payload[:8].hex(" ").upper(),
            }
        )
        manifest_rows.append(row)

        if convert_gltf and payload.startswith(GMX_MAGIC):
            gltf_candidates.append(destination)

        if convert_gmx and payload.startswith(GMX_MAGIC):
            try:
                chunks = parse_gmx_chunks(payload)
                if any(chunk.tag == "MESH" for chunk in chunks):
                    export_gmx_obj_bytes(payload, destination.with_suffix(".obj"), flip_v=flip_v)
                else:
                    scan_meta = {
                        "source_size": len(payload),
                        "mesh_count": 0,
                        "note": "This GMX has no MESH chunks; it may be hierarchy/animation-only.",
                        "chunks": [
                            {"offset": c.offset, "tag": c.tag, "size": c.size} for c in chunks
                        ],
                    }
                    write_json_private(destination.with_suffix(".gmx.json"), scan_meta)
            except Exception as exc:
                print(f"warning: GMX conversion failed for {destination}: {exc}", file=sys.stderr)

        if convert_tex and (destination.suffix.lower() == ".tex" or looks_like_any_tex(payload)):
            try:
                export_tex_png_bytes(payload, destination.with_suffix(".png"))
            except Exception as exc:
                print(f"warning: TEX conversion failed for {destination}: {exc}", file=sys.stderr)
        elif convert_tex and (destination.suffix.lower() == ".crp" or looks_like_systemfont_crp(payload)):
            try:
                decrypted = xor_systemfont_crp(payload)
                png_path = destination.with_name(destination.stem + "_atlas.png")
                meta = export_tex_png_bytes(decrypted, png_path)
                meta.update({"source_format": "SIIG systemfont CRP", "xor_key": "0xF1"})
                write_json_private(png_path.with_suffix(png_path.suffix + ".json"), meta)
            except Exception as exc:
                print(f"warning: CRP font conversion failed for {destination}: {exc}", file=sys.stderr)

        if recursive and payload.startswith(BBX_MAGIC):
            nested_dir = output_dir / f"{destination.stem}_nested"
            nested_results.append(
                extract_bbx_bytes(
                    payload,
                    nested_dir,
                    f"{source_label}:{entry.index}",
                    recursive=True,
                    convert_gmx=convert_gmx,
                    convert_gltf=convert_gltf,
                    convert_tex=convert_tex,
                    flip_v=flip_v,
                )
            )

    # Convert GMX after all archive entries have been written so referenced DDS/TEX
    # resources in the same archive are available to the material exporter.
    for gmx_path in gltf_candidates:
        try:
            relative = gmx_path.relative_to(output_dir).with_suffix(".gltf")
            export_gmx_gltf_file(
                gmx_path,
                output_dir,
                flip_v=flip_v,
                texture_roots=(output_dir,),
                relative_path=relative,
            )
        except Exception as exc:
            print(f"warning: glTF conversion failed for {gmx_path}: {exc}", file=sys.stderr)

    manifest_csv = output_dir / "manifest.csv"
    fields = [
        "index",
        "name",
        "output_file",
        "data_offset",
        "data_size",
        "name_offset",
        "identifier",
        "hash_matches",
        "payload_magic",
    ]
    with manifest_csv.open("w", newline="", encoding="utf-8") as fp:
        writer = csv.DictWriter(fp, fieldnames=fields)
        writer.writeheader()
        for row in manifest_rows:
            writer.writerow({field: row.get(field) for field in fields})

    metadata = {
        "source": privacy_safe_source_label(source_label),
        "magic": "01 42 42 58",
        "count": archive.count,
        "mode": archive.mode,
        "hash_seed": f"0x{archive.hash_seed:08X}",
        "has_sorted_hash_index": bool(archive.sorted_index),
        "entries": manifest_rows,
        "nested": nested_results,
    }
    write_json_private(output_dir / "manifest.json", metadata)
    return metadata


def extract_bbx_file(
    path: Path,
    output_root: Path,
    recursive: bool,
    convert_gmx: bool,
    convert_gltf: bool,
    convert_tex: bool,
    flip_v: bool,
) -> dict:
    data = maybe_decompress(path.read_bytes())
    if not data.startswith(BBX_MAGIC):
        raise FormatError(f"{path}: decompressed data is not BBX")
    out = output_root / path.name
    # Strip multiple packaging suffixes for a clean output directory.
    for suffix in (".sdat", ".gz", ".bin"):
        if out.name.lower().endswith(suffix):
            out = out.with_name(out.name[: -len(suffix)])
    return extract_bbx_bytes(
        data, out, path.name, recursive, convert_gmx, convert_gltf, convert_tex, flip_v
    )



@dataclass
class XWBEntry:
    index: int
    name: str
    codec: str
    channels: int
    sample_rate: int
    bits_per_sample: int
    block_align: int
    num_samples: int
    data_offset: int
    data_size: int
    loop_begin: int
    loop_length: int
    flags: int


@dataclass
class XWBInfo:
    version: int
    endian: str
    bank_name: str
    bank_flags: int
    alignment: int
    data_offset: int
    data_size: int
    entries: list[XWBEntry]


def looks_like_xwb(data: bytes) -> bool:
    return len(data) >= 0x34 and data[:4] in (XWB_MAGIC_BE, XWB_MAGIC_LE)


def _xact_u32(data: bytes, off: int, endian: str) -> int:
    if off < 0 or off + 4 > len(data):
        raise FormatError(f"XACT u32 read outside file at 0x{off:X}")
    return struct.unpack_from(endian + "I", data, off)[0]


def _xact_s32(data: bytes, off: int, endian: str) -> int:
    if off < 0 or off + 4 > len(data):
        raise FormatError(f"XACT s32 read outside file at 0x{off:X}")
    return struct.unpack_from(endian + "i", data, off)[0]


def _printable_ascii_strings(data: bytes, min_length: int = 3) -> list[str]:
    pattern = rb"[\x20-\x7E]{" + str(min_length).encode("ascii") + rb",}"
    return [m.group().decode("ascii", errors="replace") for m in re.finditer(pattern, data)]


def parse_xsb_cue_names(data: bytes, total_waves: int, bank_name: str) -> list[str]:
    """Extract cue names from the simple XACT3 XSB banks used by SIIG.

    This game has one cue per wave. The large SE bank stores the 83 cue names
    consecutively, while the single-wave BGM banks store bank/wavebank names
    followed by the cue name.
    """
    if not data.startswith((XSB_MAGIC_BE, XSB_MAGIC_LE)):
        return []
    strings = [s for s in _printable_ascii_strings(data) if s not in {"KBDS", "SDBK"}]
    if total_waves == 1:
        return [strings[-1]] if strings else []
    if len(strings) >= total_waves:
        return strings[:total_waves]
    return strings


def parse_xwb(data: bytes, cue_names: Optional[Sequence[str]] = None) -> XWBInfo:
    """Parse standard (non-compact) XACT wave banks.

    SIIG uses big-endian XACT3 version 46 banks with standard 24-byte entries
    and XMA2 streams. Little-endian banks and the older standard segment layouts
    are accepted where their fields are compatible.
    """
    if not looks_like_xwb(data):
        raise FormatError("not an XACT XWB wave bank")
    endian = ">" if data[:4] == XWB_MAGIC_BE else "<"
    endian_name = "big" if endian == ">" else "little"
    version = _xact_u32(data, 0x04, endian)
    segment = 0x08 if version <= 41 else 0x0C

    base_offset = _xact_u32(data, segment + 0x00, endian)
    entry_offset = _xact_u32(data, segment + 0x08, endian)
    entry_segment_size = _xact_u32(data, segment + 0x0C, endian)

    if version <= 21:
        suboffset = 0x08
    elif version == 22:
        suboffset = base_offset - 0x20
    else:
        suboffset = 0x10
    data_offset = _xact_u32(data, segment + 0x10 + suboffset, endian)
    data_size = _xact_u32(data, segment + 0x14 + suboffset, endian)

    if base_offset <= 0 or base_offset + 8 > len(data):
        raise FormatError("invalid XWB bank-data segment")
    bank_flags = _xact_u32(data, base_offset + 0x00, endian)
    total = _xact_s32(data, base_offset + 0x04, endian)
    if total <= 0 or total > 100000:
        raise FormatError(f"invalid XWB stream count {total}")
    name_size = 0x10 if version <= 21 else 0x40
    raw_name = data[base_offset + 0x08 : base_offset + 0x08 + name_size]
    bank_name = raw_name.split(b"\0", 1)[0].decode("ascii", errors="replace")
    base_fields = base_offset + 0x08 + name_size
    entry_size = _xact_u32(data, base_fields + 0x00, endian)
    alignment = _xact_u32(data, base_fields + 0x08, endian)

    if bank_flags & WAVEBANK_FLAGS_COMPACT:
        raise FormatError("compact XWB entries are not supported by the built-in SIIG converter")
    if entry_size < 0x18:
        raise FormatError(f"unsupported XWB entry size 0x{entry_size:X}")
    if entry_offset + total * entry_size > len(data):
        raise FormatError("XWB entry table extends beyond the file")
    if entry_segment_size < total * entry_size:
        raise FormatError("XWB entry segment is smaller than its entry table")

    names = list(cue_names or [])
    entries: list[XWBEntry] = []
    codecs = ("PCM", "XMA2", "MS_ADPCM", "XWMA")
    for index in range(total):
        off = entry_offset + index * entry_size
        entry_info, packed_format, relative_offset, stream_size, loop_begin, loop_length = struct.unpack_from(
            endian + "6I", data, off
        )
        if version <= 41:
            raise FormatError(f"built-in audio conversion currently requires XACT3 v42+, found v{version}")
        bits_flag = (packed_format >> 31) & 1
        block_align = (packed_format >> 23) & 0xFF
        sample_rate = (packed_format >> 5) & 0x3FFFF
        channels = (packed_format >> 2) & 0x7
        tag = packed_format & 0x3
        absolute_offset = data_offset + relative_offset
        if absolute_offset > len(data) or stream_size > len(data) - absolute_offset:
            raise FormatError(f"XWB stream {index} extends beyond the file")
        fallback = f"{bank_name or 'wave'}_{index + 1:03d}"
        name = names[index] if index < len(names) and names[index] else fallback
        entries.append(
            XWBEntry(
                index=index,
                name=name,
                codec=codecs[tag],
                channels=channels,
                sample_rate=sample_rate,
                bits_per_sample=8 if bits_flag == 0 else 16,
                block_align=block_align,
                num_samples=entry_info >> 4,
                data_offset=absolute_offset,
                data_size=stream_size,
                loop_begin=loop_begin,
                loop_length=loop_length,
                flags=entry_info & 0xF,
            )
        )
    return XWBInfo(version, endian_name, bank_name, bank_flags, alignment, data_offset, data_size, entries)


def _xma_channel_mask(channels: int) -> int:
    return {1: 0x4, 2: 0x3, 3: 0x7, 4: 0x33, 5: 0x37, 6: 0x3F}.get(
        channels, (1 << channels) - 1
    )


def build_xma2_riff(raw_xma: bytes, entry: XWBEntry) -> bytes:
    """Wrap one raw XACT XMA2 stream in a standard RIFF/WAVE header."""
    if entry.codec != "XMA2":
        raise FormatError(f"RIFF wrapper requested for non-XMA2 codec {entry.codec}")
    if entry.channels <= 0 or entry.sample_rate <= 0:
        raise FormatError("invalid XMA2 channel count or sample rate")
    bytes_per_block = 0x10000
    block_count = max(1, (len(raw_xma) + bytes_per_block - 1) // bytes_per_block)
    avg_bytes_per_sec = max(1, round(len(raw_xma) * entry.sample_rate / max(1, entry.num_samples)))
    wave_format = struct.pack(
        "<HHIIHHH",
        0x0166,
        entry.channels,
        entry.sample_rate,
        avg_bytes_per_sec,
        entry.channels * 2,
        16,
        34,
    )
    extra = struct.pack(
        "<HIIIIIIIBBH",
        (entry.channels + 1) // 2,
        _xma_channel_mask(entry.channels),
        entry.num_samples,
        bytes_per_block,
        0,
        entry.num_samples,
        entry.loop_begin,
        entry.loop_length,
        255 if entry.loop_length else 0,
        4,
        block_count,
    )
    fmt_payload = wave_format + extra
    body = (
        b"WAVE"
        + b"fmt "
        + struct.pack("<I", len(fmt_payload))
        + fmt_payload
        + b"data"
        + struct.pack("<I", len(raw_xma))
        + raw_xma
    )
    return b"RIFF" + struct.pack("<I", len(body)) + body


def _safe_audio_name(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._")
    return cleaned or "stream"


def export_xwb_audio_bytes(
    xwb_data: bytes,
    output_dir: Path,
    source_label: str,
    xsb_data: Optional[bytes] = None,
    ffmpeg_path: Optional[str] = None,
    keep_xma: bool = False,
) -> dict:
    preliminary = parse_xwb(xwb_data)
    cue_names = parse_xsb_cue_names(xsb_data or b"", len(preliminary.entries), preliminary.bank_name)
    info = parse_xwb(xwb_data, cue_names)
    output_dir.mkdir(parents=True, exist_ok=True)
    ffmpeg = ffmpeg_path or shutil.which("ffmpeg")
    rows: list[dict] = []
    decode_failures = 0

    for entry in info.entries:
        raw = xwb_data[entry.data_offset : entry.data_offset + entry.data_size]
        stem = f"{entry.index + 1:03d}_{_safe_audio_name(entry.name)}"
        encoded_path = output_dir / f"{stem}.xma"
        wav_path = output_dir / f"{stem}.wav"
        decoded = False
        error = ""
        if entry.codec == "XMA2":
            encoded_path.write_bytes(build_xma2_riff(raw, entry))
            if ffmpeg:
                result = subprocess.run(
                    [
                        ffmpeg,
                        "-y",
                        "-hide_banner",
                        "-loglevel",
                        "error",
                        "-i",
                        str(encoded_path),
                        "-c:a",
                        "pcm_s16le",
                        str(wav_path),
                    ],
                    capture_output=True,
                    text=True,
                )
                decoded = result.returncode == 0 and wav_path.exists()
                if not decoded:
                    decode_failures += 1
                    error = result.stderr.strip()[-1000:]
                elif not keep_xma:
                    encoded_path.unlink(missing_ok=True)
        else:
            error = f"built-in converter does not yet handle {entry.codec}"
            decode_failures += 1

        row = asdict(entry)
        row.update(
            {
                "xma_file": encoded_path.name if encoded_path.exists() else "",
                "wav_file": wav_path.name if wav_path.exists() else "",
                "decoded": decoded,
                "error": error,
            }
        )
        rows.append(row)

    manifest = {
        "source": privacy_safe_source_label(source_label),
        "format": "XACT XWB",
        "version": info.version,
        "endian": info.endian,
        "bank_name": info.bank_name,
        "bank_flags": f"0x{info.bank_flags:08X}",
        "alignment": info.alignment,
        "stream_count": len(info.entries),
        "ffmpeg": privacy_safe_path(ffmpeg) if ffmpeg else None,
        "decode_failures": decode_failures,
        "entries": rows,
    }
    write_json_private(output_dir / "xwb_manifest.json", manifest)
    if rows:
        with (output_dir / "xwb_manifest.csv").open("w", newline="", encoding="utf-8") as fp:
            writer = csv.DictWriter(fp, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    return manifest


def _collect_xact_from_bbx(data: bytes, prefix: Path = Path()) -> dict[str, bytes]:
    archive = BBXArchive.parse(data)
    collected: dict[str, bytes] = {}
    for entry in archive.entries:
        payload = archive.payload(entry)
        fallback = f"{entry.index:04d}_{entry.identifier:08X}{sniff_extension(payload)}"
        rel = prefix / safe_relative_path(entry.name, fallback)
        if payload.startswith(BBX_MAGIC):
            collected.update(_collect_xact_from_bbx(payload, prefix / f"{rel.stem}_nested"))
        elif payload.startswith((XWB_MAGIC_BE, XWB_MAGIC_LE)) or rel.suffix.lower() == ".xwb":
            collected[rel.as_posix()] = payload
        elif payload.startswith((XSB_MAGIC_BE, XSB_MAGIC_LE)) or rel.suffix.lower() == ".xsb":
            collected[rel.as_posix()] = payload
    return collected


def _decode_xact_collection(
    files: dict[str, bytes], output_root: Path, source_label: str, ffmpeg_path: Optional[str], keep_xma: bool
) -> tuple[int, int]:
    success = 0
    failures = 0
    lower_lookup = {name.lower(): data for name, data in files.items()}
    for name, data in sorted(files.items()):
        if not name.lower().endswith(".xwb") and not looks_like_xwb(data):
            continue
        rel = Path(name)
        xsb_name = rel.with_suffix(".xsb").as_posix().lower()
        xsb_data = lower_lookup.get(xsb_name)
        target = output_root / rel.parent / rel.stem
        try:
            result = export_xwb_audio_bytes(
                data, target, f"{source_label}:{name}", xsb_data=xsb_data, ffmpeg_path=ffmpeg_path, keep_xma=keep_xma
            )
            print(
                f"{name}: {result['stream_count']} stream(s), "
                f"{result['decode_failures']} decode failure(s) -> {target}"
            )
            success += result["stream_count"] - result["decode_failures"]
            failures += result["decode_failures"]
        except Exception as exc:
            failures += 1
            print(f"ERROR {name}: {exc}", file=sys.stderr)
    return success, failures


def command_xact2wav(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    ffmpeg_path = args.ffmpeg or shutil.which("ffmpeg")
    if args.ffmpeg and not Path(args.ffmpeg).exists() and not shutil.which(args.ffmpeg):
        raise FormatError(f"FFmpeg executable not found: {args.ffmpeg}")

    if input_path.is_file():
        data = maybe_decompress(input_path.read_bytes())
        if data.startswith(BBX_MAGIC):
            files = _collect_xact_from_bbx(data)
            success, failures = _decode_xact_collection(
                files, output, str(input_path), ffmpeg_path, args.keep_xma
            )
        elif looks_like_xwb(data):
            xsb_path = input_path.with_suffix(".xsb")
            xsb_data = xsb_path.read_bytes() if xsb_path.exists() else None
            result = export_xwb_audio_bytes(
                data, output / input_path.stem, str(input_path), xsb_data, ffmpeg_path, args.keep_xma
            )
            success = result["stream_count"] - result["decode_failures"]
            failures = result["decode_failures"]
        else:
            raise FormatError("input is not sound.bin/BBX or an XWB wave bank")
    elif input_path.is_dir():
        files: dict[str, bytes] = {}
        for path in input_path.rglob("*"):
            if not path.is_file():
                continue
            try:
                head = path.read_bytes()[:4]
            except OSError:
                continue
            if path.suffix.lower() in {".xwb", ".xsb"} or head in (XWB_MAGIC_BE, XWB_MAGIC_LE, XSB_MAGIC_BE, XSB_MAGIC_LE):
                files[path.relative_to(input_path).as_posix()] = path.read_bytes()
        success, failures = _decode_xact_collection(
            files, output, str(input_path), ffmpeg_path, args.keep_xma
        )
    else:
        raise FileNotFoundError(input_path)

    if not ffmpeg_path:
        print(
            "FFmpeg was not found. RIFF-wrapped .xma files were written, but WAV decoding was skipped. "
            "Install FFmpeg or use vgmstream-cli to convert them.",
            file=sys.stderr,
        )
    print(f"completed: {success} decoded stream(s), {failures} failure(s)")
    return 1 if failures and not success else 0


@dataclass
class TEXInfo:
    width: int
    height: int
    physical_pitch: int
    format: int
    format_name: str
    endianness: int
    endianness_name: str
    tiled: bool
    swizzle: tuple[int, int, int, int]
    payload_size: int
    fetch_dwords: tuple[int, int, int, int, int, int]


def parse_tex(data: bytes) -> TEXInfo:
    if not looks_like_tex(data):
        raise FormatError("not a recognized SIIG Xbox 360 TEX file")
    words = struct.unpack_from(">13I", data, 0)
    fetch = words[7:13]
    d0, d1, d2, d3, _d4, _d5 = fetch
    width = (d2 & 0x1FFF) + 1
    height = ((d2 >> 13) & 0x1FFF) + 1
    pitch_units = (d0 >> 22) & 0x1FF
    physical_pitch = pitch_units * 32 if pitch_units else ((width + 31) & ~31)
    fmt = d1 & 0x3F
    endian = (d1 >> 6) & 3
    swizzle_word = (d3 >> 1) & 0xFFF
    swizzle = tuple((swizzle_word >> (component * 3)) & 7 for component in range(4))
    return TEXInfo(
        width=width,
        height=height,
        physical_pitch=physical_pitch,
        format=fmt,
        format_name=XENOS_TEXTURE_FORMAT_NAMES.get(fmt, f"unknown_{fmt}"),
        endianness=endian,
        endianness_name=XENOS_ENDIAN_NAMES.get(endian, f"unknown_{endian}"),
        tiled=bool(d0 >> 31),
        swizzle=swizzle,  # type: ignore[arg-type]
        payload_size=len(data) - TEX_HEADER_SIZE,
        fetch_dwords=fetch,  # type: ignore[arg-type]
    )


# Source attribution: independently translated/adapted from the Xenia project
# Xenos tiled-texture addressing implementation (BSD-3-Clause). See
# LICENSES/XENIA-BSD-3-CLAUSE.txt, THIRD_PARTY_NOTICES.md, and PROVENANCE.json.
def xg_address_2d_tiled_offset(x: int, y: int, width: int, texel_pitch: int) -> int:
    """Return the Xenos byte address of one 2D tiled texel/block.

    This follows Xenia's current bit-decomposed texture-address implementation.
    The older commonly copied XGAddress2DTiledOffset formula omits the Y[3]
    XOR in the pipe selector, which produces the characteristic 8-row
    jitter/scrambling seen in the first toolkit build.

    ``width`` is the physical pitch in texels/blocks and must be 32-aligned.
    ``texel_pitch`` is the byte size of one texel/block and must be a power of 2.
    """
    aligned_width = (width + 31) & ~31
    if texel_pitch <= 0 or texel_pitch & (texel_pitch - 1):
        raise FormatError(f"invalid tiled texel pitch {texel_pitch}")
    bytes_per_block_log2 = texel_pitch.bit_length() - 1

    # Macro-tile origin and 8x16 micro-tile offset, measured in blocks.
    outer_blocks = (
        ((y >> 5) * (aligned_width >> 5) + (x >> 5)) << 6
    )
    inner_blocks = (((y >> 1) & 0b111) << 3) | (x & 0b111)
    outer_inner_bytes = (outer_blocks | inner_blocks) << bytes_per_block_log2

    # Xenos bank/pipe selection. The Y[3] XOR is essential.
    bank = (y >> 4) & 0b1
    pipe = ((x >> 3) & 0b11) ^ (((y >> 3) & 0b1) << 1)
    y_lsb = y & 0b1

    return (
        (y_lsb << 4)
        | (pipe << 6)
        | (bank << 11)
        | (outer_inner_bytes & 0x0F)
        | (((outer_inner_bytes >> 4) & 0x01) << 5)
        | (((outer_inner_bytes >> 5) & 0x07) << 8)
        | ((outer_inner_bytes >> 8) << 12)
    )


@lru_cache(maxsize=4)
def _xg_tiled_offset_table(width: int, height: int, physical_pitch: int, texel_pitch: int) -> array:
    # Compact 32-bit table; caching is especially valuable here because SIIG has
    # many textures with identical 1152x1152 layouts.
    offsets = array("I")
    append = offsets.append
    for y in range(height):
        for x in range(width):
            append(xg_address_2d_tiled_offset(x, y, physical_pitch, texel_pitch))
    return offsets


def _apply_xenos_endian(pixel: bytes, endian: int) -> bytes:
    if len(pixel) != 4:
        raise FormatError("truncated 32-bit TEX pixel")
    if endian == 0:
        return pixel
    if endian == 1:  # 8-in-16
        return bytes((pixel[1], pixel[0], pixel[3], pixel[2]))
    if endian == 2:  # 8-in-32
        return pixel[::-1]
    if endian == 3:  # 16-in-32
        return bytes((pixel[2], pixel[3], pixel[0], pixel[1]))
    raise FormatError(f"unsupported Xenos endian mode {endian}")


def _apply_xenos_swizzle(components: bytes, swizzle: tuple[int, int, int, int]) -> bytes:
    out = bytearray(4)
    for i, selector in enumerate(swizzle):
        if selector < 4:
            out[i] = components[selector]
        elif selector == 4:
            out[i] = 0
        elif selector == 5:
            out[i] = 255
        else:
            raise FormatError(f"unsupported Xenos swizzle selector {selector}")
    return bytes(out)


def decode_tex_rgba(data: bytes) -> tuple[TEXInfo, bytes]:
    info = parse_tex(data)
    if info.format != XENOS_TEXFMT_8_8_8_8:
        raise FormatError(
            f"TEX PNG conversion currently supports 8_8_8_8 (6), got {info.format_name} ({info.format})"
        )
    payload = data[TEX_HEADER_SIZE:]
    width = info.width
    height = info.height
    physical_pitch = info.physical_pitch
    rgba = bytearray(width * height * 4)

    # This is the exact combination used by every SIIG TEX sample examined:
    # k8in32 plus Z,Y,X,W swizzle. Keep a specialized path because the game has
    # many 1152x1152 images and avoiding per-pixel temporary objects is much faster.
    common_layout = info.endianness == 2 and info.swizzle == (2, 1, 0, 3)
    tiled = info.tiled
    payload_len = len(payload)
    if tiled:
        source_offsets: Iterable[int] = _xg_tiled_offset_table(width, height, physical_pitch, 4)
    else:
        source_offsets = (
            (y * physical_pitch + x) * 4 for y in range(height) for x in range(width)
        )
    target = 0
    for pixel_number, source in enumerate(source_offsets):
        if source + 4 > payload_len:
            x = pixel_number % width
            y = pixel_number // width
            raise FormatError(
                f"TEX pixel ({x},{y}) maps beyond payload at 0x{source:X} "
                f"(payload 0x{payload_len:X})"
            )
        if common_layout:
            # Raw GPU bytes ABCD -> k8in32 DCBA -> ZYXW swizzle BCDA.
            rgba[target] = payload[source + 1]
            rgba[target + 1] = payload[source + 2]
            rgba[target + 2] = payload[source + 3]
            rgba[target + 3] = payload[source]
        else:
            components = _apply_xenos_endian(payload[source : source + 4], info.endianness)
            pixel = _apply_xenos_swizzle(components, info.swizzle)
            rgba[target : target + 4] = pixel
        target += 4
    return info, bytes(rgba)


@dataclass
class PS3TEXInfo:
    width: int
    height: int
    data_offset: int
    payload_size: int
    format_name: str = "RSX_A8R8G8B8_LINEAR"
    platform: str = "ps3"


def parse_ps3_tex(data: bytes) -> PS3TEXInfo:
    if not looks_like_ps3_tex(data):
        raise FormatError("not a recognized SIIG PS3 TEX file")
    return PS3TEXInfo(
        width=be_u16(data, 0x20),
        height=be_u16(data, 0x22),
        data_offset=be_u32(data, 0x10),
        payload_size=be_u32(data, 0x14),
    )


def decode_ps3_tex_rgba(data: bytes) -> tuple[PS3TEXInfo, bytes]:
    info = parse_ps3_tex(data)
    expected = info.width * info.height * 4
    raw = data[info.data_offset : info.data_offset + expected]
    if len(raw) != expected:
        raise FormatError("truncated PS3 TEX pixel payload")
    rgba = bytearray(expected)
    # RSX bytes are A,R,G,B. PNG expects R,G,B,A.
    for offset in range(0, expected, 4):
        alpha, red, green, blue = raw[offset : offset + 4]
        rgba[offset : offset + 4] = bytes((red, green, blue, alpha))
    return info, bytes(rgba)


def decode_any_tex_rgba(data: bytes):
    if looks_like_tex(data):
        info, rgba = decode_tex_rgba(data)
        metadata = asdict(info)
        metadata["platform"] = "xbox360"
        metadata["fetch_dwords"] = [f"0x{value:08X}" for value in info.fetch_dwords]
        metadata["swizzle"] = list(info.swizzle)
        return metadata, info.width, info.height, rgba
    if looks_like_ps3_tex(data):
        info, rgba = decode_ps3_tex_rgba(data)
        return asdict(info), info.width, info.height, rgba
    raise FormatError("not a recognized SIIG Xbox 360 or PS3 TEX file")


def _png_chunk(tag: bytes, payload: bytes) -> bytes:
    return struct.pack(">I", len(payload)) + tag + payload + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF)


def write_rgba_png(path: Path, width: int, height: int, rgba: bytes) -> None:
    if len(rgba) != width * height * 4:
        raise ValueError("RGBA byte count does not match dimensions")
    rows = b"".join(b"\x00" + rgba[y * width * 4 : (y + 1) * width * 4] for y in range(height))
    png = (
        b"\x89PNG\r\n\x1a\n"
        + _png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
        + _png_chunk(b"IDAT", zlib.compress(rows, 1))
        + _png_chunk(b"IEND", b"")
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(png)


def export_tex_png_bytes(data: bytes, png_path: Path) -> dict:
    metadata, width, height, rgba = decode_any_tex_rgba(data)
    write_rgba_png(png_path, width, height, rgba)
    write_json_private(png_path.with_suffix(png_path.suffix + ".json"), metadata)
    return metadata


def export_tex_file(path: Path, output_root: Path) -> dict:
    return export_tex_png_bytes(path.read_bytes(), output_root / f"{path.stem}.png")


@dataclass
class GMXChunk:
    offset: int
    tag: str
    size: int
    raw: bytes


@dataclass
class GMXArray:
    chunk: GMXChunk
    array_index: int
    flags: int
    semantic: str
    slot: int
    components: int
    gl_type: int
    count: int
    values: list[tuple[float | int, ...]]


@dataclass
class GMXMesh:
    chunk: GMXChunk
    mesh_index: int
    flags: int
    primitive_mode: int
    unknown_14: int
    index_count: int
    skin_index: int
    array_refs: list[int]


def parse_gmx_chunks(data: bytes) -> list[GMXChunk]:
    if len(data) < 0x30 or not data.startswith(GMX_MAGIC):
        raise FormatError("not a GMX file")
    root_size = be_u32(data, 0x04)
    total_size = be_u32(data, 0x0C)
    if root_size < 8 or root_size > len(data):
        raise FormatError(f"invalid GMX root size 0x{root_size:X}")
    if total_size == 0:
        total_size = len(data)
    if total_size > len(data):
        raise FormatError(f"GMX reports size 0x{total_size:X}, file is only 0x{len(data):X}")

    chunks: list[GMXChunk] = []
    pos = 0
    while pos < total_size:
        if pos + 8 > total_size:
            raise FormatError(f"truncated GMX chunk header at 0x{pos:X}")
        raw_tag = data[pos : pos + 4]
        tag = raw_tag.rstrip(b"\0").decode("ascii", errors="replace")
        size = be_u32(data, pos + 4)
        if size < 8 or pos + size > total_size:
            raise FormatError(f"invalid {tag!r} chunk size 0x{size:X} at 0x{pos:X}")
        chunks.append(GMXChunk(pos, tag, size, data[pos : pos + size]))
        pos += size
    if pos != total_size:
        raise FormatError(f"GMX chunks end at 0x{pos:X}, expected 0x{total_size:X}")
    return chunks


def parse_gmx_array(chunk: GMXChunk) -> GMXArray:
    raw = chunk.raw
    if chunk.tag != "ARRY" or len(raw) < 0x30:
        raise FormatError("invalid ARRY chunk")
    array_index = be_u16(raw, 0x08)
    flags = be_u16(raw, 0x0A)
    semantic = raw[0x10:0x20].split(b"\0", 1)[0].decode("ascii", errors="replace")
    slot = be_u32(raw, 0x20)
    components = be_u32(raw, 0x24)
    gl_type = be_u32(raw, 0x28)
    count = be_u32(raw, 0x2C)
    if components < 1 or components > 16:
        raise FormatError(f"ARRY {array_index}: implausible component count {components}")

    if gl_type == GL_FLOAT:
        scalar_size = 4
        fmt_char = "f"
    elif gl_type == GL_UNSIGNED_SHORT:
        scalar_size = 2
        fmt_char = "H"
    else:
        raise FormatError(f"ARRY {array_index}: unsupported GL type 0x{gl_type:X}")

    byte_count = count * components * scalar_size
    if 0x30 + byte_count > len(raw):
        raise FormatError(
            f"ARRY {array_index}: data exceeds chunk ({count}*{components}*{scalar_size})"
        )
    flat = struct.unpack_from(f">{count * components}{fmt_char}", raw, 0x30)
    values = [tuple(flat[i : i + components]) for i in range(0, len(flat), components)]
    return GMXArray(chunk, array_index, flags, semantic, slot, components, gl_type, count, values)


def parse_gmx_mesh(chunk: GMXChunk) -> GMXMesh:
    raw = chunk.raw
    if chunk.tag != "MESH" or len(raw) < 0x20:
        raise FormatError("invalid MESH chunk")
    mesh_index = be_u16(raw, 0x08)
    flags = be_u16(raw, 0x0A)
    primitive_mode = be_u32(raw, 0x10)
    unknown_14 = be_u32(raw, 0x14)
    index_count = be_u32(raw, 0x18)
    skin_index = be_u16(raw, 0x1C)
    ref_count = be_u16(raw, 0x1E)
    if 0x20 + ref_count * 2 > len(raw):
        raise FormatError(f"MESH {mesh_index}: reference list exceeds chunk")
    refs = list(struct.unpack_from(f">{ref_count}H", raw, 0x20)) if ref_count else []
    return GMXMesh(chunk, mesh_index, flags, primitive_mode, unknown_14, index_count, skin_index, refs)


def _array_by_semantic(arrays: Sequence[GMXArray], semantic: str) -> Optional[GMXArray]:
    for arr in arrays:
        if arr.semantic == semantic:
            return arr
    return None


def _index_array(arrays: Sequence[GMXArray]) -> Optional[GMXArray]:
    for arr in arrays:
        if arr.gl_type == GL_UNSIGNED_SHORT and arr.components == 1:
            return arr
    return None


def export_gmx_obj_bytes(data: bytes, obj_path: Path, flip_v: bool = False) -> dict:
    chunks = parse_gmx_chunks(data)
    arrays = {arr.array_index: arr for arr in (parse_gmx_array(c) for c in chunks if c.tag == "ARRY")}
    meshes = [parse_gmx_mesh(c) for c in chunks if c.tag == "MESH"]
    if not meshes:
        raise FormatError("GMX contains no MESH chunks")

    obj_path.parent.mkdir(parents=True, exist_ok=True)
    metadata: dict = {
        "source_size": len(data),
        "chunk_count": len(chunks),
        "chunk_tags": [c.tag for c in chunks],
        "mesh_count": len(meshes),
        "meshes": [],
    }

    v_base = 0
    vt_base = 0
    vn_base = 0
    lines: list[str] = [
        "# Space Invaders Infinity Gene GMX export",
        "# Geometry decoded from big-endian GMX ARRY/MESH chunks.",
    ]

    for ordinal, mesh in enumerate(meshes):
        referenced = [arrays[idx] for idx in mesh.array_refs if idx in arrays]
        pos = _array_by_semantic(referenced, "IN.position")
        normal = _array_by_semantic(referenced, "IN.normal")
        uv = _array_by_semantic(referenced, "IN.texuv")
        color = _array_by_semantic(referenced, "IN.color")
        indices = _index_array(referenced)
        if pos is None or indices is None:
            raise FormatError(
                f"MESH {mesh.mesh_index}: missing position or index array (refs={mesh.array_refs})"
            )
        if pos.components < 3:
            raise FormatError(f"MESH {mesh.mesh_index}: position array has {pos.components} components")
        if indices.count != mesh.index_count:
            raise FormatError(
                f"MESH {mesh.mesh_index}: index count mismatch {indices.count} != {mesh.index_count}"
            )

        name = f"mesh_{ordinal:03d}_{mesh.mesh_index}"
        lines.append(f"\no {name}")
        for value in pos.values:
            lines.append(f"v {value[0]:.9g} {value[1]:.9g} {value[2]:.9g}")
        if uv is not None:
            for value in uv.values:
                u = float(value[0])
                v = 1.0 - float(value[1]) if flip_v else float(value[1])
                lines.append(f"vt {u:.9g} {v:.9g}")
        if normal is not None:
            for value in normal.values:
                lines.append(f"vn {value[0]:.9g} {value[1]:.9g} {value[2]:.9g}")

        idx = [int(v[0]) for v in indices.values]
        vertex_count = pos.count
        if any(i >= vertex_count for i in idx):
            bad = max(idx)
            raise FormatError(
                f"MESH {mesh.mesh_index}: index {bad} exceeds vertex count {vertex_count}"
            )

        def vertex_ref(i: int) -> str:
            vi = v_base + i + 1
            has_uv = uv is not None and i < uv.count
            has_normal = normal is not None and i < normal.count
            if has_uv and has_normal:
                return f"{vi}/{vt_base + i + 1}/{vn_base + i + 1}"
            if has_uv:
                return f"{vi}/{vt_base + i + 1}"
            if has_normal:
                return f"{vi}//{vn_base + i + 1}"
            return str(vi)

        if mesh.primitive_mode == GL_TRIANGLES:
            if len(idx) % 3:
                raise FormatError(f"MESH {mesh.mesh_index}: triangle index count is not divisible by 3")
            for i in range(0, len(idx), 3):
                lines.append("f " + " ".join(vertex_ref(x) for x in idx[i : i + 3]))
            primitive = "triangles"
        elif mesh.primitive_mode == GL_LINES:
            if len(idx) % 2:
                raise FormatError(f"MESH {mesh.mesh_index}: line index count is not divisible by 2")
            for i in range(0, len(idx), 2):
                lines.append("l " + " ".join(str(v_base + x + 1) for x in idx[i : i + 2]))
            primitive = "lines"
        else:
            raise FormatError(
                f"MESH {mesh.mesh_index}: unsupported primitive mode 0x{mesh.primitive_mode:X}"
            )

        metadata["meshes"].append(
            {
                "mesh_index": mesh.mesh_index,
                "primitive_mode": f"0x{mesh.primitive_mode:X}",
                "primitive": primitive,
                "index_count": mesh.index_count,
                "vertex_count": pos.count,
                "array_refs": mesh.array_refs,
                "has_normals": normal is not None,
                "has_uv": uv is not None,
                "has_color": color is not None,
                "skin_index": mesh.skin_index,
            }
        )

        v_base += pos.count
        if uv is not None:
            vt_base += uv.count
        if normal is not None:
            vn_base += normal.count

    obj_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    meta_path = obj_path.with_suffix(obj_path.suffix + ".json")
    write_json_private(meta_path, metadata)
    return metadata


def export_gmx_file(path: Path, output_root: Path, flip_v: bool) -> dict:
    out = output_root / f"{path.stem}.obj"
    return export_gmx_obj_bytes(path.read_bytes(), out, flip_v=flip_v)


@dataclass
class GMXTextureRef:
    index: int
    flags: int
    name: str


@dataclass
class GMXShader:
    index: int
    flags: int
    name: str


@dataclass
class GMXMaterialParameter:
    name: str
    type_code: int
    count: int
    value: object


@dataclass
class GMXMaterial:
    index: int
    flags: int
    name: str
    shader_index: int
    parameters: list[GMXMaterialParameter]


@dataclass
class GMXParentGroup:
    parent: int
    children: list[int]


@dataclass
class GMXBone:
    index: int
    flags: int
    name: str
    matrix: tuple[float, ...]
    material_index: Optional[int]
    mesh_index: Optional[int]


@dataclass
class GMXMotion:
    index: int
    duration: float


@dataclass
class GMXAnimationTrack:
    index: int
    target_bone: int
    channel_type: int
    times: tuple[float, ...]
    matrices: list[tuple[float, ...]]


def _fixed_ascii(raw: bytes, offset: int, length: int) -> str:
    return raw[offset : offset + length].split(b"\0", 1)[0].decode("ascii", errors="replace")


def parse_gmx_texture_ref(chunk: GMXChunk) -> GMXTextureRef:
    if chunk.tag != "TXIF" or chunk.size != 0x30:
        raise FormatError("invalid TXIF chunk")
    return GMXTextureRef(be_u16(chunk.raw, 0x08), be_u16(chunk.raw, 0x0A), _fixed_ascii(chunk.raw, 0x10, 0x20))


def parse_gmx_shader(chunk: GMXChunk) -> GMXShader:
    if chunk.tag != "SHAD" or chunk.size != 0x30:
        raise FormatError("invalid SHAD chunk")
    return GMXShader(be_u16(chunk.raw, 0x08), be_u16(chunk.raw, 0x0A), _fixed_ascii(chunk.raw, 0x10, 0x20))


def parse_gmx_material(chunk: GMXChunk) -> GMXMaterial:
    if chunk.tag != "MTRL" or chunk.size < 0x38:
        raise FormatError("invalid MTRL chunk")
    index = be_u16(chunk.raw, 0x08)
    flags = be_u16(chunk.raw, 0x0A)
    name = _fixed_ascii(chunk.raw, 0x10, 0x20)
    shader_index = be_u32(chunk.raw, 0x30)
    parameter_count = be_u32(chunk.raw, 0x34)
    offset = 0x38
    parameters: list[GMXMaterialParameter] = []
    for _ in range(parameter_count):
        if offset + 0x38 > len(chunk.raw):
            raise FormatError(f"MTRL {index}: truncated parameter header")
        param_name = _fixed_ascii(chunk.raw, offset, 0x30)
        type_code = be_u32(chunk.raw, offset + 0x30)
        count = be_u32(chunk.raw, offset + 0x34)
        value_offset = offset + 0x38
        if type_code == 0:  # float vector/scalar
            byte_count = count * 4
            if value_offset + byte_count > len(chunk.raw):
                raise FormatError(f"MTRL {index}: float parameter exceeds chunk")
            value: object = tuple(struct.unpack_from(f">{count}f", chunk.raw, value_offset)) if count else tuple()
            offset = value_offset + byte_count
        elif type_code == 1:  # one or more 4x4 matrices
            byte_count = count * 0x40
            if value_offset + byte_count > len(chunk.raw):
                raise FormatError(f"MTRL {index}: matrix parameter exceeds chunk")
            value = [tuple(struct.unpack_from(">16f", chunk.raw, value_offset + i * 0x40)) for i in range(count)]
            offset = value_offset + byte_count
        elif type_code == 2:  # texture/sampler reference; the count field is the TXIF index
            value = count
            offset = value_offset
        else:
            raise FormatError(f"MTRL {index}: unsupported parameter type {type_code}")
        parameters.append(GMXMaterialParameter(param_name, type_code, count, value))
    if any(chunk.raw[offset:]):
        raise FormatError(f"MTRL {index}: unexpected non-zero trailing bytes")
    return GMXMaterial(index, flags, name, shader_index, parameters)


def parse_gmx_parent_group(chunk: GMXChunk) -> GMXParentGroup:
    if chunk.tag != "PARE" or chunk.size < 0x18:
        raise FormatError("invalid PARE chunk")
    child_count = be_u32(chunk.raw, 0x10)
    parent = struct.unpack_from(">i", chunk.raw, 0x14)[0]
    end = 0x18 + child_count * 4
    if end > len(chunk.raw):
        raise FormatError("PARE child list exceeds chunk")
    children = list(struct.unpack_from(f">{child_count}I", chunk.raw, 0x18)) if child_count else []
    return GMXParentGroup(parent, children)


def parse_gmx_bone(chunk: GMXChunk) -> GMXBone:
    if chunk.tag != "BONE" or chunk.size != 0x80:
        raise FormatError("invalid BONE chunk")
    index = be_u16(chunk.raw, 0x08)
    flags = be_u16(chunk.raw, 0x0A)
    name = _fixed_ascii(chunk.raw, 0x10, 0x20)
    matrix = tuple(struct.unpack_from(">16f", chunk.raw, 0x30))
    attachment_count = be_u32(chunk.raw, 0x70)
    if attachment_count > 3:
        raise FormatError(f"BONE {index}: too many attachment references ({attachment_count})")
    material_index: Optional[int] = None
    mesh_index: Optional[int] = None
    for i in range(attachment_count):
        encoded = be_u32(chunk.raw, 0x74 + i * 4)
        ref_type = encoded >> 16
        ref_index = encoded & 0xFFFF
        if ref_type == 2:
            material_index = ref_index
        elif ref_type == 3:
            mesh_index = ref_index
    return GMXBone(index, flags, name, matrix, material_index, mesh_index)


def parse_gmx_motion(chunk: GMXChunk) -> GMXMotion:
    if chunk.tag != "MOTN" or chunk.size != 0x20:
        raise FormatError("invalid MOTN chunk")
    encoded_index = be_u32(chunk.raw, 0x08)
    if encoded_index & 0xFFFF:
        raise FormatError("MOTN index has unexpected low bits")
    duration = struct.unpack_from(">f", chunk.raw, 0x14)[0]
    return GMXMotion(encoded_index >> 16, duration)


def parse_gmx_animation(chunk: GMXChunk) -> GMXAnimationTrack:
    if chunk.tag != "ANIM" or chunk.size < 0x20:
        raise FormatError("invalid ANIM chunk")
    encoded_index = be_u32(chunk.raw, 0x08)
    if encoded_index & 0xFFFF:
        raise FormatError("ANIM index has unexpected low bits")
    target_bone = be_u32(chunk.raw, 0x10)
    channel_type = be_u32(chunk.raw, 0x14)
    frame_count = be_u32(chunk.raw, 0x18)
    value_count = be_u32(chunk.raw, 0x1C)
    if channel_type != 12 or value_count != 16:
        raise FormatError(
            f"ANIM {encoded_index >> 16}: unsupported channel/value layout {channel_type}/{value_count}"
        )
    times_offset = 0x20
    values_offset = times_offset + frame_count * 4
    required = values_offset + frame_count * value_count * 4
    if required > len(chunk.raw):
        raise FormatError(f"ANIM {encoded_index >> 16}: data exceeds chunk")
    times = tuple(struct.unpack_from(f">{frame_count}f", chunk.raw, times_offset))
    flat = struct.unpack_from(f">{frame_count * value_count}f", chunk.raw, values_offset)
    matrices = [tuple(flat[i : i + value_count]) for i in range(0, len(flat), value_count)]
    if any(chunk.raw[required:]):
        raise FormatError(f"ANIM {encoded_index >> 16}: unexpected non-zero trailing bytes")
    return GMXAnimationTrack(encoded_index >> 16, target_bone, channel_type, times, matrices)


def _transpose_4x4(values: Sequence[float]) -> tuple[float, ...]:
    if len(values) != 16:
        raise ValueError("matrix must contain 16 values")
    return tuple(float(values[c * 4 + r]) for r in range(4) for c in range(4))


def _det3(m: Sequence[Sequence[float]]) -> float:
    return (
        m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
        - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
    )


def _quat_from_matrix3(m: Sequence[Sequence[float]]) -> tuple[float, float, float, float]:
    trace = m[0][0] + m[1][1] + m[2][2]
    if trace > 0.0:
        s = math.sqrt(trace + 1.0) * 2.0
        w = 0.25 * s
        x = (m[2][1] - m[1][2]) / s
        y = (m[0][2] - m[2][0]) / s
        z = (m[1][0] - m[0][1]) / s
    elif m[0][0] > m[1][1] and m[0][0] > m[2][2]:
        s = math.sqrt(max(0.0, 1.0 + m[0][0] - m[1][1] - m[2][2])) * 2.0
        w = (m[2][1] - m[1][2]) / s
        x = 0.25 * s
        y = (m[0][1] + m[1][0]) / s
        z = (m[0][2] + m[2][0]) / s
    elif m[1][1] > m[2][2]:
        s = math.sqrt(max(0.0, 1.0 + m[1][1] - m[0][0] - m[2][2])) * 2.0
        w = (m[0][2] - m[2][0]) / s
        x = (m[0][1] + m[1][0]) / s
        y = 0.25 * s
        z = (m[1][2] + m[2][1]) / s
    else:
        s = math.sqrt(max(0.0, 1.0 + m[2][2] - m[0][0] - m[1][1])) * 2.0
        w = (m[1][0] - m[0][1]) / s
        x = (m[0][2] + m[2][0]) / s
        y = (m[1][2] + m[2][1]) / s
        z = 0.25 * s
    length = math.sqrt(x * x + y * y + z * z + w * w)
    if length <= 1e-12:
        return (0.0, 0.0, 0.0, 1.0)
    return (x / length, y / length, z / length, w / length)


def decompose_standard_matrix(matrix: Sequence[float]) -> tuple[tuple[float, float, float], tuple[float, float, float, float], tuple[float, float, float], float]:
    """Decompose a conventional row-major, column-vector affine matrix.

    Returns translation, quaternion (x,y,z,w), scale, and a simple orthogonality error.
    """
    if len(matrix) != 16:
        raise ValueError("matrix must contain 16 values")
    translation = (float(matrix[3]), float(matrix[7]), float(matrix[11]))
    columns = [
        [float(matrix[0]), float(matrix[4]), float(matrix[8])],
        [float(matrix[1]), float(matrix[5]), float(matrix[9])],
        [float(matrix[2]), float(matrix[6]), float(matrix[10])],
    ]
    scales = [math.sqrt(sum(value * value for value in column)) for column in columns]
    for i, scale in enumerate(scales):
        if scale <= 1e-12:
            columns[i] = [1.0 if row == i else 0.0 for row in range(3)]
            scales[i] = 0.0
        else:
            columns[i] = [value / scale for value in columns[i]]
    rotation = [[columns[col][row] for col in range(3)] for row in range(3)]
    if _det3(rotation) < 0.0:
        scales[0] = -scales[0]
        for row in range(3):
            rotation[row][0] = -rotation[row][0]
    error = max(
        abs(sum(rotation[row][a] * rotation[row][b] for row in range(3)))
        for a in range(3)
        for b in range(a + 1, 3)
    )
    quaternion = _quat_from_matrix3(rotation)
    return translation, quaternion, (scales[0], scales[1], scales[2]), error


def _dds_mask_channel(value: int, mask: int) -> int:
    if mask == 0:
        return 255
    shift = (mask & -mask).bit_length() - 1
    bits = (mask >> shift).bit_length()
    raw = (value & mask) >> shift
    maximum = (1 << bits) - 1
    return int(round(raw * 255 / maximum)) if maximum else 0


def decode_uncompressed_dds_rgba(data: bytes) -> tuple[int, int, bytes]:
    if len(data) < 128 or data[:4] != b"DDS ":
        raise FormatError("not a DDS file")
    if struct.unpack_from("<I", data, 4)[0] != 124:
        raise FormatError("unsupported DDS header size")
    height = struct.unpack_from("<I", data, 12)[0]
    width = struct.unpack_from("<I", data, 16)[0]
    pf_flags = struct.unpack_from("<I", data, 80)[0]
    fourcc = data[84:88]
    rgb_bits = struct.unpack_from("<I", data, 88)[0]
    masks = struct.unpack_from("<4I", data, 92)
    if fourcc != b"\0\0\0\0" or not (pf_flags & 0x40) or rgb_bits != 32:
        raise FormatError("only uncompressed 32-bit RGB(A) DDS is supported")
    byte_count = width * height * 4
    if 128 + byte_count > len(data):
        raise FormatError("DDS pixel payload is truncated")
    output = bytearray(byte_count)
    rmask, gmask, bmask, amask = masks
    for i in range(width * height):
        value = struct.unpack_from("<I", data, 128 + i * 4)[0]
        output[i * 4 + 0] = _dds_mask_channel(value, rmask)
        output[i * 4 + 1] = _dds_mask_channel(value, gmask)
        output[i * 4 + 2] = _dds_mask_channel(value, bmask)
        output[i * 4 + 3] = _dds_mask_channel(value, amask) if amask else 255
    return width, height, bytes(output)


class GltfBufferBuilder:
    def __init__(self) -> None:
        self.data = bytearray()
        self.buffer_views: list[dict] = []
        self.accessors: list[dict] = []

    def add_view(self, payload: bytes, target: Optional[int] = None) -> int:
        while len(self.data) % 4:
            self.data.append(0)
        offset = len(self.data)
        self.data.extend(payload)
        view: dict = {"buffer": 0, "byteOffset": offset, "byteLength": len(payload)}
        if target is not None:
            view["target"] = target
        self.buffer_views.append(view)
        return len(self.buffer_views) - 1

    def add_accessor(
        self,
        payload: bytes,
        component_type: int,
        value_type: str,
        count: int,
        *,
        target: Optional[int] = None,
        minimum: Optional[Sequence[float]] = None,
        maximum: Optional[Sequence[float]] = None,
    ) -> int:
        view_index = self.add_view(payload, target)
        accessor: dict = {
            "bufferView": view_index,
            "componentType": component_type,
            "count": count,
            "type": value_type,
        }
        if minimum is not None:
            accessor["min"] = [float(x) for x in minimum]
        if maximum is not None:
            accessor["max"] = [float(x) for x in maximum]
        self.accessors.append(accessor)
        return len(self.accessors) - 1


def _pack_float_tuples(values: Sequence[Sequence[float]]) -> bytes:
    flat = [float(component) for value in values for component in value]
    return struct.pack(f"<{len(flat)}f", *flat)


def _minmax_tuples(values: Sequence[Sequence[float]], components: int) -> tuple[list[float], list[float]]:
    return (
        [min(float(value[i]) for value in values) for i in range(components)],
        [max(float(value[i]) for value in values) for i in range(components)],
    )


def _find_texture_file(name: str, source_path: Optional[Path], texture_roots: Sequence[Path]) -> Optional[Path]:
    candidates: list[Path] = []
    if source_path is not None:
        candidates.append(source_path.parent / name)
    for root in texture_roots:
        candidates.append(root / name)
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    basename = Path(name).name.lower()
    search_roots: list[Path] = []
    if source_path is not None:
        search_roots.append(source_path.parent)
    search_roots.extend(texture_roots)
    seen: set[Path] = set()
    for root in search_roots:
        if root in seen or not root.is_dir():
            continue
        seen.add(root)
        for path in root.rglob("*"):
            if path.is_file() and path.name.lower() == basename:
                return path
    return None


def export_gmx_gltf_bytes(
    data: bytes,
    gltf_path: Path,
    *,
    source_path: Optional[Path] = None,
    texture_roots: Sequence[Path] = (),
    flip_v: bool = False,
) -> dict:
    chunks = parse_gmx_chunks(data)
    arrays = {arr.array_index: arr for arr in (parse_gmx_array(c) for c in chunks if c.tag == "ARRY")}
    meshes = {mesh.mesh_index: mesh for mesh in (parse_gmx_mesh(c) for c in chunks if c.tag == "MESH")}
    texture_refs = {item.index: item for item in (parse_gmx_texture_ref(c) for c in chunks if c.tag == "TXIF")}
    shaders = {item.index: item for item in (parse_gmx_shader(c) for c in chunks if c.tag == "SHAD")}
    materials = {item.index: item for item in (parse_gmx_material(c) for c in chunks if c.tag == "MTRL")}
    parent_groups = [parse_gmx_parent_group(c) for c in chunks if c.tag == "PARE"]
    bones = {item.index: item for item in (parse_gmx_bone(c) for c in chunks if c.tag == "BONE")}
    motions = {item.index: item for item in (parse_gmx_motion(c) for c in chunks if c.tag == "MOTN")}
    animations = [parse_gmx_animation(c) for c in chunks if c.tag == "ANIM"]

    gltf_path.parent.mkdir(parents=True, exist_ok=True)
    builder = GltfBufferBuilder()
    document: dict = {
        "asset": {"version": "2.0", "generator": "SIIG Asset Toolkit"},
        "scene": 0,
        "scenes": [{"nodes": []}],
        "nodes": [],
        "meshes": [],
        "materials": [],
        "buffers": [],
        "bufferViews": builder.buffer_views,
        "accessors": builder.accessors,
        "extras": {
            "sourceFormat": "Space Invaders Infinity Gene GMX",
            "chunkTags": [chunk.tag for chunk in chunks],
        },
    }

    image_indexes: dict[int, int] = {}
    texture_indexes: dict[int, int] = {}
    converted_textures: list[str] = []
    missing_textures: list[str] = []
    if texture_refs:
        document["images"] = []
        document["textures"] = []
        document["samplers"] = [{"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497}]
        texture_dir = gltf_path.parent / "_textures"
        for index, texture_ref in sorted(texture_refs.items()):
            source_texture = _find_texture_file(texture_ref.name, source_path, texture_roots)
            if source_texture is None:
                missing_textures.append(texture_ref.name)
                continue
            try:
                source_bytes = source_texture.read_bytes()
                if source_bytes.startswith(b"DDS "):
                    width, height, rgba = decode_uncompressed_dds_rgba(source_bytes)
                    destination = texture_dir / f"{source_texture.stem}.png"
                    if not destination.exists():
                        write_rgba_png(destination, width, height, rgba)
                elif looks_like_tex(source_bytes):
                    destination = texture_dir / f"{source_texture.stem}.png"
                    if not destination.exists():
                        export_tex_png_bytes(source_bytes, destination)
                elif source_texture.suffix.lower() in {".png", ".jpg", ".jpeg"}:
                    destination = texture_dir / source_texture.name
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    if not destination.exists() and source_texture.resolve() != destination.resolve():
                        shutil.copy2(source_texture, destination)
                else:
                    missing_textures.append(texture_ref.name)
                    continue
                uri = destination.relative_to(gltf_path.parent).as_posix()
                image_indexes[index] = len(document["images"])
                document["images"].append({"uri": uri, "name": texture_ref.name})
                texture_indexes[index] = len(document["textures"])
                document["textures"].append({"sampler": 0, "source": image_indexes[index], "name": texture_ref.name})
                converted_textures.append(uri)
            except Exception:
                missing_textures.append(texture_ref.name)

    material_map: dict[int, int] = {}
    uses_unlit = False
    for index, material in sorted(materials.items()):
        params = {parameter.name: parameter for parameter in material.parameters}
        diffuse = params.get("DiffuseColor")
        alpha = params.get("DiffuseAlpha")
        emissive = params.get("EmissiveColor")
        color_values = list(diffuse.value) if diffuse and diffuse.type_code == 0 else [1.0, 1.0, 1.0]
        while len(color_values) < 3:
            color_values.append(1.0)
        alpha_value = float(alpha.value[0]) if alpha and alpha.type_code == 0 and alpha.value else 1.0
        pbr: dict = {
            "baseColorFactor": [float(color_values[0]), float(color_values[1]), float(color_values[2]), alpha_value],
            "metallicFactor": 0.0,
            "roughnessFactor": 1.0,
        }
        sampler_param = params.get("DiffuseSampler")
        requested_texture: Optional[int] = None
        if sampler_param and sampler_param.type_code == 2:
            requested_texture = int(sampler_param.value)
            if requested_texture in texture_indexes:
                pbr["baseColorTexture"] = {"index": texture_indexes[requested_texture]}
        shader_name = shaders.get(material.shader_index).name if material.shader_index in shaders else ""
        gltf_material: dict = {
            "name": material.name or f"material_{index}",
            "pbrMetallicRoughness": pbr,
            "doubleSided": True,
            "extensions": {"KHR_materials_unlit": {}},
            "extras": {
                "gmxMaterialIndex": index,
                "gmxShader": shader_name,
                "requestedTextureIndex": requested_texture,
                "parameters": {
                    parameter.name: parameter.value for parameter in material.parameters if parameter.name != "mWVP"
                },
            },
        }
        uses_unlit = True
        if emissive and emissive.type_code == 0 and len(emissive.value) >= 3:
            gltf_material["emissiveFactor"] = [float(emissive.value[0]), float(emissive.value[1]), float(emissive.value[2])]
        if alpha_value < 0.999 or requested_texture is not None:
            gltf_material["alphaMode"] = "BLEND"
        material_map[index] = len(document["materials"])
        document["materials"].append(gltf_material)
    if uses_unlit:
        document["extensionsUsed"] = ["KHR_materials_unlit"]

    mesh_to_material: dict[int, Optional[int]] = {}
    mesh_to_bone: dict[int, int] = {}
    for bone in bones.values():
        if bone.mesh_index is not None:
            mesh_to_material[bone.mesh_index] = bone.material_index
            mesh_to_bone[bone.mesh_index] = bone.index

    mesh_map: dict[int, int] = {}
    for mesh_index, mesh in sorted(meshes.items()):
        referenced = [arrays[idx] for idx in mesh.array_refs if idx in arrays]
        position = _array_by_semantic(referenced, "IN.position")
        normal = _array_by_semantic(referenced, "IN.normal")
        texcoord = _array_by_semantic(referenced, "IN.texuv")
        color = _array_by_semantic(referenced, "IN.color")
        indices = _index_array(referenced)
        if position is None or indices is None:
            raise FormatError(f"MESH {mesh_index}: missing position or index array")
        attributes: dict = {}
        pos_values = [tuple(float(x) for x in value[:3]) for value in position.values]
        minimum, maximum = _minmax_tuples(pos_values, 3)
        attributes["POSITION"] = builder.add_accessor(
            _pack_float_tuples(pos_values), 5126, "VEC3", len(pos_values), target=34962, minimum=minimum, maximum=maximum
        )
        if normal is not None:
            normal_values = [tuple(float(x) for x in value[:3]) for value in normal.values]
            attributes["NORMAL"] = builder.add_accessor(
                _pack_float_tuples(normal_values), 5126, "VEC3", len(normal_values), target=34962
            )
        if texcoord is not None:
            uv_values = [
                (float(value[0]), 1.0 - float(value[1]) if flip_v else float(value[1]))
                for value in texcoord.values
            ]
            attributes["TEXCOORD_0"] = builder.add_accessor(
                _pack_float_tuples(uv_values), 5126, "VEC2", len(uv_values), target=34962
            )
        if color is not None:
            color_values = [tuple(float(x) for x in value[:4]) for value in color.values]
            attributes["COLOR_0"] = builder.add_accessor(
                _pack_float_tuples(color_values), 5126, "VEC4", len(color_values), target=34962
            )
        index_values = [int(value[0]) for value in indices.values]
        index_accessor = builder.add_accessor(
            struct.pack(f"<{len(index_values)}H", *index_values),
            5123,
            "SCALAR",
            len(index_values),
            target=34963,
            minimum=[min(index_values) if index_values else 0],
            maximum=[max(index_values) if index_values else 0],
        )
        primitive: dict = {
            "attributes": attributes,
            "indices": index_accessor,
            "mode": int(mesh.primitive_mode),
        }
        material_index = mesh_to_material.get(mesh_index)
        if material_index is not None and material_index in material_map:
            primitive["material"] = material_map[material_index]
        mesh_map[mesh_index] = len(document["meshes"])
        attached_bone = bones.get(mesh_to_bone.get(mesh_index, -1))
        mesh_name = attached_bone.name if attached_bone is not None and attached_bone.name else f"mesh_{mesh_index}"
        document["meshes"].append(
            {
                "name": mesh_name,
                "primitives": [primitive],
                "extras": {"gmxMeshIndex": mesh_index, "skinIndex": mesh.skin_index},
            }
        )

    node_map: dict[int, int] = {}
    decomposition_errors: list[float] = []
    for bone_index, bone in sorted(bones.items()):
        # BONE matrices use row-vector storage; transpose to conventional row-major matrix.
        standard_matrix = _transpose_4x4(bone.matrix)
        translation, rotation, scale, error = decompose_standard_matrix(standard_matrix)
        decomposition_errors.append(error)
        node: dict = {
            "name": bone.name or f"bone_{bone_index}",
            "translation": list(translation),
            "rotation": list(rotation),
            "scale": list(scale),
            "extras": {
                "gmxBoneIndex": bone_index,
                "gmxFlags": bone.flags,
                "gmxMaterialIndex": bone.material_index,
                "gmxMeshIndex": bone.mesh_index,
            },
        }
        if bone.mesh_index is not None and bone.mesh_index in mesh_map:
            node["mesh"] = mesh_map[bone.mesh_index]
        node_map[bone_index] = len(document["nodes"])
        document["nodes"].append(node)

    child_bones: set[int] = set()
    for group in parent_groups:
        valid_children = [child for child in group.children if child in node_map]
        if group.parent >= 0 and group.parent in node_map:
            parent_node = document["nodes"][node_map[group.parent]]
            parent_node.setdefault("children", []).extend(node_map[child] for child in valid_children)
            child_bones.update(valid_children)
    roots = [node_map[index] for index in sorted(node_map) if index not in child_bones]

    # Keep malformed/unreferenced meshes visible instead of silently dropping them.
    for mesh_index, gltf_mesh_index in sorted(mesh_map.items()):
        if mesh_index not in mesh_to_bone:
            node_index = len(document["nodes"])
            document["nodes"].append({"name": f"unattached_mesh_{mesh_index}", "mesh": gltf_mesh_index})
            roots.append(node_index)
    document["scenes"][0]["nodes"] = roots

    if animations:
        document["animations"] = []
        for track in animations:
            if track.target_bone not in node_map:
                continue
            translations: list[tuple[float, float, float]] = []
            rotations: list[tuple[float, float, float, float]] = []
            scales: list[tuple[float, float, float]] = []
            previous_rotation: Optional[tuple[float, float, float, float]] = None
            track_errors: list[float] = []
            for matrix in track.matrices:
                translation, rotation, scale, error = decompose_standard_matrix(matrix)
                if previous_rotation is not None and sum(a * b for a, b in zip(previous_rotation, rotation)) < 0.0:
                    rotation = tuple(-value for value in rotation)
                previous_rotation = rotation
                translations.append(translation)
                rotations.append(rotation)
                scales.append(scale)
                track_errors.append(error)
            time_values = [(float(value),) for value in track.times]
            time_accessor = builder.add_accessor(
                _pack_float_tuples(time_values),
                5126,
                "SCALAR",
                len(time_values),
                minimum=[min(track.times) if track.times else 0.0],
                maximum=[max(track.times) if track.times else 0.0],
            )
            output_accessors = {
                "translation": builder.add_accessor(_pack_float_tuples(translations), 5126, "VEC3", len(translations)),
                "rotation": builder.add_accessor(_pack_float_tuples(rotations), 5126, "VEC4", len(rotations)),
                "scale": builder.add_accessor(_pack_float_tuples(scales), 5126, "VEC3", len(scales)),
            }
            samplers: list[dict] = []
            channels: list[dict] = []
            for path_name in ("translation", "rotation", "scale"):
                sampler_index = len(samplers)
                samplers.append({"input": time_accessor, "output": output_accessors[path_name], "interpolation": "LINEAR"})
                channels.append(
                    {
                        "sampler": sampler_index,
                        "target": {"node": node_map[track.target_bone], "path": path_name},
                    }
                )
            bone_name = bones[track.target_bone].name or f"bone_{track.target_bone}"
            duration = motions.get(track.index).duration if track.index in motions else (track.times[-1] if track.times else 0.0)
            document["animations"].append(
                {
                    "name": f"motion_{track.index:03d}_{bone_name}",
                    "samplers": samplers,
                    "channels": channels,
                    "extras": {
                        "gmxMotionIndex": track.index,
                        "duration": duration,
                        "targetBone": track.target_bone,
                        "maxDecompositionError": max(track_errors, default=0.0),
                    },
                }
            )

    binary_name = f"{gltf_path.name}.bin"
    document["buffers"] = [{"uri": binary_name, "byteLength": len(builder.data)}]
    document["extras"].update(
        {
            "meshCount": len(meshes),
            "boneCount": len(bones),
            "materialCount": len(materials),
            "animationCount": len(animations),
            "convertedTextures": converted_textures,
            "missingTextures": sorted(set(missing_textures)),
            "maxStaticDecompositionError": max(decomposition_errors, default=0.0),
        }
    )
    (gltf_path.parent / binary_name).write_bytes(builder.data)
    gltf_path.write_text(json.dumps(document, indent=2), encoding="utf-8")
    metadata = {
        "source_size": len(data),
        "gltf": gltf_path.name,
        "mesh_count": len(meshes),
        "bone_count": len(bones),
        "material_count": len(materials),
        "animation_count": len(animations),
        "texture_count": len(texture_refs),
        "converted_textures": converted_textures,
        "missing_textures": sorted(set(missing_textures)),
        "max_static_decomposition_error": max(decomposition_errors, default=0.0),
    }
    write_json_private(gltf_path.with_suffix(".gltf.json"), metadata)
    return metadata


def export_gmx_gltf_file(
    path: Path,
    output_root: Path,
    *,
    flip_v: bool = False,
    texture_roots: Sequence[Path] = (),
    relative_path: Optional[Path] = None,
) -> dict:
    relative = relative_path if relative_path is not None else Path(path.stem + ".gltf")
    if relative.suffix.lower() != ".gltf":
        relative = relative.with_suffix(".gltf")
    destination = output_root / relative
    return export_gmx_gltf_bytes(
        path.read_bytes(),
        destination,
        source_path=path,
        texture_roots=texture_roots,
        flip_v=flip_v,
    )

def iter_candidate_files(path: Path) -> Iterator[Path]:
    if path.is_file():
        yield path
    elif path.is_dir():
        yield from (p for p in sorted(path.rglob("*")) if p.is_file())
    else:
        raise FileNotFoundError(path)



LOCALIZATION_LANGUAGES = (
    "japanese",
    "english",
    "french",
    "italian",
    "german",
    "spanish",
)

# message.bin uses an old single-byte, language-specific glyph convention for
# accented uppercase letters. These replacements were recovered from the text
# itself and checked against the corresponding UTF-8 translations in text.bin.
MESSAGE_ACCENT_MAPS: dict[str, dict[str, str]] = {
    "japanese": {"p": "É", "t": "Í", "k": "Ü"},
    "english": {"p": "É", "t": "Í", "k": "Ü"},
    "french": {
        "p": "É", "q": "È", "v": "Î", "r": "Ê", "e": "À",
        "y": "Œ", "k": "Ü", "t": "Í",
    },
    "italian": {
        "q": "È", "e": "À", "m": "Ù", "u": "Ì",
        "p": "É", "k": "Ü", "t": "Í",
    },
    "german": {
        "c": "Ä", "k": "Ü", "g": "Ö", "p": "É", "t": "Í",
    },
    "spanish": {
        "h": "Ó", "b": "Ñ", "l": "Ú", "d": "Á", "p": "É",
        "t": "Í", "z": "¡", "k": "Ü",
    },
}


def correct_message_glyph_codes(text: str, language: str) -> str:
    mapping = MESSAGE_ACCENT_MAPS.get(language, {})
    if not mapping:
        return text
    out: list[str] = []
    for index, char in enumerate(text):
        # Preserve printf's decimal placeholder rather than changing %d to %Á.
        if char == "d" and index > 0 and text[index - 1] == "%":
            out.append(char)
        else:
            out.append(mapping.get(char, char))
    return "".join(out)


def parse_message_script(payload: bytes, language: str) -> tuple[str, dict[str, list[str]]]:
    try:
        source = payload.decode("shift_jis")
    except UnicodeDecodeError as exc:
        raise FormatError(f"message payload is not valid Shift-JIS: {exc}") from exc

    groups: dict[str, list[str]] = {}
    current: Optional[str] = None
    assignment_re = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\s*<-\s*\[$")

    for line_number, line in enumerate(source.splitlines(), 1):
        stripped = line.strip()
        match = assignment_re.match(stripped)
        if match:
            current = match.group(1)
            groups[current] = []
            continue
        if stripped in {"]", "],"}:
            current = None
            continue
        if current is not None and stripped.startswith('"'):
            literal = stripped[:-1] if stripped.endswith(",") else stripped
            try:
                value = json.loads(literal)
            except json.JSONDecodeError as exc:
                raise FormatError(
                    f"invalid message string at line {line_number}: {exc.msg}"
                ) from exc
            groups[current].append(correct_message_glyph_codes(value, language))

    if not groups:
        raise FormatError("message payload contains no Squirrel string arrays")
    return source, groups


def _expand_inline_newlines(value: str) -> str:
    # text.bin stores intended line breaks as the two source characters \\n.
    return value.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\r", "\n").replace("\\t", "\t")


def looks_like_message_archive(archive: BBXArchive) -> bool:
    if archive.count != 6:
        return False
    return all(archive.payload(entry).startswith(b"STR_") for entry in archive.entries)


def looks_like_text_archive(archive: BBXArchive) -> bool:
    if archive.count != 7:
        return False
    first = archive.payload(archive.entries[0])
    return first.startswith(b"EVOL_TEXT1") and b"RICH_PRESENCE" in first


def export_message_archive(archive: BBXArchive, output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    parsed: list[dict[str, list[str]]] = []
    language_meta: list[dict] = []

    for language, entry in zip(LOCALIZATION_LANGUAGES, archive.entries):
        payload = archive.payload(entry)
        source, groups = parse_message_script(payload, language)
        parsed.append(groups)

        raw_path = output_dir / f"message_{language}_raw.nut"
        raw_path.write_text(source, encoding="utf-8", newline="")
        readable_source = correct_message_glyph_codes(source, language)
        readable_path = output_dir / f"message_{language}_readable.nut"
        readable_path.write_text(readable_source, encoding="utf-8", newline="")

        text_path = output_dir / f"message_{language}.txt"
        with text_path.open("w", encoding="utf-8", newline="\n") as handle:
            for group, values in groups.items():
                handle.write(f"[{group}]\n")
                for item_index, value in enumerate(values):
                    rendered = value.replace("\n", "\\n")
                    handle.write(f"{item_index:04d}\t{rendered}\n")
                handle.write("\n")

        language_meta.append({
            "language": language,
            "bbx_entry": entry.index,
            "bytes": len(payload),
            "groups": len(groups),
            "strings": sum(len(values) for values in groups.values()),
            "raw_script": raw_path.name,
            "readable_script": readable_path.name,
        })

    reference_groups = parsed[0]
    for language, groups in zip(LOCALIZATION_LANGUAGES[1:], parsed[1:]):
        if list(groups) != list(reference_groups):
            raise FormatError(f"message group order differs in {language}")
        for group, values in reference_groups.items():
            if len(groups[group]) != len(values):
                raise FormatError(f"message group {group} has a different length in {language}")

    csv_path = output_dir / "message_strings.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["group", "item_index", *LOCALIZATION_LANGUAGES])
        for group, values in reference_groups.items():
            for item_index in range(len(values)):
                writer.writerow([
                    group,
                    item_index,
                    *(groups[group][item_index] for groups in parsed),
                ])

    group_csv = output_dir / "message_groups.csv"
    with group_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["group", "string_count"])
        for group, values in reference_groups.items():
            writer.writerow([group, len(values)])

    json_groups: dict[str, list[dict]] = {}
    for group, values in reference_groups.items():
        json_groups[group] = [
            {
                "index": item_index,
                **{
                    language: parsed[language_index][group][item_index]
                    for language_index, language in enumerate(LOCALIZATION_LANGUAGES)
                },
            }
            for item_index in range(len(values))
        ]

    metadata = {
        "format": "SIIG_message.bin",
        "language_order": list(LOCALIZATION_LANGUAGES),
        "note": (
            "The Japanese-region message block intentionally contains English UI text. "
            "Readable exports replace the original language-specific accent glyph codes with Unicode."
        ),
        "group_count": len(reference_groups),
        "strings_per_language": sum(len(values) for values in reference_groups.values()),
        "languages": language_meta,
    }
    (output_dir / "message_strings.json").write_text(
        json.dumps({**metadata, "groups": json_groups}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (output_dir / "message_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return metadata


def export_text_archive(archive: BBXArchive, output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    decoded: list[list[str]] = []
    for entry_index, entry in enumerate(archive.entries):
        payload = archive.payload(entry)
        try:
            text = payload.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise FormatError(f"text.bin entry {entry_index} is not valid UTF-8: {exc}") from exc
        lines = text.splitlines()
        decoded.append(lines)
        label = "keys" if entry_index == 0 else LOCALIZATION_LANGUAGES[entry_index - 1]
        (output_dir / f"text_{label}_raw.txt").write_text(text, encoding="utf-8", newline="")

    keys = decoded[0]
    if not keys or any(len(lines) != len(keys) for lines in decoded[1:]):
        counts = [len(lines) for lines in decoded]
        raise FormatError(f"text.bin line counts do not match: {counts}")

    raw_csv = output_dir / "text_strings_raw.csv"
    readable_csv = output_dir / "text_strings.csv"
    with raw_csv.open("w", encoding="utf-8-sig", newline="") as raw_handle, readable_csv.open(
        "w", encoding="utf-8-sig", newline=""
    ) as readable_handle:
        raw_writer = csv.writer(raw_handle)
        readable_writer = csv.writer(readable_handle)
        header = ["index", "key", *LOCALIZATION_LANGUAGES]
        raw_writer.writerow(header)
        readable_writer.writerow(header)
        for index, key in enumerate(keys):
            raw_values = [decoded[lang_index + 1][index] for lang_index in range(6)]
            raw_writer.writerow([index, key, *raw_values])
            readable_writer.writerow([index, key, *(_expand_inline_newlines(v) for v in raw_values)])

    records = []
    for index, key in enumerate(keys):
        records.append({
            "index": index,
            "key": key,
            **{
                language: _expand_inline_newlines(decoded[lang_index + 1][index])
                for lang_index, language in enumerate(LOCALIZATION_LANGUAGES)
            },
        })

    for lang_index, language in enumerate(LOCALIZATION_LANGUAGES):
        path = output_dir / f"text_{language}.txt"
        with path.open("w", encoding="utf-8", newline="\n") as handle:
            for index, key in enumerate(keys):
                value = _expand_inline_newlines(decoded[lang_index + 1][index])
                handle.write(f"[{index:04d}] {key}\n{value}\n\n")

    metadata = {
        "format": "SIIG_text.bin",
        "language_order": list(LOCALIZATION_LANGUAGES),
        "string_count": len(keys),
        "note": "Entry 0 contains identifiers; entries 1-6 contain line-aligned UTF-8 translations.",
    }
    (output_dir / "text_strings.json").write_text(
        json.dumps({**metadata, "strings": records}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (output_dir / "text_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return metadata


def decode_localization_file(path: Path, output_root: Path) -> dict:
    data = maybe_decompress(path.read_bytes())
    archive = BBXArchive.parse(data)
    lowered = path.name.lower()
    if looks_like_message_archive(archive):
        metadata = export_message_archive(archive, output_root / "message")
        metadata["source"] = path.name
        return metadata
    if looks_like_text_archive(archive):
        metadata = export_text_archive(archive, output_root / "text")
        metadata["source"] = path.name
        return metadata
    raise FormatError(f"{path}: BBX is not recognized as message.bin or text.bin")


def command_text2csv(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output_root = Path(args.output)
    if not input_path.exists():
        raise FormatError(f"input not found: {input_path}")

    if input_path.is_file():
        candidates = [input_path]
    else:
        candidates = sorted(
            path for path in input_path.rglob("*")
            if path.is_file()
            and ("message.bin" in path.name.lower() or "text.bin" in path.name.lower())
        )
        if not candidates:
            raise FormatError(f"no message.bin/text.bin files found under {input_path}")

    results: list[dict] = []
    failures: list[dict] = []
    for candidate in candidates:
        try:
            result = decode_localization_file(candidate, output_root)
            results.append(result)
            kind = result["format"]
            count = result.get("string_count", result.get("strings_per_language", 0))
            print(f"decoded {candidate} -> {kind} ({count} strings)")
        except (OSError, FormatError, gzip.BadGzipFile) as exc:
            failures.append({"file": candidate.name, "error": scrub_private_text(exc)})
            print(f"warning: {candidate}: {exc}", file=sys.stderr)

    summary = {"decoded": results, "failures": failures}
    output_root.mkdir(parents=True, exist_ok=True)
    write_json_private(output_root / "localization_summary.json", summary, ensure_ascii=False)
    if not results:
        raise FormatError("no localization archive was decoded")
    print(f"completed: {len(results)} localization archive(s), {len(failures)} failure(s)")
    return 0 if not failures else 1

def command_extract(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        try:
            raw = path.read_bytes()[:4]
            if raw[:2] == b"\x1F\x8B":
                test = maybe_decompress(path.read_bytes())[:4]
            else:
                test = raw
            if test != BBX_MAGIC:
                if input_path.is_file():
                    raise FormatError("input is not BBX or standard gzip containing BBX")
                continue
            result = extract_bbx_file(
                path, output, args.recursive, args.convert_gmx, args.convert_gltf, args.convert_tex, args.flip_v
            )
            print(f"{path}: extracted {result['count']} resources")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} archive(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def command_gmx2obj(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        if path.suffix.lower() != ".gmx" and not path.read_bytes()[:4] == GMX_MAGIC:
            continue
        try:
            chunks = parse_gmx_chunks(path.read_bytes())
            if not any(chunk.tag == "MESH" for chunk in chunks):
                meta_path = output / f"{path.stem}.gmx.json"
                meta_path.write_text(
                    json.dumps(
                        {
                            "source": path.name,
                            "mesh_count": 0,
                            "note": "This GMX has no MESH chunks; it may be hierarchy/animation-only.",
                            "chunks": [
                                {"offset": c.offset, "tag": c.tag, "size": c.size} for c in chunks
                            ],
                        },
                        indent=2,
                    ),
                    encoding="utf-8",
                )
                print(f"{path}: no mesh geometry; wrote metadata only")
            else:
                meta = export_gmx_file(path, output, args.flip_v)
                print(f"{path}: exported {meta['mesh_count']} mesh(es)")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} GMX file(s), {failures} failure(s)")
    return 1 if failures and not success else 0



def command_gmx2gltf(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    texture_roots = tuple(Path(value) for value in (args.texture_root or []))
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        try:
            if path.suffix.lower() != ".gmx" and path.read_bytes()[:4] != GMX_MAGIC:
                continue
            if input_path.is_dir():
                relative = path.relative_to(input_path).with_suffix(".gltf")
            else:
                relative = Path(path.stem + ".gltf")
            roots = (input_path,) + texture_roots if input_path.is_dir() else texture_roots
            meta = export_gmx_gltf_file(
                path,
                output,
                flip_v=args.flip_v,
                texture_roots=roots,
                relative_path=relative,
            )
            print(
                f"{path}: glTF with {meta['mesh_count']} mesh(es), "
                f"{meta['bone_count']} bone(s), {meta['animation_count']} animation track(s)"
            )
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} GMX file(s), {failures} failure(s)")
    return 1 if failures and not success else 0

def command_tex2png(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        try:
            data = path.read_bytes()
            if path.suffix.lower() != ".tex" and not looks_like_any_tex(data):
                continue
            if input_path.is_dir():
                relative = path.relative_to(input_path).with_suffix(".png")
                destination = output / relative
            else:
                destination = output / f"{path.stem}.png"
            meta = export_tex_png_bytes(data, destination)
            print(f"{path}: {meta['width']}x{meta['height']} {meta['format_name']} -> {destination}")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} TEX file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def _script_opcode_name(opcode: int) -> str:
    if 0 <= opcode < len(SIIG_SCRIPT_OPCODE_NAMES):
        value = SIIG_SCRIPT_OPCODE_NAMES[opcode]
        if value:
            return value
    return f"UNKNOWN_0x{opcode:04X}"


def _dat_field(name: str, value: int, *, unit: Optional[str] = None, note: Optional[str] = None) -> dict:
    item = {"name": name, "value": value, "hex": f"0x{value & 0xFFFF:04X}"}
    if unit:
        item["unit"] = unit
    if note:
        item["note"] = note
    return item


def decode_dat_semantics(opcode: int, args: Sequence[int]) -> dict:
    """Conservative, XEX-backed semantics for one DAT command.

    Unknown words remain ``param_N``. The lossless signed/unsigned/hex arrays
    are retained alongside this interpretation layer.
    """
    name = _script_opcode_name(opcode)
    category = "other"
    confidence = "low"
    fields: list[dict] = []
    summary = name

    def add_schema(names: Sequence[str], *, units: Optional[dict[str, str]] = None, notes: Optional[dict[str, str]] = None) -> None:
        units = units or {}
        notes = notes or {}
        for index, value in enumerate(args):
            field_name = names[index] if index < len(names) else f"param_{index}"
            fields.append(_dat_field(field_name, value, unit=units.get(field_name), note=notes.get(field_name)))

    if opcode < 0x60 or 0x96 <= opcode <= 0xAB:
        category = "enemy"
        confidence = "medium"
        add_schema(["spawn_condition", "entity_parameter", "speed_or_rate", "variant", "position_x", "position_y"], notes={
            "spawn_condition": "0 is unconditional; nonzero invokes the build's conditional spawn test",
            "entity_parameter": "copied into a common enemy/entity field; exact gameplay label varies by opcode",
            "speed_or_rate": "commonly shifted to the engine's 8.8 fixed-point representation",
            "position_x": "constructor X coordinate in handlers using the common object initializer",
            "position_y": "constructor Y coordinate in handlers using the common object initializer",
        })
        summary = f"Spawn/configure {name}"
        special = {
            0x05: (["spawn_condition", "entity_parameter", "speed", "variant", "start_x", "start_y", "target_x", "target_y"], "Moving enemy from start to target"),
            0x07: (["spawn_condition", "entity_parameter", "speed", "variant", "start_x", "start_y", "target_x", "target_y"], "V-pattern enemy from start to target"),
            0x08: (["spawn_condition", "entity_parameter", "speed", "variant", "start_x", "start_y", "target_x", "target_y", "child_count", "child_delay", "child_parameter"], "Straight enemy path with optional linked child group"),
            0x0A: (["spawn_condition", "entity_parameter", "speed", "variant", "start_x", "start_y", "warp_parameter"], "Warp enemy spawn"),
            0x0C: (["spawn_condition", "entity_parameter", "horizontal_speed", "spawn_y"], "Side-dependent entry enemy"),
            0x10: (["spawn_condition", "entity_parameter", "speed", "start_x", "start_y", "direction"], "Linear enemy movement"),
            0x24: (["spawn_condition", "entity_parameter", "unused_or_style", "base_x", "base_y", "count", "step_x", "step_y"], "Repeated element formation"),
            0x25: (["spawn_condition", "entity_parameter", "unused_or_style", "base_x", "base_y", "count", "step_x", "step_y"], "Repeated element formation"),
            0x26: (["spawn_condition", "entity_parameter", "unused_or_style", "position_x", "position_y"], "Element enemy with optional linked effect"),
            0x5A: (["spawn_condition", "entity_parameter", "position_or_speed", "variant", "start_x", "start_y", "target_x", "target_y", "duration", "mode", "extra"], "3D shutter object"),
            0x5B: (["spawn_condition", "entity_parameter", "position_or_speed", "variant", "start_x", "start_y", "target_x", "target_y", "duration", "mode"], "3D shutter object"),
        }
        if opcode in special:
            names, summary = special[opcode]
            fields.clear()
            add_schema(names)
    elif opcode in (0x6E, 0x6F, 0x70):
        category, confidence = "scroll", "high"
        add_schema(["delay_or_start_frames", "duration_frames"], units={"delay_or_start_frames": "frames", "duration_frames": "frames"})
        summary = f"Configure {name} timing"
    elif 0x71 <= opcode <= 0x75:
        category, confidence = "cleanup", "high"
        add_schema([])
        summary = name.replace("_", " ").title()
    elif opcode in (0x76, 0x77):
        category, confidence = "alert", "high"
        add_schema([])
        summary = name.replace("_", " ").title()
    elif opcode == 0x78:
        category, confidence = "alert", "high"
        add_schema(["warning_value"])
        summary = f"Show warning ({args[0] if args else 0})"
    elif 0x79 <= opcode <= 0x7F or 0x84 <= opcode <= 0x8C:
        category, confidence = "background", "high"
        add_schema([])
        summary = f"Select {name.replace('_', ' ').lower()}"
    elif opcode == 0x80:
        category, confidence = "background", "high"
        color_names = ["from_r", "from_g", "from_b", "to_r", "to_g", "to_b"]
        add_schema(color_names, units={key: "0..255" for key in color_names})
        summary = "Set background color gradient"
    elif opcode == 0x81:
        category, confidence = "enemy", "low"
        add_schema([f"generator_param_{i}" for i in range(len(args))])
        summary = "Start continuous enemy generation"
    elif opcode in (0x82, 0x83):
        category, confidence = "flow", "high"
        add_schema([])
        summary = name.replace("_", " ").title()
    elif opcode == 0x8D:
        category, confidence = "background", "high"
        add_schema([])
        summary = "End background gradient"
    elif opcode == 0x8E:
        category, confidence = "flow", "medium"
        add_schema(["script_index", "delay_frames"], units={"delay_frames": "frames"})
        summary = "Loop or switch script"
    elif opcode == 0x8F:
        category, confidence = "flow", "high"
        add_schema([])
        summary = "No operation"
    elif opcode == 0xB4:
        category, confidence = "3d", "high"
        add_schema(["duration_frames"], units={"duration_frames": "frames"})
        summary = "Change 3D background scroll"
    elif opcode == 0xB5:
        category, confidence = "3d", "high"
        add_schema(["duration_frames", "scroll_mode"], units={"duration_frames": "frames"}, notes={"scroll_mode": "validated as mode 0 or 1"})
        summary = "Change 3D wall scroll"
    elif opcode == 0xB6:
        category, confidence = "3d", "high"
        rgba = ["red", "green", "blue", "alpha"]
        add_schema(rgba, units={key: "0..255" for key in rgba})
        summary = "Set 3D background color"
    elif opcode in (0xB7, 0xB8):
        category, confidence = "camera", "high"
        add_schema(["camera_index", "duration_frames"], units={"duration_frames": "frames"})
        summary = f"Change 3D camera to preset {args[0] if args else 0}"
    elif opcode == 0xB9:
        category, confidence = "3d", "high"
        add_schema(["enabled"], notes={"enabled": "0 disables; nonzero enables"})
        summary = "Toggle 3D demo mode"
    elif opcode in (0xBA, 0xBB):
        category, confidence = "cleanup", "high"
        add_schema([])
        summary = name.replace("_", " ").title()
    elif opcode == 0xBC:
        category, confidence = "3d", "high"
        add_schema(["animation_index"])
        summary = "Play/select 3D background animation"
    elif opcode == 0xBD:
        category, confidence = "3d", "high"
        add_schema(["rotation_x", "rotation_y", "rotation_z", "duration_frames", "mode"], units={"rotation_x": "degrees", "rotation_y": "degrees", "rotation_z": "degrees", "duration_frames": "frames"})
        summary = "Rotate 3D background"
    elif opcode == 0xBE:
        category, confidence = "3d", "high"
        add_schema(["control_value"])
        summary = "Set 3D field rotation control"
    elif 0xC8 <= opcode <= 0xCE:
        category, confidence = "visualizer", "high"
        schemas = {0xC8: [], 0xC9: [], 0xCA: [], 0xCB: [], 0xCC: ["sequence_set_id"], 0xCD: ["channel_or_target", "change_time", "param_2", "param_3"], 0xCE: ["volume_scale"]}
        add_schema(schemas[opcode])
        summary = name.replace("_", " ").title()
    else:
        add_schema([f"param_{i}" for i in range(len(args))])

    return {"category": category, "summary": summary, "confidence": confidence, "fields": fields}


def parse_dat_bytes(data: bytes) -> dict:
    """Decode SIIG stage/generator DAT command streams.

    Confirmed from the June 10 DebugOpt XEX ``stageScriptBlockLoad`` routine:
    byte 0 is format version 1; bytes 1..2 are a big-endian entry count.
    Every entry then stores a one-byte 16-bit-word count followed by that many
    big-endian words. Word 0 is a non-negative delta-frame value, word 1 is the
    script opcode, and remaining words are opcode-specific signed parameters.
    """
    if len(data) < 3:
        raise FormatError("DAT file is smaller than its 3-byte header")
    version = data[0]
    if version != 1:
        raise FormatError(f"unsupported DAT version {version}; expected 1")
    entry_count = be_u16(data, 1)
    offset = 3
    absolute_frame = 0
    records: list[dict] = []
    for index in range(entry_count):
        if offset >= len(data):
            raise FormatError(f"DAT entry {index} is missing its word-count byte")
        word_count = data[offset]
        entry_offset = offset
        offset += 1
        byte_count = word_count * 2
        if offset + byte_count > len(data):
            raise FormatError(
                f"DAT entry {index} declares {word_count} word(s) beyond the end of the file"
            )
        unsigned_words = list(struct.unpack_from(f">{word_count}H", data, offset)) if word_count else []
        signed_words = list(struct.unpack_from(f">{word_count}h", data, offset)) if word_count else []
        offset += byte_count
        if word_count < 2:
            raise FormatError(f"DAT entry {index} has only {word_count} word(s); expected frame and opcode")
        delta_frame = signed_words[0]
        if delta_frame < 0:
            raise FormatError(f"DAT entry {index} has a negative delta frame: {delta_frame}")
        absolute_frame += delta_frame
        opcode = unsigned_words[1]
        args_signed = signed_words[2:]
        args_unsigned = unsigned_words[2:]
        records.append(
            {
                "index": index,
                "file_offset": entry_offset,
                "word_count": word_count,
                "delta_frame": delta_frame,
                "absolute_frame": absolute_frame,
                "opcode": opcode,
                "opcode_hex": f"0x{opcode:04X}",
                "opcode_name": _script_opcode_name(opcode),
                "args_signed": args_signed,
                "args_unsigned": args_unsigned,
                "args_hex": [f"0x{value:04X}" for value in args_unsigned],
                "raw_words_hex": [f"0x{value:04X}" for value in unsigned_words],
                "semantic": decode_dat_semantics(opcode, args_signed),
            }
        )
    if offset != len(data):
        raise FormatError(f"DAT has {len(data) - offset} trailing byte(s) after {entry_count} entries")
    return {
        "format": "SIIG_DAT_COMMAND_STREAM",
        "version": version,
        "entry_count": entry_count,
        "duration_frames": absolute_frame,
        "records": records,
    }


def export_dat_csv_bytes(data: bytes, csv_path: Path) -> dict:
    parsed = parse_dat_bytes(data)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "index", "file_offset", "word_count", "delta_frame", "absolute_frame",
                "opcode", "opcode_hex", "opcode_name", "category", "summary", "semantic_fields", "args_signed", "args_hex",
            ],
        )
        writer.writeheader()
        for record in parsed["records"]:
            writer.writerow(
                {
                    "index": record["index"],
                    "file_offset": f"0x{record['file_offset']:X}",
                    "word_count": record["word_count"],
                    "delta_frame": record["delta_frame"],
                    "absolute_frame": record["absolute_frame"],
                    "opcode": record["opcode"],
                    "opcode_hex": record["opcode_hex"],
                    "opcode_name": record["opcode_name"],
                    "category": record["semantic"]["category"],
                    "summary": record["semantic"]["summary"],
                    "semantic_fields": " ".join(f"{field['name']}={field['value']}" for field in record["semantic"]["fields"]),
                    "args_signed": " ".join(str(value) for value in record["args_signed"]),
                    "args_hex": " ".join(record["args_hex"]),
                }
            )
    write_json_private(csv_path.with_suffix(csv_path.suffix + ".json"), parsed)
    return parsed


def command_dat2csv(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        if path.suffix.lower() != ".dat":
            continue
        try:
            relative = path.relative_to(input_path) if input_path.is_dir() else Path(path.name)
            destination = output / relative.parent / f"{relative.name}.csv"
            parsed = export_dat_csv_bytes(path.read_bytes(), destination)
            print(
                f"{path}: {parsed['entry_count']} command(s), "
                f"{parsed['duration_frames']} frame(s) -> {destination}"
            )
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} DAT file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def parse_map_bytes(data: bytes) -> dict:
    """Decode SIIG MAP byte-grid layers.

    Confirmed from the June 10 DebugOpt XEX ``stageGenerate2DMap`` routine:
    ``MAP\\0`` is followed by a big-endian layer count. Each layer stores a
    big-endian width and height, followed immediately by ``width*height`` raw
    one-byte cells in row-major order. Every retail/prototype sample has three
    layers, but the parser preserves the count rather than hard-coding it.
    """
    if len(data) < 8 or data[:4] != MAP_MAGIC:
        raise FormatError("not a SIIG MAP byte-grid file")
    layer_count = be_u32(data, 4)
    if layer_count > 64:
        raise FormatError(f"implausible MAP layer count: {layer_count}")
    offset = 8
    layers: list[dict] = []
    for index in range(layer_count):
        if offset + 8 > len(data):
            raise FormatError(f"MAP layer {index} is missing its dimensions")
        width = be_u32(data, offset)
        height = be_u32(data, offset + 4)
        header_offset = offset
        offset += 8
        if width > 65536 or height > 65536:
            raise FormatError(f"implausible MAP layer {index} dimensions: {width}x{height}")
        size = width * height
        if offset + size > len(data):
            raise FormatError(
                f"MAP layer {index} payload is truncated: expected {size} byte(s), "
                f"found {len(data) - offset}"
            )
        cells = data[offset : offset + size]
        data_offset = offset
        offset += size
        counts: dict[str, int] = {}
        for value in cells:
            key = f"0x{value:02X}"
            counts[key] = counts.get(key, 0) + 1
        layers.append(
            {
                "index": index,
                "header_offset": header_offset,
                "data_offset": data_offset,
                "width": width,
                "height": height,
                "cell_count": size,
                "nonzero_cells": sum(value != 0 for value in cells),
                "unique_values": len(counts),
                "value_counts": dict(sorted(counts.items())),
                "cells": cells,
            }
        )
    if offset != len(data):
        raise FormatError(f"MAP has {len(data) - offset} trailing byte(s)")
    return {
        "format": "SIIG_MAP_BYTE_GRIDS",
        "layer_count": layer_count,
        "layers": layers,
    }


def _map_cell_rgba(value: int, grayscale: bool) -> bytes:
    if value == 0:
        return b"\x00\x00\x00\xff"
    if grayscale:
        return bytes((value, value, value, 255))
    red = 48 + ((value * 73) % 208)
    green = 48 + ((value * 151) % 208)
    blue = 48 + ((value * 199) % 208)
    return bytes((red, green, blue, 255))


def _scale_rgba_nearest(rgba: bytes, width: int, height: int, scale: int) -> tuple[int, int, bytes]:
    if scale <= 1 or width == 0 or height == 0:
        return width, height, rgba
    row_size = width * 4
    output_rows: list[bytes] = []
    for y in range(height):
        source = rgba[y * row_size : (y + 1) * row_size]
        expanded = b"".join(source[x : x + 4] * scale for x in range(0, row_size, 4))
        output_rows.extend([expanded] * scale)
    return width * scale, height * scale, b"".join(output_rows)


def export_map_png_bytes(
    data: bytes,
    output_stem: Path,
    *,
    scale: int = 1,
    grayscale: bool = False,
    write_csv: bool = False,
) -> dict:
    if scale < 1 or scale > 64:
        raise FormatError("MAP scale must be between 1 and 64")
    parsed = parse_map_bytes(data)
    metadata_layers: list[dict] = []
    for layer in parsed["layers"]:
        index = layer["index"]
        width = layer["width"]
        height = layer["height"]
        cells: bytes = layer["cells"]
        layer_meta = {key: value for key, value in layer.items() if key != "cells"}
        if width and height:
            rgba = b"".join(_map_cell_rgba(value, grayscale) for value in cells)
            out_width, out_height, rgba = _scale_rgba_nearest(rgba, width, height, scale)
            png_path = output_stem.with_name(f"{output_stem.name}.layer{index}.png")
            write_rgba_png(png_path, out_width, out_height, rgba)
            layer_meta["png_file"] = png_path.name
            layer_meta["png_width"] = out_width
            layer_meta["png_height"] = out_height
            if write_csv:
                csv_path = output_stem.with_name(f"{output_stem.name}.layer{index}.csv")
                csv_path.parent.mkdir(parents=True, exist_ok=True)
                with csv_path.open("w", encoding="utf-8", newline="") as handle:
                    writer = csv.writer(handle)
                    for y in range(height):
                        row = cells[y * width : (y + 1) * width]
                        writer.writerow(row)
                layer_meta["csv_file"] = csv_path.name
        metadata_layers.append(layer_meta)
    metadata = {
        "format": parsed["format"],
        "layer_count": parsed["layer_count"],
        "scale": scale,
        "palette": "grayscale" if grayscale else "categorical",
        "layers": metadata_layers,
    }
    write_json_private(output_stem.with_suffix(output_stem.suffix + ".json"), metadata)
    return metadata


def command_map2png(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        if path.suffix.lower() != ".map":
            continue
        try:
            relative = path.relative_to(input_path) if input_path.is_dir() else Path(path.name)
            destination = output / relative.parent / relative.name
            parsed = export_map_png_bytes(
                path.read_bytes(),
                destination,
                scale=args.scale,
                grayscale=args.grayscale,
                write_csv=args.csv,
            )
            dims = ", ".join(
                f"{layer['width']}x{layer['height']}" for layer in parsed["layers"]
            )
            print(f"{path}: {parsed['layer_count']} layer(s) [{dims}] -> {destination.parent}")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} MAP file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def parse_col_bytes(data: bytes) -> dict:
    """Decode SIIG's standalone .col collision-mask format.

    The files are a 16-byte big-endian header followed by a tightly packed
    one-bit image. Bits are stored least-significant-bit first inside each byte.
    The third header word is preserved as ``variant`` because its gameplay
    meaning has not yet been proven (retail samples use 1 or 4).
    """
    if len(data) < 16:
        raise FormatError("COL file is smaller than its 16-byte header")
    width, height, variant, reserved = struct.unpack_from(">4I", data, 0)
    if not width or not height or width > 16384 or height > 16384:
        raise FormatError(f"implausible COL dimensions: {width}x{height}")
    expected = (width * height + 7) // 8
    if len(data) != 16 + expected:
        raise FormatError(
            f"COL payload size mismatch: expected {expected} byte(s), found {len(data) - 16}"
        )
    return {
        "width": width,
        "height": height,
        "variant": variant,
        "reserved": reserved,
        "payload": data[16:],
    }


def export_col_png_bytes(data: bytes, png_path: Path, *, invert: bool = False) -> dict:
    parsed = parse_col_bytes(data)
    width = parsed["width"]
    height = parsed["height"]
    packed = parsed["payload"]
    # Expand eight LSB-first pixels per byte through a lookup table. This is
    # dramatically faster than a Python loop over every pixel when converting
    # the complete wall archive (over 80 million collision pixels).
    on = bytes((255, 255, 255, 255))
    off = bytes((0, 0, 0, 255))
    lookup = []
    for byte_value in range(256):
        pixels = []
        for bit_index in range(8):
            bit = (byte_value >> bit_index) & 1
            if invert:
                bit ^= 1
            pixels.append(on if bit else off)
        lookup.append(b"".join(pixels))
    rgba = b"".join(lookup[byte_value] for byte_value in packed)
    rgba = rgba[: width * height * 4]
    write_rgba_png(png_path, width, height, rgba)
    metadata = {
        "format": "SIIG_COL_1BIT",
        "width": width,
        "height": height,
        "variant": parsed["variant"],
        "reserved": parsed["reserved"],
        "bit_order": "LSB-first",
        "inverted": invert,
    }
    write_json_private(png_path.with_suffix(png_path.suffix + ".json"), metadata)
    return metadata


def parse_anm_bytes(data: bytes) -> list[dict]:
    """Decode SIIG's standalone .anm lookup table.

    Each 28-byte record contains a 20-byte ASCII model name, one big-endian
    float parameter and one big-endian 32-bit flag. The exact gameplay meaning
    of the numeric fields is intentionally left neutral until confirmed in code.
    """
    if not data or len(data) % 28:
        raise FormatError(f"ANM size is not a non-zero multiple of 28: {len(data)}")
    records: list[dict] = []
    for offset in range(0, len(data), 28):
        raw_name = data[offset : offset + 20].split(b"\0", 1)[0]
        try:
            name = raw_name.decode("ascii")
        except UnicodeDecodeError as exc:
            raise FormatError(f"ANM record {offset // 28} has a non-ASCII name") from exc
        parameter = struct.unpack_from(">f", data, offset + 20)[0]
        flag = be_u32(data, offset + 24)
        records.append(
            {
                "index": offset // 28,
                "model_name": name,
                "parameter": parameter,
                "flag": flag,
            }
        )
    return records


def export_anm_csv_bytes(data: bytes, csv_path: Path) -> dict:
    records = parse_anm_bytes(data)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["index", "model_name", "parameter", "flag"],
        )
        writer.writeheader()
        writer.writerows(records)
    metadata = {
        "format": "SIIG_ANM_TABLE",
        "record_size": 28,
        "record_count": len(records),
        "records": records,
    }
    write_json_private(csv_path.with_suffix(csv_path.suffix + ".json"), metadata)
    return metadata


def command_col2png(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        if path.suffix.lower() != ".col":
            continue
        try:
            relative = path.relative_to(input_path) if input_path.is_dir() else Path(path.name)
            destination = output / relative.parent / f"{relative.name}.png"
            meta = export_col_png_bytes(path.read_bytes(), destination, invert=args.invert)
            print(f"{path}: {meta['width']}x{meta['height']} collision mask -> {destination}")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} COL file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def command_anm2csv(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        if path.suffix.lower() != ".anm":
            continue
        try:
            relative = path.relative_to(input_path) if input_path.is_dir() else Path(path.name)
            destination = output / relative.parent / f"{relative.name}.csv"
            meta = export_anm_csv_bytes(path.read_bytes(), destination)
            print(f"{path}: {meta['record_count']} ANM record(s) -> {destination}")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} ANM file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def _systemfont_crp_from_input(path: Path) -> bytes:
    data = maybe_decompress(path.read_bytes())
    if data.startswith(BBX_MAGIC):
        archive = BBXArchive.parse(data)
        matches = [
            archive.payload(entry)
            for entry in archive.entries
            if entry.name.lower().endswith(".crp") or looks_like_systemfont_crp(archive.payload(entry))
        ]
        if len(matches) != 1:
            raise FormatError(f"expected one systemfont CRP resource, found {len(matches)}")
        return matches[0]
    if looks_like_systemfont_crp(data):
        return data
    raise FormatError("input is not systemfont.bin or an encrypted systemfont.crp")


def command_font2png(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    encrypted = _systemfont_crp_from_input(input_path)
    decrypted = xor_systemfont_crp(encrypted)
    png_path = output / "systemfont_atlas.png"
    meta = export_tex_png_bytes(decrypted, png_path)
    meta.update(
        {
            "source_format": "SIIG systemfont CRP",
            "xor_key": "0xF1",
            "cell_width": 32,
            "cell_height": 32,
            "columns": 64,
            "rows": 106,
            "glyph_record_count": 6732,
        }
    )
    write_json_private(png_path.with_suffix(png_path.suffix + ".json"), meta)
    if args.write_decrypted_tex:
        (output / "systemfont_decrypted.tex").write_bytes(decrypted)
    print(f"{input_path}: decrypted XOR 0xF1 and exported {meta['width']}x{meta['height']} atlas -> {png_path}")
    return 0


def command_sanitize_json(args: argparse.Namespace) -> int:
    target = Path(args.input)
    if not target.exists():
        raise FormatError(f"input not found: {target}")
    files = [target] if target.is_file() else sorted(target.rglob("*.json"))
    changed = 0
    failed = 0
    for path in files:
        if path.suffix.lower() != ".json":
            continue
        try:
            original = path.read_text(encoding="utf-8")
            parsed = json.loads(original)
            sanitized = json.dumps(
                sanitize_json_value(parsed),
                ensure_ascii=False,
                indent=2,
            ) + "\n"
            if sanitized != original:
                if args.backup:
                    backup = path.with_suffix(path.suffix + ".bak")
                    if not backup.exists():
                        backup.write_text(original, encoding="utf-8")
                path.write_text(sanitized, encoding="utf-8")
                changed += 1
        except (OSError, json.JSONDecodeError) as exc:
            failed += 1
            print(f"warning: {path.name}: {scrub_private_text(exc)}", file=sys.stderr)
    print(f"sanitized: {changed} JSON file(s), {failed} failure(s)")
    return 1 if failed else 0


def command_scan(args: argparse.Namespace) -> int:
    path = Path(args.input)
    data = maybe_decompress(path.read_bytes())
    if data.startswith(BBX_MAGIC):
        archive = BBXArchive.parse(data)
        print(
            json.dumps(
                {
                    "format": "BBX",
                    "count": archive.count,
                    "mode": archive.mode,
                    "hash_seed": f"0x{archive.hash_seed:08X}",
                    "has_sorted_hash_index": bool(archive.sorted_index),
                    "entries": [asdict(e) for e in archive.entries],
                },
                indent=2,
            )
        )
        return 0
    if data.startswith(GMX_MAGIC):
        chunks = parse_gmx_chunks(data)
        arrays = [parse_gmx_array(c) for c in chunks if c.tag == "ARRY"]
        meshes = [parse_gmx_mesh(c) for c in chunks if c.tag == "MESH"]
        textures = [parse_gmx_texture_ref(c) for c in chunks if c.tag == "TXIF"]
        shaders = [parse_gmx_shader(c) for c in chunks if c.tag == "SHAD"]
        materials = [parse_gmx_material(c) for c in chunks if c.tag == "MTRL"]
        parents = [parse_gmx_parent_group(c) for c in chunks if c.tag == "PARE"]
        bones = [parse_gmx_bone(c) for c in chunks if c.tag == "BONE"]
        motions = [parse_gmx_motion(c) for c in chunks if c.tag == "MOTN"]
        animations = [parse_gmx_animation(c) for c in chunks if c.tag == "ANIM"]
        print(
            json.dumps(
                {
                    "format": "GMX",
                    "size": len(data),
                    "chunks": [{"offset": c.offset, "tag": c.tag, "size": c.size} for c in chunks],
                    "arrays": [
                        {
                            "index": a.array_index,
                            "semantic": a.semantic,
                            "slot": a.slot,
                            "components": a.components,
                            "gl_type": f"0x{a.gl_type:X}",
                            "count": a.count,
                        }
                        for a in arrays
                    ],
                    "meshes": [
                        {
                            "index": m.mesh_index,
                            "primitive_mode": f"0x{m.primitive_mode:X}",
                            "index_count": m.index_count,
                            "skin_index": m.skin_index,
                            "array_refs": m.array_refs,
                        }
                        for m in meshes
                    ],
                    "textures": [asdict(item) for item in textures],
                    "shaders": [asdict(item) for item in shaders],
                    "materials": [
                        {
                            "index": item.index,
                            "name": item.name,
                            "shader_index": item.shader_index,
                            "parameters": [asdict(parameter) for parameter in item.parameters],
                        }
                        for item in materials
                    ],
                    "hierarchy": [asdict(item) for item in parents],
                    "bones": [
                        {
                            "index": item.index,
                            "name": item.name,
                            "material_index": item.material_index,
                            "mesh_index": item.mesh_index,
                            "matrix": list(item.matrix),
                        }
                        for item in bones
                    ],
                    "motions": [asdict(item) for item in motions],
                    "animations": [
                        {
                            "index": item.index,
                            "target_bone": item.target_bone,
                            "channel_type": item.channel_type,
                            "frame_count": len(item.times),
                            "duration": item.times[-1] if item.times else 0.0,
                        }
                        for item in animations
                    ],
                },
                indent=2,
            )
        )
        return 0
    if looks_like_xwb(data):
        xsb_path = path.with_suffix(".xsb")
        preliminary = parse_xwb(data)
        cue_names = parse_xsb_cue_names(
            xsb_path.read_bytes() if xsb_path.exists() else b"",
            len(preliminary.entries),
            preliminary.bank_name,
        )
        info = parse_xwb(data, cue_names)
        print(
            json.dumps(
                {
                    "format": "XACT_XWB",
                    "version": info.version,
                    "endian": info.endian,
                    "bank_name": info.bank_name,
                    "bank_flags": f"0x{info.bank_flags:08X}",
                    "alignment": info.alignment,
                    "stream_count": len(info.entries),
                    "entries": [asdict(entry) for entry in info.entries],
                },
                indent=2,
            )
        )
        return 0
    if data.startswith(MAP_MAGIC):
        parsed = parse_map_bytes(data)
        printable = {
            "format": parsed["format"],
            "layer_count": parsed["layer_count"],
            "layers": [
                {key: value for key, value in layer.items() if key != "cells"}
                for layer in parsed["layers"]
            ],
        }
        print(json.dumps(printable, indent=2))
        return 0
    if path.suffix.lower() == ".dat" or (len(data) >= 3 and data[0] == 1):
        try:
            parsed = parse_dat_bytes(data)
        except FormatError:
            parsed = None
        if parsed is not None:
            print(json.dumps(parsed, indent=2))
            return 0
    if looks_like_systemfont_crp(data):
        decrypted = xor_systemfont_crp(data)
        info = asdict(parse_tex(decrypted))
        info["texture_format"] = f"0x{info.pop('format'):X}"
        info["fetch_dwords"] = [f"0x{value:08X}" for value in info["fetch_dwords"]]
        info["swizzle"] = list(info["swizzle"])
        print(json.dumps({"format": "SIIG_SYSTEMFONT_CRP", "xor_key": "0xF1", **info}, indent=2))
        return 0
    if looks_like_tex(data):
        info = asdict(parse_tex(data))
        info["texture_format"] = f"0x{info.pop('format'):X}"
        info["fetch_dwords"] = [f"0x{value:08X}" for value in info["fetch_dwords"]]
        info["swizzle"] = list(info["swizzle"])
        print(json.dumps({"format": "TEX", "platform": "xbox360", **info}, indent=2))
        return 0
    if looks_like_ps3_tex(data):
        print(json.dumps({"format": "TEX", **asdict(parse_ps3_tex(data))}, indent=2))
        return 0
    raise FormatError("unrecognized input (not BBX, gzip->BBX, GMX, TEX, DAT, MAP, XWB, or systemfont CRP)")



TOOLKIT_VERSION = "1.8.0"
NPD_MAGIC = b"NPD\x00"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_extract_zip(zip_path: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    with zipfile.ZipFile(zip_path) as archive:
        for info in archive.infolist():
            member = Path(info.filename.replace("\\", "/"))
            if member.is_absolute() or ".." in member.parts:
                raise FormatError(f"unsafe ZIP member: {info.filename}")
            target = (destination / member).resolve()
            if root != target and root not in target.parents:
                raise FormatError(f"ZIP member escapes destination: {info.filename}")
        archive.extractall(destination)


def detect_game_platform(root: Path) -> tuple[str, Path]:
    xex_files = sorted(root.rglob("default.xex"))
    eboot_files = sorted(root.rglob("EBOOT.BIN"))
    if xex_files and not eboot_files:
        return "xbox360", xex_files[0].parent
    if eboot_files and not xex_files:
        eboot = eboot_files[0]
        # The main PS3 content is under NPUB.../USRDIR. Use the title directory
        # so metadata files such as PARAM.SFO are included in the inventory.
        return "ps3", eboot.parent.parent if eboot.parent.name.upper() == "USRDIR" else eboot.parent
    if xex_files:
        return "xbox360", xex_files[0].parent
    if eboot_files:
        eboot = eboot_files[0]
        return "ps3", eboot.parent.parent if eboot.parent.name.upper() == "USRDIR" else eboot.parent
    raise FormatError("could not detect Xbox 360 default.xex or PS3 EBOOT.BIN")


def _decrypted_sdat_lookup(search_roots: Sequence[Path]) -> dict[str, Path]:
    found: dict[str, Path] = {}
    for root in search_roots:
        if not root.exists():
            continue
        candidates = [root] if root.is_file() else root.rglob("*")
        for path in candidates:
            if not path.is_file():
                continue
            name = path.name.lower()
            if name.endswith(".bin.gz.dat"):
                found.setdefault(name, path)
    return found


def _archive_basename(name: str) -> str:
    lowered = name.lower()
    result = name
    for suffix in (".sdat", ".dat", ".gz", ".bin"):
        if result.lower().endswith(suffix):
            result = result[: -len(suffix)]
    return result or "archive"


def _copy_ready_file(path: Path, game_root: Path, output_root: Path) -> Path:
    try:
        relative = path.relative_to(game_root)
    except ValueError:
        relative = Path(path.name)
    target = output_root / "ready_files" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    return target


def _privacy_audit_json(root: Path) -> dict:
    suspicious: list[dict] = []
    drive_re = re.compile(r"(?i)(?<![A-Za-z0-9_:/])[A-Z]:[\\/]")
    for path in sorted(root.rglob("*.json")):
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        hits: list[str] = []
        if drive_re.search(text):
            hits.append("windows_absolute_path")
        # Avoid flagging game-internal /foo.bin strings; require two path components.
        if re.search(r'(?<![A-Za-z0-9_])/(?:[^/\s\"]+/){2,}[^/\s\"]*', text):
            hits.append("posix_absolute_path")
        if hits:
            suspicious.append({"file": path.relative_to(root).as_posix(), "issues": hits})
    return {"files_checked": len(list(root.rglob("*.json"))), "suspicious": suspicious}


def _write_rip_report(output_root: Path, report: dict) -> None:
    validation = output_root / "validation"
    validation.mkdir(parents=True, exist_ok=True)
    write_json_private(validation / "RIP_REPORT.json", report, ensure_ascii=False)
    lines = [
        "Space Invaders Infinity Gene full-game rip report",
        f"Toolkit: {report['toolkit_version']}",
        f"Platform: {report['platform']}",
        f"Archives processed: {report['archives']['processed']}",
        f"Archives skipped: {report['archives']['skipped']}",
        f"Archives failed: {report['archives']['failed']}",
        f"Resources extracted: {report['archives']['resources']}",
        f"BBX hash mismatches: {report['archives']['hash_mismatches']}",
        f"PNG textures: {report['outputs']['png']}",
        f"glTF models: {report['outputs']['gltf']}",
        f"OBJ models: {report['outputs']['obj']}",
        f"WAV audio: {report['outputs']['wav']}",
        f"Ready files copied: {report['outputs']['ready_files']}",
        f"Missing PS3 SDAT decryptions: {len(report['ps3_sdat']['missing'])}",
        f"Unsupported/retained resources: {len(report['unsupported'])}",
        f"Errors: {len(report['errors'])}",
        f"Privacy audit issues: {len(report['privacy_audit']['suspicious'])}",
    ]
    if report["ps3_sdat"]["missing"]:
        lines += ["", "PS3 SDAT files still requiring TrueAncestor decryption:"]
        lines += [f"- {item}" for item in report["ps3_sdat"]["missing"]]
    if report["errors"]:
        lines += ["", "Errors:"]
        lines += [f"- {item['file']}: {item['error']}" for item in report["errors"]]
    (validation / "RIP_REPORT.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def command_rip_game(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output_root = Path(args.output)
    if not input_path.exists():
        raise FormatError(f"input not found: {input_path}")
    if output_root.exists() and args.clean:
        shutil.rmtree(output_root)
    output_root.mkdir(parents=True, exist_ok=True)

    temp_context: Optional[tempfile.TemporaryDirectory] = None
    try:
        if input_path.is_file() and input_path.suffix.lower() == ".zip":
            temp_context = tempfile.TemporaryDirectory(prefix="siig_rip_")
            staged_root = Path(temp_context.name)
            print(f"extracting input ZIP: {input_path.name}")
            _safe_extract_zip(input_path, staged_root)
            source_kind = "zip"
        elif input_path.is_dir():
            staged_root = input_path
            source_kind = "directory"
        else:
            raise FormatError("rip-game input must be a game directory or ZIP")

        platform, game_root = detect_game_platform(staged_root)
        content_root = game_root / "USRDIR" if platform == "ps3" and (game_root / "USRDIR").is_dir() else game_root
        print(f"detected platform: {platform}; content root: {game_root.name}")

        decrypted_roots = [Path(value) for value in (args.ps3_sdat_dir or [])]
        # TrueAncestor outputs may also be placed inside or next to the selected input.
        decrypted_roots.extend([staged_root, input_path.parent])
        decrypted_lookup = _decrypted_sdat_lookup(decrypted_roots)

        report: dict = {
            "toolkit_version": TOOLKIT_VERSION,
            "platform": platform,
            "source_kind": source_kind,
            "game_root": game_root.name,
            "files_scanned": sum(1 for p in game_root.rglob("*") if p.is_file()),
            "archives": {"processed": 0, "skipped": 0, "failed": 0, "resources": 0, "hash_mismatches": 0},
            "ps3_sdat": {"decrypted_used": [], "missing": []},
            "outputs": {},
            "unsupported": [],
            "errors": [],
        }

        bbx_source_root = output_root / "decompressed_bbx"
        assets_root = output_root / "assets"
        localization_inputs: list[Path] = []
        systemfont_inputs: list[Path] = []
        x360_sound_inputs: list[Path] = []

        candidates = sorted(path for path in content_root.rglob("*") if path.is_file())
        for source in candidates:
            relative = source.relative_to(game_root)
            raw_head = source.read_bytes()[:4]
            lowered = source.name.lower()
            data: Optional[bytes] = None
            actual_source = source

            if raw_head == NPD_MAGIC:
                expected = source.name[:-5] + ".dat" if lowered.endswith(".sdat") else source.name + ".dat"
                replacement = decrypted_lookup.get(expected.lower())
                if replacement is None:
                    report["ps3_sdat"]["missing"].append(relative.as_posix())
                    report["archives"]["skipped"] += 1
                    continue
                actual_source = replacement
                report["ps3_sdat"]["decrypted_used"].append({
                    "original": relative.as_posix(),
                    "decrypted": replacement.name,
                })
                try:
                    data = maybe_decompress(replacement.read_bytes())
                except Exception as exc:
                    report["errors"].append({"file": relative.as_posix(), "error": scrub_private_text(exc)})
                    report["archives"]["failed"] += 1
                    continue
            elif raw_head[:2] == b"\x1F\x8B":
                try:
                    data = maybe_decompress(source.read_bytes())
                except Exception as exc:
                    report["errors"].append({"file": relative.as_posix(), "error": scrub_private_text(exc)})
                    report["archives"]["failed"] += 1
                    continue
            elif raw_head == BBX_MAGIC:
                data = source.read_bytes()
            else:
                continue

            if not data.startswith(BBX_MAGIC):
                continue

            archive_base = _archive_basename(source.name)
            relative_parent = relative.parent
            archive_out = assets_root / relative_parent / archive_base
            bbx_out = bbx_source_root / relative_parent / f"{archive_base}.bin"
            fingerprint = hashlib.sha256(data).hexdigest()
            conversion_profile = (
                f"sha256={fingerprint};gltf={int(not args.no_gltf)};"
                f"obj={int(bool(args.convert_obj))};tex={int(not args.no_textures)};flipv={int(bool(args.flip_v))}"
            )
            cache_path = archive_out / ".siig_source_state"
            if (
                args.resume
                and cache_path.exists()
                and cache_path.read_text(encoding="ascii", errors="ignore").strip() == conversion_profile
                and (archive_out / "manifest.json").exists()
            ):
                print(f"resume: unchanged archive skipped: {relative.as_posix()}")
                report["archives"]["skipped"] += 1
                try:
                    cached_manifest = json.loads((archive_out / "manifest.json").read_text(encoding="utf-8"))
                    report["archives"]["resources"] += int(cached_manifest.get("count", 0))
                    report["archives"]["hash_mismatches"] += sum(
                        1 for row in cached_manifest.get("entries", [])
                        if row.get("name") and row.get("hash_matches") is False
                    )
                except (OSError, json.JSONDecodeError, TypeError, ValueError):
                    pass
                if "message.bin" in lowered or "text.bin" in lowered:
                    localization_inputs.append(bbx_out if bbx_out.exists() else actual_source)
                if "systemfont.bin" in lowered:
                    systemfont_inputs.append(bbx_out if bbx_out.exists() else actual_source)
                if source.name.lower() == "sound.bin" and platform == "xbox360":
                    x360_sound_inputs.append(bbx_out if bbx_out.exists() else source)
                continue

            if archive_out.exists():
                shutil.rmtree(archive_out)
            archive_out.mkdir(parents=True, exist_ok=True)
            bbx_out.parent.mkdir(parents=True, exist_ok=True)
            bbx_out.write_bytes(data)
            try:
                result = extract_bbx_bytes(
                    data,
                    archive_out,
                    relative.as_posix(),
                    recursive=True,
                    convert_gmx=bool(args.convert_obj),
                    convert_gltf=not args.no_gltf,
                    convert_tex=not args.no_textures,
                    flip_v=bool(args.flip_v),
                )
                cache_path.write_text(conversion_profile + "\n", encoding="ascii")
                report["archives"]["processed"] += 1
                report["archives"]["resources"] += int(result.get("count", 0))
                report["archives"]["hash_mismatches"] += sum(
                    1 for row in result.get("entries", []) if row.get("name") and row.get("hash_matches") is False
                )
                print(f"{relative.as_posix()}: extracted {result['count']} resources")
            except Exception as exc:
                report["archives"]["failed"] += 1
                report["errors"].append({"file": relative.as_posix(), "error": scrub_private_text(exc)})
                print(f"ERROR {relative.as_posix()}: {exc}", file=sys.stderr)
                continue

            if "message.bin" in lowered or "text.bin" in lowered:
                localization_inputs.append(bbx_out)
            if "systemfont.bin" in lowered:
                systemfont_inputs.append(bbx_out)
            if source.name.lower() == "sound.bin" and platform == "xbox360":
                x360_sound_inputs.append(bbx_out)

        # Ready-to-use files are copied without conversion.
        ready_suffixes = {".wma", ".at3", ".png", ".sfo", ".xml"}
        copied_ready: list[str] = []
        for source in candidates:
            if source.suffix.lower() in ready_suffixes:
                target = _copy_ready_file(source, game_root, output_root)
                copied_ready.append(target.relative_to(output_root).as_posix())

        # Dedicated localization exports combine both language databases.
        localization_root = output_root / "localization"
        localization_results = 0
        for path in localization_inputs:
            try:
                decode_localization_file(path, localization_root)
                localization_results += 1
            except Exception as exc:
                report["errors"].append({"file": path.name, "error": scrub_private_text(exc)})

        # Dedicated system-font package, including the atlas and supplied glyph map.
        font_root = output_root / "systemfont"
        for path in systemfont_inputs[:1]:
            try:
                command_font2png(argparse.Namespace(input=str(path), output=str(font_root), write_decrypted_tex=False))
                toolkit_dir = Path(__file__).resolve().parent
                for name in ("systemfont.fnt", "systemfont_glyphs.csv", "systemfont_metadata.json", "SYSTEMFONT_NOTES.md"):
                    source_meta = toolkit_dir / name
                    if source_meta.exists():
                        shutil.copy2(source_meta, font_root / name)
            except Exception as exc:
                report["errors"].append({"file": path.name, "error": scrub_private_text(exc)})

        # Xbox 360 XACT conversion. PS3's Sony SBlk/VAG bank is retained as .bnk
        # by the BBX extractor and listed as externally decodable via vgmstream.
        if x360_sound_inputs and not args.no_audio:
            try:
                command_xact2wav(argparse.Namespace(
                    input=str(x360_sound_inputs[0]),
                    output=str(output_root / "audio" / "xact"),
                    ffmpeg=args.ffmpeg,
                    keep_xma=False,
                ))
            except Exception as exc:
                report["errors"].append({"file": x360_sound_inputs[0].name, "error": scrub_private_text(exc)})

        if platform == "ps3":
            banks = list(assets_root.rglob("*.bnk"))
            for bank in banks:
                report["unsupported"].append({
                    "file": bank.relative_to(output_root).as_posix(),
                    "format": "Sony 989SND/SCREAM SBlk bank",
                    "note": "Extracted losslessly; use vgmstream-cli for individual VAG streams.",
                })

        collision_converted = 0
        for col_path in sorted(assets_root.rglob("*.col")):
            try:
                export_col_png_bytes(
                    col_path.read_bytes(),
                    col_path.with_suffix(col_path.suffix + ".png"),
                )
                collision_converted += 1
            except Exception as exc:
                report["errors"].append({
                    "file": col_path.relative_to(output_root).as_posix(),
                    "error": scrub_private_text(exc),
                })

        anm_converted = 0
        for anm_path in sorted(assets_root.rglob("*.anm")):
            try:
                export_anm_csv_bytes(
                    anm_path.read_bytes(),
                    anm_path.with_suffix(anm_path.suffix + ".csv"),
                )
                anm_converted += 1
            except Exception as exc:
                report["errors"].append({
                    "file": anm_path.relative_to(output_root).as_posix(),
                    "error": scrub_private_text(exc),
                })

        dat_converted = 0
        dat_root = output_root / "structured" / "dat"
        for dat_path in sorted(assets_root.rglob("*.dat")):
            try:
                relative = dat_path.relative_to(assets_root)
                export_dat_csv_bytes(
                    dat_path.read_bytes(),
                    dat_root / relative.parent / f"{relative.name}.csv",
                )
                dat_converted += 1
            except Exception as exc:
                report["errors"].append({
                    "file": dat_path.relative_to(output_root).as_posix(),
                    "error": scrub_private_text(exc),
                })

        map_converted = 0
        map_root = output_root / "structured" / "map"
        for map_path in sorted(assets_root.rglob("*.map")):
            try:
                relative = map_path.relative_to(assets_root)
                export_map_png_bytes(
                    map_path.read_bytes(),
                    map_root / relative.parent / relative.name,
                )
                map_converted += 1
            except Exception as exc:
                report["errors"].append({
                    "file": map_path.relative_to(output_root).as_posix(),
                    "error": scrub_private_text(exc),
                })

        report["outputs"] = {
            "png": len(list(output_root.rglob("*.png"))),
            "gltf": len(list(output_root.rglob("*.gltf"))),
            "obj": len(list(output_root.rglob("*.obj"))),
            "wav": len(list(output_root.rglob("*.wav"))),
            "wma": len(list(output_root.rglob("*.wma"))),
            "bnk": len(list(output_root.rglob("*.bnk"))),
            "collision_png": collision_converted,
            "anm_csv": anm_converted,
            "dat_csv": dat_converted,
            "map_files": map_converted,
            "localization_archives": localization_results,
            "ready_files": len(copied_ready),
        }
        report["privacy_audit"] = _privacy_audit_json(output_root)
        _write_rip_report(output_root, report)

        print("\nFull-game rip complete")
        print(f"  platform: {platform}")
        print(f"  archives: {report['archives']['processed']} processed, {report['archives']['failed']} failed")
        print(f"  resources: {report['archives']['resources']}")
        print(f"  textures: {report['outputs']['png']} PNG")
        print(f"  models: {report['outputs']['gltf']} glTF")
        print(f"  audio: {report['outputs']['wav']} WAV, {report['outputs']['wma']} WMA retained")
        print(f"  report: {output_root / 'validation' / 'RIP_REPORT.txt'}")
        return 1 if report["archives"]["failed"] or report["errors"] else 0
    finally:
        if temp_context is not None:
            temp_context.cleanup()

def command_credits(args: argparse.Namespace) -> int:
    root = Path(__file__).resolve().parent
    print("SIIG Asset Toolkit attribution and provenance")
    for name in (
        "CREDITS.md",
        "SOURCES.csv",
        "PROVENANCE.json",
        "SOURCE_AUDIT.md",
        "THIRD_PARTY_NOTICES.md",
        "AI_DISCLOSURE.md",
        "ATTRIBUTION_POLICY.md",
        "PROJECT_LICENSE_STATUS.md",
    ):
        path = root / name
        print(f"  {name}: {'present' if path.exists() else 'missing'}")
    print("Adapted code: Xenia-derived Xenos tiled-texture addressing (BSD-3-Clause).")
    print("No third-party binaries or libraries are bundled.")
    return 0


def command_stageviz(args: argparse.Namespace) -> int:
    from siig_stageviz import build_stage_explorer
    manifest = build_stage_explorer(Path(args.input), Path(args.output))
    commands = sum(stage["commands"] for stage in manifest["stages"])
    map_cells = sum(stage["map_cells"] for stage in manifest["stages"])
    print(f"stage explorer: {manifest['stage_count']} stage(s), {commands} command(s), {map_cells} MAP cell(s)")
    print(f"open: {Path(args.output) / 'SIIG_Stage_Explorer.html'}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    p_credits = sub.add_parser(
        "credits",
        help="show attribution, source-provenance, license, and AI-disclosure records",
    )
    p_credits.set_defaults(func=command_credits)

    p_rip = sub.add_parser(
        "rip-game",
        help="one-click Xbox 360/PS3 full-game extraction, conversion, and validation",
    )
    p_rip.add_argument("input", help="original game directory or ZIP")
    p_rip.add_argument("-o", "--output", default="SIIG_Ripped", help="output directory")
    p_rip.add_argument(
        "--ps3-sdat-dir",
        action="append",
        help="directory containing TrueAncestor .bin.gz.dat outputs (repeatable)",
    )
    p_rip.add_argument("--clean", action="store_true", help="delete the output directory before starting")
    p_rip.add_argument("--resume", action="store_true", help="skip unchanged archives already extracted")
    p_rip.add_argument("--no-gltf", action="store_true", help="skip GMX to glTF conversion")
    p_rip.add_argument("--convert-obj", action="store_true", help="also write legacy OBJ models")
    p_rip.add_argument("--no-textures", action="store_true", help="skip TEX/font PNG conversion")
    p_rip.add_argument("--no-audio", action="store_true", help="skip Xbox 360 XACT to WAV conversion")
    p_rip.add_argument("--ffmpeg", help="path/name of FFmpeg executable")
    p_rip.add_argument("--flip-v", action="store_true", help="flip model texture V coordinates")
    p_rip.set_defaults(func=command_rip_game)

    p_extract = sub.add_parser("extract", help="extract one BBX archive or every BBX in a directory")
    p_extract.add_argument("input", help="input .bin/.gz file or directory")
    p_extract.add_argument("-o", "--output", default="siig_extracted", help="output directory")
    p_extract.add_argument("--recursive", action="store_true", help="recursively extract nested BBX payloads")
    p_extract.add_argument("--convert-gmx", action="store_true", help="also convert extracted GMX geometry to OBJ")
    p_extract.add_argument(
        "--convert-gltf",
        action="store_true",
        help="also export GMX hierarchy, materials and animations to glTF 2.0",
    )
    p_extract.add_argument("--convert-tex", action="store_true", help="also convert extracted TEX textures to PNG")
    p_extract.add_argument("--flip-v", action="store_true", help="flip texture V coordinates for OBJ/glTF output")
    p_extract.set_defaults(func=command_extract)

    p_gmx = sub.add_parser("gmx2obj", help="convert one GMX or a directory of GMX files to OBJ")
    p_gmx.add_argument("input", help="input .gmx file or directory")
    p_gmx.add_argument("-o", "--output", default="siig_obj", help="output directory")
    p_gmx.add_argument("--flip-v", action="store_true", help="flip the OBJ texture V coordinate")
    p_gmx.set_defaults(func=command_gmx2obj)

    p_gltf = sub.add_parser(
        "gmx2gltf",
        help="export GMX geometry, hierarchy, materials and animation tracks to glTF 2.0",
    )
    p_gltf.add_argument("input", help="input .gmx file or directory")
    p_gltf.add_argument("-o", "--output", default="siig_gltf", help="output directory")
    p_gltf.add_argument("--flip-v", action="store_true", help="flip the glTF texture V coordinate")
    p_gltf.add_argument(
        "--texture-root",
        action="append",
        help="additional directory to search recursively for TXIF-referenced DDS/TEX files",
    )
    p_gltf.set_defaults(func=command_gmx2gltf)

    p_tex = sub.add_parser("tex2png", help="convert one TEX or a directory of TEX files to PNG")
    p_tex.add_argument("input", help="input .tex file or directory")
    p_tex.add_argument("-o", "--output", default="siig_png", help="output directory")
    p_tex.set_defaults(func=command_tex2png)

    p_col = sub.add_parser("col2png", help="convert one-bit SIIG collision masks to PNG")
    p_col.add_argument("input", help="input .col file or directory")
    p_col.add_argument("-o", "--output", default="siig_collision", help="output directory")
    p_col.add_argument("--invert", action="store_true", help="invert black and white pixels")
    p_col.set_defaults(func=command_col2png)

    p_anm = sub.add_parser("anm2csv", help="decode standalone SIIG ANM tables to CSV and JSON")
    p_anm.add_argument("input", help="input .anm file or directory")
    p_anm.add_argument("-o", "--output", default="siig_anm", help="output directory")
    p_anm.set_defaults(func=command_anm2csv)

    p_dat = sub.add_parser("dat2csv", help="decode SIIG DAT command streams to timed CSV and JSON")
    p_dat.add_argument("input", help="input .dat file or directory")
    p_dat.add_argument("-o", "--output", default="siig_dat", help="output directory")
    p_dat.set_defaults(func=command_dat2csv)

    p_map = sub.add_parser("map2png", help="decode SIIG MAP byte-grid layers to PNG and JSON")
    p_map.add_argument("input", help="input .map file or directory")
    p_map.add_argument("-o", "--output", default="siig_map", help="output directory")
    p_map.add_argument("--scale", type=int, default=1, help="nearest-neighbor display scale (1-64)")
    p_map.add_argument("--grayscale", action="store_true", help="use cell values as grayscale instead of categorical colors")
    p_map.add_argument("--csv", action="store_true", help="also write every layer as a numeric CSV grid")
    p_map.set_defaults(func=command_map2png)

    p_stage = sub.add_parser("stageviz", help="build a self-contained stage MAP and DAT timeline explorer")
    p_stage.add_argument("input", help="full rip directory, game Media directory, or directory containing script/map")
    p_stage.add_argument("-o", "--output", default="siig_stage_explorer", help="output directory")
    p_stage.set_defaults(func=command_stageviz)

    p_font = sub.add_parser("font2png", help="decrypt systemfont.bin/systemfont.crp and export the glyph atlas")
    p_font.add_argument("input", help="input systemfont.bin, systemfont.bin.gz, or extracted systemfont.crp")
    p_font.add_argument("-o", "--output", default="siig_systemfont", help="output directory")
    p_font.add_argument("--write-decrypted-tex", action="store_true", help="also save the decrypted TEX payload")
    p_font.set_defaults(func=command_font2png)

    p_audio = sub.add_parser(
        "xact2wav",
        help="extract XACT XWB/XSB audio from sound.bin or convert XWB banks to WAV",
    )
    p_audio.add_argument("input", help="sound.bin/BBX, an .xwb file, or a directory containing XWB/XSB files")
    p_audio.add_argument("-o", "--output", default="siig_audio", help="output directory")
    p_audio.add_argument(
        "--ffmpeg",
        help="path/name of FFmpeg executable (auto-detected from PATH when omitted)",
    )
    p_audio.add_argument(
        "--keep-xma",
        action="store_true",
        help="keep the intermediate RIFF-wrapped .xma files after successful WAV decoding",
    )
    p_audio.set_defaults(func=command_xact2wav)


    p_text = sub.add_parser(
        "text2csv",
        help="decode message.bin/text.bin localization data to UTF-8 CSV, JSON, and text",
    )
    p_text.add_argument("input", help="message.bin, text.bin, or a directory containing both")
    p_text.add_argument("-o", "--output", default="siig_text", help="output directory")
    p_text.set_defaults(func=command_text2csv)

    p_sanitize = sub.add_parser(
        "sanitize-json",
        help="remove absolute local filesystem routes from existing JSON metadata in place",
    )
    p_sanitize.add_argument("input", help="JSON file or directory tree containing generated JSON metadata")
    p_sanitize.add_argument(
        "--backup",
        action="store_true",
        help="save each changed original as .json.bak before sanitizing",
    )
    p_sanitize.set_defaults(func=command_sanitize_json)

    p_scan = sub.add_parser("scan", help="print a JSON description of a BBX, GMX, TEX, DAT, MAP, XWB, or systemfont CRP file")
    p_scan.add_argument("input")
    p_scan.set_defaults(func=command_scan)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (OSError, FormatError, gzip.BadGzipFile) as exc:
        parser.error(str(exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
