# AI-assisted development disclosure

OpenAI ChatGPT was used as an active research and development assistant for this
project. Its roles included:

- suggesting reverse-engineering hypotheses;
- interpreting user-supplied Ghidra output and binary samples;
- drafting Python and Java code;
- producing tests, validation scripts, reports, and documentation;
- helping organize release artifacts and provenance records.

The project owner supplied the game packages, prototype builds, Ghidra exports,
PS3 SDAT decryptions, and real-hardware/emulator verification. Important claims
were checked against the supplied corpus and, where possible, validated across
all matching files rather than accepted from AI output alone.

No original game source code was available. The work is based on black-box file
comparison, binary inspection, and decompiler/listing evidence. Game binaries
and copyrighted game assets are not included in the toolkit release.

## Scope of source disclosure

This project can disclose every external source explicitly consulted during the
work and every code block intentionally adapted from another project. Those are
recorded in `SOURCES.csv` and `PROVENANCE.json`.

It is not possible for this project to enumerate the full training dataset or
all latent influences of the AI model. Therefore, the ethical safeguard is a
release-time source audit: identify direct adaptations, preserve licenses,
avoid unclear-license code, keep external tools unbundled, and document the AI
role openly.

AI-generated code may contain mistakes or accidental similarities. Public
releases should continue to receive human review and source-overlap/license
checks.
