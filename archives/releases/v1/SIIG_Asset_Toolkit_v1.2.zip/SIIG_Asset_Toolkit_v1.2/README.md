# Space Invaders Infinity Gene Xbox 360 Asset Toolkit

**Version 1.2 — system font decoding added**

This toolkit extracts and converts assets from the Xbox 360 version of **Space Invaders Infinity Gene**. It was derived from the supplied game containers and cross-checked against the supplied `default.xex` Ghidra export.

## What works

- **BBX extraction** (`01 42 42 58` magic)
  - named and unnamed entries
  - nested BBX archives
  - standard `.gz` files whose decompressed content is BBX
  - original filename hierarchy, including `se/` and `bgm/`
  - exact filename-hash verification
  - CSV and JSON manifests
- **GMX → OBJ**
  - positions, normals, UVs and indexed geometry
  - triangle meshes and line meshes
  - multiple meshes per GMX
  - per-model JSON metadata
- **TEX → PNG**
  - corrected Xbox 360 tiled `8_8_8_8` decoding
  - correct Xenos bank/pipe addressing, 8-in-32 endian conversion and channel swizzle
  - original logical dimensions, excluding physical pitch padding
- **System font → PNG atlas**
  - accepts `systemfont.bin`, `systemfont.bin.gz`, or extracted `systemfont.crp`
  - removes the game's bytewise XOR `0xF1` obfuscation
  - exports the underlying 2048×3392 Xbox 360 texture atlas
  - optional decrypted `.tex` output
  - includes the executable-derived 6,732-record glyph mapping/metrics table
  - includes an AngelCode BMFont descriptor for the native Unicode mappings
- **Ghidra labels**
  - optional script that renames confirmed BBX, GMX, TEX and resource-table functions

Only Python 3.9 or newer is required. The main tool uses the Python standard library only.

## Quick start

Open Command Prompt or PowerShell in the toolkit folder.

### Decode the system font

Directly from the BBX container:

```bat
python siig_toolkit.py font2png "C:\path\to\systemfont.bin" -o systemfont_decoded
```

Or from the extracted resource:

```bat
python siig_toolkit.py font2png "C:\path\to\systemfont.crp" -o systemfont_decoded
```

Also preserve the decrypted texture payload:

```bat
python siig_toolkit.py font2png "C:\path\to\systemfont.bin" -o systemfont_decoded --write-decrypted-tex
```

The output is:

```text
systemfont_decoded\
├── systemfont_atlas.png
├── systemfont_atlas.png.json
└── systemfont_decrypted.tex       (only with --write-decrypted-tex)
```

Place the included `systemfont.fnt` and `systemfont_glyphs.csv` beside `systemfont_atlas.png` when using the mapping data.

### Extract one container

```bat
python siig_toolkit.py extract "C:\path\to\player.bin" -o extracted --convert-gmx --convert-tex
```

### Extract every BBX container in a directory

```bat
python siig_toolkit.py extract "C:\path\to\game_bins" -o extracted --recursive --convert-gmx --convert-tex
```

`--recursive` is important for `sound.bin`, whose audio banks are inside nested BBX archives. `--convert-tex` also detects and converts `systemfont.crp` after extraction.

### Convert extracted GMX files separately

```bat
python siig_toolkit.py gmx2obj extracted -o obj
```

Add `--flip-v` if your model viewer expects vertically inverted texture coordinates:

```bat
python siig_toolkit.py gmx2obj extracted -o obj --flip-v
```

### Convert extracted TEX files separately

```bat
python siig_toolkit.py tex2png extracted -o png
```

### Inspect a file without extracting it

```bat
python siig_toolkit.py scan player.bin
python siig_toolkit.py scan plr_001.gmx
python siig_toolkit.py scan button_A.tex
python siig_toolkit.py scan systemfont.crp
```

## System font details

`systemfont.crp` is not a conventional TTF/OTF font. It is a bytewise-XOR-obfuscated TEX texture. The game performs this sequence:

1. Open `/systemfont.bin.gz`.
2. Retrieve `systemfont.crp` from BBX.
3. XOR every byte with `0xF1`.
4. Pass the result to the ordinary texture loader.

After decryption, it is a normal game TEX:

```text
size              2048 × 3392
cell size         32 × 32
atlas grid        64 columns × 106 rows
texture format    Xenos 8_8_8_8 (format 6)
endian mode       8-in-32
layout            Xbox 360 tiled
```

The executable contains 6,732 glyph records beginning at virtual address `0x8200E508`. Each 12-byte record stores:

```text
+0x00  packed UTF-8 character bytes (4 bytes)
+0x04  glyph width in pixels (big-endian u32)
+0x08  left inset inside the 32-pixel cell (big-endian u32)
```

`systemfont_glyphs.csv` exposes these fields, atlas coordinates and known aliases. The game maps ordinary ASCII letters and digits to the fullwidth glyph records and renders them at half scale, so alias behavior is listed separately rather than baked into `systemfont.fnt`.

## Validation performed

- 23 top-level BBX containers
- 2,593 top-level resources
- 2,522 named entries with zero hash mismatches
- 486 GMX files examined
- 485 mesh-bearing GMX files converted
- 1,938 mesh sections
- 819,004 vertices and 1,456,924 indices
- 54 TEX files converted with the corrected untile mapping
- system font CRP decrypted and converted to a clean 2048×3392 glyph atlas
- 6,732 glyph records extracted from the executable; 6,730 have native Unicode mappings

## Current limitations

- GMX bones, animation tracks, materials and shader assignments are not yet exported. OBJ output is static geometry.
- `.anm`, `.col`, stage `.bin`, gameplay `.map`, generator/script `.dat` and shader payloads still need conversion work.
- The system font output is a bitmap atlas plus mapping/metrics, not a reconstructed vector TTF/OTF.
- Nested XACT `.xsb` and `.xwb` files are extracted, but audio streams are not converted.
- TEX conversion currently supports Xenos texture format 6 (`8_8_8_8`), which covers every supplied `.tex` file and the font atlas.
