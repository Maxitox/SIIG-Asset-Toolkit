# Changelog

## 1.1

- Fixed TEX untile addressing.
- Added the missing Y[3] XOR in the Xenos pipe selector.
- Eliminated repeating 8-row jitter/scrambling in converted PNG files.
- Revalidated all 54 supplied TEX files with zero conversion failures.

## 1.0

- Initial BBX extraction, GMX-to-OBJ and TEX-to-PNG release.
