#!/usr/bin/env python3
"""
Space Invaders Infinity Gene (Xbox 360) asset toolkit.

Confirmed by cross-checking the game files with the default.xex Ghidra export:
- Extracts BBX containers (magic 01 42 42 58), including unnamed and nested entries.
- Verifies the game-specific filename hash.
- Parses GMX chunk files and exports static mesh geometry to Wavefront OBJ.

Python 3.9+; standard library only.
"""

from __future__ import annotations

import argparse
import csv
from array import array
from functools import lru_cache
import gzip
import json
import math
import os
import re
import struct
import sys
import zlib
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Iterator, Optional, Sequence

BBX_MAGIC = b"\x01BBX"
GMX_MAGIC = b"GMX\x00"
MAP_MAGIC = b"MAP\x00"
GL_FLOAT = 0x1406
GL_UNSIGNED_SHORT = 0x1403
GL_LINES = 0x0001
GL_TRIANGLES = 0x0004
TEX_HEADER_SIZE = 0x34
XENOS_TEXFMT_8_8_8_8 = 6
XENOS_ENDIAN_NAMES = {0: "none", 1: "8in16", 2: "8in32", 3: "16in32"}
XENOS_TEXTURE_FORMAT_NAMES = {
    0: "1_REVERSE", 1: "1", 2: "8", 3: "1_5_5_5", 4: "5_6_5", 5: "6_5_5",
    6: "8_8_8_8", 7: "2_10_10_10", 8: "8_A", 9: "8_B", 10: "8_8",
    18: "DXT1", 19: "DXT2_3", 20: "DXT4_5", 49: "DXN", 60: "CTX1",
}


class FormatError(ValueError):
    pass


def be_u16(data: bytes, off: int) -> int:
    if off < 0 or off + 2 > len(data):
        raise FormatError(f"u16 read outside file at 0x{off:X}")
    return struct.unpack_from(">H", data, off)[0]


def be_u32(data: bytes, off: int) -> int:
    if off < 0 or off + 4 > len(data):
        raise FormatError(f"u32 read outside file at 0x{off:X}")
    return struct.unpack_from(">I", data, off)[0]


def read_c_string(data: bytes, off: int, max_len: int = 4096) -> str:
    if off <= 0 or off >= len(data):
        return ""
    end_limit = min(len(data), off + max_len)
    end = data.find(b"\0", off, end_limit)
    if end < 0:
        raise FormatError(f"unterminated string at 0x{off:X}")
    raw = data[off:end]
    return raw.decode("utf-8", errors="replace")


def safe_relative_path(name: str, fallback: str) -> Path:
    # Preserve legitimate archive subdirectories (notably sound/se and sound/bgm)
    # while preventing absolute paths and traversal outside the output folder.
    raw_parts = name.replace("\\", "/").split("/") if name else []
    parts: list[str] = []
    for raw in raw_parts:
        part = raw.strip()
        if part in {"", ".", ".."}:
            continue
        part = re.sub(r"[\x00-\x1F<>:\"|?*]", "_", part)[:120]
        if part:
            parts.append(part)
    if not parts:
        parts = [fallback]
    return Path(*parts)


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem, suffix = path.stem, path.suffix
    for n in range(1, 100000):
        candidate = path.with_name(f"{stem}_{n}{suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"could not find unique output name for {path}")


def rotl32(value: int, count: int) -> int:
    count &= 31
    value &= 0xFFFFFFFF
    if count == 0:
        return value
    return ((value << count) | (value >> (32 - count))) & 0xFFFFFFFF


def _s8(value: int) -> int:
    return value - 256 if value & 0x80 else value


def bbx_name_hash(name: str | bytes, seed: int = 0) -> int:
    """Reimplementation of default.xex Function_824739D0.

    BBX filenames in this title are ASCII. Passing bytes preserves arbitrary byte names.
    """
    raw = name.encode("utf-8") if isinstance(name, str) else bytes(name)
    result = 0
    running_sum = 0
    seed &= 0xFFFFFFFF

    for byte in raw:
        signed_byte = _s8(byte)
        running_sum = (running_sum + signed_byte) & 0xFFFFFFFF
        shift = running_sum & 31

        left = ((signed_byte & 0xFFFFFFFF) << shift) & 0xFFFFFFFF
        right_count = 32 - shift
        if right_count >= 32:
            shifted = -1 if signed_byte < 0 else 0
        else:
            shifted = signed_byte >> right_count

        # The PPC code sign-extends the low byte after the right shift.
        low = shifted & 0xFF
        sign_extended_low = _s8(low) & 0xFFFFFFFF
        rotated_seed = rotl32(seed, byte & 31)
        result = (result + rotated_seed + (left | sign_extended_low)) & 0xFFFFFFFF

    return result


@dataclass
class BBXEntry:
    index: int
    data_offset: int
    data_size: int
    name_offset: int
    identifier: int
    name: str
    hash_matches: Optional[bool]


@dataclass
class BBXArchive:
    data: bytes
    count: int
    mode: int
    hash_seed: int
    entries: list[BBXEntry]
    sorted_index: list[tuple[int, int]]

    @classmethod
    def parse(cls, data: bytes) -> "BBXArchive":
        if len(data) < 0x20:
            raise FormatError("file is too small for a BBX header")
        if data[:4] != BBX_MAGIC:
            raise FormatError(f"bad BBX magic: {data[:4].hex(' ')}")

        count = be_u32(data, 0x04)
        mode = be_u32(data, 0x08)
        hash_seed = be_u32(data, 0x0C)
        table_end = 0x20 + count * 0x10
        if table_end > len(data):
            raise FormatError(
                f"BBX entry table exceeds file: count={count}, end=0x{table_end:X}, size=0x{len(data):X}"
            )

        entries: list[BBXEntry] = []
        for index in range(count):
            rec = 0x20 + index * 0x10
            data_offset, data_size, name_offset, identifier = struct.unpack_from(">4I", data, rec)
            if data_offset > len(data) or data_size > len(data) - data_offset:
                raise FormatError(
                    f"entry {index}: payload outside file (offset=0x{data_offset:X}, size=0x{data_size:X})"
                )
            name = read_c_string(data, name_offset) if name_offset else ""
            match = None if not name else bbx_name_hash(name, hash_seed) == identifier
            entries.append(
                BBXEntry(index, data_offset, data_size, name_offset, identifier, name, match)
            )

        # The executable uses a sorted {hash,index} table for modes 0 and 1.
        sorted_index: list[tuple[int, int]] = []
        if mode < 2:
            index_end = table_end + count * 8
            if index_end <= len(data):
                for i in range(count):
                    h, resource_index = struct.unpack_from(">2I", data, table_end + i * 8)
                    if resource_index >= count:
                        # Avoid treating payload bytes as a table in malformed/unusual files.
                        sorted_index = []
                        break
                    sorted_index.append((h, resource_index))

        return cls(data, count, mode, hash_seed, entries, sorted_index)

    def payload(self, entry: BBXEntry) -> bytes:
        return self.data[entry.data_offset : entry.data_offset + entry.data_size]


def maybe_decompress(data: bytes) -> bytes:
    if data[:2] == b"\x1F\x8B":
        return gzip.decompress(data)
    return data


def looks_like_tex(data: bytes) -> bool:
    if len(data) < TEX_HEADER_SIZE:
        return False
    try:
        words = struct.unpack_from(">13I", data, 0)
    except struct.error:
        return False
    # All SIIG TEX samples are a 0x1C-byte D3D resource header followed by a
    # six-dword Xenos texture fetch constant and pixel data.
    if words[:5] != (3, 1, 0, 0, 0):
        return False
    fetch0, fetch1, fetch2 = words[7], words[8], words[9]
    width = (fetch2 & 0x1FFF) + 1
    height = ((fetch2 >> 13) & 0x1FFF) + 1
    fmt = fetch1 & 0x3F
    return (fetch0 & 3) == 2 and 0 < width <= 8192 and 0 < height <= 8192 and fmt < 64


def sniff_extension(payload: bytes) -> str:
    if payload.startswith(GMX_MAGIC):
        return ".gmx"
    if payload.startswith(MAP_MAGIC):
        return ".map"
    if payload.startswith(BBX_MAGIC):
        return ".bbx"
    if payload.startswith(b"RIFF"):
        return ".riff"
    if payload.startswith(b"FSGX"):
        return ".fsgx"
    if payload.startswith(b"XWB"):
        return ".xwb"
    if payload.startswith(b"XSB"):
        return ".xsb"
    if looks_like_tex(payload):
        return ".tex"
    return ".bin"


def extract_bbx_bytes(
    data: bytes,
    output_dir: Path,
    source_label: str,
    recursive: bool = False,
    convert_gmx: bool = False,
    convert_tex: bool = False,
    flip_v: bool = False,
) -> dict:
    archive = BBXArchive.parse(data)
    output_dir.mkdir(parents=True, exist_ok=True)

    manifest_rows: list[dict] = []
    nested_results: list[dict] = []

    for entry in archive.entries:
        payload = archive.payload(entry)
        fallback = f"{entry.index:04d}_{entry.identifier:08X}{sniff_extension(payload)}"
        relative_output = safe_relative_path(entry.name, fallback)
        destination = unique_path(output_dir / relative_output)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(payload)

        row = asdict(entry)
        row.update(
            {
                "output_file": destination.relative_to(output_dir).as_posix(),
                "payload_magic": payload[:8].hex(" ").upper(),
            }
        )
        manifest_rows.append(row)

        if convert_gmx and payload.startswith(GMX_MAGIC):
            try:
                chunks = parse_gmx_chunks(payload)
                if any(chunk.tag == "MESH" for chunk in chunks):
                    export_gmx_obj_bytes(payload, destination.with_suffix(".obj"), flip_v=flip_v)
                else:
                    scan_meta = {
                        "source_size": len(payload),
                        "mesh_count": 0,
                        "note": "This GMX has no MESH chunks; it may be hierarchy/animation-only.",
                        "chunks": [
                            {"offset": c.offset, "tag": c.tag, "size": c.size} for c in chunks
                        ],
                    }
                    destination.with_suffix(".gmx.json").write_text(
                        json.dumps(scan_meta, indent=2), encoding="utf-8"
                    )
            except Exception as exc:
                print(f"warning: GMX conversion failed for {destination}: {exc}", file=sys.stderr)

        if convert_tex and (destination.suffix.lower() == ".tex" or looks_like_tex(payload)):
            try:
                export_tex_png_bytes(payload, destination.with_suffix(".png"))
            except Exception as exc:
                print(f"warning: TEX conversion failed for {destination}: {exc}", file=sys.stderr)

        if recursive and payload.startswith(BBX_MAGIC):
            nested_dir = output_dir / f"{destination.stem}_nested"
            nested_results.append(
                extract_bbx_bytes(
                    payload,
                    nested_dir,
                    f"{source_label}:{entry.index}",
                    recursive=True,
                    convert_gmx=convert_gmx,
                    convert_tex=convert_tex,
                    flip_v=flip_v,
                )
            )

    manifest_csv = output_dir / "manifest.csv"
    fields = [
        "index",
        "name",
        "output_file",
        "data_offset",
        "data_size",
        "name_offset",
        "identifier",
        "hash_matches",
        "payload_magic",
    ]
    with manifest_csv.open("w", newline="", encoding="utf-8") as fp:
        writer = csv.DictWriter(fp, fieldnames=fields)
        writer.writeheader()
        for row in manifest_rows:
            writer.writerow({field: row.get(field) for field in fields})

    metadata = {
        "source": source_label,
        "magic": "01 42 42 58",
        "count": archive.count,
        "mode": archive.mode,
        "hash_seed": f"0x{archive.hash_seed:08X}",
        "has_sorted_hash_index": bool(archive.sorted_index),
        "entries": manifest_rows,
        "nested": nested_results,
    }
    (output_dir / "manifest.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return metadata


def extract_bbx_file(
    path: Path,
    output_root: Path,
    recursive: bool,
    convert_gmx: bool,
    convert_tex: bool,
    flip_v: bool,
) -> dict:
    data = maybe_decompress(path.read_bytes())
    if not data.startswith(BBX_MAGIC):
        raise FormatError(f"{path}: decompressed data is not BBX")
    out = output_root / path.name
    # Strip multiple packaging suffixes for a clean output directory.
    for suffix in (".sdat", ".gz", ".bin"):
        if out.name.lower().endswith(suffix):
            out = out.with_name(out.name[: -len(suffix)])
    return extract_bbx_bytes(data, out, str(path), recursive, convert_gmx, convert_tex, flip_v)



@dataclass
class TEXInfo:
    width: int
    height: int
    physical_pitch: int
    format: int
    format_name: str
    endianness: int
    endianness_name: str
    tiled: bool
    swizzle: tuple[int, int, int, int]
    payload_size: int
    fetch_dwords: tuple[int, int, int, int, int, int]


def parse_tex(data: bytes) -> TEXInfo:
    if not looks_like_tex(data):
        raise FormatError("not a recognized SIIG Xbox 360 TEX file")
    words = struct.unpack_from(">13I", data, 0)
    fetch = words[7:13]
    d0, d1, d2, d3, _d4, _d5 = fetch
    width = (d2 & 0x1FFF) + 1
    height = ((d2 >> 13) & 0x1FFF) + 1
    pitch_units = (d0 >> 22) & 0x1FF
    physical_pitch = pitch_units * 32 if pitch_units else ((width + 31) & ~31)
    fmt = d1 & 0x3F
    endian = (d1 >> 6) & 3
    swizzle_word = (d3 >> 1) & 0xFFF
    swizzle = tuple((swizzle_word >> (component * 3)) & 7 for component in range(4))
    return TEXInfo(
        width=width,
        height=height,
        physical_pitch=physical_pitch,
        format=fmt,
        format_name=XENOS_TEXTURE_FORMAT_NAMES.get(fmt, f"unknown_{fmt}"),
        endianness=endian,
        endianness_name=XENOS_ENDIAN_NAMES.get(endian, f"unknown_{endian}"),
        tiled=bool(d0 >> 31),
        swizzle=swizzle,  # type: ignore[arg-type]
        payload_size=len(data) - TEX_HEADER_SIZE,
        fetch_dwords=fetch,  # type: ignore[arg-type]
    )


def xg_address_2d_tiled_offset(x: int, y: int, width: int, texel_pitch: int) -> int:
    """Return the Xenos byte address of one 2D tiled texel/block.

    This follows Xenia's current bit-decomposed texture-address implementation.
    The older commonly copied XGAddress2DTiledOffset formula omits the Y[3]
    XOR in the pipe selector, which produces the characteristic 8-row
    jitter/scrambling seen in the first toolkit build.

    ``width`` is the physical pitch in texels/blocks and must be 32-aligned.
    ``texel_pitch`` is the byte size of one texel/block and must be a power of 2.
    """
    aligned_width = (width + 31) & ~31
    if texel_pitch <= 0 or texel_pitch & (texel_pitch - 1):
        raise FormatError(f"invalid tiled texel pitch {texel_pitch}")
    bytes_per_block_log2 = texel_pitch.bit_length() - 1

    # Macro-tile origin and 8x16 micro-tile offset, measured in blocks.
    outer_blocks = (
        ((y >> 5) * (aligned_width >> 5) + (x >> 5)) << 6
    )
    inner_blocks = (((y >> 1) & 0b111) << 3) | (x & 0b111)
    outer_inner_bytes = (outer_blocks | inner_blocks) << bytes_per_block_log2

    # Xenos bank/pipe selection. The Y[3] XOR is essential.
    bank = (y >> 4) & 0b1
    pipe = ((x >> 3) & 0b11) ^ (((y >> 3) & 0b1) << 1)
    y_lsb = y & 0b1

    return (
        (y_lsb << 4)
        | (pipe << 6)
        | (bank << 11)
        | (outer_inner_bytes & 0x0F)
        | (((outer_inner_bytes >> 4) & 0x01) << 5)
        | (((outer_inner_bytes >> 5) & 0x07) << 8)
        | ((outer_inner_bytes >> 8) << 12)
    )


@lru_cache(maxsize=4)
def _xg_tiled_offset_table(width: int, height: int, physical_pitch: int, texel_pitch: int) -> array:
    # Compact 32-bit table; caching is especially valuable here because SIIG has
    # many textures with identical 1152x1152 layouts.
    offsets = array("I")
    append = offsets.append
    for y in range(height):
        for x in range(width):
            append(xg_address_2d_tiled_offset(x, y, physical_pitch, texel_pitch))
    return offsets


def _apply_xenos_endian(pixel: bytes, endian: int) -> bytes:
    if len(pixel) != 4:
        raise FormatError("truncated 32-bit TEX pixel")
    if endian == 0:
        return pixel
    if endian == 1:  # 8-in-16
        return bytes((pixel[1], pixel[0], pixel[3], pixel[2]))
    if endian == 2:  # 8-in-32
        return pixel[::-1]
    if endian == 3:  # 16-in-32
        return bytes((pixel[2], pixel[3], pixel[0], pixel[1]))
    raise FormatError(f"unsupported Xenos endian mode {endian}")


def _apply_xenos_swizzle(components: bytes, swizzle: tuple[int, int, int, int]) -> bytes:
    out = bytearray(4)
    for i, selector in enumerate(swizzle):
        if selector < 4:
            out[i] = components[selector]
        elif selector == 4:
            out[i] = 0
        elif selector == 5:
            out[i] = 255
        else:
            raise FormatError(f"unsupported Xenos swizzle selector {selector}")
    return bytes(out)


def decode_tex_rgba(data: bytes) -> tuple[TEXInfo, bytes]:
    info = parse_tex(data)
    if info.format != XENOS_TEXFMT_8_8_8_8:
        raise FormatError(
            f"TEX PNG conversion currently supports 8_8_8_8 (6), got {info.format_name} ({info.format})"
        )
    payload = data[TEX_HEADER_SIZE:]
    width = info.width
    height = info.height
    physical_pitch = info.physical_pitch
    rgba = bytearray(width * height * 4)

    # This is the exact combination used by every SIIG TEX sample examined:
    # k8in32 plus Z,Y,X,W swizzle. Keep a specialized path because the game has
    # many 1152x1152 images and avoiding per-pixel temporary objects is much faster.
    common_layout = info.endianness == 2 and info.swizzle == (2, 1, 0, 3)
    tiled = info.tiled
    payload_len = len(payload)
    if tiled:
        source_offsets: Iterable[int] = _xg_tiled_offset_table(width, height, physical_pitch, 4)
    else:
        source_offsets = (
            (y * physical_pitch + x) * 4 for y in range(height) for x in range(width)
        )
    target = 0
    for pixel_number, source in enumerate(source_offsets):
        if source + 4 > payload_len:
            x = pixel_number % width
            y = pixel_number // width
            raise FormatError(
                f"TEX pixel ({x},{y}) maps beyond payload at 0x{source:X} "
                f"(payload 0x{payload_len:X})"
            )
        if common_layout:
            # Raw GPU bytes ABCD -> k8in32 DCBA -> ZYXW swizzle BCDA.
            rgba[target] = payload[source + 1]
            rgba[target + 1] = payload[source + 2]
            rgba[target + 2] = payload[source + 3]
            rgba[target + 3] = payload[source]
        else:
            components = _apply_xenos_endian(payload[source : source + 4], info.endianness)
            pixel = _apply_xenos_swizzle(components, info.swizzle)
            rgba[target : target + 4] = pixel
        target += 4
    return info, bytes(rgba)


def _png_chunk(tag: bytes, payload: bytes) -> bytes:
    return struct.pack(">I", len(payload)) + tag + payload + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF)


def write_rgba_png(path: Path, width: int, height: int, rgba: bytes) -> None:
    if len(rgba) != width * height * 4:
        raise ValueError("RGBA byte count does not match dimensions")
    rows = b"".join(b"\x00" + rgba[y * width * 4 : (y + 1) * width * 4] for y in range(height))
    png = (
        b"\x89PNG\r\n\x1a\n"
        + _png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
        + _png_chunk(b"IDAT", zlib.compress(rows, 1))
        + _png_chunk(b"IEND", b"")
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(png)


def export_tex_png_bytes(data: bytes, png_path: Path) -> dict:
    info, rgba = decode_tex_rgba(data)
    write_rgba_png(png_path, info.width, info.height, rgba)
    metadata = asdict(info)
    metadata["fetch_dwords"] = [f"0x{value:08X}" for value in info.fetch_dwords]
    metadata["swizzle"] = list(info.swizzle)
    png_path.with_suffix(png_path.suffix + ".json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    return metadata


def export_tex_file(path: Path, output_root: Path) -> dict:
    return export_tex_png_bytes(path.read_bytes(), output_root / f"{path.stem}.png")


@dataclass
class GMXChunk:
    offset: int
    tag: str
    size: int
    raw: bytes


@dataclass
class GMXArray:
    chunk: GMXChunk
    array_index: int
    flags: int
    semantic: str
    slot: int
    components: int
    gl_type: int
    count: int
    values: list[tuple[float | int, ...]]


@dataclass
class GMXMesh:
    chunk: GMXChunk
    mesh_index: int
    flags: int
    primitive_mode: int
    unknown_14: int
    index_count: int
    skin_index: int
    array_refs: list[int]


def parse_gmx_chunks(data: bytes) -> list[GMXChunk]:
    if len(data) < 0x30 or not data.startswith(GMX_MAGIC):
        raise FormatError("not a GMX file")
    root_size = be_u32(data, 0x04)
    total_size = be_u32(data, 0x0C)
    if root_size < 8 or root_size > len(data):
        raise FormatError(f"invalid GMX root size 0x{root_size:X}")
    if total_size == 0:
        total_size = len(data)
    if total_size > len(data):
        raise FormatError(f"GMX reports size 0x{total_size:X}, file is only 0x{len(data):X}")

    chunks: list[GMXChunk] = []
    pos = 0
    while pos < total_size:
        if pos + 8 > total_size:
            raise FormatError(f"truncated GMX chunk header at 0x{pos:X}")
        raw_tag = data[pos : pos + 4]
        tag = raw_tag.rstrip(b"\0").decode("ascii", errors="replace")
        size = be_u32(data, pos + 4)
        if size < 8 or pos + size > total_size:
            raise FormatError(f"invalid {tag!r} chunk size 0x{size:X} at 0x{pos:X}")
        chunks.append(GMXChunk(pos, tag, size, data[pos : pos + size]))
        pos += size
    if pos != total_size:
        raise FormatError(f"GMX chunks end at 0x{pos:X}, expected 0x{total_size:X}")
    return chunks


def parse_gmx_array(chunk: GMXChunk) -> GMXArray:
    raw = chunk.raw
    if chunk.tag != "ARRY" or len(raw) < 0x30:
        raise FormatError("invalid ARRY chunk")
    array_index = be_u16(raw, 0x08)
    flags = be_u16(raw, 0x0A)
    semantic = raw[0x10:0x20].split(b"\0", 1)[0].decode("ascii", errors="replace")
    slot = be_u32(raw, 0x20)
    components = be_u32(raw, 0x24)
    gl_type = be_u32(raw, 0x28)
    count = be_u32(raw, 0x2C)
    if components < 1 or components > 16:
        raise FormatError(f"ARRY {array_index}: implausible component count {components}")

    if gl_type == GL_FLOAT:
        scalar_size = 4
        fmt_char = "f"
    elif gl_type == GL_UNSIGNED_SHORT:
        scalar_size = 2
        fmt_char = "H"
    else:
        raise FormatError(f"ARRY {array_index}: unsupported GL type 0x{gl_type:X}")

    byte_count = count * components * scalar_size
    if 0x30 + byte_count > len(raw):
        raise FormatError(
            f"ARRY {array_index}: data exceeds chunk ({count}*{components}*{scalar_size})"
        )
    flat = struct.unpack_from(f">{count * components}{fmt_char}", raw, 0x30)
    values = [tuple(flat[i : i + components]) for i in range(0, len(flat), components)]
    return GMXArray(chunk, array_index, flags, semantic, slot, components, gl_type, count, values)


def parse_gmx_mesh(chunk: GMXChunk) -> GMXMesh:
    raw = chunk.raw
    if chunk.tag != "MESH" or len(raw) < 0x20:
        raise FormatError("invalid MESH chunk")
    mesh_index = be_u16(raw, 0x08)
    flags = be_u16(raw, 0x0A)
    primitive_mode = be_u32(raw, 0x10)
    unknown_14 = be_u32(raw, 0x14)
    index_count = be_u32(raw, 0x18)
    skin_index = be_u16(raw, 0x1C)
    ref_count = be_u16(raw, 0x1E)
    if 0x20 + ref_count * 2 > len(raw):
        raise FormatError(f"MESH {mesh_index}: reference list exceeds chunk")
    refs = list(struct.unpack_from(f">{ref_count}H", raw, 0x20)) if ref_count else []
    return GMXMesh(chunk, mesh_index, flags, primitive_mode, unknown_14, index_count, skin_index, refs)


def _array_by_semantic(arrays: Sequence[GMXArray], semantic: str) -> Optional[GMXArray]:
    for arr in arrays:
        if arr.semantic == semantic:
            return arr
    return None


def _index_array(arrays: Sequence[GMXArray]) -> Optional[GMXArray]:
    for arr in arrays:
        if arr.gl_type == GL_UNSIGNED_SHORT and arr.components == 1:
            return arr
    return None


def export_gmx_obj_bytes(data: bytes, obj_path: Path, flip_v: bool = False) -> dict:
    chunks = parse_gmx_chunks(data)
    arrays = {arr.array_index: arr for arr in (parse_gmx_array(c) for c in chunks if c.tag == "ARRY")}
    meshes = [parse_gmx_mesh(c) for c in chunks if c.tag == "MESH"]
    if not meshes:
        raise FormatError("GMX contains no MESH chunks")

    obj_path.parent.mkdir(parents=True, exist_ok=True)
    metadata: dict = {
        "source_size": len(data),
        "chunk_count": len(chunks),
        "chunk_tags": [c.tag for c in chunks],
        "mesh_count": len(meshes),
        "meshes": [],
    }

    v_base = 0
    vt_base = 0
    vn_base = 0
    lines: list[str] = [
        "# Space Invaders Infinity Gene GMX export",
        "# Geometry decoded from big-endian GMX ARRY/MESH chunks.",
    ]

    for ordinal, mesh in enumerate(meshes):
        referenced = [arrays[idx] for idx in mesh.array_refs if idx in arrays]
        pos = _array_by_semantic(referenced, "IN.position")
        normal = _array_by_semantic(referenced, "IN.normal")
        uv = _array_by_semantic(referenced, "IN.texuv")
        color = _array_by_semantic(referenced, "IN.color")
        indices = _index_array(referenced)
        if pos is None or indices is None:
            raise FormatError(
                f"MESH {mesh.mesh_index}: missing position or index array (refs={mesh.array_refs})"
            )
        if pos.components < 3:
            raise FormatError(f"MESH {mesh.mesh_index}: position array has {pos.components} components")
        if indices.count != mesh.index_count:
            raise FormatError(
                f"MESH {mesh.mesh_index}: index count mismatch {indices.count} != {mesh.index_count}"
            )

        name = f"mesh_{ordinal:03d}_{mesh.mesh_index}"
        lines.append(f"\no {name}")
        for value in pos.values:
            lines.append(f"v {value[0]:.9g} {value[1]:.9g} {value[2]:.9g}")
        if uv is not None:
            for value in uv.values:
                u = float(value[0])
                v = 1.0 - float(value[1]) if flip_v else float(value[1])
                lines.append(f"vt {u:.9g} {v:.9g}")
        if normal is not None:
            for value in normal.values:
                lines.append(f"vn {value[0]:.9g} {value[1]:.9g} {value[2]:.9g}")

        idx = [int(v[0]) for v in indices.values]
        vertex_count = pos.count
        if any(i >= vertex_count for i in idx):
            bad = max(idx)
            raise FormatError(
                f"MESH {mesh.mesh_index}: index {bad} exceeds vertex count {vertex_count}"
            )

        def vertex_ref(i: int) -> str:
            vi = v_base + i + 1
            has_uv = uv is not None and i < uv.count
            has_normal = normal is not None and i < normal.count
            if has_uv and has_normal:
                return f"{vi}/{vt_base + i + 1}/{vn_base + i + 1}"
            if has_uv:
                return f"{vi}/{vt_base + i + 1}"
            if has_normal:
                return f"{vi}//{vn_base + i + 1}"
            return str(vi)

        if mesh.primitive_mode == GL_TRIANGLES:
            if len(idx) % 3:
                raise FormatError(f"MESH {mesh.mesh_index}: triangle index count is not divisible by 3")
            for i in range(0, len(idx), 3):
                lines.append("f " + " ".join(vertex_ref(x) for x in idx[i : i + 3]))
            primitive = "triangles"
        elif mesh.primitive_mode == GL_LINES:
            if len(idx) % 2:
                raise FormatError(f"MESH {mesh.mesh_index}: line index count is not divisible by 2")
            for i in range(0, len(idx), 2):
                lines.append("l " + " ".join(str(v_base + x + 1) for x in idx[i : i + 2]))
            primitive = "lines"
        else:
            raise FormatError(
                f"MESH {mesh.mesh_index}: unsupported primitive mode 0x{mesh.primitive_mode:X}"
            )

        metadata["meshes"].append(
            {
                "mesh_index": mesh.mesh_index,
                "primitive_mode": f"0x{mesh.primitive_mode:X}",
                "primitive": primitive,
                "index_count": mesh.index_count,
                "vertex_count": pos.count,
                "array_refs": mesh.array_refs,
                "has_normals": normal is not None,
                "has_uv": uv is not None,
                "has_color": color is not None,
                "skin_index": mesh.skin_index,
            }
        )

        v_base += pos.count
        if uv is not None:
            vt_base += uv.count
        if normal is not None:
            vn_base += normal.count

    obj_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    meta_path = obj_path.with_suffix(obj_path.suffix + ".json")
    meta_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return metadata


def export_gmx_file(path: Path, output_root: Path, flip_v: bool) -> dict:
    out = output_root / f"{path.stem}.obj"
    return export_gmx_obj_bytes(path.read_bytes(), out, flip_v=flip_v)


def iter_candidate_files(path: Path) -> Iterator[Path]:
    if path.is_file():
        yield path
    elif path.is_dir():
        yield from (p for p in sorted(path.rglob("*")) if p.is_file())
    else:
        raise FileNotFoundError(path)


def command_extract(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        try:
            raw = path.read_bytes()[:4]
            if raw[:2] == b"\x1F\x8B":
                test = maybe_decompress(path.read_bytes())[:4]
            else:
                test = raw
            if test != BBX_MAGIC:
                if input_path.is_file():
                    raise FormatError("input is not BBX or standard gzip containing BBX")
                continue
            result = extract_bbx_file(path, output, args.recursive, args.convert_gmx, args.convert_tex, args.flip_v)
            print(f"{path}: extracted {result['count']} resources")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} archive(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def command_gmx2obj(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        if path.suffix.lower() != ".gmx" and not path.read_bytes()[:4] == GMX_MAGIC:
            continue
        try:
            chunks = parse_gmx_chunks(path.read_bytes())
            if not any(chunk.tag == "MESH" for chunk in chunks):
                meta_path = output / f"{path.stem}.gmx.json"
                meta_path.write_text(
                    json.dumps(
                        {
                            "source": str(path),
                            "mesh_count": 0,
                            "note": "This GMX has no MESH chunks; it may be hierarchy/animation-only.",
                            "chunks": [
                                {"offset": c.offset, "tag": c.tag, "size": c.size} for c in chunks
                            ],
                        },
                        indent=2,
                    ),
                    encoding="utf-8",
                )
                print(f"{path}: no mesh geometry; wrote metadata only")
            else:
                meta = export_gmx_file(path, output, args.flip_v)
                print(f"{path}: exported {meta['mesh_count']} mesh(es)")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} GMX file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def command_tex2png(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        try:
            data = path.read_bytes()
            if path.suffix.lower() != ".tex" and not looks_like_tex(data):
                continue
            if input_path.is_dir():
                relative = path.relative_to(input_path).with_suffix(".png")
                destination = output / relative
            else:
                destination = output / f"{path.stem}.png"
            meta = export_tex_png_bytes(data, destination)
            print(f"{path}: {meta['width']}x{meta['height']} {meta['format_name']} -> {destination}")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} TEX file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def command_scan(args: argparse.Namespace) -> int:
    path = Path(args.input)
    data = maybe_decompress(path.read_bytes())
    if data.startswith(BBX_MAGIC):
        archive = BBXArchive.parse(data)
        print(
            json.dumps(
                {
                    "format": "BBX",
                    "count": archive.count,
                    "mode": archive.mode,
                    "hash_seed": f"0x{archive.hash_seed:08X}",
                    "has_sorted_hash_index": bool(archive.sorted_index),
                    "entries": [asdict(e) for e in archive.entries],
                },
                indent=2,
            )
        )
        return 0
    if data.startswith(GMX_MAGIC):
        chunks = parse_gmx_chunks(data)
        arrays = [parse_gmx_array(c) for c in chunks if c.tag == "ARRY"]
        meshes = [parse_gmx_mesh(c) for c in chunks if c.tag == "MESH"]
        print(
            json.dumps(
                {
                    "format": "GMX",
                    "size": len(data),
                    "chunks": [{"offset": c.offset, "tag": c.tag, "size": c.size} for c in chunks],
                    "arrays": [
                        {
                            "index": a.array_index,
                            "semantic": a.semantic,
                            "slot": a.slot,
                            "components": a.components,
                            "gl_type": f"0x{a.gl_type:X}",
                            "count": a.count,
                        }
                        for a in arrays
                    ],
                    "meshes": [
                        {
                            "index": m.mesh_index,
                            "primitive_mode": f"0x{m.primitive_mode:X}",
                            "index_count": m.index_count,
                            "skin_index": m.skin_index,
                            "array_refs": m.array_refs,
                        }
                        for m in meshes
                    ],
                },
                indent=2,
            )
        )
        return 0
    if looks_like_tex(data):
        info = asdict(parse_tex(data))
        info["texture_format"] = f"0x{info.pop('format'):X}"
        info["fetch_dwords"] = [f"0x{value:08X}" for value in info["fetch_dwords"]]
        info["swizzle"] = list(info["swizzle"])
        print(json.dumps({"format": "TEX", **info}, indent=2))
        return 0
    raise FormatError("unrecognized input (not BBX, gzip->BBX, GMX, or TEX)")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    p_extract = sub.add_parser("extract", help="extract one BBX archive or every BBX in a directory")
    p_extract.add_argument("input", help="input .bin/.gz file or directory")
    p_extract.add_argument("-o", "--output", default="siig_extracted", help="output directory")
    p_extract.add_argument("--recursive", action="store_true", help="recursively extract nested BBX payloads")
    p_extract.add_argument("--convert-gmx", action="store_true", help="also convert extracted GMX geometry to OBJ")
    p_extract.add_argument("--convert-tex", action="store_true", help="also convert extracted TEX textures to PNG")
    p_extract.add_argument("--flip-v", action="store_true", help="flip the OBJ texture V coordinate")
    p_extract.set_defaults(func=command_extract)

    p_gmx = sub.add_parser("gmx2obj", help="convert one GMX or a directory of GMX files to OBJ")
    p_gmx.add_argument("input", help="input .gmx file or directory")
    p_gmx.add_argument("-o", "--output", default="siig_obj", help="output directory")
    p_gmx.add_argument("--flip-v", action="store_true", help="flip the OBJ texture V coordinate")
    p_gmx.set_defaults(func=command_gmx2obj)

    p_tex = sub.add_parser("tex2png", help="convert one TEX or a directory of TEX files to PNG")
    p_tex.add_argument("input", help="input .tex file or directory")
    p_tex.add_argument("-o", "--output", default="siig_png", help="output directory")
    p_tex.set_defaults(func=command_tex2png)

    p_scan = sub.add_parser("scan", help="print a JSON description of a BBX, GMX, or TEX file")
    p_scan.add_argument("input")
    p_scan.set_defaults(func=command_scan)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (OSError, FormatError, gzip.BadGzipFile) as exc:
        parser.error(str(exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
