# Space Invaders Infinity Gene Xbox 360 Asset Toolkit

**Version 1.1 — corrected TEX untile addressing**

This toolkit extracts and converts assets from the Xbox 360 version of **Space Invaders Infinity Gene**.
It was derived from the supplied game containers and cross-checked against the supplied `default.xex` Ghidra export.

## What works

- **BBX extraction** (`01 42 42 58` magic)
  - named and unnamed entries
  - nested BBX archives
  - standard `.gz` files whose decompressed content is BBX
  - original filename hierarchy, including `se/` and `bgm/`
  - exact filename-hash verification
  - CSV and JSON manifests
- **GMX → OBJ**
  - positions, normals, UVs and indexed geometry
  - triangle meshes and line meshes
  - multiple meshes per GMX
  - per-model JSON metadata
- **TEX → PNG**
  - Xbox 360 tiled `8_8_8_8` textures used by this game
  - corrected Xenos bank/pipe addressing, including the Y[3] pipe XOR
  - correct 8-in-32 endian conversion and channel swizzle
  - original logical dimensions, excluding physical pitch padding
  - per-texture JSON metadata
- **Ghidra labels**
  - optional script that renames confirmed BBX, GMX, TEX and resource-table functions

Only Python 3.9 or newer is required. The main tool uses the Python standard library only.

## Quick start

Open Command Prompt or PowerShell in the toolkit folder.

### Extract one container

```bat
python siig_toolkit.py extract "C:\path\to\player.bin" -o extracted --convert-gmx --convert-tex
```

### Extract every BBX container in a directory

Use the directory containing the already decompressed `.bin` files:

```bat
python siig_toolkit.py extract "C:\path\to\game_bins" -o extracted --recursive --convert-gmx --convert-tex
```

`--recursive` is important for `sound.bin`, whose audio banks are inside nested BBX archives.

### Convert extracted GMX files separately

```bat
python siig_toolkit.py gmx2obj extracted -o obj
```

Add `--flip-v` if your model viewer expects vertically inverted texture coordinates:

```bat
python siig_toolkit.py gmx2obj extracted -o obj --flip-v
```

### Convert extracted TEX files separately

```bat
python siig_toolkit.py tex2png extracted -o png
```

### Inspect a file without extracting it

```bat
python siig_toolkit.py scan player.bin
python siig_toolkit.py scan plr_001.gmx
python siig_toolkit.py scan button_A.tex
```

The `scan` command prints JSON describing the detected format and fields.

## Output

For every BBX archive, the extractor writes:

- the original embedded resources
- `manifest.csv`
- `manifest.json`
- converted `.obj` and `.obj.json` files when `--convert-gmx` is used
- converted `.png` and `.png.json` files when `--convert-tex` is used

Unnamed resources receive deterministic names containing their entry index and identifier. Nested BBX resources are placed in `_nested` directories.

## Validation performed

The tool was tested against all supplied files:

- 23 top-level BBX containers
- 2,593 top-level resources
- 2,522 named entries, with the executable-derived hash matching every name
- 486 GMX files
- 485 mesh-bearing GMX files converted successfully
- 1 hierarchy/animation-only GMX with no `MESH` chunk, reported as metadata rather than an error
- 1,938 mesh sections: 766 triangle meshes and 1,172 line meshes
- 819,004 vertices and 1,456,924 indices
- 54 TEX files converted to PNG with zero failures using the corrected untile mapping
- visual spot checks include clean controller icons, UI screens and 1152×1152 texture atlases

## Version 1.1 correction

Version 1.0 used a widely circulated older `XGAddress2DTiledOffset` formula that omitted the Y bit used to XOR the Xenos pipe selector. The result was recognizable but scrambled in repeating 8-row bands. Version 1.1 uses the corrected bank/pipe mapping and should be used to regenerate every PNG. Existing PNGs from version 1.0 are not repaired in place.

## Current limitations

- GMX bones, animation tracks, materials and shader assignments are not yet exported. OBJ output is static geometry.
- `.anm`, `.col`, stage `.bin`, `.map`, `.dat`, `.crp` and shader payloads are extracted losslessly but not converted yet.
- Nested XACT `.xsb` and `.xwb` files are extracted, but this tool does not convert the audio streams.
- TEX conversion currently supports Xenos texture format 6 (`8_8_8_8`), which covers every supplied `.tex` file. Other Xenos formats are reported but not decoded.
- A raw `.gz.sdat` wrapper may require the same preliminary unpacking method you already used. The toolkit accepts the resulting BBX `.bin` directly.

## Optional Ghidra renaming

`ApplySIIGFunctionNames.java` applies conservative names and comments to confirmed functions in the analyzed `default.xex`.

1. Open the analyzed XEX in Ghidra CodeBrowser.
2. Open **Window → Script Manager**.
3. Add the toolkit folder as a script directory.
4. Refresh and run `ApplySIIGFunctionNames.java`.

This does not modify the executable on disk; it only improves labels in the Ghidra project.
