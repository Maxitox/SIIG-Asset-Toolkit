# Reverse-engineered format notes

These notes distinguish fields confirmed by the game executable and corpus-wide validation from portions that remain incomplete.

## BBX container — confirmed

All multibyte fields are big-endian.

```text
0x00  4   magic: 01 42 42 58
0x04  4   resource count
0x08  4   archive mode
0x0C  4   filename-hash seed
0x10 16   reserved / runtime-related header fields
0x20 ...  resource records, 0x10 bytes each
```

Each resource record is:

```text
+0x00  u32  payload offset, relative to BBX base
+0x04  u32  payload size
+0x08  u32  null-terminated filename offset, or zero when unnamed
+0x0C  u32  game-specific filename identifier/hash
```

For archive modes 0 and 1, the record table is followed by a sorted array of `{hash, resource_index}` pairs, each 8 bytes. The executable can use this table for name lookup.

The toolkit reimplements the exact PowerPC hash routine found at `0x824739D0` and supports the seed at header offset `0x0C`.

### Runtime resource table — confirmed

After loading an archive, the game registers resources in 0x88-byte records:

```c
struct ResourceEntry {
    char     name[0x80];
    void*    data;       // +0x80
    uint32_t size;       // +0x84
};
```

The executable enumerates every BBX resource as `(name, data, size)` and copies it into this table.

## GMX model format — geometry fields confirmed

GMX is a sequential big-endian chunk stream. Every chunk begins with:

```text
+0x00  char[4]  tag
+0x04  u32      total chunk size, including the 8-byte header
```

Common tags include:

```text
GMX  SHAD  MTRL  PARE  BONE  MESH  ARRY  ANIM
```

### ARRY chunk

```text
+0x08  u16  array index
+0x0A  u16  flags
+0x10  char[16] semantic, such as IN.position / IN.normal / IN.texuv / IN.color
+0x20  u32  attribute slot
+0x24  u32  components per element
+0x28  u32  OpenGL-style scalar type
+0x2C  u32  element count
+0x30  ...  big-endian array data
```

Observed scalar types:

```text
0x1406  float32
0x1403  uint16
```

### MESH chunk

```text
+0x08  u16  mesh index
+0x0A  u16  flags
+0x10  u32  primitive mode
+0x14  u32  not yet named
+0x18  u32  index count
+0x1C  u16  skin index
+0x1E  u16  ARRY-reference count
+0x20  u16[] referenced ARRY indices
```

Observed primitive modes:

```text
0x0001  lines
0x0004  triangles
```

The OBJ converter writes positions, normals, UVs, indexed faces and indexed lines. Colors are recognized and reported in JSON but Wavefront OBJ has no universally supported vertex-color representation.

## TEX texture format — confirmed for all supplied textures

A `.tex` file consists of:

```text
0x00  0x1C bytes  serialized Xbox 360 D3D resource fields
0x1C  0x18 bytes  six-dword Xenos texture-fetch constant
0x34  ...         tiled GPU pixel data
```

All 54 supplied textures use:

```text
Xenos format       6 (8_8_8_8)
Endian mode        2 (8-in-32)
Tiled              yes
Channel swizzle    Z, Y, X, W
```

The logical width and height are encoded in fetch dword 2 as 13-bit minus-one fields. The physical row pitch is encoded in 32-pixel units in fetch dword 0. Pixel data uses the Xbox 360 32×32 tiled address layout. The 2D pipe selector is `((x >> 3) & 3) XOR (((y >> 3) & 1) << 1)`; omitting the Y[3] XOR produces repeating 8-row jitter. The corrected converter applies this bank/pipe mapping, then the endian transform and channel swizzle. It was validated against the controller icons, yielding the expected green A, red B, blue X and yellow Y, and against larger UI/atlas textures.

## Sound archive

`sound.bin` has unnamed top-level records and four nested BBX archives. The nested archives contain paths such as:

```text
se/SE.xsb
se/SE.xwb
bgm/BGM_007.xsb
bgm/BGM_007.xwb
bgm/BGM_008.xsb
bgm/BGM_008.xwb
bgm/BGM_XACT_SE33.xsb
bgm/BGM_XACT_SE33.xwb
```

The nested files are extracted with their directory hierarchy intact.

## Remaining formats

The following are structurally separable and extracted, but their inner semantics still need more work:

- `.anm` animation data
- `.col` wall/collision data
- stage `Bmap*.bin` / `Xmap*.bin`
- gameplay `.map`
- generator/script `.dat`
- `.crp` system font
- compiled shader payloads
- XACT audio bank internals
