# Changelog

## 1.5

- Added `gmx2gltf` and `extract --convert-gltf`.
- Decoded GMX `TXIF`, `SHAD`, `MTRL`, `PARE`, `BONE`, `MOTN`, and `ANIM` chunk relationships.
- Added glTF 2.0 hierarchy, rigid mesh attachment, materials, vertex colors, texture assignment, and transform-animation export.
- Added automatic conversion of the shared uncompressed `ptn_001.dds` texture to PNG.
- Added `GMX_GLTF_NOTES.md` and detailed GMX output in `scan`.
- Validated 486 GMX files, 1,938 meshes, 3,298 nodes, 776 materials, and 913 animation tracks with zero conversion failures.


## 1.4

- Added `text2csv` for direct decoding of `text.bin`, `message.bin`, or a directory containing both.
- Recovered the 542-row `text.bin` key/translation table across Japanese, English, French, Italian, German and Spanish.
- Parsed all 284 Squirrel-style `message.bin` arrays and 1,295 strings per language.
- Added Unicode correction for the legacy language-specific accented-glyph codes while retaining untouched raw scripts.
- Added combined CSV/JSON, per-language text files, metadata, and `LOCALIZATION_NOTES.md`.


## 1.3

- Added `xact2wav` for direct conversion from `sound.bin`, extracted XWB files, or XWB/XSB directories.
- Added standard big-endian XACT3 wave-bank parsing and XSB cue-name recovery.
- Added RIFF XMA2 wrapper generation and optional FFmpeg PCM WAV decoding.
- Validated all 86 SIIG streams: 83 SE cues plus BGM007, BGM008_MIX_C and BGM_XACT_SE33.
- Added per-bank CSV/JSON manifests with channels, sample rates, sample counts and loop metadata.


## 1.2

- Added `font2png` for `systemfont.bin`, `.gz`, or extracted `systemfont.crp`.
- Confirmed from `default.xex` that `systemfont.crp` is XOR-obfuscated bytewise with key `0xF1`.
- Added automatic CRP conversion when `extract --convert-tex` is used.
- Added `systemfont_glyphs.csv` with all 6,732 executable-resident glyph records, atlas coordinates, widths, left insets and known aliases.
- Added `systemfont.fnt` AngelCode BMFont descriptor for the 6,730 native Unicode mappings.
- Added CRP detection to `scan`.

## 1.1

- Fixed TEX untile addressing.
- Added the missing Y[3] XOR in the Xenos pipe selector.
- Eliminated repeating 8-row jitter/scrambling in converted PNG files.
- Revalidated all 54 supplied TEX files with zero conversion failures.

## 1.0

- Initial BBX extraction, GMX-to-OBJ and TEX-to-PNG release.
