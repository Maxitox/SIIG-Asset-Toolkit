# Space Invaders Infinity Gene Xbox 360 Asset Toolkit

**Version 1.5 — GMX hierarchy, materials and animations exported to glTF 2.0**

This toolkit extracts and converts assets from the Xbox 360 version of **Space Invaders Infinity Gene**. It was derived from the supplied game containers and cross-checked against the supplied `default.xex` Ghidra export.

## What works

- **BBX extraction** (`01 42 42 58` magic)
  - named and unnamed entries
  - nested BBX archives
  - standard `.gz` files whose decompressed content is BBX
  - original filename hierarchy, including `se/` and `bgm/`
  - exact filename-hash verification
  - CSV and JSON manifests
- **GMX → glTF 2.0**
  - indexed triangles and lines with positions, normals, UVs and vertex colors
  - complete `PARE`/`BONE` hierarchy and rigid mesh attachment
  - `SHAD`/`MTRL` material assignment, diffuse/alpha/emissive values and textures
  - automatic conversion of the referenced `ptn_001.dds` to a shared PNG
  - `MOTN`/`ANIM` transform tracks exported as glTF translation/rotation/scale animation
  - external `.gltf.bin` buffers and conversion diagnostics
- **GMX → OBJ**
  - retained as a lightweight static-geometry option
  - positions, normals, UVs, indexed triangles and indexed lines
  - multiple meshes per GMX and per-model JSON metadata
- **TEX → PNG**
  - corrected Xbox 360 tiled `8_8_8_8` decoding
  - correct Xenos bank/pipe addressing, 8-in-32 endian conversion and channel swizzle
  - original logical dimensions, excluding physical pitch padding
- **System font → PNG atlas**
  - accepts `systemfont.bin`, `systemfont.bin.gz`, or extracted `systemfont.crp`
  - removes the game's bytewise XOR `0xF1` obfuscation
  - exports the underlying 2048×3392 Xbox 360 texture atlas
  - optional decrypted `.tex` output
  - includes the executable-derived 6,732-record glyph mapping/metrics table
  - includes an AngelCode BMFont descriptor for the native Unicode mappings
- **XACT audio → WAV**
  - accepts `sound.bin` directly, extracted `.xwb` banks, or a directory of `.xwb`/`.xsb` pairs
  - parses big-endian Xbox 360 XACT3 wave banks
  - uses companion XSB cue names where available
  - writes RIFF-wrapped XMA2 streams and automatically decodes them to PCM WAV when FFmpeg is installed
  - exports CSV and JSON audio manifests, including loops, sample counts, channels and sample rates
- **Localization databases → CSV/JSON/text**
  - accepts `text.bin`, `message.bin`, or a directory containing both
  - aligns all 542 `text.bin` keys with Japanese, English, French, Italian, German and Spanish
  - parses all 284 `message.bin` arrays / 1,295 strings per language
  - exports raw scripts and readable Unicode-corrected message scripts
- **Ghidra labels**
  - optional script that renames confirmed BBX, GMX, TEX and resource-table functions

Python 3.9 or newer is required. BBX/GMX/TEX/font processing uses only the Python standard library. WAV audio decoding additionally requires FFmpeg on `PATH`; without FFmpeg, the tool still exports playable RIFF-wrapped `.xma` files for vgmstream or another XMA2 decoder.

## Quick start

### Decode `text.bin` and `message.bin`

Point the command at the directory containing both files:

```bat
python siig_toolkit.py text2csv "C:\path\to\media" -o localization
```

Or decode either archive directly:

```bat
python siig_toolkit.py text2csv "C:\path\to\text.bin" -o localization
python siig_toolkit.py text2csv "C:\path\to\message.bin" -o localization
```

The main combined tables are:

```text
localization\text\text_strings.csv
localization\message\message_strings.csv
```

JSON, raw source, corrected UTF-8 `.nut`, and per-language text exports are also written. See `LOCALIZATION_NOTES.md`.


### Extract all sounds directly from `sound.bin`

With FFmpeg installed and available on `PATH`:

```bat
python siig_toolkit.py xact2wav "C:\path\to\sound.bin" -o audio
```

The command recursively finds the nested XACT banks, uses the XSB cue names, and creates 86 WAV files for the supplied game data:

```text
audio\
├── 0001_7346AAB9_nested\se\SE\
│   ├── 001_SE01.wav
│   ├── 002_SE02.wav
│   └── ...
├── 0055_FD910846_nested\bgm\BGM_007\001_BGM007.wav
├── 0056_D6019B85_nested\bgm\BGM_008\001_BGM008_MIX_C.wav
└── 0057_69117B88_nested\bgm\BGM_XACT_SE33\001_BGM_XACT_SE33.wav
```

Keep the intermediate XMA2 files as well:

```bat
python siig_toolkit.py xact2wav "C:\path\to\sound.bin" -o audio --keep-xma
```

Or convert already extracted banks:

```bat
python siig_toolkit.py xact2wav "C:\path\to\extracted\sound" -o audio
```

If FFmpeg is not installed, the command writes `.xma` files and manifests but skips WAV creation. You can open those `.xma` files in vgmstream-compatible players or install FFmpeg and rerun the command.


Open Command Prompt or PowerShell in the toolkit folder.

### Decode the system font

Directly from the BBX container:

```bat
python siig_toolkit.py font2png "C:\path\to\systemfont.bin" -o systemfont_decoded
```

Or from the extracted resource:

```bat
python siig_toolkit.py font2png "C:\path\to\systemfont.crp" -o systemfont_decoded
```

Also preserve the decrypted texture payload:

```bat
python siig_toolkit.py font2png "C:\path\to\systemfont.bin" -o systemfont_decoded --write-decrypted-tex
```

The output is:

```text
systemfont_decoded\
├── systemfont_atlas.png
├── systemfont_atlas.png.json
└── systemfont_decrypted.tex       (only with --write-decrypted-tex)
```

Place the included `systemfont.fnt` and `systemfont_glyphs.csv` beside `systemfont_atlas.png` when using the mapping data.

### Extract one container

```bat
python siig_toolkit.py extract "C:\path\to\player.bin" -o extracted --convert-gltf --convert-tex
```

### Extract every BBX container in a directory

```bat
python siig_toolkit.py extract "C:\path\to\game_bins" -o extracted --recursive --convert-gltf --convert-gmx --convert-tex
```

`--recursive` is important for `sound.bin`, whose audio banks are inside nested BBX archives. `--convert-tex` also detects and converts `systemfont.crp` after extraction.

### Export extracted GMX files to glTF 2.0

```bat
python siig_toolkit.py gmx2gltf extracted -o gltf
```

The command preserves hierarchy, materials, textures, vertex colors and GMX transform-animation tracks. When texture resources are outside the GMX directory, add a search root:

```bat
python siig_toolkit.py gmx2gltf extracted -o gltf --texture-root "C:\path\to\all_extracted_assets"
```

See `GMX_GLTF_NOTES.md` for the decoded chunk fields and limitations.

### Convert extracted GMX files to static OBJ separately

```bat
python siig_toolkit.py gmx2obj extracted -o obj
```

Add `--flip-v` if your model viewer expects vertically inverted texture coordinates:

```bat
python siig_toolkit.py gmx2obj extracted -o obj --flip-v
```

### Convert extracted TEX files separately

```bat
python siig_toolkit.py tex2png extracted -o png
```

### Inspect a file without extracting it

```bat
python siig_toolkit.py scan player.bin
python siig_toolkit.py scan plr_001.gmx
python siig_toolkit.py scan button_A.tex
python siig_toolkit.py scan systemfont.crp
python siig_toolkit.py scan SE.xwb
```

## System font details

`systemfont.crp` is not a conventional TTF/OTF font. It is a bytewise-XOR-obfuscated TEX texture. The game performs this sequence:

1. Open `/systemfont.bin.gz`.
2. Retrieve `systemfont.crp` from BBX.
3. XOR every byte with `0xF1`.
4. Pass the result to the ordinary texture loader.

After decryption, it is a normal game TEX:

```text
size              2048 × 3392
cell size         32 × 32
atlas grid        64 columns × 106 rows
texture format    Xenos 8_8_8_8 (format 6)
endian mode       8-in-32
layout            Xbox 360 tiled
```

The executable contains 6,732 glyph records beginning at virtual address `0x8200E508`. Each 12-byte record stores:

```text
+0x00  packed UTF-8 character bytes (4 bytes)
+0x04  glyph width in pixels (big-endian u32)
+0x08  left inset inside the 32-pixel cell (big-endian u32)
```

`systemfont_glyphs.csv` exposes these fields, atlas coordinates and known aliases. The game maps ordinary ASCII letters and digits to the fullwidth glyph records and renders them at half scale, so alias behavior is listed separately rather than baked into `systemfont.fnt`.

## Validation performed

- 23 top-level BBX containers
- 2,593 top-level resources
- 2,522 named entries with zero hash mismatches
- 486 GMX files exported to glTF with zero failures
- 1,938 meshes/primitives and 3,298 hierarchy nodes
- 776 materials and 913 transform-animation tracks
- 819,004 vertices and 1,456,924 indices
- zero hierarchy cycles, unreachable nodes, or missing GMX texture references
- 54 TEX files converted with the corrected untile mapping
- system font CRP decrypted and converted to a clean 2048×3392 glyph atlas
- 6,732 glyph records extracted from the executable; 6,730 have native Unicode mappings
- 4 XACT3 wave banks parsed
- 86 XMA2 streams decoded to WAV with zero failures
- 542 `text.bin` records aligned across six languages
- 284 `message.bin` arrays and 1,295 strings per language parsed with matching structure
- all 86 decoded files contain non-silent PCM data

## Current limitations

- GMX animation tracks are exported individually; higher-level gameplay grouping of multiple tracks is not yet known.
- GMX geometry has rigid node attachment but no per-vertex skin-weight arrays were found, so the glTF output is not a conventional skinned character rig.
- Source Xbox shader bytecode is represented with portable unlit glTF materials rather than translated custom shaders.
- `.anm`, `.col`, stage `.bin`, gameplay `.map`, generator/script `.dat` and shader payloads still need conversion work.
- Localization exports are readable/extractable; writing edited text back into BBX is not implemented yet.
- The built-in audio converter currently targets the standard XACT3/XMA2 banks used by this game; vgmstream remains the recommended general-purpose fallback for other XACT variants.
- The system font output is a bitmap atlas plus mapping/metrics, not a reconstructed vector TTF/OTF.
- TEX conversion currently supports Xenos texture format 6 (`8_8_8_8`), which covers every supplied `.tex` file and the font atlas.
