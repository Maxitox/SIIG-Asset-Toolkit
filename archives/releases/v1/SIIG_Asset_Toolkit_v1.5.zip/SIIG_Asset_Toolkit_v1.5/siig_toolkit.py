#!/usr/bin/env python3
"""
Space Invaders Infinity Gene (Xbox 360) asset toolkit.

Confirmed by cross-checking the game files with the default.xex Ghidra export:
- Extracts BBX containers (magic 01 42 42 58), including unnamed and nested entries.
- Verifies the game-specific filename hash.
- Exports GMX geometry, hierarchy, materials and transform animations to glTF 2.0, with OBJ retained for static geometry.
- Decrypts the XOR-obfuscated systemfont CRP and exports its 2048x3392 glyph atlas.
- Extracts XACT3 XWB/XSB banks and wraps Xbox 360 XMA2 streams for FFmpeg/vgmstream conversion.
- Decodes text.bin and message.bin localization databases to UTF-8 CSV/JSON/text.

Python 3.9+; standard library only.
"""

from __future__ import annotations

import argparse
import csv
from array import array
from functools import lru_cache
import gzip
import json
import math
import os
import re
import shutil
import struct
import subprocess
import sys
import zlib
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Iterator, Optional, Sequence

BBX_MAGIC = b"\x01BBX"
GMX_MAGIC = b"GMX\x00"
MAP_MAGIC = b"MAP\x00"
GL_FLOAT = 0x1406
GL_UNSIGNED_SHORT = 0x1403
GL_LINES = 0x0001
GL_TRIANGLES = 0x0004
TEX_HEADER_SIZE = 0x34
XENOS_TEXFMT_8_8_8_8 = 6
SYSTEMFONT_CRP_XOR = 0xF1
XWB_MAGIC_BE = b"DNBW"
XWB_MAGIC_LE = b"WBND"
XSB_MAGIC_BE = b"KBDS"
XSB_MAGIC_LE = b"SDBK"
WAVEBANK_FLAGS_COMPACT = 0x00020000
XENOS_ENDIAN_NAMES = {0: "none", 1: "8in16", 2: "8in32", 3: "16in32"}
XENOS_TEXTURE_FORMAT_NAMES = {
    0: "1_REVERSE", 1: "1", 2: "8", 3: "1_5_5_5", 4: "5_6_5", 5: "6_5_5",
    6: "8_8_8_8", 7: "2_10_10_10", 8: "8_A", 9: "8_B", 10: "8_8",
    18: "DXT1", 19: "DXT2_3", 20: "DXT4_5", 49: "DXN", 60: "CTX1",
}


class FormatError(ValueError):
    pass


def be_u16(data: bytes, off: int) -> int:
    if off < 0 or off + 2 > len(data):
        raise FormatError(f"u16 read outside file at 0x{off:X}")
    return struct.unpack_from(">H", data, off)[0]


def be_u32(data: bytes, off: int) -> int:
    if off < 0 or off + 4 > len(data):
        raise FormatError(f"u32 read outside file at 0x{off:X}")
    return struct.unpack_from(">I", data, off)[0]


def read_c_string(data: bytes, off: int, max_len: int = 4096) -> str:
    if off <= 0 or off >= len(data):
        return ""
    end_limit = min(len(data), off + max_len)
    end = data.find(b"\0", off, end_limit)
    if end < 0:
        raise FormatError(f"unterminated string at 0x{off:X}")
    raw = data[off:end]
    return raw.decode("utf-8", errors="replace")


def safe_relative_path(name: str, fallback: str) -> Path:
    # Preserve legitimate archive subdirectories (notably sound/se and sound/bgm)
    # while preventing absolute paths and traversal outside the output folder.
    raw_parts = name.replace("\\", "/").split("/") if name else []
    parts: list[str] = []
    for raw in raw_parts:
        part = raw.strip()
        if part in {"", ".", ".."}:
            continue
        part = re.sub(r"[\x00-\x1F<>:\"|?*]", "_", part)[:120]
        if part:
            parts.append(part)
    if not parts:
        parts = [fallback]
    return Path(*parts)


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem, suffix = path.stem, path.suffix
    for n in range(1, 100000):
        candidate = path.with_name(f"{stem}_{n}{suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"could not find unique output name for {path}")


def rotl32(value: int, count: int) -> int:
    count &= 31
    value &= 0xFFFFFFFF
    if count == 0:
        return value
    return ((value << count) | (value >> (32 - count))) & 0xFFFFFFFF


def _s8(value: int) -> int:
    return value - 256 if value & 0x80 else value


def bbx_name_hash(name: str | bytes, seed: int = 0) -> int:
    """Reimplementation of default.xex Function_824739D0.

    BBX filenames in this title are ASCII. Passing bytes preserves arbitrary byte names.
    """
    raw = name.encode("utf-8") if isinstance(name, str) else bytes(name)
    result = 0
    running_sum = 0
    seed &= 0xFFFFFFFF

    for byte in raw:
        signed_byte = _s8(byte)
        running_sum = (running_sum + signed_byte) & 0xFFFFFFFF
        shift = running_sum & 31

        left = ((signed_byte & 0xFFFFFFFF) << shift) & 0xFFFFFFFF
        right_count = 32 - shift
        if right_count >= 32:
            shifted = -1 if signed_byte < 0 else 0
        else:
            shifted = signed_byte >> right_count

        # The PPC code sign-extends the low byte after the right shift.
        low = shifted & 0xFF
        sign_extended_low = _s8(low) & 0xFFFFFFFF
        rotated_seed = rotl32(seed, byte & 31)
        result = (result + rotated_seed + (left | sign_extended_low)) & 0xFFFFFFFF

    return result


@dataclass
class BBXEntry:
    index: int
    data_offset: int
    data_size: int
    name_offset: int
    identifier: int
    name: str
    hash_matches: Optional[bool]


@dataclass
class BBXArchive:
    data: bytes
    count: int
    mode: int
    hash_seed: int
    entries: list[BBXEntry]
    sorted_index: list[tuple[int, int]]

    @classmethod
    def parse(cls, data: bytes) -> "BBXArchive":
        if len(data) < 0x20:
            raise FormatError("file is too small for a BBX header")
        if data[:4] != BBX_MAGIC:
            raise FormatError(f"bad BBX magic: {data[:4].hex(' ')}")

        count = be_u32(data, 0x04)
        mode = be_u32(data, 0x08)
        hash_seed = be_u32(data, 0x0C)
        table_end = 0x20 + count * 0x10
        if table_end > len(data):
            raise FormatError(
                f"BBX entry table exceeds file: count={count}, end=0x{table_end:X}, size=0x{len(data):X}"
            )

        entries: list[BBXEntry] = []
        for index in range(count):
            rec = 0x20 + index * 0x10
            data_offset, data_size, name_offset, identifier = struct.unpack_from(">4I", data, rec)
            if data_offset > len(data) or data_size > len(data) - data_offset:
                raise FormatError(
                    f"entry {index}: payload outside file (offset=0x{data_offset:X}, size=0x{data_size:X})"
                )
            name = read_c_string(data, name_offset) if name_offset else ""
            match = None if not name else bbx_name_hash(name, hash_seed) == identifier
            entries.append(
                BBXEntry(index, data_offset, data_size, name_offset, identifier, name, match)
            )

        # The executable uses a sorted {hash,index} table for modes 0 and 1.
        sorted_index: list[tuple[int, int]] = []
        if mode < 2:
            index_end = table_end + count * 8
            if index_end <= len(data):
                for i in range(count):
                    h, resource_index = struct.unpack_from(">2I", data, table_end + i * 8)
                    if resource_index >= count:
                        # Avoid treating payload bytes as a table in malformed/unusual files.
                        sorted_index = []
                        break
                    sorted_index.append((h, resource_index))

        return cls(data, count, mode, hash_seed, entries, sorted_index)

    def payload(self, entry: BBXEntry) -> bytes:
        return self.data[entry.data_offset : entry.data_offset + entry.data_size]


def maybe_decompress(data: bytes) -> bytes:
    if data[:2] == b"\x1F\x8B":
        return gzip.decompress(data)
    return data


def xor_systemfont_crp(data: bytes) -> bytes:
    """Decrypt the systemfont.crp payload used by SIIG.

    default.xex Function_8215B010 XORs every byte with 0xF1 before
    passing the result to the normal Xbox 360 texture loader.
    """
    return bytes(byte ^ SYSTEMFONT_CRP_XOR for byte in data)


def looks_like_tex(data: bytes) -> bool:
    if len(data) < TEX_HEADER_SIZE:
        return False
    try:
        words = struct.unpack_from(">13I", data, 0)
    except struct.error:
        return False
    # All SIIG TEX samples are a 0x1C-byte D3D resource header followed by a
    # six-dword Xenos texture fetch constant and pixel data.
    if words[:5] != (3, 1, 0, 0, 0):
        return False
    fetch0, fetch1, fetch2 = words[7], words[8], words[9]
    width = (fetch2 & 0x1FFF) + 1
    height = ((fetch2 >> 13) & 0x1FFF) + 1
    fmt = fetch1 & 0x3F
    return (fetch0 & 3) == 2 and 0 < width <= 8192 and 0 < height <= 8192 and fmt < 64


def looks_like_systemfont_crp(data: bytes) -> bool:
    if len(data) < TEX_HEADER_SIZE:
        return False
    decrypted_header = bytes(byte ^ SYSTEMFONT_CRP_XOR for byte in data[:TEX_HEADER_SIZE])
    # looks_like_tex only needs the 0x34-byte header.
    return looks_like_tex(decrypted_header)


def sniff_extension(payload: bytes) -> str:
    if payload.startswith(GMX_MAGIC):
        return ".gmx"
    if payload.startswith(MAP_MAGIC):
        return ".map"
    if payload.startswith(BBX_MAGIC):
        return ".bbx"
    if payload.startswith(b"RIFF"):
        return ".riff"
    if payload.startswith(b"FSGX"):
        return ".fsgx"
    if payload.startswith((XWB_MAGIC_BE, XWB_MAGIC_LE)):
        return ".xwb"
    if payload.startswith((XSB_MAGIC_BE, XSB_MAGIC_LE)):
        return ".xsb"
    if looks_like_tex(payload):
        return ".tex"
    if looks_like_systemfont_crp(payload):
        return ".crp"
    return ".bin"


def extract_bbx_bytes(
    data: bytes,
    output_dir: Path,
    source_label: str,
    recursive: bool = False,
    convert_gmx: bool = False,
    convert_gltf: bool = False,
    convert_tex: bool = False,
    flip_v: bool = False,
) -> dict:
    archive = BBXArchive.parse(data)
    output_dir.mkdir(parents=True, exist_ok=True)

    manifest_rows: list[dict] = []
    nested_results: list[dict] = []
    gltf_candidates: list[Path] = []

    for entry in archive.entries:
        payload = archive.payload(entry)
        fallback = f"{entry.index:04d}_{entry.identifier:08X}{sniff_extension(payload)}"
        relative_output = safe_relative_path(entry.name, fallback)
        destination = unique_path(output_dir / relative_output)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(payload)

        row = asdict(entry)
        row.update(
            {
                "output_file": destination.relative_to(output_dir).as_posix(),
                "payload_magic": payload[:8].hex(" ").upper(),
            }
        )
        manifest_rows.append(row)

        if convert_gltf and payload.startswith(GMX_MAGIC):
            gltf_candidates.append(destination)

        if convert_gmx and payload.startswith(GMX_MAGIC):
            try:
                chunks = parse_gmx_chunks(payload)
                if any(chunk.tag == "MESH" for chunk in chunks):
                    export_gmx_obj_bytes(payload, destination.with_suffix(".obj"), flip_v=flip_v)
                else:
                    scan_meta = {
                        "source_size": len(payload),
                        "mesh_count": 0,
                        "note": "This GMX has no MESH chunks; it may be hierarchy/animation-only.",
                        "chunks": [
                            {"offset": c.offset, "tag": c.tag, "size": c.size} for c in chunks
                        ],
                    }
                    destination.with_suffix(".gmx.json").write_text(
                        json.dumps(scan_meta, indent=2), encoding="utf-8"
                    )
            except Exception as exc:
                print(f"warning: GMX conversion failed for {destination}: {exc}", file=sys.stderr)

        if convert_tex and (destination.suffix.lower() == ".tex" or looks_like_tex(payload)):
            try:
                export_tex_png_bytes(payload, destination.with_suffix(".png"))
            except Exception as exc:
                print(f"warning: TEX conversion failed for {destination}: {exc}", file=sys.stderr)
        elif convert_tex and (destination.suffix.lower() == ".crp" or looks_like_systemfont_crp(payload)):
            try:
                decrypted = xor_systemfont_crp(payload)
                png_path = destination.with_name(destination.stem + "_atlas.png")
                meta = export_tex_png_bytes(decrypted, png_path)
                meta.update({"source_format": "SIIG systemfont CRP", "xor_key": "0xF1"})
                png_path.with_suffix(png_path.suffix + ".json").write_text(
                    json.dumps(meta, indent=2), encoding="utf-8"
                )
            except Exception as exc:
                print(f"warning: CRP font conversion failed for {destination}: {exc}", file=sys.stderr)

        if recursive and payload.startswith(BBX_MAGIC):
            nested_dir = output_dir / f"{destination.stem}_nested"
            nested_results.append(
                extract_bbx_bytes(
                    payload,
                    nested_dir,
                    f"{source_label}:{entry.index}",
                    recursive=True,
                    convert_gmx=convert_gmx,
                    convert_gltf=convert_gltf,
                    convert_tex=convert_tex,
                    flip_v=flip_v,
                )
            )

    # Convert GMX after all archive entries have been written so referenced DDS/TEX
    # resources in the same archive are available to the material exporter.
    for gmx_path in gltf_candidates:
        try:
            relative = gmx_path.relative_to(output_dir).with_suffix(".gltf")
            export_gmx_gltf_file(
                gmx_path,
                output_dir,
                flip_v=flip_v,
                texture_roots=(output_dir,),
                relative_path=relative,
            )
        except Exception as exc:
            print(f"warning: glTF conversion failed for {gmx_path}: {exc}", file=sys.stderr)

    manifest_csv = output_dir / "manifest.csv"
    fields = [
        "index",
        "name",
        "output_file",
        "data_offset",
        "data_size",
        "name_offset",
        "identifier",
        "hash_matches",
        "payload_magic",
    ]
    with manifest_csv.open("w", newline="", encoding="utf-8") as fp:
        writer = csv.DictWriter(fp, fieldnames=fields)
        writer.writeheader()
        for row in manifest_rows:
            writer.writerow({field: row.get(field) for field in fields})

    metadata = {
        "source": source_label,
        "magic": "01 42 42 58",
        "count": archive.count,
        "mode": archive.mode,
        "hash_seed": f"0x{archive.hash_seed:08X}",
        "has_sorted_hash_index": bool(archive.sorted_index),
        "entries": manifest_rows,
        "nested": nested_results,
    }
    (output_dir / "manifest.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return metadata


def extract_bbx_file(
    path: Path,
    output_root: Path,
    recursive: bool,
    convert_gmx: bool,
    convert_gltf: bool,
    convert_tex: bool,
    flip_v: bool,
) -> dict:
    data = maybe_decompress(path.read_bytes())
    if not data.startswith(BBX_MAGIC):
        raise FormatError(f"{path}: decompressed data is not BBX")
    out = output_root / path.name
    # Strip multiple packaging suffixes for a clean output directory.
    for suffix in (".sdat", ".gz", ".bin"):
        if out.name.lower().endswith(suffix):
            out = out.with_name(out.name[: -len(suffix)])
    return extract_bbx_bytes(
        data, out, str(path), recursive, convert_gmx, convert_gltf, convert_tex, flip_v
    )



@dataclass
class XWBEntry:
    index: int
    name: str
    codec: str
    channels: int
    sample_rate: int
    bits_per_sample: int
    block_align: int
    num_samples: int
    data_offset: int
    data_size: int
    loop_begin: int
    loop_length: int
    flags: int


@dataclass
class XWBInfo:
    version: int
    endian: str
    bank_name: str
    bank_flags: int
    alignment: int
    data_offset: int
    data_size: int
    entries: list[XWBEntry]


def looks_like_xwb(data: bytes) -> bool:
    return len(data) >= 0x34 and data[:4] in (XWB_MAGIC_BE, XWB_MAGIC_LE)


def _xact_u32(data: bytes, off: int, endian: str) -> int:
    if off < 0 or off + 4 > len(data):
        raise FormatError(f"XACT u32 read outside file at 0x{off:X}")
    return struct.unpack_from(endian + "I", data, off)[0]


def _xact_s32(data: bytes, off: int, endian: str) -> int:
    if off < 0 or off + 4 > len(data):
        raise FormatError(f"XACT s32 read outside file at 0x{off:X}")
    return struct.unpack_from(endian + "i", data, off)[0]


def _printable_ascii_strings(data: bytes, min_length: int = 3) -> list[str]:
    pattern = rb"[\x20-\x7E]{" + str(min_length).encode("ascii") + rb",}"
    return [m.group().decode("ascii", errors="replace") for m in re.finditer(pattern, data)]


def parse_xsb_cue_names(data: bytes, total_waves: int, bank_name: str) -> list[str]:
    """Extract cue names from the simple XACT3 XSB banks used by SIIG.

    This game has one cue per wave. The large SE bank stores the 83 cue names
    consecutively, while the single-wave BGM banks store bank/wavebank names
    followed by the cue name.
    """
    if not data.startswith((XSB_MAGIC_BE, XSB_MAGIC_LE)):
        return []
    strings = [s for s in _printable_ascii_strings(data) if s not in {"KBDS", "SDBK"}]
    if total_waves == 1:
        return [strings[-1]] if strings else []
    if len(strings) >= total_waves:
        return strings[:total_waves]
    return strings


def parse_xwb(data: bytes, cue_names: Optional[Sequence[str]] = None) -> XWBInfo:
    """Parse standard (non-compact) XACT wave banks.

    SIIG uses big-endian XACT3 version 46 banks with standard 24-byte entries
    and XMA2 streams. Little-endian banks and the older standard segment layouts
    are accepted where their fields are compatible.
    """
    if not looks_like_xwb(data):
        raise FormatError("not an XACT XWB wave bank")
    endian = ">" if data[:4] == XWB_MAGIC_BE else "<"
    endian_name = "big" if endian == ">" else "little"
    version = _xact_u32(data, 0x04, endian)
    segment = 0x08 if version <= 41 else 0x0C

    base_offset = _xact_u32(data, segment + 0x00, endian)
    entry_offset = _xact_u32(data, segment + 0x08, endian)
    entry_segment_size = _xact_u32(data, segment + 0x0C, endian)

    if version <= 21:
        suboffset = 0x08
    elif version == 22:
        suboffset = base_offset - 0x20
    else:
        suboffset = 0x10
    data_offset = _xact_u32(data, segment + 0x10 + suboffset, endian)
    data_size = _xact_u32(data, segment + 0x14 + suboffset, endian)

    if base_offset <= 0 or base_offset + 8 > len(data):
        raise FormatError("invalid XWB bank-data segment")
    bank_flags = _xact_u32(data, base_offset + 0x00, endian)
    total = _xact_s32(data, base_offset + 0x04, endian)
    if total <= 0 or total > 100000:
        raise FormatError(f"invalid XWB stream count {total}")
    name_size = 0x10 if version <= 21 else 0x40
    raw_name = data[base_offset + 0x08 : base_offset + 0x08 + name_size]
    bank_name = raw_name.split(b"\0", 1)[0].decode("ascii", errors="replace")
    base_fields = base_offset + 0x08 + name_size
    entry_size = _xact_u32(data, base_fields + 0x00, endian)
    alignment = _xact_u32(data, base_fields + 0x08, endian)

    if bank_flags & WAVEBANK_FLAGS_COMPACT:
        raise FormatError("compact XWB entries are not supported by the built-in SIIG converter")
    if entry_size < 0x18:
        raise FormatError(f"unsupported XWB entry size 0x{entry_size:X}")
    if entry_offset + total * entry_size > len(data):
        raise FormatError("XWB entry table extends beyond the file")
    if entry_segment_size < total * entry_size:
        raise FormatError("XWB entry segment is smaller than its entry table")

    names = list(cue_names or [])
    entries: list[XWBEntry] = []
    codecs = ("PCM", "XMA2", "MS_ADPCM", "XWMA")
    for index in range(total):
        off = entry_offset + index * entry_size
        entry_info, packed_format, relative_offset, stream_size, loop_begin, loop_length = struct.unpack_from(
            endian + "6I", data, off
        )
        if version <= 41:
            raise FormatError(f"built-in audio conversion currently requires XACT3 v42+, found v{version}")
        bits_flag = (packed_format >> 31) & 1
        block_align = (packed_format >> 23) & 0xFF
        sample_rate = (packed_format >> 5) & 0x3FFFF
        channels = (packed_format >> 2) & 0x7
        tag = packed_format & 0x3
        absolute_offset = data_offset + relative_offset
        if absolute_offset > len(data) or stream_size > len(data) - absolute_offset:
            raise FormatError(f"XWB stream {index} extends beyond the file")
        fallback = f"{bank_name or 'wave'}_{index + 1:03d}"
        name = names[index] if index < len(names) and names[index] else fallback
        entries.append(
            XWBEntry(
                index=index,
                name=name,
                codec=codecs[tag],
                channels=channels,
                sample_rate=sample_rate,
                bits_per_sample=8 if bits_flag == 0 else 16,
                block_align=block_align,
                num_samples=entry_info >> 4,
                data_offset=absolute_offset,
                data_size=stream_size,
                loop_begin=loop_begin,
                loop_length=loop_length,
                flags=entry_info & 0xF,
            )
        )
    return XWBInfo(version, endian_name, bank_name, bank_flags, alignment, data_offset, data_size, entries)


def _xma_channel_mask(channels: int) -> int:
    return {1: 0x4, 2: 0x3, 3: 0x7, 4: 0x33, 5: 0x37, 6: 0x3F}.get(
        channels, (1 << channels) - 1
    )


def build_xma2_riff(raw_xma: bytes, entry: XWBEntry) -> bytes:
    """Wrap one raw XACT XMA2 stream in a standard RIFF/WAVE header."""
    if entry.codec != "XMA2":
        raise FormatError(f"RIFF wrapper requested for non-XMA2 codec {entry.codec}")
    if entry.channels <= 0 or entry.sample_rate <= 0:
        raise FormatError("invalid XMA2 channel count or sample rate")
    bytes_per_block = 0x10000
    block_count = max(1, (len(raw_xma) + bytes_per_block - 1) // bytes_per_block)
    avg_bytes_per_sec = max(1, round(len(raw_xma) * entry.sample_rate / max(1, entry.num_samples)))
    wave_format = struct.pack(
        "<HHIIHHH",
        0x0166,
        entry.channels,
        entry.sample_rate,
        avg_bytes_per_sec,
        entry.channels * 2,
        16,
        34,
    )
    extra = struct.pack(
        "<HIIIIIIIBBH",
        (entry.channels + 1) // 2,
        _xma_channel_mask(entry.channels),
        entry.num_samples,
        bytes_per_block,
        0,
        entry.num_samples,
        entry.loop_begin,
        entry.loop_length,
        255 if entry.loop_length else 0,
        4,
        block_count,
    )
    fmt_payload = wave_format + extra
    body = (
        b"WAVE"
        + b"fmt "
        + struct.pack("<I", len(fmt_payload))
        + fmt_payload
        + b"data"
        + struct.pack("<I", len(raw_xma))
        + raw_xma
    )
    return b"RIFF" + struct.pack("<I", len(body)) + body


def _safe_audio_name(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._")
    return cleaned or "stream"


def export_xwb_audio_bytes(
    xwb_data: bytes,
    output_dir: Path,
    source_label: str,
    xsb_data: Optional[bytes] = None,
    ffmpeg_path: Optional[str] = None,
    keep_xma: bool = False,
) -> dict:
    preliminary = parse_xwb(xwb_data)
    cue_names = parse_xsb_cue_names(xsb_data or b"", len(preliminary.entries), preliminary.bank_name)
    info = parse_xwb(xwb_data, cue_names)
    output_dir.mkdir(parents=True, exist_ok=True)
    ffmpeg = ffmpeg_path or shutil.which("ffmpeg")
    rows: list[dict] = []
    decode_failures = 0

    for entry in info.entries:
        raw = xwb_data[entry.data_offset : entry.data_offset + entry.data_size]
        stem = f"{entry.index + 1:03d}_{_safe_audio_name(entry.name)}"
        encoded_path = output_dir / f"{stem}.xma"
        wav_path = output_dir / f"{stem}.wav"
        decoded = False
        error = ""
        if entry.codec == "XMA2":
            encoded_path.write_bytes(build_xma2_riff(raw, entry))
            if ffmpeg:
                result = subprocess.run(
                    [
                        ffmpeg,
                        "-y",
                        "-hide_banner",
                        "-loglevel",
                        "error",
                        "-i",
                        str(encoded_path),
                        "-c:a",
                        "pcm_s16le",
                        str(wav_path),
                    ],
                    capture_output=True,
                    text=True,
                )
                decoded = result.returncode == 0 and wav_path.exists()
                if not decoded:
                    decode_failures += 1
                    error = result.stderr.strip()[-1000:]
                elif not keep_xma:
                    encoded_path.unlink(missing_ok=True)
        else:
            error = f"built-in converter does not yet handle {entry.codec}"
            decode_failures += 1

        row = asdict(entry)
        row.update(
            {
                "xma_file": encoded_path.name if encoded_path.exists() else "",
                "wav_file": wav_path.name if wav_path.exists() else "",
                "decoded": decoded,
                "error": error,
            }
        )
        rows.append(row)

    manifest = {
        "source": source_label,
        "format": "XACT XWB",
        "version": info.version,
        "endian": info.endian,
        "bank_name": info.bank_name,
        "bank_flags": f"0x{info.bank_flags:08X}",
        "alignment": info.alignment,
        "stream_count": len(info.entries),
        "ffmpeg": ffmpeg,
        "decode_failures": decode_failures,
        "entries": rows,
    }
    (output_dir / "xwb_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    if rows:
        with (output_dir / "xwb_manifest.csv").open("w", newline="", encoding="utf-8") as fp:
            writer = csv.DictWriter(fp, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    return manifest


def _collect_xact_from_bbx(data: bytes, prefix: Path = Path()) -> dict[str, bytes]:
    archive = BBXArchive.parse(data)
    collected: dict[str, bytes] = {}
    for entry in archive.entries:
        payload = archive.payload(entry)
        fallback = f"{entry.index:04d}_{entry.identifier:08X}{sniff_extension(payload)}"
        rel = prefix / safe_relative_path(entry.name, fallback)
        if payload.startswith(BBX_MAGIC):
            collected.update(_collect_xact_from_bbx(payload, prefix / f"{rel.stem}_nested"))
        elif payload.startswith((XWB_MAGIC_BE, XWB_MAGIC_LE)) or rel.suffix.lower() == ".xwb":
            collected[rel.as_posix()] = payload
        elif payload.startswith((XSB_MAGIC_BE, XSB_MAGIC_LE)) or rel.suffix.lower() == ".xsb":
            collected[rel.as_posix()] = payload
    return collected


def _decode_xact_collection(
    files: dict[str, bytes], output_root: Path, source_label: str, ffmpeg_path: Optional[str], keep_xma: bool
) -> tuple[int, int]:
    success = 0
    failures = 0
    lower_lookup = {name.lower(): data for name, data in files.items()}
    for name, data in sorted(files.items()):
        if not name.lower().endswith(".xwb") and not looks_like_xwb(data):
            continue
        rel = Path(name)
        xsb_name = rel.with_suffix(".xsb").as_posix().lower()
        xsb_data = lower_lookup.get(xsb_name)
        target = output_root / rel.parent / rel.stem
        try:
            result = export_xwb_audio_bytes(
                data, target, f"{source_label}:{name}", xsb_data=xsb_data, ffmpeg_path=ffmpeg_path, keep_xma=keep_xma
            )
            print(
                f"{name}: {result['stream_count']} stream(s), "
                f"{result['decode_failures']} decode failure(s) -> {target}"
            )
            success += result["stream_count"] - result["decode_failures"]
            failures += result["decode_failures"]
        except Exception as exc:
            failures += 1
            print(f"ERROR {name}: {exc}", file=sys.stderr)
    return success, failures


def command_xact2wav(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    ffmpeg_path = args.ffmpeg or shutil.which("ffmpeg")
    if args.ffmpeg and not Path(args.ffmpeg).exists() and not shutil.which(args.ffmpeg):
        raise FormatError(f"FFmpeg executable not found: {args.ffmpeg}")

    if input_path.is_file():
        data = maybe_decompress(input_path.read_bytes())
        if data.startswith(BBX_MAGIC):
            files = _collect_xact_from_bbx(data)
            success, failures = _decode_xact_collection(
                files, output, str(input_path), ffmpeg_path, args.keep_xma
            )
        elif looks_like_xwb(data):
            xsb_path = input_path.with_suffix(".xsb")
            xsb_data = xsb_path.read_bytes() if xsb_path.exists() else None
            result = export_xwb_audio_bytes(
                data, output / input_path.stem, str(input_path), xsb_data, ffmpeg_path, args.keep_xma
            )
            success = result["stream_count"] - result["decode_failures"]
            failures = result["decode_failures"]
        else:
            raise FormatError("input is not sound.bin/BBX or an XWB wave bank")
    elif input_path.is_dir():
        files: dict[str, bytes] = {}
        for path in input_path.rglob("*"):
            if not path.is_file():
                continue
            try:
                head = path.read_bytes()[:4]
            except OSError:
                continue
            if path.suffix.lower() in {".xwb", ".xsb"} or head in (XWB_MAGIC_BE, XWB_MAGIC_LE, XSB_MAGIC_BE, XSB_MAGIC_LE):
                files[path.relative_to(input_path).as_posix()] = path.read_bytes()
        success, failures = _decode_xact_collection(
            files, output, str(input_path), ffmpeg_path, args.keep_xma
        )
    else:
        raise FileNotFoundError(input_path)

    if not ffmpeg_path:
        print(
            "FFmpeg was not found. RIFF-wrapped .xma files were written, but WAV decoding was skipped. "
            "Install FFmpeg or use vgmstream-cli to convert them.",
            file=sys.stderr,
        )
    print(f"completed: {success} decoded stream(s), {failures} failure(s)")
    return 1 if failures and not success else 0


@dataclass
class TEXInfo:
    width: int
    height: int
    physical_pitch: int
    format: int
    format_name: str
    endianness: int
    endianness_name: str
    tiled: bool
    swizzle: tuple[int, int, int, int]
    payload_size: int
    fetch_dwords: tuple[int, int, int, int, int, int]


def parse_tex(data: bytes) -> TEXInfo:
    if not looks_like_tex(data):
        raise FormatError("not a recognized SIIG Xbox 360 TEX file")
    words = struct.unpack_from(">13I", data, 0)
    fetch = words[7:13]
    d0, d1, d2, d3, _d4, _d5 = fetch
    width = (d2 & 0x1FFF) + 1
    height = ((d2 >> 13) & 0x1FFF) + 1
    pitch_units = (d0 >> 22) & 0x1FF
    physical_pitch = pitch_units * 32 if pitch_units else ((width + 31) & ~31)
    fmt = d1 & 0x3F
    endian = (d1 >> 6) & 3
    swizzle_word = (d3 >> 1) & 0xFFF
    swizzle = tuple((swizzle_word >> (component * 3)) & 7 for component in range(4))
    return TEXInfo(
        width=width,
        height=height,
        physical_pitch=physical_pitch,
        format=fmt,
        format_name=XENOS_TEXTURE_FORMAT_NAMES.get(fmt, f"unknown_{fmt}"),
        endianness=endian,
        endianness_name=XENOS_ENDIAN_NAMES.get(endian, f"unknown_{endian}"),
        tiled=bool(d0 >> 31),
        swizzle=swizzle,  # type: ignore[arg-type]
        payload_size=len(data) - TEX_HEADER_SIZE,
        fetch_dwords=fetch,  # type: ignore[arg-type]
    )


def xg_address_2d_tiled_offset(x: int, y: int, width: int, texel_pitch: int) -> int:
    """Return the Xenos byte address of one 2D tiled texel/block.

    This follows Xenia's current bit-decomposed texture-address implementation.
    The older commonly copied XGAddress2DTiledOffset formula omits the Y[3]
    XOR in the pipe selector, which produces the characteristic 8-row
    jitter/scrambling seen in the first toolkit build.

    ``width`` is the physical pitch in texels/blocks and must be 32-aligned.
    ``texel_pitch`` is the byte size of one texel/block and must be a power of 2.
    """
    aligned_width = (width + 31) & ~31
    if texel_pitch <= 0 or texel_pitch & (texel_pitch - 1):
        raise FormatError(f"invalid tiled texel pitch {texel_pitch}")
    bytes_per_block_log2 = texel_pitch.bit_length() - 1

    # Macro-tile origin and 8x16 micro-tile offset, measured in blocks.
    outer_blocks = (
        ((y >> 5) * (aligned_width >> 5) + (x >> 5)) << 6
    )
    inner_blocks = (((y >> 1) & 0b111) << 3) | (x & 0b111)
    outer_inner_bytes = (outer_blocks | inner_blocks) << bytes_per_block_log2

    # Xenos bank/pipe selection. The Y[3] XOR is essential.
    bank = (y >> 4) & 0b1
    pipe = ((x >> 3) & 0b11) ^ (((y >> 3) & 0b1) << 1)
    y_lsb = y & 0b1

    return (
        (y_lsb << 4)
        | (pipe << 6)
        | (bank << 11)
        | (outer_inner_bytes & 0x0F)
        | (((outer_inner_bytes >> 4) & 0x01) << 5)
        | (((outer_inner_bytes >> 5) & 0x07) << 8)
        | ((outer_inner_bytes >> 8) << 12)
    )


@lru_cache(maxsize=4)
def _xg_tiled_offset_table(width: int, height: int, physical_pitch: int, texel_pitch: int) -> array:
    # Compact 32-bit table; caching is especially valuable here because SIIG has
    # many textures with identical 1152x1152 layouts.
    offsets = array("I")
    append = offsets.append
    for y in range(height):
        for x in range(width):
            append(xg_address_2d_tiled_offset(x, y, physical_pitch, texel_pitch))
    return offsets


def _apply_xenos_endian(pixel: bytes, endian: int) -> bytes:
    if len(pixel) != 4:
        raise FormatError("truncated 32-bit TEX pixel")
    if endian == 0:
        return pixel
    if endian == 1:  # 8-in-16
        return bytes((pixel[1], pixel[0], pixel[3], pixel[2]))
    if endian == 2:  # 8-in-32
        return pixel[::-1]
    if endian == 3:  # 16-in-32
        return bytes((pixel[2], pixel[3], pixel[0], pixel[1]))
    raise FormatError(f"unsupported Xenos endian mode {endian}")


def _apply_xenos_swizzle(components: bytes, swizzle: tuple[int, int, int, int]) -> bytes:
    out = bytearray(4)
    for i, selector in enumerate(swizzle):
        if selector < 4:
            out[i] = components[selector]
        elif selector == 4:
            out[i] = 0
        elif selector == 5:
            out[i] = 255
        else:
            raise FormatError(f"unsupported Xenos swizzle selector {selector}")
    return bytes(out)


def decode_tex_rgba(data: bytes) -> tuple[TEXInfo, bytes]:
    info = parse_tex(data)
    if info.format != XENOS_TEXFMT_8_8_8_8:
        raise FormatError(
            f"TEX PNG conversion currently supports 8_8_8_8 (6), got {info.format_name} ({info.format})"
        )
    payload = data[TEX_HEADER_SIZE:]
    width = info.width
    height = info.height
    physical_pitch = info.physical_pitch
    rgba = bytearray(width * height * 4)

    # This is the exact combination used by every SIIG TEX sample examined:
    # k8in32 plus Z,Y,X,W swizzle. Keep a specialized path because the game has
    # many 1152x1152 images and avoiding per-pixel temporary objects is much faster.
    common_layout = info.endianness == 2 and info.swizzle == (2, 1, 0, 3)
    tiled = info.tiled
    payload_len = len(payload)
    if tiled:
        source_offsets: Iterable[int] = _xg_tiled_offset_table(width, height, physical_pitch, 4)
    else:
        source_offsets = (
            (y * physical_pitch + x) * 4 for y in range(height) for x in range(width)
        )
    target = 0
    for pixel_number, source in enumerate(source_offsets):
        if source + 4 > payload_len:
            x = pixel_number % width
            y = pixel_number // width
            raise FormatError(
                f"TEX pixel ({x},{y}) maps beyond payload at 0x{source:X} "
                f"(payload 0x{payload_len:X})"
            )
        if common_layout:
            # Raw GPU bytes ABCD -> k8in32 DCBA -> ZYXW swizzle BCDA.
            rgba[target] = payload[source + 1]
            rgba[target + 1] = payload[source + 2]
            rgba[target + 2] = payload[source + 3]
            rgba[target + 3] = payload[source]
        else:
            components = _apply_xenos_endian(payload[source : source + 4], info.endianness)
            pixel = _apply_xenos_swizzle(components, info.swizzle)
            rgba[target : target + 4] = pixel
        target += 4
    return info, bytes(rgba)


def _png_chunk(tag: bytes, payload: bytes) -> bytes:
    return struct.pack(">I", len(payload)) + tag + payload + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF)


def write_rgba_png(path: Path, width: int, height: int, rgba: bytes) -> None:
    if len(rgba) != width * height * 4:
        raise ValueError("RGBA byte count does not match dimensions")
    rows = b"".join(b"\x00" + rgba[y * width * 4 : (y + 1) * width * 4] for y in range(height))
    png = (
        b"\x89PNG\r\n\x1a\n"
        + _png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
        + _png_chunk(b"IDAT", zlib.compress(rows, 1))
        + _png_chunk(b"IEND", b"")
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(png)


def export_tex_png_bytes(data: bytes, png_path: Path) -> dict:
    info, rgba = decode_tex_rgba(data)
    write_rgba_png(png_path, info.width, info.height, rgba)
    metadata = asdict(info)
    metadata["fetch_dwords"] = [f"0x{value:08X}" for value in info.fetch_dwords]
    metadata["swizzle"] = list(info.swizzle)
    png_path.with_suffix(png_path.suffix + ".json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    return metadata


def export_tex_file(path: Path, output_root: Path) -> dict:
    return export_tex_png_bytes(path.read_bytes(), output_root / f"{path.stem}.png")


@dataclass
class GMXChunk:
    offset: int
    tag: str
    size: int
    raw: bytes


@dataclass
class GMXArray:
    chunk: GMXChunk
    array_index: int
    flags: int
    semantic: str
    slot: int
    components: int
    gl_type: int
    count: int
    values: list[tuple[float | int, ...]]


@dataclass
class GMXMesh:
    chunk: GMXChunk
    mesh_index: int
    flags: int
    primitive_mode: int
    unknown_14: int
    index_count: int
    skin_index: int
    array_refs: list[int]


def parse_gmx_chunks(data: bytes) -> list[GMXChunk]:
    if len(data) < 0x30 or not data.startswith(GMX_MAGIC):
        raise FormatError("not a GMX file")
    root_size = be_u32(data, 0x04)
    total_size = be_u32(data, 0x0C)
    if root_size < 8 or root_size > len(data):
        raise FormatError(f"invalid GMX root size 0x{root_size:X}")
    if total_size == 0:
        total_size = len(data)
    if total_size > len(data):
        raise FormatError(f"GMX reports size 0x{total_size:X}, file is only 0x{len(data):X}")

    chunks: list[GMXChunk] = []
    pos = 0
    while pos < total_size:
        if pos + 8 > total_size:
            raise FormatError(f"truncated GMX chunk header at 0x{pos:X}")
        raw_tag = data[pos : pos + 4]
        tag = raw_tag.rstrip(b"\0").decode("ascii", errors="replace")
        size = be_u32(data, pos + 4)
        if size < 8 or pos + size > total_size:
            raise FormatError(f"invalid {tag!r} chunk size 0x{size:X} at 0x{pos:X}")
        chunks.append(GMXChunk(pos, tag, size, data[pos : pos + size]))
        pos += size
    if pos != total_size:
        raise FormatError(f"GMX chunks end at 0x{pos:X}, expected 0x{total_size:X}")
    return chunks


def parse_gmx_array(chunk: GMXChunk) -> GMXArray:
    raw = chunk.raw
    if chunk.tag != "ARRY" or len(raw) < 0x30:
        raise FormatError("invalid ARRY chunk")
    array_index = be_u16(raw, 0x08)
    flags = be_u16(raw, 0x0A)
    semantic = raw[0x10:0x20].split(b"\0", 1)[0].decode("ascii", errors="replace")
    slot = be_u32(raw, 0x20)
    components = be_u32(raw, 0x24)
    gl_type = be_u32(raw, 0x28)
    count = be_u32(raw, 0x2C)
    if components < 1 or components > 16:
        raise FormatError(f"ARRY {array_index}: implausible component count {components}")

    if gl_type == GL_FLOAT:
        scalar_size = 4
        fmt_char = "f"
    elif gl_type == GL_UNSIGNED_SHORT:
        scalar_size = 2
        fmt_char = "H"
    else:
        raise FormatError(f"ARRY {array_index}: unsupported GL type 0x{gl_type:X}")

    byte_count = count * components * scalar_size
    if 0x30 + byte_count > len(raw):
        raise FormatError(
            f"ARRY {array_index}: data exceeds chunk ({count}*{components}*{scalar_size})"
        )
    flat = struct.unpack_from(f">{count * components}{fmt_char}", raw, 0x30)
    values = [tuple(flat[i : i + components]) for i in range(0, len(flat), components)]
    return GMXArray(chunk, array_index, flags, semantic, slot, components, gl_type, count, values)


def parse_gmx_mesh(chunk: GMXChunk) -> GMXMesh:
    raw = chunk.raw
    if chunk.tag != "MESH" or len(raw) < 0x20:
        raise FormatError("invalid MESH chunk")
    mesh_index = be_u16(raw, 0x08)
    flags = be_u16(raw, 0x0A)
    primitive_mode = be_u32(raw, 0x10)
    unknown_14 = be_u32(raw, 0x14)
    index_count = be_u32(raw, 0x18)
    skin_index = be_u16(raw, 0x1C)
    ref_count = be_u16(raw, 0x1E)
    if 0x20 + ref_count * 2 > len(raw):
        raise FormatError(f"MESH {mesh_index}: reference list exceeds chunk")
    refs = list(struct.unpack_from(f">{ref_count}H", raw, 0x20)) if ref_count else []
    return GMXMesh(chunk, mesh_index, flags, primitive_mode, unknown_14, index_count, skin_index, refs)


def _array_by_semantic(arrays: Sequence[GMXArray], semantic: str) -> Optional[GMXArray]:
    for arr in arrays:
        if arr.semantic == semantic:
            return arr
    return None


def _index_array(arrays: Sequence[GMXArray]) -> Optional[GMXArray]:
    for arr in arrays:
        if arr.gl_type == GL_UNSIGNED_SHORT and arr.components == 1:
            return arr
    return None


def export_gmx_obj_bytes(data: bytes, obj_path: Path, flip_v: bool = False) -> dict:
    chunks = parse_gmx_chunks(data)
    arrays = {arr.array_index: arr for arr in (parse_gmx_array(c) for c in chunks if c.tag == "ARRY")}
    meshes = [parse_gmx_mesh(c) for c in chunks if c.tag == "MESH"]
    if not meshes:
        raise FormatError("GMX contains no MESH chunks")

    obj_path.parent.mkdir(parents=True, exist_ok=True)
    metadata: dict = {
        "source_size": len(data),
        "chunk_count": len(chunks),
        "chunk_tags": [c.tag for c in chunks],
        "mesh_count": len(meshes),
        "meshes": [],
    }

    v_base = 0
    vt_base = 0
    vn_base = 0
    lines: list[str] = [
        "# Space Invaders Infinity Gene GMX export",
        "# Geometry decoded from big-endian GMX ARRY/MESH chunks.",
    ]

    for ordinal, mesh in enumerate(meshes):
        referenced = [arrays[idx] for idx in mesh.array_refs if idx in arrays]
        pos = _array_by_semantic(referenced, "IN.position")
        normal = _array_by_semantic(referenced, "IN.normal")
        uv = _array_by_semantic(referenced, "IN.texuv")
        color = _array_by_semantic(referenced, "IN.color")
        indices = _index_array(referenced)
        if pos is None or indices is None:
            raise FormatError(
                f"MESH {mesh.mesh_index}: missing position or index array (refs={mesh.array_refs})"
            )
        if pos.components < 3:
            raise FormatError(f"MESH {mesh.mesh_index}: position array has {pos.components} components")
        if indices.count != mesh.index_count:
            raise FormatError(
                f"MESH {mesh.mesh_index}: index count mismatch {indices.count} != {mesh.index_count}"
            )

        name = f"mesh_{ordinal:03d}_{mesh.mesh_index}"
        lines.append(f"\no {name}")
        for value in pos.values:
            lines.append(f"v {value[0]:.9g} {value[1]:.9g} {value[2]:.9g}")
        if uv is not None:
            for value in uv.values:
                u = float(value[0])
                v = 1.0 - float(value[1]) if flip_v else float(value[1])
                lines.append(f"vt {u:.9g} {v:.9g}")
        if normal is not None:
            for value in normal.values:
                lines.append(f"vn {value[0]:.9g} {value[1]:.9g} {value[2]:.9g}")

        idx = [int(v[0]) for v in indices.values]
        vertex_count = pos.count
        if any(i >= vertex_count for i in idx):
            bad = max(idx)
            raise FormatError(
                f"MESH {mesh.mesh_index}: index {bad} exceeds vertex count {vertex_count}"
            )

        def vertex_ref(i: int) -> str:
            vi = v_base + i + 1
            has_uv = uv is not None and i < uv.count
            has_normal = normal is not None and i < normal.count
            if has_uv and has_normal:
                return f"{vi}/{vt_base + i + 1}/{vn_base + i + 1}"
            if has_uv:
                return f"{vi}/{vt_base + i + 1}"
            if has_normal:
                return f"{vi}//{vn_base + i + 1}"
            return str(vi)

        if mesh.primitive_mode == GL_TRIANGLES:
            if len(idx) % 3:
                raise FormatError(f"MESH {mesh.mesh_index}: triangle index count is not divisible by 3")
            for i in range(0, len(idx), 3):
                lines.append("f " + " ".join(vertex_ref(x) for x in idx[i : i + 3]))
            primitive = "triangles"
        elif mesh.primitive_mode == GL_LINES:
            if len(idx) % 2:
                raise FormatError(f"MESH {mesh.mesh_index}: line index count is not divisible by 2")
            for i in range(0, len(idx), 2):
                lines.append("l " + " ".join(str(v_base + x + 1) for x in idx[i : i + 2]))
            primitive = "lines"
        else:
            raise FormatError(
                f"MESH {mesh.mesh_index}: unsupported primitive mode 0x{mesh.primitive_mode:X}"
            )

        metadata["meshes"].append(
            {
                "mesh_index": mesh.mesh_index,
                "primitive_mode": f"0x{mesh.primitive_mode:X}",
                "primitive": primitive,
                "index_count": mesh.index_count,
                "vertex_count": pos.count,
                "array_refs": mesh.array_refs,
                "has_normals": normal is not None,
                "has_uv": uv is not None,
                "has_color": color is not None,
                "skin_index": mesh.skin_index,
            }
        )

        v_base += pos.count
        if uv is not None:
            vt_base += uv.count
        if normal is not None:
            vn_base += normal.count

    obj_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    meta_path = obj_path.with_suffix(obj_path.suffix + ".json")
    meta_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return metadata


def export_gmx_file(path: Path, output_root: Path, flip_v: bool) -> dict:
    out = output_root / f"{path.stem}.obj"
    return export_gmx_obj_bytes(path.read_bytes(), out, flip_v=flip_v)


@dataclass
class GMXTextureRef:
    index: int
    flags: int
    name: str


@dataclass
class GMXShader:
    index: int
    flags: int
    name: str


@dataclass
class GMXMaterialParameter:
    name: str
    type_code: int
    count: int
    value: object


@dataclass
class GMXMaterial:
    index: int
    flags: int
    name: str
    shader_index: int
    parameters: list[GMXMaterialParameter]


@dataclass
class GMXParentGroup:
    parent: int
    children: list[int]


@dataclass
class GMXBone:
    index: int
    flags: int
    name: str
    matrix: tuple[float, ...]
    material_index: Optional[int]
    mesh_index: Optional[int]


@dataclass
class GMXMotion:
    index: int
    duration: float


@dataclass
class GMXAnimationTrack:
    index: int
    target_bone: int
    channel_type: int
    times: tuple[float, ...]
    matrices: list[tuple[float, ...]]


def _fixed_ascii(raw: bytes, offset: int, length: int) -> str:
    return raw[offset : offset + length].split(b"\0", 1)[0].decode("ascii", errors="replace")


def parse_gmx_texture_ref(chunk: GMXChunk) -> GMXTextureRef:
    if chunk.tag != "TXIF" or chunk.size != 0x30:
        raise FormatError("invalid TXIF chunk")
    return GMXTextureRef(be_u16(chunk.raw, 0x08), be_u16(chunk.raw, 0x0A), _fixed_ascii(chunk.raw, 0x10, 0x20))


def parse_gmx_shader(chunk: GMXChunk) -> GMXShader:
    if chunk.tag != "SHAD" or chunk.size != 0x30:
        raise FormatError("invalid SHAD chunk")
    return GMXShader(be_u16(chunk.raw, 0x08), be_u16(chunk.raw, 0x0A), _fixed_ascii(chunk.raw, 0x10, 0x20))


def parse_gmx_material(chunk: GMXChunk) -> GMXMaterial:
    if chunk.tag != "MTRL" or chunk.size < 0x38:
        raise FormatError("invalid MTRL chunk")
    index = be_u16(chunk.raw, 0x08)
    flags = be_u16(chunk.raw, 0x0A)
    name = _fixed_ascii(chunk.raw, 0x10, 0x20)
    shader_index = be_u32(chunk.raw, 0x30)
    parameter_count = be_u32(chunk.raw, 0x34)
    offset = 0x38
    parameters: list[GMXMaterialParameter] = []
    for _ in range(parameter_count):
        if offset + 0x38 > len(chunk.raw):
            raise FormatError(f"MTRL {index}: truncated parameter header")
        param_name = _fixed_ascii(chunk.raw, offset, 0x30)
        type_code = be_u32(chunk.raw, offset + 0x30)
        count = be_u32(chunk.raw, offset + 0x34)
        value_offset = offset + 0x38
        if type_code == 0:  # float vector/scalar
            byte_count = count * 4
            if value_offset + byte_count > len(chunk.raw):
                raise FormatError(f"MTRL {index}: float parameter exceeds chunk")
            value: object = tuple(struct.unpack_from(f">{count}f", chunk.raw, value_offset)) if count else tuple()
            offset = value_offset + byte_count
        elif type_code == 1:  # one or more 4x4 matrices
            byte_count = count * 0x40
            if value_offset + byte_count > len(chunk.raw):
                raise FormatError(f"MTRL {index}: matrix parameter exceeds chunk")
            value = [tuple(struct.unpack_from(">16f", chunk.raw, value_offset + i * 0x40)) for i in range(count)]
            offset = value_offset + byte_count
        elif type_code == 2:  # texture/sampler reference; the count field is the TXIF index
            value = count
            offset = value_offset
        else:
            raise FormatError(f"MTRL {index}: unsupported parameter type {type_code}")
        parameters.append(GMXMaterialParameter(param_name, type_code, count, value))
    if any(chunk.raw[offset:]):
        raise FormatError(f"MTRL {index}: unexpected non-zero trailing bytes")
    return GMXMaterial(index, flags, name, shader_index, parameters)


def parse_gmx_parent_group(chunk: GMXChunk) -> GMXParentGroup:
    if chunk.tag != "PARE" or chunk.size < 0x18:
        raise FormatError("invalid PARE chunk")
    child_count = be_u32(chunk.raw, 0x10)
    parent = struct.unpack_from(">i", chunk.raw, 0x14)[0]
    end = 0x18 + child_count * 4
    if end > len(chunk.raw):
        raise FormatError("PARE child list exceeds chunk")
    children = list(struct.unpack_from(f">{child_count}I", chunk.raw, 0x18)) if child_count else []
    return GMXParentGroup(parent, children)


def parse_gmx_bone(chunk: GMXChunk) -> GMXBone:
    if chunk.tag != "BONE" or chunk.size != 0x80:
        raise FormatError("invalid BONE chunk")
    index = be_u16(chunk.raw, 0x08)
    flags = be_u16(chunk.raw, 0x0A)
    name = _fixed_ascii(chunk.raw, 0x10, 0x20)
    matrix = tuple(struct.unpack_from(">16f", chunk.raw, 0x30))
    attachment_count = be_u32(chunk.raw, 0x70)
    if attachment_count > 3:
        raise FormatError(f"BONE {index}: too many attachment references ({attachment_count})")
    material_index: Optional[int] = None
    mesh_index: Optional[int] = None
    for i in range(attachment_count):
        encoded = be_u32(chunk.raw, 0x74 + i * 4)
        ref_type = encoded >> 16
        ref_index = encoded & 0xFFFF
        if ref_type == 2:
            material_index = ref_index
        elif ref_type == 3:
            mesh_index = ref_index
    return GMXBone(index, flags, name, matrix, material_index, mesh_index)


def parse_gmx_motion(chunk: GMXChunk) -> GMXMotion:
    if chunk.tag != "MOTN" or chunk.size != 0x20:
        raise FormatError("invalid MOTN chunk")
    encoded_index = be_u32(chunk.raw, 0x08)
    if encoded_index & 0xFFFF:
        raise FormatError("MOTN index has unexpected low bits")
    duration = struct.unpack_from(">f", chunk.raw, 0x14)[0]
    return GMXMotion(encoded_index >> 16, duration)


def parse_gmx_animation(chunk: GMXChunk) -> GMXAnimationTrack:
    if chunk.tag != "ANIM" or chunk.size < 0x20:
        raise FormatError("invalid ANIM chunk")
    encoded_index = be_u32(chunk.raw, 0x08)
    if encoded_index & 0xFFFF:
        raise FormatError("ANIM index has unexpected low bits")
    target_bone = be_u32(chunk.raw, 0x10)
    channel_type = be_u32(chunk.raw, 0x14)
    frame_count = be_u32(chunk.raw, 0x18)
    value_count = be_u32(chunk.raw, 0x1C)
    if channel_type != 12 or value_count != 16:
        raise FormatError(
            f"ANIM {encoded_index >> 16}: unsupported channel/value layout {channel_type}/{value_count}"
        )
    times_offset = 0x20
    values_offset = times_offset + frame_count * 4
    required = values_offset + frame_count * value_count * 4
    if required > len(chunk.raw):
        raise FormatError(f"ANIM {encoded_index >> 16}: data exceeds chunk")
    times = tuple(struct.unpack_from(f">{frame_count}f", chunk.raw, times_offset))
    flat = struct.unpack_from(f">{frame_count * value_count}f", chunk.raw, values_offset)
    matrices = [tuple(flat[i : i + value_count]) for i in range(0, len(flat), value_count)]
    if any(chunk.raw[required:]):
        raise FormatError(f"ANIM {encoded_index >> 16}: unexpected non-zero trailing bytes")
    return GMXAnimationTrack(encoded_index >> 16, target_bone, channel_type, times, matrices)


def _transpose_4x4(values: Sequence[float]) -> tuple[float, ...]:
    if len(values) != 16:
        raise ValueError("matrix must contain 16 values")
    return tuple(float(values[c * 4 + r]) for r in range(4) for c in range(4))


def _det3(m: Sequence[Sequence[float]]) -> float:
    return (
        m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
        - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
    )


def _quat_from_matrix3(m: Sequence[Sequence[float]]) -> tuple[float, float, float, float]:
    trace = m[0][0] + m[1][1] + m[2][2]
    if trace > 0.0:
        s = math.sqrt(trace + 1.0) * 2.0
        w = 0.25 * s
        x = (m[2][1] - m[1][2]) / s
        y = (m[0][2] - m[2][0]) / s
        z = (m[1][0] - m[0][1]) / s
    elif m[0][0] > m[1][1] and m[0][0] > m[2][2]:
        s = math.sqrt(max(0.0, 1.0 + m[0][0] - m[1][1] - m[2][2])) * 2.0
        w = (m[2][1] - m[1][2]) / s
        x = 0.25 * s
        y = (m[0][1] + m[1][0]) / s
        z = (m[0][2] + m[2][0]) / s
    elif m[1][1] > m[2][2]:
        s = math.sqrt(max(0.0, 1.0 + m[1][1] - m[0][0] - m[2][2])) * 2.0
        w = (m[0][2] - m[2][0]) / s
        x = (m[0][1] + m[1][0]) / s
        y = 0.25 * s
        z = (m[1][2] + m[2][1]) / s
    else:
        s = math.sqrt(max(0.0, 1.0 + m[2][2] - m[0][0] - m[1][1])) * 2.0
        w = (m[1][0] - m[0][1]) / s
        x = (m[0][2] + m[2][0]) / s
        y = (m[1][2] + m[2][1]) / s
        z = 0.25 * s
    length = math.sqrt(x * x + y * y + z * z + w * w)
    if length <= 1e-12:
        return (0.0, 0.0, 0.0, 1.0)
    return (x / length, y / length, z / length, w / length)


def decompose_standard_matrix(matrix: Sequence[float]) -> tuple[tuple[float, float, float], tuple[float, float, float, float], tuple[float, float, float], float]:
    """Decompose a conventional row-major, column-vector affine matrix.

    Returns translation, quaternion (x,y,z,w), scale, and a simple orthogonality error.
    """
    if len(matrix) != 16:
        raise ValueError("matrix must contain 16 values")
    translation = (float(matrix[3]), float(matrix[7]), float(matrix[11]))
    columns = [
        [float(matrix[0]), float(matrix[4]), float(matrix[8])],
        [float(matrix[1]), float(matrix[5]), float(matrix[9])],
        [float(matrix[2]), float(matrix[6]), float(matrix[10])],
    ]
    scales = [math.sqrt(sum(value * value for value in column)) for column in columns]
    for i, scale in enumerate(scales):
        if scale <= 1e-12:
            columns[i] = [1.0 if row == i else 0.0 for row in range(3)]
            scales[i] = 0.0
        else:
            columns[i] = [value / scale for value in columns[i]]
    rotation = [[columns[col][row] for col in range(3)] for row in range(3)]
    if _det3(rotation) < 0.0:
        scales[0] = -scales[0]
        for row in range(3):
            rotation[row][0] = -rotation[row][0]
    error = max(
        abs(sum(rotation[row][a] * rotation[row][b] for row in range(3)))
        for a in range(3)
        for b in range(a + 1, 3)
    )
    quaternion = _quat_from_matrix3(rotation)
    return translation, quaternion, (scales[0], scales[1], scales[2]), error


def _dds_mask_channel(value: int, mask: int) -> int:
    if mask == 0:
        return 255
    shift = (mask & -mask).bit_length() - 1
    bits = (mask >> shift).bit_length()
    raw = (value & mask) >> shift
    maximum = (1 << bits) - 1
    return int(round(raw * 255 / maximum)) if maximum else 0


def decode_uncompressed_dds_rgba(data: bytes) -> tuple[int, int, bytes]:
    if len(data) < 128 or data[:4] != b"DDS ":
        raise FormatError("not a DDS file")
    if struct.unpack_from("<I", data, 4)[0] != 124:
        raise FormatError("unsupported DDS header size")
    height = struct.unpack_from("<I", data, 12)[0]
    width = struct.unpack_from("<I", data, 16)[0]
    pf_flags = struct.unpack_from("<I", data, 80)[0]
    fourcc = data[84:88]
    rgb_bits = struct.unpack_from("<I", data, 88)[0]
    masks = struct.unpack_from("<4I", data, 92)
    if fourcc != b"\0\0\0\0" or not (pf_flags & 0x40) or rgb_bits != 32:
        raise FormatError("only uncompressed 32-bit RGB(A) DDS is supported")
    byte_count = width * height * 4
    if 128 + byte_count > len(data):
        raise FormatError("DDS pixel payload is truncated")
    output = bytearray(byte_count)
    rmask, gmask, bmask, amask = masks
    for i in range(width * height):
        value = struct.unpack_from("<I", data, 128 + i * 4)[0]
        output[i * 4 + 0] = _dds_mask_channel(value, rmask)
        output[i * 4 + 1] = _dds_mask_channel(value, gmask)
        output[i * 4 + 2] = _dds_mask_channel(value, bmask)
        output[i * 4 + 3] = _dds_mask_channel(value, amask) if amask else 255
    return width, height, bytes(output)


class GltfBufferBuilder:
    def __init__(self) -> None:
        self.data = bytearray()
        self.buffer_views: list[dict] = []
        self.accessors: list[dict] = []

    def add_view(self, payload: bytes, target: Optional[int] = None) -> int:
        while len(self.data) % 4:
            self.data.append(0)
        offset = len(self.data)
        self.data.extend(payload)
        view: dict = {"buffer": 0, "byteOffset": offset, "byteLength": len(payload)}
        if target is not None:
            view["target"] = target
        self.buffer_views.append(view)
        return len(self.buffer_views) - 1

    def add_accessor(
        self,
        payload: bytes,
        component_type: int,
        value_type: str,
        count: int,
        *,
        target: Optional[int] = None,
        minimum: Optional[Sequence[float]] = None,
        maximum: Optional[Sequence[float]] = None,
    ) -> int:
        view_index = self.add_view(payload, target)
        accessor: dict = {
            "bufferView": view_index,
            "componentType": component_type,
            "count": count,
            "type": value_type,
        }
        if minimum is not None:
            accessor["min"] = [float(x) for x in minimum]
        if maximum is not None:
            accessor["max"] = [float(x) for x in maximum]
        self.accessors.append(accessor)
        return len(self.accessors) - 1


def _pack_float_tuples(values: Sequence[Sequence[float]]) -> bytes:
    flat = [float(component) for value in values for component in value]
    return struct.pack(f"<{len(flat)}f", *flat)


def _minmax_tuples(values: Sequence[Sequence[float]], components: int) -> tuple[list[float], list[float]]:
    return (
        [min(float(value[i]) for value in values) for i in range(components)],
        [max(float(value[i]) for value in values) for i in range(components)],
    )


def _find_texture_file(name: str, source_path: Optional[Path], texture_roots: Sequence[Path]) -> Optional[Path]:
    candidates: list[Path] = []
    if source_path is not None:
        candidates.append(source_path.parent / name)
    for root in texture_roots:
        candidates.append(root / name)
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    basename = Path(name).name.lower()
    search_roots: list[Path] = []
    if source_path is not None:
        search_roots.append(source_path.parent)
    search_roots.extend(texture_roots)
    seen: set[Path] = set()
    for root in search_roots:
        if root in seen or not root.is_dir():
            continue
        seen.add(root)
        for path in root.rglob("*"):
            if path.is_file() and path.name.lower() == basename:
                return path
    return None


def export_gmx_gltf_bytes(
    data: bytes,
    gltf_path: Path,
    *,
    source_path: Optional[Path] = None,
    texture_roots: Sequence[Path] = (),
    flip_v: bool = False,
) -> dict:
    chunks = parse_gmx_chunks(data)
    arrays = {arr.array_index: arr for arr in (parse_gmx_array(c) for c in chunks if c.tag == "ARRY")}
    meshes = {mesh.mesh_index: mesh for mesh in (parse_gmx_mesh(c) for c in chunks if c.tag == "MESH")}
    texture_refs = {item.index: item for item in (parse_gmx_texture_ref(c) for c in chunks if c.tag == "TXIF")}
    shaders = {item.index: item for item in (parse_gmx_shader(c) for c in chunks if c.tag == "SHAD")}
    materials = {item.index: item for item in (parse_gmx_material(c) for c in chunks if c.tag == "MTRL")}
    parent_groups = [parse_gmx_parent_group(c) for c in chunks if c.tag == "PARE"]
    bones = {item.index: item for item in (parse_gmx_bone(c) for c in chunks if c.tag == "BONE")}
    motions = {item.index: item for item in (parse_gmx_motion(c) for c in chunks if c.tag == "MOTN")}
    animations = [parse_gmx_animation(c) for c in chunks if c.tag == "ANIM"]

    gltf_path.parent.mkdir(parents=True, exist_ok=True)
    builder = GltfBufferBuilder()
    document: dict = {
        "asset": {"version": "2.0", "generator": "SIIG Asset Toolkit"},
        "scene": 0,
        "scenes": [{"nodes": []}],
        "nodes": [],
        "meshes": [],
        "materials": [],
        "buffers": [],
        "bufferViews": builder.buffer_views,
        "accessors": builder.accessors,
        "extras": {
            "sourceFormat": "Space Invaders Infinity Gene GMX",
            "chunkTags": [chunk.tag for chunk in chunks],
        },
    }

    image_indexes: dict[int, int] = {}
    texture_indexes: dict[int, int] = {}
    converted_textures: list[str] = []
    missing_textures: list[str] = []
    if texture_refs:
        document["images"] = []
        document["textures"] = []
        document["samplers"] = [{"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497}]
        texture_dir = gltf_path.parent / "_textures"
        for index, texture_ref in sorted(texture_refs.items()):
            source_texture = _find_texture_file(texture_ref.name, source_path, texture_roots)
            if source_texture is None:
                missing_textures.append(texture_ref.name)
                continue
            try:
                source_bytes = source_texture.read_bytes()
                if source_bytes.startswith(b"DDS "):
                    width, height, rgba = decode_uncompressed_dds_rgba(source_bytes)
                    destination = texture_dir / f"{source_texture.stem}.png"
                    if not destination.exists():
                        write_rgba_png(destination, width, height, rgba)
                elif looks_like_tex(source_bytes):
                    destination = texture_dir / f"{source_texture.stem}.png"
                    if not destination.exists():
                        export_tex_png_bytes(source_bytes, destination)
                elif source_texture.suffix.lower() in {".png", ".jpg", ".jpeg"}:
                    destination = texture_dir / source_texture.name
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    if not destination.exists() and source_texture.resolve() != destination.resolve():
                        shutil.copy2(source_texture, destination)
                else:
                    missing_textures.append(texture_ref.name)
                    continue
                uri = destination.relative_to(gltf_path.parent).as_posix()
                image_indexes[index] = len(document["images"])
                document["images"].append({"uri": uri, "name": texture_ref.name})
                texture_indexes[index] = len(document["textures"])
                document["textures"].append({"sampler": 0, "source": image_indexes[index], "name": texture_ref.name})
                converted_textures.append(uri)
            except Exception:
                missing_textures.append(texture_ref.name)

    material_map: dict[int, int] = {}
    uses_unlit = False
    for index, material in sorted(materials.items()):
        params = {parameter.name: parameter for parameter in material.parameters}
        diffuse = params.get("DiffuseColor")
        alpha = params.get("DiffuseAlpha")
        emissive = params.get("EmissiveColor")
        color_values = list(diffuse.value) if diffuse and diffuse.type_code == 0 else [1.0, 1.0, 1.0]
        while len(color_values) < 3:
            color_values.append(1.0)
        alpha_value = float(alpha.value[0]) if alpha and alpha.type_code == 0 and alpha.value else 1.0
        pbr: dict = {
            "baseColorFactor": [float(color_values[0]), float(color_values[1]), float(color_values[2]), alpha_value],
            "metallicFactor": 0.0,
            "roughnessFactor": 1.0,
        }
        sampler_param = params.get("DiffuseSampler")
        requested_texture: Optional[int] = None
        if sampler_param and sampler_param.type_code == 2:
            requested_texture = int(sampler_param.value)
            if requested_texture in texture_indexes:
                pbr["baseColorTexture"] = {"index": texture_indexes[requested_texture]}
        shader_name = shaders.get(material.shader_index).name if material.shader_index in shaders else ""
        gltf_material: dict = {
            "name": material.name or f"material_{index}",
            "pbrMetallicRoughness": pbr,
            "doubleSided": True,
            "extensions": {"KHR_materials_unlit": {}},
            "extras": {
                "gmxMaterialIndex": index,
                "gmxShader": shader_name,
                "requestedTextureIndex": requested_texture,
                "parameters": {
                    parameter.name: parameter.value for parameter in material.parameters if parameter.name != "mWVP"
                },
            },
        }
        uses_unlit = True
        if emissive and emissive.type_code == 0 and len(emissive.value) >= 3:
            gltf_material["emissiveFactor"] = [float(emissive.value[0]), float(emissive.value[1]), float(emissive.value[2])]
        if alpha_value < 0.999 or requested_texture is not None:
            gltf_material["alphaMode"] = "BLEND"
        material_map[index] = len(document["materials"])
        document["materials"].append(gltf_material)
    if uses_unlit:
        document["extensionsUsed"] = ["KHR_materials_unlit"]

    mesh_to_material: dict[int, Optional[int]] = {}
    mesh_to_bone: dict[int, int] = {}
    for bone in bones.values():
        if bone.mesh_index is not None:
            mesh_to_material[bone.mesh_index] = bone.material_index
            mesh_to_bone[bone.mesh_index] = bone.index

    mesh_map: dict[int, int] = {}
    for mesh_index, mesh in sorted(meshes.items()):
        referenced = [arrays[idx] for idx in mesh.array_refs if idx in arrays]
        position = _array_by_semantic(referenced, "IN.position")
        normal = _array_by_semantic(referenced, "IN.normal")
        texcoord = _array_by_semantic(referenced, "IN.texuv")
        color = _array_by_semantic(referenced, "IN.color")
        indices = _index_array(referenced)
        if position is None or indices is None:
            raise FormatError(f"MESH {mesh_index}: missing position or index array")
        attributes: dict = {}
        pos_values = [tuple(float(x) for x in value[:3]) for value in position.values]
        minimum, maximum = _minmax_tuples(pos_values, 3)
        attributes["POSITION"] = builder.add_accessor(
            _pack_float_tuples(pos_values), 5126, "VEC3", len(pos_values), target=34962, minimum=minimum, maximum=maximum
        )
        if normal is not None:
            normal_values = [tuple(float(x) for x in value[:3]) for value in normal.values]
            attributes["NORMAL"] = builder.add_accessor(
                _pack_float_tuples(normal_values), 5126, "VEC3", len(normal_values), target=34962
            )
        if texcoord is not None:
            uv_values = [
                (float(value[0]), 1.0 - float(value[1]) if flip_v else float(value[1]))
                for value in texcoord.values
            ]
            attributes["TEXCOORD_0"] = builder.add_accessor(
                _pack_float_tuples(uv_values), 5126, "VEC2", len(uv_values), target=34962
            )
        if color is not None:
            color_values = [tuple(float(x) for x in value[:4]) for value in color.values]
            attributes["COLOR_0"] = builder.add_accessor(
                _pack_float_tuples(color_values), 5126, "VEC4", len(color_values), target=34962
            )
        index_values = [int(value[0]) for value in indices.values]
        index_accessor = builder.add_accessor(
            struct.pack(f"<{len(index_values)}H", *index_values),
            5123,
            "SCALAR",
            len(index_values),
            target=34963,
            minimum=[min(index_values) if index_values else 0],
            maximum=[max(index_values) if index_values else 0],
        )
        primitive: dict = {
            "attributes": attributes,
            "indices": index_accessor,
            "mode": int(mesh.primitive_mode),
        }
        material_index = mesh_to_material.get(mesh_index)
        if material_index is not None and material_index in material_map:
            primitive["material"] = material_map[material_index]
        mesh_map[mesh_index] = len(document["meshes"])
        attached_bone = bones.get(mesh_to_bone.get(mesh_index, -1))
        mesh_name = attached_bone.name if attached_bone is not None and attached_bone.name else f"mesh_{mesh_index}"
        document["meshes"].append(
            {
                "name": mesh_name,
                "primitives": [primitive],
                "extras": {"gmxMeshIndex": mesh_index, "skinIndex": mesh.skin_index},
            }
        )

    node_map: dict[int, int] = {}
    decomposition_errors: list[float] = []
    for bone_index, bone in sorted(bones.items()):
        # BONE matrices use row-vector storage; transpose to conventional row-major matrix.
        standard_matrix = _transpose_4x4(bone.matrix)
        translation, rotation, scale, error = decompose_standard_matrix(standard_matrix)
        decomposition_errors.append(error)
        node: dict = {
            "name": bone.name or f"bone_{bone_index}",
            "translation": list(translation),
            "rotation": list(rotation),
            "scale": list(scale),
            "extras": {
                "gmxBoneIndex": bone_index,
                "gmxFlags": bone.flags,
                "gmxMaterialIndex": bone.material_index,
                "gmxMeshIndex": bone.mesh_index,
            },
        }
        if bone.mesh_index is not None and bone.mesh_index in mesh_map:
            node["mesh"] = mesh_map[bone.mesh_index]
        node_map[bone_index] = len(document["nodes"])
        document["nodes"].append(node)

    child_bones: set[int] = set()
    for group in parent_groups:
        valid_children = [child for child in group.children if child in node_map]
        if group.parent >= 0 and group.parent in node_map:
            parent_node = document["nodes"][node_map[group.parent]]
            parent_node.setdefault("children", []).extend(node_map[child] for child in valid_children)
            child_bones.update(valid_children)
    roots = [node_map[index] for index in sorted(node_map) if index not in child_bones]

    # Keep malformed/unreferenced meshes visible instead of silently dropping them.
    for mesh_index, gltf_mesh_index in sorted(mesh_map.items()):
        if mesh_index not in mesh_to_bone:
            node_index = len(document["nodes"])
            document["nodes"].append({"name": f"unattached_mesh_{mesh_index}", "mesh": gltf_mesh_index})
            roots.append(node_index)
    document["scenes"][0]["nodes"] = roots

    if animations:
        document["animations"] = []
        for track in animations:
            if track.target_bone not in node_map:
                continue
            translations: list[tuple[float, float, float]] = []
            rotations: list[tuple[float, float, float, float]] = []
            scales: list[tuple[float, float, float]] = []
            previous_rotation: Optional[tuple[float, float, float, float]] = None
            track_errors: list[float] = []
            for matrix in track.matrices:
                translation, rotation, scale, error = decompose_standard_matrix(matrix)
                if previous_rotation is not None and sum(a * b for a, b in zip(previous_rotation, rotation)) < 0.0:
                    rotation = tuple(-value for value in rotation)
                previous_rotation = rotation
                translations.append(translation)
                rotations.append(rotation)
                scales.append(scale)
                track_errors.append(error)
            time_values = [(float(value),) for value in track.times]
            time_accessor = builder.add_accessor(
                _pack_float_tuples(time_values),
                5126,
                "SCALAR",
                len(time_values),
                minimum=[min(track.times) if track.times else 0.0],
                maximum=[max(track.times) if track.times else 0.0],
            )
            output_accessors = {
                "translation": builder.add_accessor(_pack_float_tuples(translations), 5126, "VEC3", len(translations)),
                "rotation": builder.add_accessor(_pack_float_tuples(rotations), 5126, "VEC4", len(rotations)),
                "scale": builder.add_accessor(_pack_float_tuples(scales), 5126, "VEC3", len(scales)),
            }
            samplers: list[dict] = []
            channels: list[dict] = []
            for path_name in ("translation", "rotation", "scale"):
                sampler_index = len(samplers)
                samplers.append({"input": time_accessor, "output": output_accessors[path_name], "interpolation": "LINEAR"})
                channels.append(
                    {
                        "sampler": sampler_index,
                        "target": {"node": node_map[track.target_bone], "path": path_name},
                    }
                )
            bone_name = bones[track.target_bone].name or f"bone_{track.target_bone}"
            duration = motions.get(track.index).duration if track.index in motions else (track.times[-1] if track.times else 0.0)
            document["animations"].append(
                {
                    "name": f"motion_{track.index:03d}_{bone_name}",
                    "samplers": samplers,
                    "channels": channels,
                    "extras": {
                        "gmxMotionIndex": track.index,
                        "duration": duration,
                        "targetBone": track.target_bone,
                        "maxDecompositionError": max(track_errors, default=0.0),
                    },
                }
            )

    binary_name = f"{gltf_path.name}.bin"
    document["buffers"] = [{"uri": binary_name, "byteLength": len(builder.data)}]
    document["extras"].update(
        {
            "meshCount": len(meshes),
            "boneCount": len(bones),
            "materialCount": len(materials),
            "animationCount": len(animations),
            "convertedTextures": converted_textures,
            "missingTextures": sorted(set(missing_textures)),
            "maxStaticDecompositionError": max(decomposition_errors, default=0.0),
        }
    )
    (gltf_path.parent / binary_name).write_bytes(builder.data)
    gltf_path.write_text(json.dumps(document, indent=2), encoding="utf-8")
    metadata = {
        "source_size": len(data),
        "gltf": str(gltf_path),
        "mesh_count": len(meshes),
        "bone_count": len(bones),
        "material_count": len(materials),
        "animation_count": len(animations),
        "texture_count": len(texture_refs),
        "converted_textures": converted_textures,
        "missing_textures": sorted(set(missing_textures)),
        "max_static_decomposition_error": max(decomposition_errors, default=0.0),
    }
    gltf_path.with_suffix(".gltf.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return metadata


def export_gmx_gltf_file(
    path: Path,
    output_root: Path,
    *,
    flip_v: bool = False,
    texture_roots: Sequence[Path] = (),
    relative_path: Optional[Path] = None,
) -> dict:
    relative = relative_path if relative_path is not None else Path(path.stem + ".gltf")
    if relative.suffix.lower() != ".gltf":
        relative = relative.with_suffix(".gltf")
    destination = output_root / relative
    return export_gmx_gltf_bytes(
        path.read_bytes(),
        destination,
        source_path=path,
        texture_roots=texture_roots,
        flip_v=flip_v,
    )

def iter_candidate_files(path: Path) -> Iterator[Path]:
    if path.is_file():
        yield path
    elif path.is_dir():
        yield from (p for p in sorted(path.rglob("*")) if p.is_file())
    else:
        raise FileNotFoundError(path)



LOCALIZATION_LANGUAGES = (
    "japanese",
    "english",
    "french",
    "italian",
    "german",
    "spanish",
)

# message.bin uses an old single-byte, language-specific glyph convention for
# accented uppercase letters. These replacements were recovered from the text
# itself and checked against the corresponding UTF-8 translations in text.bin.
MESSAGE_ACCENT_MAPS: dict[str, dict[str, str]] = {
    "japanese": {"p": "É", "t": "Í", "k": "Ü"},
    "english": {"p": "É", "t": "Í", "k": "Ü"},
    "french": {
        "p": "É", "q": "È", "v": "Î", "r": "Ê", "e": "À",
        "y": "Œ", "k": "Ü", "t": "Í",
    },
    "italian": {
        "q": "È", "e": "À", "m": "Ù", "u": "Ì",
        "p": "É", "k": "Ü", "t": "Í",
    },
    "german": {
        "c": "Ä", "k": "Ü", "g": "Ö", "p": "É", "t": "Í",
    },
    "spanish": {
        "h": "Ó", "b": "Ñ", "l": "Ú", "d": "Á", "p": "É",
        "t": "Í", "z": "¡", "k": "Ü",
    },
}


def correct_message_glyph_codes(text: str, language: str) -> str:
    mapping = MESSAGE_ACCENT_MAPS.get(language, {})
    if not mapping:
        return text
    out: list[str] = []
    for index, char in enumerate(text):
        # Preserve printf's decimal placeholder rather than changing %d to %Á.
        if char == "d" and index > 0 and text[index - 1] == "%":
            out.append(char)
        else:
            out.append(mapping.get(char, char))
    return "".join(out)


def parse_message_script(payload: bytes, language: str) -> tuple[str, dict[str, list[str]]]:
    try:
        source = payload.decode("shift_jis")
    except UnicodeDecodeError as exc:
        raise FormatError(f"message payload is not valid Shift-JIS: {exc}") from exc

    groups: dict[str, list[str]] = {}
    current: Optional[str] = None
    assignment_re = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\s*<-\s*\[$")

    for line_number, line in enumerate(source.splitlines(), 1):
        stripped = line.strip()
        match = assignment_re.match(stripped)
        if match:
            current = match.group(1)
            groups[current] = []
            continue
        if stripped in {"]", "],"}:
            current = None
            continue
        if current is not None and stripped.startswith('"'):
            literal = stripped[:-1] if stripped.endswith(",") else stripped
            try:
                value = json.loads(literal)
            except json.JSONDecodeError as exc:
                raise FormatError(
                    f"invalid message string at line {line_number}: {exc.msg}"
                ) from exc
            groups[current].append(correct_message_glyph_codes(value, language))

    if not groups:
        raise FormatError("message payload contains no Squirrel string arrays")
    return source, groups


def _expand_inline_newlines(value: str) -> str:
    # text.bin stores intended line breaks as the two source characters \\n.
    return value.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\r", "\n").replace("\\t", "\t")


def looks_like_message_archive(archive: BBXArchive) -> bool:
    if archive.count != 6:
        return False
    return all(archive.payload(entry).startswith(b"STR_") for entry in archive.entries)


def looks_like_text_archive(archive: BBXArchive) -> bool:
    if archive.count != 7:
        return False
    first = archive.payload(archive.entries[0])
    return first.startswith(b"EVOL_TEXT1") and b"RICH_PRESENCE" in first


def export_message_archive(archive: BBXArchive, output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    parsed: list[dict[str, list[str]]] = []
    language_meta: list[dict] = []

    for language, entry in zip(LOCALIZATION_LANGUAGES, archive.entries):
        payload = archive.payload(entry)
        source, groups = parse_message_script(payload, language)
        parsed.append(groups)

        raw_path = output_dir / f"message_{language}_raw.nut"
        raw_path.write_text(source, encoding="utf-8", newline="")
        readable_source = correct_message_glyph_codes(source, language)
        readable_path = output_dir / f"message_{language}_readable.nut"
        readable_path.write_text(readable_source, encoding="utf-8", newline="")

        text_path = output_dir / f"message_{language}.txt"
        with text_path.open("w", encoding="utf-8", newline="\n") as handle:
            for group, values in groups.items():
                handle.write(f"[{group}]\n")
                for item_index, value in enumerate(values):
                    rendered = value.replace("\n", "\\n")
                    handle.write(f"{item_index:04d}\t{rendered}\n")
                handle.write("\n")

        language_meta.append({
            "language": language,
            "bbx_entry": entry.index,
            "bytes": len(payload),
            "groups": len(groups),
            "strings": sum(len(values) for values in groups.values()),
            "raw_script": raw_path.name,
            "readable_script": readable_path.name,
        })

    reference_groups = parsed[0]
    for language, groups in zip(LOCALIZATION_LANGUAGES[1:], parsed[1:]):
        if list(groups) != list(reference_groups):
            raise FormatError(f"message group order differs in {language}")
        for group, values in reference_groups.items():
            if len(groups[group]) != len(values):
                raise FormatError(f"message group {group} has a different length in {language}")

    csv_path = output_dir / "message_strings.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["group", "item_index", *LOCALIZATION_LANGUAGES])
        for group, values in reference_groups.items():
            for item_index in range(len(values)):
                writer.writerow([
                    group,
                    item_index,
                    *(groups[group][item_index] for groups in parsed),
                ])

    group_csv = output_dir / "message_groups.csv"
    with group_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["group", "string_count"])
        for group, values in reference_groups.items():
            writer.writerow([group, len(values)])

    json_groups: dict[str, list[dict]] = {}
    for group, values in reference_groups.items():
        json_groups[group] = [
            {
                "index": item_index,
                **{
                    language: parsed[language_index][group][item_index]
                    for language_index, language in enumerate(LOCALIZATION_LANGUAGES)
                },
            }
            for item_index in range(len(values))
        ]

    metadata = {
        "format": "SIIG_message.bin",
        "language_order": list(LOCALIZATION_LANGUAGES),
        "note": (
            "The Japanese-region message block intentionally contains English UI text. "
            "Readable exports replace the original language-specific accent glyph codes with Unicode."
        ),
        "group_count": len(reference_groups),
        "strings_per_language": sum(len(values) for values in reference_groups.values()),
        "languages": language_meta,
    }
    (output_dir / "message_strings.json").write_text(
        json.dumps({**metadata, "groups": json_groups}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (output_dir / "message_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return metadata


def export_text_archive(archive: BBXArchive, output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    decoded: list[list[str]] = []
    for entry_index, entry in enumerate(archive.entries):
        payload = archive.payload(entry)
        try:
            text = payload.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise FormatError(f"text.bin entry {entry_index} is not valid UTF-8: {exc}") from exc
        lines = text.splitlines()
        decoded.append(lines)
        label = "keys" if entry_index == 0 else LOCALIZATION_LANGUAGES[entry_index - 1]
        (output_dir / f"text_{label}_raw.txt").write_text(text, encoding="utf-8", newline="")

    keys = decoded[0]
    if not keys or any(len(lines) != len(keys) for lines in decoded[1:]):
        counts = [len(lines) for lines in decoded]
        raise FormatError(f"text.bin line counts do not match: {counts}")

    raw_csv = output_dir / "text_strings_raw.csv"
    readable_csv = output_dir / "text_strings.csv"
    with raw_csv.open("w", encoding="utf-8-sig", newline="") as raw_handle, readable_csv.open(
        "w", encoding="utf-8-sig", newline=""
    ) as readable_handle:
        raw_writer = csv.writer(raw_handle)
        readable_writer = csv.writer(readable_handle)
        header = ["index", "key", *LOCALIZATION_LANGUAGES]
        raw_writer.writerow(header)
        readable_writer.writerow(header)
        for index, key in enumerate(keys):
            raw_values = [decoded[lang_index + 1][index] for lang_index in range(6)]
            raw_writer.writerow([index, key, *raw_values])
            readable_writer.writerow([index, key, *(_expand_inline_newlines(v) for v in raw_values)])

    records = []
    for index, key in enumerate(keys):
        records.append({
            "index": index,
            "key": key,
            **{
                language: _expand_inline_newlines(decoded[lang_index + 1][index])
                for lang_index, language in enumerate(LOCALIZATION_LANGUAGES)
            },
        })

    for lang_index, language in enumerate(LOCALIZATION_LANGUAGES):
        path = output_dir / f"text_{language}.txt"
        with path.open("w", encoding="utf-8", newline="\n") as handle:
            for index, key in enumerate(keys):
                value = _expand_inline_newlines(decoded[lang_index + 1][index])
                handle.write(f"[{index:04d}] {key}\n{value}\n\n")

    metadata = {
        "format": "SIIG_text.bin",
        "language_order": list(LOCALIZATION_LANGUAGES),
        "string_count": len(keys),
        "note": "Entry 0 contains identifiers; entries 1-6 contain line-aligned UTF-8 translations.",
    }
    (output_dir / "text_strings.json").write_text(
        json.dumps({**metadata, "strings": records}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (output_dir / "text_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return metadata


def decode_localization_file(path: Path, output_root: Path) -> dict:
    data = maybe_decompress(path.read_bytes())
    archive = BBXArchive.parse(data)
    lowered = path.name.lower()
    if looks_like_message_archive(archive):
        metadata = export_message_archive(archive, output_root / "message")
        metadata["source"] = str(path)
        return metadata
    if looks_like_text_archive(archive):
        metadata = export_text_archive(archive, output_root / "text")
        metadata["source"] = str(path)
        return metadata
    raise FormatError(f"{path}: BBX is not recognized as message.bin or text.bin")


def command_text2csv(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output_root = Path(args.output)
    if not input_path.exists():
        raise FormatError(f"input not found: {input_path}")

    if input_path.is_file():
        candidates = [input_path]
    else:
        candidates = sorted(
            path for path in input_path.rglob("*")
            if path.is_file()
            and ("message.bin" in path.name.lower() or "text.bin" in path.name.lower())
        )
        if not candidates:
            raise FormatError(f"no message.bin/text.bin files found under {input_path}")

    results: list[dict] = []
    failures: list[dict] = []
    for candidate in candidates:
        try:
            result = decode_localization_file(candidate, output_root)
            results.append(result)
            kind = result["format"]
            count = result.get("string_count", result.get("strings_per_language", 0))
            print(f"decoded {candidate} -> {kind} ({count} strings)")
        except (OSError, FormatError, gzip.BadGzipFile) as exc:
            failures.append({"file": str(candidate), "error": str(exc)})
            print(f"warning: {candidate}: {exc}", file=sys.stderr)

    summary = {"decoded": results, "failures": failures}
    output_root.mkdir(parents=True, exist_ok=True)
    (output_root / "localization_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    if not results:
        raise FormatError("no localization archive was decoded")
    print(f"completed: {len(results)} localization archive(s), {len(failures)} failure(s)")
    return 0 if not failures else 1

def command_extract(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        try:
            raw = path.read_bytes()[:4]
            if raw[:2] == b"\x1F\x8B":
                test = maybe_decompress(path.read_bytes())[:4]
            else:
                test = raw
            if test != BBX_MAGIC:
                if input_path.is_file():
                    raise FormatError("input is not BBX or standard gzip containing BBX")
                continue
            result = extract_bbx_file(
                path, output, args.recursive, args.convert_gmx, args.convert_gltf, args.convert_tex, args.flip_v
            )
            print(f"{path}: extracted {result['count']} resources")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} archive(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def command_gmx2obj(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        if path.suffix.lower() != ".gmx" and not path.read_bytes()[:4] == GMX_MAGIC:
            continue
        try:
            chunks = parse_gmx_chunks(path.read_bytes())
            if not any(chunk.tag == "MESH" for chunk in chunks):
                meta_path = output / f"{path.stem}.gmx.json"
                meta_path.write_text(
                    json.dumps(
                        {
                            "source": str(path),
                            "mesh_count": 0,
                            "note": "This GMX has no MESH chunks; it may be hierarchy/animation-only.",
                            "chunks": [
                                {"offset": c.offset, "tag": c.tag, "size": c.size} for c in chunks
                            ],
                        },
                        indent=2,
                    ),
                    encoding="utf-8",
                )
                print(f"{path}: no mesh geometry; wrote metadata only")
            else:
                meta = export_gmx_file(path, output, args.flip_v)
                print(f"{path}: exported {meta['mesh_count']} mesh(es)")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} GMX file(s), {failures} failure(s)")
    return 1 if failures and not success else 0



def command_gmx2gltf(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    texture_roots = tuple(Path(value) for value in (args.texture_root or []))
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        try:
            if path.suffix.lower() != ".gmx" and path.read_bytes()[:4] != GMX_MAGIC:
                continue
            if input_path.is_dir():
                relative = path.relative_to(input_path).with_suffix(".gltf")
            else:
                relative = Path(path.stem + ".gltf")
            roots = (input_path,) + texture_roots if input_path.is_dir() else texture_roots
            meta = export_gmx_gltf_file(
                path,
                output,
                flip_v=args.flip_v,
                texture_roots=roots,
                relative_path=relative,
            )
            print(
                f"{path}: glTF with {meta['mesh_count']} mesh(es), "
                f"{meta['bone_count']} bone(s), {meta['animation_count']} animation track(s)"
            )
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} GMX file(s), {failures} failure(s)")
    return 1 if failures and not success else 0

def command_tex2png(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    success = 0
    failures = 0
    for path in iter_candidate_files(input_path):
        try:
            data = path.read_bytes()
            if path.suffix.lower() != ".tex" and not looks_like_tex(data):
                continue
            if input_path.is_dir():
                relative = path.relative_to(input_path).with_suffix(".png")
                destination = output / relative
            else:
                destination = output / f"{path.stem}.png"
            meta = export_tex_png_bytes(data, destination)
            print(f"{path}: {meta['width']}x{meta['height']} {meta['format_name']} -> {destination}")
            success += 1
        except Exception as exc:
            failures += 1
            print(f"ERROR {path}: {exc}", file=sys.stderr)
    print(f"completed: {success} TEX file(s), {failures} failure(s)")
    return 1 if failures and not success else 0


def _systemfont_crp_from_input(path: Path) -> bytes:
    data = maybe_decompress(path.read_bytes())
    if data.startswith(BBX_MAGIC):
        archive = BBXArchive.parse(data)
        matches = [
            archive.payload(entry)
            for entry in archive.entries
            if entry.name.lower().endswith(".crp") or looks_like_systemfont_crp(archive.payload(entry))
        ]
        if len(matches) != 1:
            raise FormatError(f"expected one systemfont CRP resource, found {len(matches)}")
        return matches[0]
    if looks_like_systemfont_crp(data):
        return data
    raise FormatError("input is not systemfont.bin or an encrypted systemfont.crp")


def command_font2png(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    encrypted = _systemfont_crp_from_input(input_path)
    decrypted = xor_systemfont_crp(encrypted)
    png_path = output / "systemfont_atlas.png"
    meta = export_tex_png_bytes(decrypted, png_path)
    meta.update(
        {
            "source_format": "SIIG systemfont CRP",
            "xor_key": "0xF1",
            "cell_width": 32,
            "cell_height": 32,
            "columns": 64,
            "rows": 106,
            "glyph_record_count": 6732,
        }
    )
    png_path.with_suffix(png_path.suffix + ".json").write_text(
        json.dumps(meta, indent=2), encoding="utf-8"
    )
    if args.write_decrypted_tex:
        (output / "systemfont_decrypted.tex").write_bytes(decrypted)
    print(f"{input_path}: decrypted XOR 0xF1 and exported {meta['width']}x{meta['height']} atlas -> {png_path}")
    return 0


def command_scan(args: argparse.Namespace) -> int:
    path = Path(args.input)
    data = maybe_decompress(path.read_bytes())
    if data.startswith(BBX_MAGIC):
        archive = BBXArchive.parse(data)
        print(
            json.dumps(
                {
                    "format": "BBX",
                    "count": archive.count,
                    "mode": archive.mode,
                    "hash_seed": f"0x{archive.hash_seed:08X}",
                    "has_sorted_hash_index": bool(archive.sorted_index),
                    "entries": [asdict(e) for e in archive.entries],
                },
                indent=2,
            )
        )
        return 0
    if data.startswith(GMX_MAGIC):
        chunks = parse_gmx_chunks(data)
        arrays = [parse_gmx_array(c) for c in chunks if c.tag == "ARRY"]
        meshes = [parse_gmx_mesh(c) for c in chunks if c.tag == "MESH"]
        textures = [parse_gmx_texture_ref(c) for c in chunks if c.tag == "TXIF"]
        shaders = [parse_gmx_shader(c) for c in chunks if c.tag == "SHAD"]
        materials = [parse_gmx_material(c) for c in chunks if c.tag == "MTRL"]
        parents = [parse_gmx_parent_group(c) for c in chunks if c.tag == "PARE"]
        bones = [parse_gmx_bone(c) for c in chunks if c.tag == "BONE"]
        motions = [parse_gmx_motion(c) for c in chunks if c.tag == "MOTN"]
        animations = [parse_gmx_animation(c) for c in chunks if c.tag == "ANIM"]
        print(
            json.dumps(
                {
                    "format": "GMX",
                    "size": len(data),
                    "chunks": [{"offset": c.offset, "tag": c.tag, "size": c.size} for c in chunks],
                    "arrays": [
                        {
                            "index": a.array_index,
                            "semantic": a.semantic,
                            "slot": a.slot,
                            "components": a.components,
                            "gl_type": f"0x{a.gl_type:X}",
                            "count": a.count,
                        }
                        for a in arrays
                    ],
                    "meshes": [
                        {
                            "index": m.mesh_index,
                            "primitive_mode": f"0x{m.primitive_mode:X}",
                            "index_count": m.index_count,
                            "skin_index": m.skin_index,
                            "array_refs": m.array_refs,
                        }
                        for m in meshes
                    ],
                    "textures": [asdict(item) for item in textures],
                    "shaders": [asdict(item) for item in shaders],
                    "materials": [
                        {
                            "index": item.index,
                            "name": item.name,
                            "shader_index": item.shader_index,
                            "parameters": [asdict(parameter) for parameter in item.parameters],
                        }
                        for item in materials
                    ],
                    "hierarchy": [asdict(item) for item in parents],
                    "bones": [
                        {
                            "index": item.index,
                            "name": item.name,
                            "material_index": item.material_index,
                            "mesh_index": item.mesh_index,
                            "matrix": list(item.matrix),
                        }
                        for item in bones
                    ],
                    "motions": [asdict(item) for item in motions],
                    "animations": [
                        {
                            "index": item.index,
                            "target_bone": item.target_bone,
                            "channel_type": item.channel_type,
                            "frame_count": len(item.times),
                            "duration": item.times[-1] if item.times else 0.0,
                        }
                        for item in animations
                    ],
                },
                indent=2,
            )
        )
        return 0
    if looks_like_xwb(data):
        xsb_path = path.with_suffix(".xsb")
        preliminary = parse_xwb(data)
        cue_names = parse_xsb_cue_names(
            xsb_path.read_bytes() if xsb_path.exists() else b"",
            len(preliminary.entries),
            preliminary.bank_name,
        )
        info = parse_xwb(data, cue_names)
        print(
            json.dumps(
                {
                    "format": "XACT_XWB",
                    "version": info.version,
                    "endian": info.endian,
                    "bank_name": info.bank_name,
                    "bank_flags": f"0x{info.bank_flags:08X}",
                    "alignment": info.alignment,
                    "stream_count": len(info.entries),
                    "entries": [asdict(entry) for entry in info.entries],
                },
                indent=2,
            )
        )
        return 0
    if looks_like_systemfont_crp(data):
        decrypted = xor_systemfont_crp(data)
        info = asdict(parse_tex(decrypted))
        info["texture_format"] = f"0x{info.pop('format'):X}"
        info["fetch_dwords"] = [f"0x{value:08X}" for value in info["fetch_dwords"]]
        info["swizzle"] = list(info["swizzle"])
        print(json.dumps({"format": "SIIG_SYSTEMFONT_CRP", "xor_key": "0xF1", **info}, indent=2))
        return 0
    if looks_like_tex(data):
        info = asdict(parse_tex(data))
        info["texture_format"] = f"0x{info.pop('format'):X}"
        info["fetch_dwords"] = [f"0x{value:08X}" for value in info["fetch_dwords"]]
        info["swizzle"] = list(info["swizzle"])
        print(json.dumps({"format": "TEX", **info}, indent=2))
        return 0
    raise FormatError("unrecognized input (not BBX, gzip->BBX, GMX, TEX, XWB, or systemfont CRP)")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    p_extract = sub.add_parser("extract", help="extract one BBX archive or every BBX in a directory")
    p_extract.add_argument("input", help="input .bin/.gz file or directory")
    p_extract.add_argument("-o", "--output", default="siig_extracted", help="output directory")
    p_extract.add_argument("--recursive", action="store_true", help="recursively extract nested BBX payloads")
    p_extract.add_argument("--convert-gmx", action="store_true", help="also convert extracted GMX geometry to OBJ")
    p_extract.add_argument(
        "--convert-gltf",
        action="store_true",
        help="also export GMX hierarchy, materials and animations to glTF 2.0",
    )
    p_extract.add_argument("--convert-tex", action="store_true", help="also convert extracted TEX textures to PNG")
    p_extract.add_argument("--flip-v", action="store_true", help="flip texture V coordinates for OBJ/glTF output")
    p_extract.set_defaults(func=command_extract)

    p_gmx = sub.add_parser("gmx2obj", help="convert one GMX or a directory of GMX files to OBJ")
    p_gmx.add_argument("input", help="input .gmx file or directory")
    p_gmx.add_argument("-o", "--output", default="siig_obj", help="output directory")
    p_gmx.add_argument("--flip-v", action="store_true", help="flip the OBJ texture V coordinate")
    p_gmx.set_defaults(func=command_gmx2obj)

    p_gltf = sub.add_parser(
        "gmx2gltf",
        help="export GMX geometry, hierarchy, materials and animation tracks to glTF 2.0",
    )
    p_gltf.add_argument("input", help="input .gmx file or directory")
    p_gltf.add_argument("-o", "--output", default="siig_gltf", help="output directory")
    p_gltf.add_argument("--flip-v", action="store_true", help="flip the glTF texture V coordinate")
    p_gltf.add_argument(
        "--texture-root",
        action="append",
        help="additional directory to search recursively for TXIF-referenced DDS/TEX files",
    )
    p_gltf.set_defaults(func=command_gmx2gltf)

    p_tex = sub.add_parser("tex2png", help="convert one TEX or a directory of TEX files to PNG")
    p_tex.add_argument("input", help="input .tex file or directory")
    p_tex.add_argument("-o", "--output", default="siig_png", help="output directory")
    p_tex.set_defaults(func=command_tex2png)

    p_font = sub.add_parser("font2png", help="decrypt systemfont.bin/systemfont.crp and export the glyph atlas")
    p_font.add_argument("input", help="input systemfont.bin, systemfont.bin.gz, or extracted systemfont.crp")
    p_font.add_argument("-o", "--output", default="siig_systemfont", help="output directory")
    p_font.add_argument("--write-decrypted-tex", action="store_true", help="also save the decrypted TEX payload")
    p_font.set_defaults(func=command_font2png)

    p_audio = sub.add_parser(
        "xact2wav",
        help="extract XACT XWB/XSB audio from sound.bin or convert XWB banks to WAV",
    )
    p_audio.add_argument("input", help="sound.bin/BBX, an .xwb file, or a directory containing XWB/XSB files")
    p_audio.add_argument("-o", "--output", default="siig_audio", help="output directory")
    p_audio.add_argument(
        "--ffmpeg",
        help="path/name of FFmpeg executable (auto-detected from PATH when omitted)",
    )
    p_audio.add_argument(
        "--keep-xma",
        action="store_true",
        help="keep the intermediate RIFF-wrapped .xma files after successful WAV decoding",
    )
    p_audio.set_defaults(func=command_xact2wav)


    p_text = sub.add_parser(
        "text2csv",
        help="decode message.bin/text.bin localization data to UTF-8 CSV, JSON, and text",
    )
    p_text.add_argument("input", help="message.bin, text.bin, or a directory containing both")
    p_text.add_argument("-o", "--output", default="siig_text", help="output directory")
    p_text.set_defaults(func=command_text2csv)

    p_scan = sub.add_parser("scan", help="print a JSON description of a BBX, GMX, TEX, XWB, or systemfont CRP file")
    p_scan.add_argument("input")
    p_scan.set_defaults(func=command_scan)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (OSError, FormatError, gzip.BadGzipFile) as exc:
        parser.error(str(exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
