# GMX → glTF notes

Version 1.5 adds a glTF 2.0 exporter for the game's GMX scene/model files. Unlike the older OBJ exporter, this path preserves the GMX scene graph, material assignments, vertex colors, and embedded transform animation tracks.

## Confirmed GMX relationships

GMX is a sequential big-endian chunk stream. The exporter uses these confirmed links:

- `TXIF` records name texture resources such as `ptn_001.dds`.
- `SHAD` records name the material shader (`no_texture` or `texture` in the supplied corpus).
- `MTRL` records reference one `SHAD` and contain typed parameters.
- `PARE` records store a signed parent bone index followed by its child bone indices.
- `BONE` records contain a 4×4 local transform and encoded material/mesh attachments.
- `MESH` records reference position, normal, UV, color and index `ARRY` records.
- `MOTN` records describe one motion track and its duration.
- `ANIM` records target one bone and store key times followed by one 4×4 transform per key.

### BONE attachment references

The final 16 bytes of a `BONE` record contain an attachment count and encoded references:

```text
high 16 bits  2  → MTRL index
high 16 bits  3  → MESH index
low  16 bits     → referenced record index
```

Every mesh-bearing bone in the supplied corpus has one material reference and one mesh reference.

### PARE hierarchy

```text
+0x10  u32  child count
+0x14  s32  parent bone index (-1 means scene root)
+0x18  u32[] child bone indices
```

### Material parameters

After the fixed MTRL header, each parameter has a 48-byte name and two 32-bit fields:

```text
type 0  float scalar/vector; second field is component count
type 1  4×4 matrix array; second field is matrix count
type 2  texture sampler; second field is TXIF index
```

Observed parameters are `mWVP`, `DiffuseSampler`, `DiffuseColor`, `DiffuseAlpha`, and `EmissiveColor`.

### Animation tracks

```text
ANIM +0x08  encoded motion index (index in upper 16 bits)
ANIM +0x10  target BONE index
ANIM +0x14  channel type (12 in every supplied file)
ANIM +0x18  key count
ANIM +0x1C  values per key (16 in every supplied file)
ANIM +0x20  float32 key times
             followed immediately by key_count × 16 float32 matrices
```

BONE matrices use the engine's row-vector storage convention. ANIM matrices use the transposed conventional row-major form. The exporter normalizes both conventions and decomposes each animation matrix into glTF translation, quaternion rotation, and scale channels.

## glTF output

For each input GMX, the exporter writes:

```text
model.gltf       JSON scene description
model.gltf.bin   geometry and animation buffers
model.gltf.json  conversion summary/diagnostics
_textures/       converted texture dependencies when present
```

The glTF contains:

- indexed triangles and lines;
- positions, normals, UVs and vertex colors;
- GMX bone hierarchy as glTF nodes;
- mesh attachment to the correct bone;
- diffuse color, alpha, emissive color and texture assignment;
- `KHR_materials_unlit` materials, matching the simple SIIG shader parameter set;
- one glTF animation per GMX `ANIM`/`MOTN` track.

The supplied textured GMX files all reference `ptn_001.dds`, an uncompressed 128×128 ARGB8888 DDS. The exporter converts it to PNG automatically when the DDS is available in the GMX directory or a `--texture-root` search directory.

## Usage

```bat
python siig_toolkit.py gmx2gltf "C:\path\to\extracted" -o gltf
```

When texture files live elsewhere:

```bat
python siig_toolkit.py gmx2gltf "C:\path\to\gmx" -o gltf --texture-root "C:\path\to\all_extracted_assets"
```

Directly during BBX extraction:

```bat
python siig_toolkit.py extract "C:\path\to\3ddata" -o extracted --convert-gltf
```

Add `--flip-v` only when the destination application expects inverted V coordinates.

## Validation

The final exporter was run over the complete supplied `3ddata` corpus:

```text
486 GMX files
1,938 meshes/primitives
3,298 hierarchy nodes
776 materials
913 animation tracks
0 conversion failures
0 hierarchy cycles or unreachable nodes
0 missing texture references
```

Representative static, textured, multi-mesh and animated files were also loaded with an independent glTF reader.

## Limitations

- The GMX files do not contain per-vertex skin weights; geometry is attached rigidly to scene nodes rather than exported as a skinned mesh.
- Each `ANIM` chunk is exported as its own animation. The engine may trigger several tracks together during gameplay; that higher-level grouping is not stored explicitly in the GMX chunk stream recovered so far.
- The source shader programs are not translated to equivalent custom glTF shaders. Materials use standard unlit PBR fields so they remain portable.
- Standalone `.anm` resources, if encountered outside GMX, are not handled by this exporter.
