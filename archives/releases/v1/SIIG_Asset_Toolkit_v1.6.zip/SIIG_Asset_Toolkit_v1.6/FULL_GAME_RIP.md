# One-click full-game rip

Version 1.6 adds a platform-aware `rip-game` command for the original Xbox 360 and PlayStation 3 folder layouts or ZIP archives.

## Fastest Windows method

Drag the original game ZIP or folder onto `SIIG_Rip_Game.bat`.

The output is created beside the input as `SIIG_Ripped`. Repeating the operation uses `--resume` and skips archives whose source hash and conversion profile have not changed.

## Command line

```bat
python siig_toolkit.py rip-game "C:\Games\Space Invaders IG X360.zip" -o "C:\Rips\SIIG_X360" --resume
```

For PS3, first decrypt the six `*.bin.gz.sdat` files with TrueAncestor EDAT Rebuilder. Put the resulting `*.bin.gz.dat` files beside the game ZIP, or specify their directory:

```bat
python siig_toolkit.py rip-game "C:\Games\Space Invaders IG PS3.zip" -o "C:\Rips\SIIG_PS3" --ps3-sdat-dir "C:\Games\SIIG_PS3_decrypted" --resume
```

The expected TrueAncestor outputs are:

```text
generator.bin.gz.dat
message.bin.gz.dat
script.bin.gz.dat
shader.bin.gz.dat
text.bin.gz.dat
visualizerSet.bin.gz.dat
```

## Output layout

```text
SIIG_Ripped\
├── assets\                 raw BBX resources plus PNG/glTF conversions
├── decompressed_bbx\       normalized `.bin` BBX archives
├── audio\xact\             Xbox 360 XACT streams converted to WAV
├── localization\           combined UTF-8 CSV/JSON/text exports
├── systemfont\             decoded atlas and glyph mapping
├── ready_files\            WMA, AT3, PNG, SFO and XML files copied unchanged
└── validation\
    ├── RIP_REPORT.json
    └── RIP_REPORT.txt
```

All generated metadata uses archive-relative names. The final report includes a privacy audit for accidental absolute paths.

## Platform behavior

### Xbox 360

- Ordinary `.bin.gz` and `.bin.gz.sdat` files are recognized as gzip by their header.
- BBX resources are extracted recursively.
- TEX files are untiled and converted to PNG.
- GMX files are exported to glTF 2.0.
- `sound.bin` XACT/XMA2 banks are converted to WAV when FFmpeg is installed.
- Existing `Media/BGM/*.wma` files are copied unchanged.

### PlayStation 3

- Ordinary `.bin.gz` files are decompressed directly.
- `NPD\0` SDAT files use matching TrueAncestor `.bin.gz.dat` outputs.
- PS3 TEX files use their native 0x80-byte RSX wrapper and linear A8R8G8B8 pixels.
- The shared GMX files use the same glTF converter.
- The Sony SBlk/VAG audio bank is extracted losslessly as `.bnk`; individual stream conversion is currently delegated to vgmstream.
- `SND0.AT3` and other ready-to-use media are copied unchanged.

## Useful options

```text
--clean          remove an old output tree before starting
--resume         skip unchanged archives and matching conversion profiles
--convert-obj    also write legacy OBJ models
--no-gltf        skip glTF model conversion
--no-textures    skip TEX conversion
--no-audio       skip Xbox 360 XACT conversion
--ffmpeg PATH    choose a specific FFmpeg executable
```
