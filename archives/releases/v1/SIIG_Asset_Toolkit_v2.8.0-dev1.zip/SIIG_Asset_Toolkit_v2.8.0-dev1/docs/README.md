# SIIG Asset Toolkit documentation

This folder keeps the toolkit root focused on commands and launchers. No documentation or research data was removed in v2.5.1.

## Start here

- [Full-game extraction](guides/FULL_GAME_RIP.md)
- [Container inputs](guides/CONTAINER_INPUT_NOTES.md)
- [Testing](guides/TESTING.md)
- [Security](guides/SECURITY_NOTES.md)
- [Asset Viewer](guides/ASSET_VIEWER_NOTES.md)
- [BBX repacking](guides/BBX_REPACK_NOTES.md)
- [Blender add-on](guides/BLENDER_ADDON_NOTES.md)

## Format research

The [`formats/`](formats/) folder contains BBX/GMX/TEX/audio/localization/DAT/MAP/ANM/stage/shader findings.

## Project and provenance

The [`project/`](project/) folder contains credits, attribution policy, AI disclosure, source audit, exclusions, notices, and license status. Machine-readable source records are in [`../reference/provenance/`](../reference/provenance/).

## Releases and validation

- Historical release notes: [`releases/`](releases/)
- Validation reports: [`../validation/`](../validation/)
- Reference tables: [`../reference/tables/`](../reference/tables/)
- System-font support data: [`../reference/systemfont/`](../reference/systemfont/)
- Ghidra helper: [`../tools/ghidra/`](../tools/ghidra/)
- Blender add-on: [`../addons/`](../addons/)
