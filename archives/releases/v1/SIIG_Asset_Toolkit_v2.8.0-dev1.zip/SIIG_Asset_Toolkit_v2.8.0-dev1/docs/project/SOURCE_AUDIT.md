# Source-provenance audit report

Audit date: 2026-09-05  
Development tree reviewed: SIIG Asset Toolkit 2.8.0-dev1

## Scope

Reviewed bundled Python/Java source, launchers, add-on source, documentation, provenance tables, and release-layout files for vendored dependencies, copied/adapted logic, external-process calls, game assets, and unresolved attribution.

## Findings

- No third-party Python package, executable, shared library, emulator, decompiler, OpenSSL binary, FFmpeg binary, or vgmstream binary/source is bundled.
- One direct code adaptation remains identified: `xg_address_2d_tiled_offset`, an independent Python translation/adaptation of Xenia's Xenos tiled-texture addressing. The BSD 3-Clause notice remains bundled. The historical exact Xenia commit/file consulted was not preserved; that limitation remains explicit.
- The XMA2 RIFF wrapper is locally written against public Microsoft/DirectXTK structure documentation.
- AES-128, STFS, PS3 PKG, debug package streaming, extraction-safety policy, and NPDRM SDAT handling are locally authored clean-room code. FIPS-197 is the AES normative/known-answer reference.
- Finalized PS3 PKG extraction may invoke an installed OpenSSL executable as an optional acceleration backend. OpenSSL is external and not bundled; Python AES-CTR remains the fallback and is equivalence-tested.
- The new Sony SBlk v3/PS-ADPCM implementation is locally authored for the supplied SIIG bank. vgmstream `src/meta/bnk_sony.c` and `src/coding/psx_decoder.c` were explicitly consulted as behavioral/field-layout cross-checks. No vgmstream code was copied or vendored.
- BBX, GMX, SIIG TEX wrappers, system font, localization, COL, ANM, DAT, MAP, stage tables, atlas mapping, Bmap/Xmap, wall/generator, and shader-container work remains based on user-supplied binaries, Ghidra exports, synthetic fixtures, and corpus validation.
- Stage Explorer v5 source was reconstructed from the project's own retained validated generated explorer plus current executable-backed semantics; no third-party UI code was introduced.
- The Blender add-on, Asset Viewer, BBX repacker, localhost server, and resume-cache implementation are locally authored.
- TCRF/The Cutting Room Floor remains explicitly excluded.

## Real-package validation

The project now possesses and has directly exercised the supplied original retail Xbox 360 LIVE STFS and PS3 type-1 PKG. This supersedes older notes claiming those exact packages were unavailable. Retail regressions reach 2,593 resources with zero BBX hash mismatches/archive failures on both platforms; PS3 validates six internally decrypted SDATs / 18 authenticated blocks and 84 Sony WAV streams, while Xbox validates 86 XACT WAV streams.

## Current source-only validation

The 2.8.0-dev1 source tree passes 23/23 built-in tests. A packaging audit found zero proprietary game-asset extensions, zero PE/ELF/STFS/PKG executable/container magic, zero bundled binary members inside the locally authored Blender add-on ZIP, and zero non-synthetic private runtime paths. `reference/provenance/SOURCES.csv` contains 18 source/reference rows with a consistent 10-column schema.

Independent post-processing validation also passed on both supplied retail rips: Stage Explorer v5 generated 92 entries / 78 runtime pairings on both Xbox `Media` and PS3 `USRDIR` layouts; Asset Viewer coverage reached 3,520/3,520 Xbox and 3,991/3,991 PS3 previewable thumbnails with zero missing; full hash/privacy verification checked 9,855 Xbox files and 11,195 PS3 files with zero issues.

## AI disclosure

OpenAI ChatGPT assisted with analysis, code drafting, tests, documentation, and packaging. The project can enumerate explicit sources intentionally consulted, but cannot enumerate the model's full training corpus or latent influences. See `AI_DISCLOSURE.md`.

## Remaining publication gates

- Select a license for original project code before public redistribution.
- Preserve Xenia's BSD notice and all provenance records.
- Keep proprietary game packages/assets and generated game-data viewers out of a source-only public release.
- Perform in-Blender UI/operator validation when Blender is available.
- Continue source-overlap/license review whenever future code is copied or adapted.
- Record exact upstream commit/file whenever feasible for all future external code references.
