# SIIG 3D stage tables

## Path and placement records

`Bmap*.bin`, `Xmap*.bin`, and the same-layout `map4_*.bin` / `map5_*.bin` resources contain fixed `0x118`-byte records. These are separate from the 2D `MAP\0` tile resources.

```text
record +0x00  placement[0] (0x34 bytes)
       +0x34  placement[1]
       +0x68  placement[2]
       +0x9C  placement[3]
       +0xD0  be f32 cell_step[3]
       +0xDC  be f32 auxiliary_points[5][3]
```

Each placement is:

```text
+0x00  char[16] model name (`notuse` is empty)
+0x10  be f32 position[3]
+0x1C  be f32 stored_scale[3] (runtime multiplies each component by 5.0)
+0x28  be f32 rotation_degrees[3] (runtime converts to radians)
```

The executable preloads each used placement as `<name>.gmx`. It accumulates `cell_step` into an 800-unit path and constructs an 800×800×800 lookup box around each path-cell center. A zero step marks the end when it occurs before file capacity. The five trailing vectors are homogeneous optional route-point slots: the runtime scans all five and concatenates every nonzero point into the route spline. Across the supplied 47-file corpus, only slot 2 is used (19,562 nonzero points across 19,563 active records). Slots 0, 1, 3, and 4 are supported but unused, so no separate role should be assigned to them.

Record 0 slot 2 supplies the initial `FieldPos`. If it is zero, the runtime falls back to record 0 placement slot 0's stored position; this occurs only in `Bmap16.bin`. The JSON export records both `initial_field_position` and `initial_field_position_source`.

`stage3dmap` writes lossless JSON, path CSV, placement CSV, and an OBJ polyline of cell centers.

Validation found 47 same-layout files, 19,563 active path records, 23,830 used placements, and 77 unique referenced model names. Every model reference resolves to a supplied GMX file. All 77 path/wall/generator stage files compared between the June 10 prototype and retail are byte-identical.

## Wall strips and generator candidates

`wall*.bin`, `Xwall*.bin`, and `stage_generate.bin` use 20-byte records:

```text
+0x00  char[16] name
+0x10  be u32 value
```

For wall tables, `value` is a repeat count. The executable clamps values above 16, then expands each named strip element that many times. `notuse` creates an empty segment. For `stage_generate.bin`, nonzero values mark the 53 names eligible for runtime selection.

`stagewall` exports both forms to CSV and JSON without discarding raw values.

### XEX evidence

Key June 10 functions include:

- `0x82101850`: scans `0x118` records and preloads four GMX names
- `0x82102610`: accumulates steps and constructs 800-unit cell boxes
- `0x82102120`: exposes up to five reserved route-point vector slots
- `0x82101AD0`: loads `wall` / `Xwall` data
- `0x82105D50`: copies 20-byte wall records and clamps counts to 16
- `0x82106478`: expands the wall strip according to each count
- `0x82101C40`: selects enabled entries from `stage_generate.bin`
