# Research

Prototype and cross-build research notes.

- [`PROTOTYPE_NOTES.md`](PROTOTYPE_NOTES.md)
