# Reference tables

CSV tables used by the toolkit and retained for independent review. Runtime-required files include `STAGE_PAIRING.csv`, `STAGE_TILE_SETS.csv`, and `TILE_SET_TEXTURES.csv`.
