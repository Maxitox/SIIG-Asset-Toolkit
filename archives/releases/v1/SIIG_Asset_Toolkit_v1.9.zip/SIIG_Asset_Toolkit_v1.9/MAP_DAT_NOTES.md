# DAT and MAP reverse-engineering notes

## Evidence used

The June 10, 2010 DebugOpt executable retained source-path, assertion and diagnostic strings around the original loaders:

```text
StageGenerator:script is too large(index)
StageGenerator:script is too large(data)
scriptTime is over signed 16bit:%d
stageScriptBlockLoad
stageGenerate2DMap
WARNING:NO MAP BLOCK DATA:%s
```

The relevant loader functions are near `0x8226BC48` (DAT) and `0x8226CB28` (MAP). The stage executor at `0x820FB578` dispatches the decoded opcode in command word 1.

## DAT

```text
01             format version
00 04          big-endian command count = 4
08             first record contains 8 words
00 00          delta frame
00 80          opcode BACKGROUND_GRADATION
...            six arguments
```

The first word is stored as a signed 16-bit delta in the file. During loading, the game replaces it with the accumulated absolute frame. The second word is an unsigned opcode ID. Remaining words are interpreted by the opcode-specific analyzer. `DAT_OPCODE_TABLE.csv` lists all 207 executable table slots and the record lengths observed in the June 10 corpus.

`dat2csv` writes:

- record index and source offset
- word count
- delta and absolute frame
- opcode ID, hexadecimal ID, and executable-derived name
- parameters as signed integers and exact hexadecimal words

## MAP

Every supplied file begins with `MAP\0`, a big-endian layer count of 3, and three independently sized byte grids. A completely empty file is therefore 32 bytes:

```text
4 bytes magic + 4 bytes count + (3 * 8-byte dimension records)
```

The loader reads width and height, then copies exactly `width * height` bytes in row-major order. It does not decompress or reinterpret the bytes while loading.

The recurring values `x`, `x|0x40`, `x|0x80`, and `x|0xC0` suggest that the upper two bits may encode orientation or another transform while the lower six bits identify a tile/object. That pattern is an inference from the corpus and is not yet treated as a confirmed field in the converter.

## Validation

| Build | DAT files | Commands | MAP files | Layers | Failures |
|---|---:|---:|---:|---:|---:|
| May 9 prototype | 1,288 | 22,191 | 394 | 1,182 | 0 |
| May 11 prototype | 1,288 | 23,365 | 394 | 1,182 | 0 |
| June 10 prototype | 1,334 | 25,597 | 394 | 1,182 | 0 |
| Retail Xbox 360 | 1,334 | 25,597 | 394 | 1,182 | 0 |
| **Combined** | **5,244** | **96,750** | **1,576** | **4,728** | **0** |

The 1,334 June/retail DAT resources consist of 1,258 generator fragments and 76 stage scripts. The 394 MAP resources consist of 330 generator blocks and 64 stage maps.

## Remaining work

The layouts are now parsed completely, but semantic work remains:

- parameter names and units for each opcode
- names for a small number of active but unnamed opcode IDs
- exact role of each MAP layer
- exact meaning of every MAP cell value and its upper bits
- reconstruction of complete generated stages from selected MAP/DAT fragments
