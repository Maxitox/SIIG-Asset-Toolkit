# Space Invaders Infinity Gene Asset Toolkit

**Version 1.9 — semantic DAT decoding and offline stage explorer**

This toolkit extracts and converts assets from both console releases of **Space Invaders Infinity Gene**. The Xbox 360 formats were cross-checked against the supplied `default.xex` Ghidra export; the PS3 pipeline was validated against the original game ZIP and decrypted TrueAncestor SDAT payloads.

## What works

- **BBX extraction** (`01 42 42 58` magic)
  - named and unnamed entries
  - nested BBX archives
  - standard `.gz` files whose decompressed content is BBX
  - original filename hierarchy, including `se/` and `bgm/`
  - exact filename-hash verification
  - CSV and JSON manifests
- **GMX → glTF 2.0**
  - indexed triangles and lines with positions, normals, UVs and vertex colors
  - complete `PARE`/`BONE` hierarchy and rigid mesh attachment
  - `SHAD`/`MTRL` material assignment, diffuse/alpha/emissive values and textures
  - automatic conversion of the referenced `ptn_001.dds` to a shared PNG
  - `MOTN`/`ANIM` transform tracks exported as glTF translation/rotation/scale animation
  - external `.gltf.bin` buffers and conversion diagnostics
- **GMX → OBJ**
  - retained as a lightweight static-geometry option
  - positions, normals, UVs, indexed triangles and indexed lines
  - multiple meshes per GMX and per-model JSON metadata
- **TEX → PNG**
  - corrected Xbox 360 tiled `8_8_8_8` decoding
  - PS3 0x80-byte RSX texture wrappers and linear A8R8G8B8 decoding
  - correct Xenos bank/pipe addressing, 8-in-32 endian conversion and channel swizzle
  - original logical dimensions, excluding physical pitch padding
- **System font → PNG atlas**
  - accepts `systemfont.bin`, `systemfont.bin.gz`, or extracted `systemfont.crp`
  - removes the game's bytewise XOR `0xF1` obfuscation
  - exports the underlying 2048×3392 Xbox 360 texture atlas
  - optional decrypted `.tex` output
  - includes the executable-derived 6,732-record glyph mapping/metrics table
  - includes an AngelCode BMFont descriptor for the native Unicode mappings
- **XACT audio → WAV**
  - accepts `sound.bin` directly, extracted `.xwb` banks, or a directory of `.xwb`/`.xsb` pairs
  - parses big-endian Xbox 360 XACT3 wave banks
  - uses companion XSB cue names where available
  - writes RIFF-wrapped XMA2 streams and automatically decodes them to PCM WAV when FFmpeg is installed
  - exports CSV and JSON audio manifests, including loops, sample counts, channels and sample rates
- **Localization databases → CSV/JSON/text**
  - accepts `text.bin`, `message.bin`, or a directory containing both
  - aligns all 542 `text.bin` keys with Japanese, English, French, Italian, German and Spanish
  - parses all 284 `message.bin` arrays / 1,295 strings per language
  - exports raw scripts and readable Unicode-corrected message scripts
- **DAT command streams → CSV/JSON**
  - parses the version/count header and every variable-length 16-bit command record
  - converts delta-frame timing to absolute frames
  - resolves the executable's 207-slot opcode-name table
  - preserves all opcode-specific parameters as signed integers and hexadecimal words
  - adds XEX-backed command categories, summaries, confidence labels and proven parameter names
- **Offline stage explorer**
  - pairs DAT scripts with MAP resources using the executable stage tables rather than filename guesses
  - renders all three MAP layers as raw-byte, lower-six-bit and upper-two-bit views
  - provides a searchable/filterable frame timeline in one self-contained HTML file
  - separately exposes package MAPs that are not referenced by the runtime table
- **MAP byte grids → PNG/JSON**
  - parses all three independent width/height layers
  - writes lossless categorical or grayscale cell visualizations
  - optional numeric CSV grids
- **COL collision masks → PNG**
  - decodes packed one-bit collision images
  - preserves dimensions and header metadata in JSON
- **ANM lookup/configuration tables → CSV/JSON**
  - decodes fixed 28-byte model records
  - preserves the float parameter and flag without speculative labels
- **Ghidra labels**
  - optional script that renames confirmed BBX, GMX, TEX and resource-table functions

Python 3.9 or newer is required. BBX/GMX/TEX/font processing uses only the Python standard library. WAV audio decoding additionally requires FFmpeg on `PATH`; without FFmpeg, the tool still exports playable RIFF-wrapped `.xma` files for vgmstream or another XMA2 decoder.

## One-click full-game extraction

Drag an original game ZIP or folder onto `SIIG_Rip_Game.bat`, or run:

```bat
python siig_toolkit.py rip-game "C:\path\to\game.zip" -o "C:\path\to\SIIG_Ripped" --resume
```

For PS3, place TrueAncestor `*.bin.gz.dat` outputs beside the ZIP or pass `--ps3-sdat-dir`. See `FULL_GAME_RIP.md` for the full workflow and output layout.

## Quick start

### Build the offline stage explorer

Run this after `rip-game`:

```bat
python siig_toolkit.py stageviz "C:\path\to\SIIG_Ripped" -o stage_explorer
```

Open `stage_explorer\SIIG_Stage_Explorer.html`. The explorer is self-contained, makes no network requests, and uses the XEX-derived stage-index table to pair DAT scripts with MAP files. See `STAGE_EXPLORER_NOTES.md`.


### Decode `text.bin` and `message.bin`

Point the command at the directory containing both files:

```bat
python siig_toolkit.py text2csv "C:\path\to\media" -o localization
```

Or decode either archive directly:

```bat
python siig_toolkit.py text2csv "C:\path\to\text.bin" -o localization
python siig_toolkit.py text2csv "C:\path\to\message.bin" -o localization
```

The main combined tables are:

```text
localization\text\text_strings.csv
localization\message\message_strings.csv
```

JSON, raw source, corrected UTF-8 `.nut`, and per-language text exports are also written. See `LOCALIZATION_NOTES.md`.


### Extract all sounds directly from `sound.bin`

With FFmpeg installed and available on `PATH`:

```bat
python siig_toolkit.py xact2wav "C:\path\to\sound.bin" -o audio
```

The command recursively finds the nested XACT banks, uses the XSB cue names, and creates 86 WAV files for the supplied game data:

```text
audio\
├── 0001_7346AAB9_nested\se\SE\
│   ├── 001_SE01.wav
│   ├── 002_SE02.wav
│   └── ...
├── 0055_FD910846_nested\bgm\BGM_007\001_BGM007.wav
├── 0056_D6019B85_nested\bgm\BGM_008\001_BGM008_MIX_C.wav
└── 0057_69117B88_nested\bgm\BGM_XACT_SE33\001_BGM_XACT_SE33.wav
```

Keep the intermediate XMA2 files as well:

```bat
python siig_toolkit.py xact2wav "C:\path\to\sound.bin" -o audio --keep-xma
```

Or convert already extracted banks:

```bat
python siig_toolkit.py xact2wav "C:\path\to\extracted\sound" -o audio
```

If FFmpeg is not installed, the command writes `.xma` files and manifests but skips WAV creation. You can open those `.xma` files in vgmstream-compatible players or install FFmpeg and rerun the command.


Open Command Prompt or PowerShell in the toolkit folder.

### Decode the system font

Directly from the BBX container:

```bat
python siig_toolkit.py font2png "C:\path\to\systemfont.bin" -o systemfont_decoded
```

Or from the extracted resource:

```bat
python siig_toolkit.py font2png "C:\path\to\systemfont.crp" -o systemfont_decoded
```

Also preserve the decrypted texture payload:

```bat
python siig_toolkit.py font2png "C:\path\to\systemfont.bin" -o systemfont_decoded --write-decrypted-tex
```

The output is:

```text
systemfont_decoded\
├── systemfont_atlas.png
├── systemfont_atlas.png.json
└── systemfont_decrypted.tex       (only with --write-decrypted-tex)
```

Place the included `systemfont.fnt` and `systemfont_glyphs.csv` beside `systemfont_atlas.png` when using the mapping data.

### Extract one container

```bat
python siig_toolkit.py extract "C:\path\to\player.bin" -o extracted --convert-gltf --convert-tex
```

### Extract every BBX container in a directory

```bat
python siig_toolkit.py extract "C:\path\to\game_bins" -o extracted --recursive --convert-gltf --convert-gmx --convert-tex
```

`--recursive` is important for `sound.bin`, whose audio banks are inside nested BBX archives. `--convert-tex` also detects and converts `systemfont.crp` after extraction.

### Export extracted GMX files to glTF 2.0

```bat
python siig_toolkit.py gmx2gltf extracted -o gltf
```

The command preserves hierarchy, materials, textures, vertex colors and GMX transform-animation tracks. When texture resources are outside the GMX directory, add a search root:

```bat
python siig_toolkit.py gmx2gltf extracted -o gltf --texture-root "C:\path\to\all_extracted_assets"
```

See `GMX_GLTF_NOTES.md` for the decoded chunk fields and limitations.

### Convert extracted GMX files to static OBJ separately

```bat
python siig_toolkit.py gmx2obj extracted -o obj
```

Add `--flip-v` if your model viewer expects vertically inverted texture coordinates:

```bat
python siig_toolkit.py gmx2obj extracted -o obj --flip-v
```

### Convert extracted TEX files separately

```bat
python siig_toolkit.py tex2png extracted -o png
```

### Decode DAT stage/generator commands

```bat
python siig_toolkit.py dat2csv extracted -o dat_decoded
```

Each CSV row contains the delta frame, accumulated absolute frame, opcode ID/name, and all raw arguments in signed and hexadecimal forms. JSON preserves the complete record structure.

### Visualize MAP layers

```bat
python siig_toolkit.py map2png extracted -o map_decoded
```

Use `--scale 8` for enlarged nearest-neighbor previews, `--grayscale` for literal byte values, or `--csv` to write the numeric grid cells. See `MAP_DAT_NOTES.md`.

### Inspect a file without extracting it

```bat
python siig_toolkit.py scan player.bin
python siig_toolkit.py scan plr_001.gmx
python siig_toolkit.py scan button_A.tex
python siig_toolkit.py scan level1_stage1.dat
python siig_toolkit.py scan a_000.map
python siig_toolkit.py scan systemfont.crp
python siig_toolkit.py scan SE.xwb
```

## System font details

`systemfont.crp` is not a conventional TTF/OTF font. It is a bytewise-XOR-obfuscated TEX texture. The game performs this sequence:

1. Open `/systemfont.bin.gz`.
2. Retrieve `systemfont.crp` from BBX.
3. XOR every byte with `0xF1`.
4. Pass the result to the ordinary texture loader.

After decryption, it is a normal game TEX:

```text
size              2048 × 3392
cell size         32 × 32
atlas grid        64 columns × 106 rows
texture format    Xenos 8_8_8_8 (format 6)
endian mode       8-in-32
layout            Xbox 360 tiled
```

The executable contains 6,732 glyph records beginning at virtual address `0x8200E508`. Each 12-byte record stores:

```text
+0x00  packed UTF-8 character bytes (4 bytes)
+0x04  glyph width in pixels (big-endian u32)
+0x08  left inset inside the 32-pixel cell (big-endian u32)
```

`systemfont_glyphs.csv` exposes these fields, atlas coordinates and known aliases. The game maps ordinary ASCII letters and digits to the fullwidth glyph records and renders them at half scale, so alias behavior is listed separately rather than baked into `systemfont.fnt`.

## Validation performed

- 23 top-level BBX containers
- 2,593 top-level resources
- 2,522 named entries with zero hash mismatches
- 486 GMX files exported to glTF with zero failures
- 1,938 meshes/primitives and 3,298 hierarchy nodes
- 776 materials and 913 transform-animation tracks
- 819,004 vertices and 1,456,924 indices
- zero hierarchy cycles, unreachable nodes, or missing GMX texture references
- 54 TEX files converted with the corrected untile mapping
- system font CRP decrypted and converted to a clean 2048×3392 glyph atlas
- 6,732 glyph records extracted from the executable; 6,730 have native Unicode mappings
- 4 XACT3 wave banks parsed
- 86 XMA2 streams decoded to WAV with zero failures
- 542 `text.bin` records aligned across six languages
- 284 `message.bin` arrays and 1,295 strings per language parsed with matching structure
- all 86 decoded files contain non-silent PCM data
- 5,244 DAT files / 96,750 command records validated across four Xbox 360 builds with zero failures
- 1,576 MAP files / 4,728 layer descriptors validated across four Xbox 360 builds with zero failures

## Current limitations

- GMX animation tracks are exported individually; higher-level gameplay grouping of multiple tracks is not yet known.
- GMX geometry has rigid node attachment but no per-vertex skin-weight arrays were found, so the glTF output is not a conventional skinned character rig.
- Source Xbox shader bytecode is represented with portable unlit glTF materials rather than translated custom shaders.
- COL, ANM, DAT, and MAP structures are decoded and exported; their remaining limitations are semantic labels, not binary extraction. Stage wrapper `.bin` files and platform shader payloads remain preserved rather than converted into editable high-level formats.
- Localization exports are readable/extractable; writing edited text back into BBX is not implemented yet.
- The built-in audio converter currently targets the standard XACT3/XMA2 banks used by this game; vgmstream remains the recommended general-purpose fallback for other XACT variants.
- The system font output is a bitmap atlas plus mapping/metrics, not a reconstructed vector TTF/OTF.
- TEX conversion currently supports Xenos texture format 6 (`8_8_8_8`), which covers every supplied `.tex` file and the font atlas.

## Privacy-safe metadata

Version 1.5.1 no longer writes absolute local filesystem routes into JSON metadata.
Fields such as `source`, `gltf`, and `ffmpeg` contain only filenames or archive-relative names.
The actual `.gltf` files already use relative buffer and texture URIs.

To clean JSON files generated by v1.5 or earlier:

```bat
python siig_toolkit.py sanitize-json "C:\path\to\old_export" --backup
```

This edits JSON metadata in place. With `--backup`, each changed file is preserved as
`filename.json.bak`. Geometry, textures, audio, and other asset files are not modified.

## Collision and standalone animation tables

Convert collision masks:

```bat
python siig_toolkit.py col2png "C:\path\to\extracted" -o collision_png
```

Decode standalone animation lookup tables:

```bat
python siig_toolkit.py anm2csv "C:\path\to\extracted" -o anm_tables
```

These conversions are also run automatically by `rip-game`.

## Timed command streams and map grids

Decode generator and stage-script DAT command streams:

```bat
python siig_toolkit.py dat2csv "C:\path\to\extracted" -o dat_decoded
```

Render all MAP layers and retain exact cell values in JSON:

```bat
python siig_toolkit.py map2png "C:\path\to\extracted" -o map_decoded --scale 8
```

The converters preserve unknown DAT arguments as signed values plus exact hexadecimal words. MAP layer names and cell semantics are intentionally left neutral until executable behavior confirms them.
