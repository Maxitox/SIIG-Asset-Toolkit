# Stage Explorer and DAT semantics

Version 1.9 adds a self-contained offline explorer that joins the stage-script DAT stream with the stage MAP selected by the June 10 Xbox 360 executable.

## Generate the explorer

```bat
python siig_toolkit.py stageviz "C:\path\to\SIIG_Ripped" -o stage_explorer
```

Open `stage_explorer\SIIG_Stage_Explorer.html` in a modern browser. The HTML contains its data and makes no network requests.

## Correct DAT/MAP pairing

The filenames are not directly equivalent. The executable loads a MAP by one-based stage number and a DAT from the adjacent zero-based script table. Version 1.9 ships `STAGE_PAIRING.csv`, reconstructed from the June 10 DebugOpt XEX:

- 75 runtime stage/script slots.
- Two MAP-only slots (`level0_stage0.map` and `level0_stage0EX.map`).
- One trial-script variant: `trial_level5_stage1.dat` uses stage 25's MAP slot.
- Several extra stages intentionally reuse `level1_stage1.map`.
- Twelve normal level-4/5 MAP names are present in the executable table but absent from the package. The loader accepts a missing MAP and continues.
- Fourteen EX MAP files are present in the package but absent from the runtime table; the explorer lists them separately as unreferenced package assets.

## Semantic DAT export

`dat2csv` now adds these columns:

- `category`
- `summary`
- `semantic_fields`

Its JSON output includes typed field records with confidence labels. Labels are conservative:

- **high**: parameter use is direct and clear in the XEX handler.
- **medium**: the handler proves the general role, but one or more detailed gameplay meanings remain uncertain.
- **low**: command framing is known, but the handler does not yet support a stable semantic label.

The bundled `DAT_SEMANTIC_SCHEMAS.csv` summarizes every opcode observed in the June 10 stage scripts, including counts, argument lengths, confidence, and field names.

## Current limitations

The MAP arrays are rendered accurately, but the roles of the three layers remain unconfirmed. The upper two bits are exposed as a separate transform candidate view because recurring `x`, `x|0x40`, `x|0x80`, and `x|0xC0` families strongly suggest flags; the viewer does not claim that they are rotations yet.

The explorer is not yet a full 3D stage renderer. Its purpose is to correlate exact MAP cells with a searchable, frame-based event timeline so later wall-model and generator-ID assignments can be validated without losing raw data.
